package v11.com.ibm.icm.extension.ewf.services.bulkprint;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.util.Date;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import v11.com.ibm.ewf.exception.EWFException;
import v11.com.ibm.ewf.bulkprint.BulkPrintConstants;
import v11.com.ibm.ewf.bulkprint.FNService;
import v11.com.ibm.ewf.config.ComponentConfig;

import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.UserContext;

import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.extension.PluginLogger;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

import filenet.vw.api.VWSession;

/**
 * @author Purna
 *   
 */
public class BulkPrintPluginService extends PluginService {

	final static private Logger logger = Logger.getLogger(BulkPrintPluginService.class);
	
	static private int icnLogLevel = -99999;
	
	final static private Object logLevelUpdateLocker = new Object();
	
	private ObjectStore objectStore = null;
		
	FNService fnService = null;
	
	VWSession vwSession = null;
	
	final private static String[] loggingPackageClassList = new String[] {
		"com.ibm.icm.extension.ewf.services.advice",
		"com.ibm.icm.extension.ewf.services.activity",
		"com.ibm.icm.extension.ewf.services.casepropsfilter",
		"com.ibm.icm.extension.ewf.services.bulkprint",
		"com.ibm.ewf.activity",
		"com.ibm.ewf.cache"
	};
	
	
	public String getId() {
		
		return "EWFBulkPrintPluginService";
	}

	private void setObjectStore(PluginServiceCallbacks callbacks, Subject subject, String objectStoreName) {
		
		UserContext.get().pushSubject(subject);
		
		objectStore = callbacks.getP8ObjectStore(objectStoreName);
	}
	
	private void setVWSession() {
		
		ComponentConfig config = ComponentConfig.getInstance("base");
		
		vwSession = new VWSession();
	    
		vwSession.setBootstrapCEURI(objectStore.getConnection().getURI());
	    
		vwSession.logon(config.get(BulkPrintConstants.CONNECTION_POINT));
	}

	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) {
		
		callbacks.getLogger().logEntry(this, "execute", request);
		
		matchLogLevel(callbacks.getLogger());
		
		JSONObject jsonResult = new JSONObject();
		
		PrintWriter printWriter  = null;
		
		Date startTime = new Date();
		
		try {
			
			logger.info("inside EWFBulkPrintPluginService execute");
			
			System.out.println("inside EWFBulkPrintPluginService execute request started at " + startTime);
			
			printWriter = response.getWriter();
			
			fnService = new FNService();
			
			String action = request.getParameter(BulkPrintConstants.ACTION);
				
			logger.info("inside the plugin service action --> " + action);
			
			if( action.equalsIgnoreCase(BulkPrintConstants.GET_DOCUMENT_IDS)) {
					
				jsonResult = getDocIds(callbacks, request, jsonResult);
					
			} else if( action.equalsIgnoreCase(BulkPrintConstants.DISPATCH_PRINT_CASES)) {
				
				jsonResult = dispatch(callbacks, request, jsonResult);
				
			} else if( action.equalsIgnoreCase(BulkPrintConstants.UNLOCK_CASE)) {
				
				unlock(callbacks, request, jsonResult);
				
			} else if( action.equalsIgnoreCase(BulkPrintConstants.DISPATCH_REPRINT_CASES)) {
				
				unlockWorkItems(callbacks, request, jsonResult, true);
				
			} else if(action.equalsIgnoreCase(BulkPrintConstants.UNLOCK_WORKITEMS)) {
				
				unlockWorkItems(callbacks, request, jsonResult, false);
				
			} else if(action.equalsIgnoreCase(BulkPrintConstants.CONVERT_USERID_TO_INT)) {
				
				convertUserIdToInt(callbacks, request, jsonResult);
				
			} else {
				
				logger.info("required parameters are missing or empty : " + action);
				
				throw new Exception("Some required parameters are missing action:" + action);
			}
			
		} catch(IOException objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} catch(Exception objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} finally {
			
		}
		
		Date endTime = new Date();
		
		System.out.println("EWFBulkPrintPluginService request Completed at: " + endTime + " Time taken (in MilliSec): " + (endTime.getTime() - startTime.getTime()));
		
		printWriter.write(jsonResult.toString());
		
		printWriter.close();
		
	}
	
	private JSONObject dispatch(PluginServiceCallbacks callbacks, HttpServletRequest request, JSONObject jsonResult) {
		
		JSONObject jObject = null;
		
		String wobNoJson = null;
		
		String wobNo = null;
		
		String objectStoreName = null;
		
		String queueName = null;
		
		String currentUserId = null;
		
		String solutionPrefix = null;
		
		Subject subject = null;
		
		try {
			
			wobNoJson = getRequestBody(request.getInputStream());
			
			logger.info("wobNoJson:: " + wobNoJson);
			
			jObject = JSONObject.parse(wobNoJson);
			
			wobNo = jObject.get(BulkPrintConstants.WORKOBJNUMBER).toString();
	
			objectStoreName = request.getParameter(BulkPrintConstants.OBJECTSTORE);
			
			queueName = request.getParameter(BulkPrintConstants.QUEUE_NAME);
			
			solutionPrefix = request.getParameter(BulkPrintConstants.SOLUTION_PREFIX);
			
			subject = callbacks.getP8Subject(objectStoreName);
			
			currentUserId = request.getParameter(BulkPrintConstants.USER_ID);
			
			logger.info("wobNo: " + wobNo + " queueName: " + queueName + " objectStoreName: " + objectStoreName + " currentUserId: " + currentUserId);
			
			if(null != objectStoreName && !objectStoreName.equals("") && null != wobNo && !wobNo.equals("") && subject != null) {
				
				setObjectStore(callbacks, subject, objectStoreName);
				
				setVWSession();
				
				String[] arrWobNumber = getWobNumberArray(JSONArray.parse(wobNo));
                
                logger.info("arrWobNumber:: " + arrWobNumber.toString() + arrWobNumber.length);
				
                jsonResult = fnService.dispatchBulkPrintCases(arrWobNumber, queueName, objectStore, vwSession, currentUserId);
					
				logger.info("Case Dispatched..");
				
				jsonResult.put("response", "SUCCESS");
			}
			
		} catch(Exception objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} finally {
			
			UserContext.get().popSubject();
			
			objectStoreName = null;
			
			queueName = null;
			
			subject = null;
		}
		
		return jsonResult;
	}
	
	private void unlock(PluginServiceCallbacks callbacks, HttpServletRequest request, JSONObject jsonResult) {
		
		JSONObject jObject = null;
		
		String wobNoJson = null;
		
		String wobNo = null;
		
		String objectStoreName = null;
		
		String queueName = null;
		
		String currentUserId = null;
		
		Subject subject = null;
		
		try {
			
			wobNoJson = getRequestBody(request.getInputStream());
			
			jObject = JSONObject.parse(wobNoJson);
			
			wobNo = jObject.get(BulkPrintConstants.WORKOBJNUMBER).toString();
	
			objectStoreName = request.getParameter(BulkPrintConstants.OBJECTSTORE);
			
			queueName = request.getParameter(BulkPrintConstants.QUEUE_NAME);
			
			currentUserId = request.getParameter(BulkPrintConstants.USER_ID);
			
			subject = callbacks.getP8Subject(objectStoreName);
			
			logger.info("wobNo: " + wobNo + " queueName: " + queueName + " objectStoreName: " + objectStoreName + " currentUserId: " + currentUserId);
			
			if(null != objectStoreName && !objectStoreName.equals("") && null != wobNo && !wobNo.equals("") && subject != null) {
				
				setObjectStore(callbacks, subject, objectStoreName);
				
				setVWSession();
				
				String[] arrWobNumber = getWobNumberArray(JSONArray.parse(wobNo));
								
				JSONArray unlockFailedCases = fnService.unlockAllCaseItems(arrWobNumber, queueName, vwSession, objectStore, currentUserId);
					
				jsonResult.put("response", "SUCCESS");
				
				if(null != unlockFailedCases && unlockFailedCases.size() > 0) {
					
					jsonResult.put("FailedCases", unlockFailedCases);
				}
					
			}
			
		} catch(Exception objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} finally {
			
			UserContext.get().popSubject();
			
			objectStoreName = null;
			
			queueName = null;
			
			subject = null;
		}
	}
	
	private void unlockWorkItems(PluginServiceCallbacks callbacks, HttpServletRequest request, JSONObject jsonResult, boolean isBulkReprint) {
		
		JSONObject jObject = null;
		
		String wobNoJson = null;
		
		String wobNo = null;
		
		String objectStoreName = null;
		
		String queueName = null;
		
		String currentUserId = null;
		
		Subject subject = null;
		
		try {
			
			wobNoJson = getRequestBody(request.getInputStream());
			
			jObject = JSONObject.parse(wobNoJson);
			
			wobNo = jObject.get(BulkPrintConstants.WORKOBJNUMBER).toString();
	
			objectStoreName = request.getParameter(BulkPrintConstants.OBJECTSTORE);
			
			queueName = request.getParameter(BulkPrintConstants.QUEUE_NAME);
			
			subject = callbacks.getP8Subject(objectStoreName);
			
			currentUserId = request.getParameter(BulkPrintConstants.USER_ID);
			
			logger.info("wobNo: " + wobNo + " queueName: " + queueName + " objectStoreName: " + objectStoreName + " currentUserId: " + currentUserId);
			
			if(null != objectStoreName && !objectStoreName.equals("") && null != wobNo && !wobNo.equals("") && subject != null) {
				
				setObjectStore(callbacks, subject, objectStoreName);
				
				setVWSession();
				
				String[] arrWobNumber = getWobNumberArray(JSONArray.parse(wobNo));
				
				fnService.unlockWorkItems(objectStore, arrWobNumber, queueName, vwSession, isBulkReprint);
					
				logger.info("Workitems Unlocked..");
				
				jsonResult.put("response", "SUCCESS");
			}
			
		} catch (IOException objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} catch(Exception objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} finally {
			
			UserContext.get().popSubject();
			
			objectStoreName = null;
			
			queueName = null;
			
			subject = null;
		}
	}
	
	private JSONObject getDocIds(PluginServiceCallbacks callbacks, HttpServletRequest request, JSONObject jsonResult) {
		
		String objectStoreName = null;
		
		String queueName = null;
		
		String userId = null;
		
		try {
			
			String requestBody = getRequestBody(request.getInputStream());
			
			String wobNosJSONArr = JSONObject.parse(requestBody).get(BulkPrintConstants.WORKOBJNUMBER).toString();
	
			objectStoreName = request.getParameter(BulkPrintConstants.OBJECTSTORE);
			
			queueName = request.getParameter(BulkPrintConstants.QUEUE_NAME);
			
			userId = request.getParameter(BulkPrintConstants.USER_ID);
			
			String isBulkReprint = request.getParameter(BulkPrintConstants.IS_BULK_REPRINT);
			
			boolean isReprint = false;
			
			if(null != isBulkReprint && !isBulkReprint.isEmpty()) {
			
				isReprint = Boolean.parseBoolean(isBulkReprint);
			}
			
			Subject subject = callbacks.getP8Subject(objectStoreName);
			
			logger.info("wobNo: " + wobNosJSONArr + " queueName: " + queueName + " objectStoreName: " + objectStoreName + " currentUserId: " + userId);
			
			if(null != objectStoreName && !objectStoreName.equals("") && null != wobNosJSONArr && !wobNosJSONArr.equals("") && null != subject) {
				
				setObjectStore(callbacks, subject, objectStoreName);
				
				setVWSession();
				
				String[] arrWobNumber = getWobNumberArray(wobNosJSONArr);
                
                logger.info("arrWobNumber:: " + arrWobNumber.toString() + " Length: " + arrWobNumber.length);
			               
                jsonResult = fnService.getDocumentIds(arrWobNumber, queueName, objectStore, vwSession, userId, isReprint);
			}
			
		} catch (IOException objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} catch(Exception objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} finally {
			
			UserContext.get().popSubject();
			
			objectStoreName = null;
			
			queueName = null;
		}
		
		return jsonResult;
	}

	private JSONObject convertUserIdToInt(PluginServiceCallbacks callbacks, HttpServletRequest request, JSONObject jsonResult) {
		
		String objectStoreName = null;
		
		String userId = null;
		
		try {
			
			objectStoreName = request.getParameter(BulkPrintConstants.OBJECTSTORE);
			
			userId = request.getParameter(BulkPrintConstants.USER_ID);
			
			Subject subject = callbacks.getP8Subject(objectStoreName);
			
			if(null != objectStoreName && !objectStoreName.equals("") && null != subject) {
				
				setObjectStore(callbacks, subject, objectStoreName);
				
				setVWSession();
				
				int intUserid = vwSession.convertUserNameToId(userId);           

				jsonResult.put("intUserId", intUserid);
				
				return jsonResult;
			}
			
		} catch(Exception objException) {
			
			objException.printStackTrace();
			
			jsonResult.put("response", "FAILED");
			
			jsonResult.put("Failure", objException.getMessage());
			
		} finally {
			
			UserContext.get().popSubject();
			
			objectStoreName = null;
		}
		
		return jsonResult;
	}
	
	public String[] getWobNumberArray(JSONArray arrWobObjects) throws IOException {
		
		String[] arrWobNumber = new String[arrWobObjects.size()];

        for(int index = 0; index < arrWobObjects.size(); index++) {
        	
        	arrWobNumber[index] = (String) arrWobObjects.get(index);
        }
        
        return arrWobNumber;
	}

	public String[] getWobNumberArray(String wobNosJSONArr) throws IOException {
		
		JSONArray arrWobObjects = JSONArray.parse(wobNosJSONArr);
		
		String[] arrWobNumber = new String[arrWobObjects.size()];

        for(int index = 0; index < arrWobObjects.size(); index++) {

        	arrWobNumber[index] = (String) arrWobObjects.get(index);
        }
        
        return arrWobNumber;
	}
	
	public String getRequestBody(InputStream inStream) throws EWFException {
		
		String s = null;
		
		try {
		    
			BufferedReader reader = new BufferedReader(new InputStreamReader(inStream, "UTF-8"));
	
		    StringBuffer buf = new StringBuffer();
		    
		    char[] data = new char[8196];
		    
		    int amtRead = 0;
		    
		    amtRead = reader.read(data, 0, 8196);
		    
		    while (amtRead != -1) {
		      
		    	buf.append(data, 0, amtRead);
		      
		    	amtRead = reader.read(data, 0, 8196);
		    }
		    
		    s = buf.toString().trim();
		    
		} catch(IOException e) {
			
			throw new EWFException("IOException occurred in getRequestBody: " + e.getStackTrace(), e);
			
		} catch(Exception e) {
			
			throw new EWFException("Exception occurred in getRequestBody: " + e.getStackTrace(), e);
		}
		
	    return s;
	}
	
	private static void matchLogLevel(PluginLogger pluginLogger) {
		
		int newIcnLevel = pluginLogger.getLogLevel();
		
		if (newIcnLevel == icnLogLevel) {
			
			return;
		}
		
		synchronized (logLevelUpdateLocker) {
			
			if (newIcnLevel == icnLogLevel) {
				
				return;
			}
			
			Level log4jLevel = Level.ERROR;
			
			switch (newIcnLevel) {
			
				case PluginLogger.LOG_DEBUG:
				
				case PluginLogger.LOG_DEV:
				
				case PluginLogger.LOG_ENTRY:
				
				case PluginLogger.LOG_EXIT:
					
					log4jLevel = Level.DEBUG;
					
					break;
			
				case PluginLogger.LOG_INFO:
			
					log4jLevel = Level.INFO;
				
					break;
			
				case PluginLogger.LOG_WARNING:
				
					log4jLevel = Level.WARN;
				
					break;
			
				case PluginLogger.LOG_ERROR:
				
					log4jLevel = Level.ERROR;
				
					break;
			
				default : 
				
					log4jLevel = Level.ERROR;
				
					break;
			}
			
			setLogLevelForLoggers(loggingPackageClassList, log4jLevel);
			
			icnLogLevel = newIcnLevel;
		}
	}

	private static void setLogLevelForLoggers(String[] loggerNameList, Level level) {
	
		for (String loggerName : loggerNameList) {
			
			if (loggerName == null || loggerName.isEmpty()) {
				
				continue;
			}
			
			Logger curLogger = Logger.getLogger(loggerName);
			
			if (!level.equals(curLogger.getLevel())) {
				
				curLogger.setLevel(level);
				
			}
		}
	}
}
