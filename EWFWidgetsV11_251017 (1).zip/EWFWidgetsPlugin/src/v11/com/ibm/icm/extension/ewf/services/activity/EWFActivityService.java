package v11.com.ibm.icm.extension.ewf.services.activity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.UserContext;
import com.ibm.ecm.extension.PluginLogger;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import v11.com.ibm.ewf.activity.EWFActivity;
import v11.com.ibm.ewf.activity.EWFActivityJsonConvertor;
import v11.com.ibm.ewf.activity.EWFActivityOp;
import v11.com.ibm.ewf.activity.EWFActivityUtil;
import v11.com.ibm.ewf.activity.EWFSuggestionListHelper;
import v11.com.ibm.ewf.cache.EWFCacheUtil;
import v11.com.ibm.ewf.config.ComponentConfig;
import v11.com.ibm.ewf.config.Credential;
import v11.com.ibm.ewf.config.CredentialStore;
import v11.com.ibm.icm.extension.ewf.CommonUtils;
import v11.com.ibm.icm.extension.ewf.actions.activity.WASDynaCacheProvider;
//import com.ibm.icm.extension.ewf.services.advice.EWFAdviceService;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class EWFActivityService extends PluginService {
	
	final static private Logger logger = Logger.getLogger(EWFActivityService.class);
	static private int icnLogLevel = -99999;
	final static private Object logLevelUpdateLocker = new Object();
	
	private static final String URLPARM_REPOSITORY_ID = "repositoryId";
	private static final String URLPARM_CASE_ID = "caseId";
	private static final String URLPARM_METHOD = "method";
	private static final String URLPARM_INCLUDESTATUS = "includeStatus";
	private static final String CONFIG_DISABLE_CACHE = "service.cache.disabled";
	
	private static final String PREFIX_METHOD = "method_";
	private static final String MIMETYPE_JSON = "application/json";
	
	final private static String[] loggingPackageClassList = new String[] {
		"v11.com.ibm.icm.extension.ewf.services.advice",
		"v11.com.ibm.icm.extension.ewf.services.activity",
		"v11.com.ibm.ewf.activity",
		"v11.com.ibm.ewf.cache"
	};
	
	final private static String[] docx4jPackages = new String[] {
		"org.docx4j",
		"o.d",
		"com.topologi"
	};
	
	private static final HashMap<String, Method> methodMap = new HashMap<String, Method> ();
	
	public EWFActivityService() {
		;
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String methodName = "execute";
		callbacks.getLogger().logEntry(this, methodName, request);
		matchLogLevel(callbacks.getLogger());
		initCache(this, callbacks);
		//EWFAdviceService.initAdviceTemplate(this, callbacks);
		if (!EWFSuggestionListHelper.hasComponentConfig()) {
			callbacks.getLogger().logDebug(this, methodName, request, "Put component configuration to suggestion list helper.");
			ComponentConfig config = CommonUtils.getComponentConfig();
			EWFSuggestionListHelper.putComponentConfig(config);
			populateIcmSystemUser(config);
		}
		
		String requestMethod = request.getParameter(URLPARM_METHOD);
		if (requestMethod == null || requestMethod.trim().isEmpty()) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			callbacks.getLogger().logError(this, methodName, request, "The required URL parameter 'method' is not provided.");
			//genErrorJson(999, "The required URL parameter 'method' is not provided.").serialize(response.getWriter());
			return;
		}
		
		requestMethod = PREFIX_METHOD + requestMethod;
		
		Method methodToInvoke = methodMap.get(requestMethod);
		if (methodToInvoke == null) {
			try {
				methodToInvoke = this.getClass().getMethod(requestMethod, PluginServiceCallbacks.class, HttpServletRequest.class, HttpServletResponse.class);
			} catch (NoSuchMethodException e) {
				response.setContentType(MIMETYPE_JSON);
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				//genErrorJson(999, "The method " + requestMethod + " is not found.").serialize(response.getWriter());
				callbacks.getLogger().logError(this, methodName, request, "The method " + requestMethod + " is not found.");
			} catch (SecurityException e) {
				response.setContentType(MIMETYPE_JSON);
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				//genErrorJson(999, "The method " + requestMethod + " is not accessible.").serialize(response.getWriter());
				callbacks.getLogger().logError(this, methodName, request, "The method " + requestMethod + " is not accessible.");
			}
			if (methodToInvoke == null) {
				callbacks.getLogger().logError(this, methodName, request, "Error happened in fetching the executable method. Terminate the request.");
				return;
			}
			synchronized (methodMap) {
				if (!methodMap.containsKey(requestMethod)) {
					methodMap.put(requestMethod, methodToInvoke);
				}
			}
		}

		callbacks.getLogger().logDebug(this, methodName, request, "Invoking method " + requestMethod + " ...");
		long invokeStart = System.currentTimeMillis();
		try {
			methodToInvoke.invoke(this, callbacks, request, response);
		} catch (InvocationTargetException ite) {
			Throwable t = ite.getCause();
			if (t == null) {
				t = ite;
			}
			logger.error("Error occurred in invoking method " + requestMethod, t);
			callbacks.getLogger().logError(this, methodName, "Error occurred in invoking method " + requestMethod, t);
			if (t instanceof Exception) {
				throw (Exception) t;
			} else if (t instanceof RuntimeException) {
				throw (RuntimeException) t;
			} else {
				throw ite;
			}
		}
		long invokeEnd = System.currentTimeMillis();
		callbacks.getLogger().logDebug(this, methodName, request, "Method " + requestMethod + " completed. Time elapsed : " + (invokeEnd - invokeStart) + " msec");
		
		callbacks.getLogger().logExit(this, methodName, request);
	}

	@Override
	public String getId() {
		return "EWFActivityService";
	}
	
	public void method_listActivity(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_listActivity";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);
		
		String repositoryId = request.getParameter("repositoryId");
		
		Subject subject = callbacks.getP8Subject(repositoryId);
		String caseId = request.getParameter("caseId");
		String caseType = request.getParameter("caseType");
		String statusFilters = request.getParameter("includeStatus");
		
		logger.debug("method_listActivity: repositoryId: " + repositoryId + ", caseId: " + caseId + ", caseType: " + caseType + ", statusFilters: " + statusFilters);
		
		HashSet<String> statusFilterSet = null;
		
		if (statusFilters != null && !statusFilters.trim().isEmpty()) {
			statusFilterSet = new HashSet<String>();
			if (statusFilters.contains(",")) {
				String[] filterArray = statusFilters.split(",");
				for (String statusFilter : filterArray) {
					statusFilter = statusFilter.replaceAll("\\W", "").toUpperCase();
					statusFilterSet.add(statusFilter);
				}
			} else {
				statusFilters = statusFilters.replaceAll("\\W", "").toUpperCase();
				statusFilterSet.add(statusFilters);
			}
		}
		
		if (subject == null) {
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}

		UserContext.get().pushSubject(subject);
		ObjectStore os = callbacks.getP8ObjectStore(repositoryId);
		logger.debug("method_listActivity: connected to CE.");
		JSONObject jsonRoot = null;
		try {
			List<EWFActivity> activityList = EWFActivityOp.listActivityInCase(os, caseType, caseId, statusFilterSet);
			jsonRoot = EWFActivityJsonConvertor.activityListToJson(os, activityList, caseType, 0);
		} finally {
			UserContext.get().popSubject();
		}
		response.setContentType(MIMETYPE_JSON);
		jsonRoot.serialize(response.getWriter());
		
		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	
	public void method_getActivity(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_getActivity";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);

		String caseId = request.getParameter("caseId");
		String activityId = request.getParameter("activityId");
		String repositoryId = request.getParameter("repositoryId");
		
		logger.debug("method_listActivity: repositoryId: " + repositoryId + ", caseId: " + caseId + ", activityId: " + activityId);
		
		Subject subject = callbacks.getP8Subject(repositoryId);
		
		if (subject == null) {
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}
		
		UserContext.get().pushSubject(subject);
		ObjectStore os = callbacks.getP8ObjectStore(repositoryId);
		//ObjectStore os = Factory.ObjectStore.fetchInstance(domain, repositoryId, null);
		logger.debug("method_getActivity: connected to CE.");
		JSONObject jsonRoot = null;
		try {
			EWFActivity activity = EWFActivityOp.getActivity(os, activityId, caseId);
			jsonRoot = (JSONObject)EWFActivityJsonConvertor.activityToJson(os, activity, EWFActivityUtil.JCFLAG_NORMAL_STYLE);
		} finally {
			UserContext.get().popSubject();
		}
		
		response.setContentType(MIMETYPE_JSON);
		jsonRoot.serialize(response.getWriter());
		
		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	
	public void method_saveActivity(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_saveActivity";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);

		String repositoryId = request.getParameter("repositoryId");
		
		String postJson = getContentStringFromRequest(request);
		callbacks.getLogger().logDebug(this, methodName, request, "postJson : " + postJson);
		JSONObject jsonRoot = JSONObject.parse(postJson);
		
		Subject subject = callbacks.getP8Subject(repositoryId);
		
		if (subject == null) {
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}
		
		UserContext.get().pushSubject(subject);
		ObjectStore os = callbacks.getP8ObjectStore(repositoryId);
		logger.debug("method_saveActivity: connected to CE.");
		
		JSONArray jsonActivityPropArray = null;
		boolean multipleActivities = false;
		try {
			ArrayList<EWFActivity> activityList = new ArrayList<EWFActivity>();
			if (jsonRoot.get(EWFActivityUtil.JSONKEY_ACTIVITY_LIST) != null) {
				multipleActivities = true;
				JSONArray jsonActivityList = (JSONArray)jsonRoot.get(EWFActivityUtil.JSONKEY_ACTIVITY_LIST);
				for (int i = 0; i < jsonActivityList.size(); i++) {
					JSONObject jsonActivity = (JSONObject)jsonActivityList.get(i);
					EWFActivity activity = EWFActivityJsonConvertor.activityFromJson(os, jsonActivity, 0);
					activityList.add(activity);
				}
			} else {
				EWFActivity activity = EWFActivityJsonConvertor.activityFromJson(os, jsonRoot, 0);
				activityList.add(activity);
			}
			if (activityList.size() > 0) {
				String caseId = activityList.get(0).getCaseId();
				EWFActivityOp.saveActivityToCe(os, activityList, EWFActivityOp.fetchCaseFolderFromCe(os, caseId));
				
				if (multipleActivities) {
					jsonActivityPropArray = new JSONArray();
					for (EWFActivity activity : activityList) {
						JSONArray subArray = (JSONArray)EWFActivityJsonConvertor.activityToJson(os, activity, EWFActivityUtil.JCFLAG_PROP_ONLY_STYLE);
						jsonActivityPropArray.add(subArray);
					}
				} else {
					jsonActivityPropArray = (JSONArray)EWFActivityJsonConvertor.activityToJson(os, activityList.get(0), EWFActivityUtil.JCFLAG_PROP_ONLY_STYLE);
				}
			}
		} finally {
			UserContext.get().popSubject();
		}
		
		response.setContentType(MIMETYPE_JSON);
		jsonRoot = genErrorJson(0, "Operation completed successfully.");
		jsonRoot.put(EWFActivityUtil.JSONKEY_PROP_ARRAY, jsonActivityPropArray);
		
		jsonRoot.serialize(response.getWriter());
		
		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	
	public void method_createActivity(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_createActivity";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);

		String repositoryId = request.getParameter("repositoryId");
		
		String postJson = getContentStringFromRequest(request);
		callbacks.getLogger().logDebug(this, methodName, request, "postJson : " + postJson);
		JSONObject jsonRoot = JSONObject.parse(postJson);
		
		Subject subject = callbacks.getP8Subject(repositoryId);
		
		if (subject == null) {
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}
		
		UserContext.get().pushSubject(subject);
		ObjectStore os = callbacks.getP8ObjectStore(repositoryId);
		logger.debug("method_createActivity: connected to CE.");
		
		JSONArray jsonActivityPropArray = null;
		boolean multipleActivities = false;
		try {
			ArrayList<EWFActivity> activityList = new ArrayList<EWFActivity>();
			if (jsonRoot.get(EWFActivityUtil.JSONKEY_ACTIVITY_LIST) != null) {
				multipleActivities = true;
				JSONArray jsonActivityList = (JSONArray)jsonRoot.get(EWFActivityUtil.JSONKEY_ACTIVITY_LIST);
				for (int i = 0; i < jsonActivityList.size(); i++) {
					JSONObject jsonActivity = (JSONObject)jsonActivityList.get(i);
					EWFActivity activity = EWFActivityJsonConvertor.activityFromJson(os, jsonActivity, 0);
					activityList.add(activity);
				}
			} else {
				EWFActivity activity = EWFActivityJsonConvertor.activityFromJson(os, jsonRoot, 0);
				activityList.add(activity);
			}
			if (activityList.size() > 0) {
				String caseId = activityList.get(0).getCaseId();
				EWFActivityOp.createActivityCaseObjInCe(os, activityList, EWFActivityOp.fetchCaseFolderFromCe(os, caseId));
				
				if (multipleActivities) {
					jsonActivityPropArray = new JSONArray();
					for (EWFActivity activity : activityList) {
						JSONArray subArray = (JSONArray)EWFActivityJsonConvertor.activityToJson(os, activity, EWFActivityUtil.JCFLAG_PROP_ONLY_STYLE);
						jsonActivityPropArray.add(subArray);
					}
				} else {
					jsonActivityPropArray = (JSONArray)EWFActivityJsonConvertor.activityToJson(os, activityList.get(0), EWFActivityUtil.JCFLAG_PROP_ONLY_STYLE);
				}
			}
		} finally {
			UserContext.get().popSubject();
		}
		
		response.setContentType(MIMETYPE_JSON);
		jsonRoot = genErrorJson(0, "Operation completed successfully.");
		jsonRoot.put(EWFActivityUtil.JSONKEY_PROP_ARRAY, jsonActivityPropArray);
		
		jsonRoot.serialize(response.getWriter());
		
		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	
	private static JSONObject genErrorJson(int errCode, String errMsg) {
		JSONObject jsonResp = new JSONObject();
		JSONObject jsonMsg = new JSONObject();
		
		jsonResp.put("messages", jsonMsg);
		jsonMsg.put("adminResponse", null);
		jsonMsg.put("moreInformation", null);
		jsonMsg.put("explanation", null);
		jsonMsg.put("number", Integer.toString(errCode));
		jsonMsg.put("userResponse", null);
		jsonMsg.put("text", errMsg);
		return jsonResp;
	}

	public static String getContentStringFromRequest(HttpServletRequest req) throws IOException {
		String line = null;
		StringBuffer strBuff = new StringBuffer();
		BufferedReader reader = null;
		InputStream inputStream = null;
		
		try {
			inputStream = req.getInputStream();
			if (inputStream != null) {
				reader = new BufferedReader(new InputStreamReader(inputStream));
				while ((line = reader.readLine()) != null) {
					strBuff.append(line).append("\n");
				}
			}
		} finally {
			if (inputStream != null) {
				try {inputStream.close();} catch (IOException e) {;}
				inputStream = null;
			}
			if (reader != null) {
				try {reader.close();} catch (IOException e) {;}
				reader = null;
			}
		}
		
		String str = strBuff.toString();
		return str;
	}
	
	private static void matchLogLevel(PluginLogger pluginLogger) {
		int newIcnLevel = pluginLogger.getLogLevel();
		if (newIcnLevel == icnLogLevel) {
			return;
		}
		synchronized (logLevelUpdateLocker) {
			if (newIcnLevel == icnLogLevel) {
				return;
			}
			Level log4jLevel = Level.ERROR;
			switch (newIcnLevel) {
			case PluginLogger.LOG_DEBUG:
			case PluginLogger.LOG_DEV:
			case PluginLogger.LOG_ENTRY:
			case PluginLogger.LOG_EXIT:
				log4jLevel = Level.DEBUG;
				break;
			case PluginLogger.LOG_INFO:
			//case PluginLogger.LOG_PERF:
				log4jLevel = Level.INFO;
				break;
			case PluginLogger.LOG_WARNING:
				log4jLevel = Level.WARN;
				break;
			case PluginLogger.LOG_ERROR:
				log4jLevel = Level.ERROR;
				break;
			default : 
				log4jLevel = Level.ERROR;
				break;
			}
			setLogLevelForLoggers(loggingPackageClassList, log4jLevel);
			setLogLevelForLoggers(docx4jPackages, Level.ERROR);
			icnLogLevel = newIcnLevel;
		}
	}
	
	private static void setLogLevelForLoggers(String[] loggerNameList, Level level) {
		for (String loggerName : loggerNameList) {
			if (loggerName == null || loggerName.isEmpty()) {
				continue;
			}
			Logger curLogger = Logger.getLogger(loggerName);
			if (!level.equals(curLogger.getLevel())) {
				curLogger.setLevel(level);
				/*
				Enumeration appenderEnum = curLogger.getAllAppenders();
				Appender appender = null;
				while (appenderEnum.hasMoreElements()) {
					appender = (Appender) appenderEnum.nextElement();
					if (appender instanceof org.apache.log4j.ConsoleAppender) {
						break;
					}
				}
				if (appender == null) {
					appender = new org.apache.log4j.ConsoleAppender();
					curLogger.addAppender(appender);
				}
				curLogger.isAttached(appender)
				appender.
				 */
			}
		}
	}
	
	public void method_test(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
//		// create the in-memory activity object. You will need an object store, the activit type, and the case folder ID.
//		EWFActivity activity = EWFActivity.createActivity(os, "COPC_DetermineAnnualIncome", "{xxx}");
//		
//		// set property values if needed
//		activity.setPropValue("COPC_AnnualGrossIncome", 120000);
//		
//		// set status
//		activity.setStatus("Pend-Repair");
//		
//		// set comment if needed
//		activity.setComment("Create the annual income check activity");
//		
//		// save it to CE. If you don't have csae folder on hand, the method will retrieve it for you.
//		EWFActivityOp.saveActivityToCe(os, activity);
//		// if you have case folder object on hand, use the following method instead to avoid unnecessary retrieval of case folder. 
//		//EWFActivityOp.saveActivityToCe(os, activity, caseFolder);
	}
	
	public void method_clearCache(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.debug("Clearing cache ... ");
		EWFCacheUtil.clear();
		response.setContentType("text/plain");
		response.getWriter().println("Cache cleared.");
		response.getWriter().flush();
		logger.debug("Cache cleared.");
	}
	
	private static String expandWasVariable(String wasVariableName) {  
		com.ibm.websphere.management.AdminService as = com.ibm.websphere.management.AdminServiceFactory.getAdminService();  
		String server = as.getProcessName();  
		String expandResult = null;
		try {
			java.util.Set result;
			result = as.queryNames(new javax.management.ObjectName("*:*,type=AdminOperations,process=" + server), null);
			expandResult = (String)as.invoke((javax.management.ObjectName)result.iterator().next(),"expandVariable",new Object[] {"${" + wasVariableName + "}"}, new String[] {"java.lang.String"});
		} catch (Throwable e) {
			;
		}
		return expandResult;
	}
	
	public static void initCache(PluginService pluginService, PluginServiceCallbacks callbacks) {
		if (EWFCacheUtil.isCacheInitalized()) {
			return;
		} 
		String toDisableCache = null;
		ComponentConfig config = CommonUtils.getComponentConfig();
		toDisableCache = config.get(CONFIG_DISABLE_CACHE, "FALSE");
		if ("TRUE".equalsIgnoreCase(toDisableCache)) {
			logger.debug("Cache is disabled.");
			callbacks.getLogger().logDebug(pluginService, "initCache", "Cache is disabled.");
			return;
		}
		if (WASDynaCacheProvider.isDynaCacheAvailable()) {
			logger.debug("Initialize the WAS dyanmic cache.");
			callbacks.getLogger().logDebug(pluginService, "initCache", "Initialize the WAS dyanmic cache.");
			EWFCacheUtil.initCache(WASDynaCacheProvider.class);
		} else {
			callbacks.getLogger().logDebug(pluginService, "initCache", "Initialize the default cache.");
			logger.debug("Initialize the default cache.");
			EWFCacheUtil.initCache();
		}
	}
	
	private static void populateIcmSystemUser(ComponentConfig config) {
		CredentialStore cs = config.getCredentialStore();
		if (cs == null) {
			return;
		}
		Credential icmCredential = cs.get(EWFActivityUtil.CONFIG_ICM_CREDENTIAL_KEY);
		EWFActivityUtil.icmSystemUserId = icmCredential.getUsername();
	}
}
