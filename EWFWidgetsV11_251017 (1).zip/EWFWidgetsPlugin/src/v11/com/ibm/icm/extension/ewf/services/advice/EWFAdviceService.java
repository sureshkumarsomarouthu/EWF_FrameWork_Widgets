package v11.com.ibm.icm.extension.ewf.services.advice;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Annotation;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.CustomObject;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.IndependentlyPersistableObject;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.util.UserContext;
import com.ibm.ecm.extension.PluginLogger;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import v11.com.ibm.ewf.activity.EWFActivityOp;
import v11.com.ibm.ewf.activity.EWFActivityUtil;
import v11.com.ibm.ewf.advice.EWFAdviceTemplateManager;
import v11.com.ibm.ewf.advice.Template;
import v11.com.ibm.ewf.config.ComponentConfig;
import v11.com.ibm.icm.extension.ewf.CommonUtils;
import v11.com.ibm.icm.extension.ewf.services.activity.EWFActivityService;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import java.util.Set;
import java.util.Iterator;

public class EWFAdviceService extends PluginService {

	final static private Logger logger = Logger.getLogger(EWFAdviceService.class);
	static private int icnLogLevel = -99999;
	final static private Object logLevelUpdateLocker = new Object();

	private static final String URLPARM_REPOSITORY_ID = "repositoryId";
	private static final String URLPARM_CASE_ID = "caseId";
	private static final String URLPARM_METHOD = "method";

	private static final String PREFIX_METHOD = "method_";
	private static final String MIMETYPE_JSON = "application/json";
	private static final String JSONKEY_TEMPLATE = "template";
	private static final String DFT_CE_CLASS_ADVICE_DOC = "NonScannedDocument";
	
	private static final Object configAdviceTemplateLocker = new Object();
	
	private static String adviceDocCeClass = DFT_CE_CLASS_ADVICE_DOC;

	final private static String[] loggingPackageClassList = new String[] {
		"v11.com.ibm.icm.extension.ewf.services.advice",
		"v11.com.ibm.icm.extension.ewf.services.activity",
		"v11.com.ibm.ewf.activity",
		"v11.com.ibm.ewf.cache"
	};
	
	final private static String[] docx4jPackages = new String[] {
		"org.docx4j",
		"o.d",
		"com.topologi"
	};

	private static final HashMap<String, Method> methodMap = new HashMap<String, Method> ();

	public EWFAdviceService() {
		;
	}


	@SuppressWarnings("rawtypes")
	@Override
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String methodName = "execute";
		callbacks.getLogger().logEntry(this, methodName, request);
		matchLogLevel(callbacks.getLogger());
		EWFActivityService.initCache(this, callbacks);
		configAdviceTemplate(this, callbacks);

		String requestMethod = request.getParameter(URLPARM_METHOD);
		if (requestMethod == null || requestMethod.trim().isEmpty()) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			callbacks.getLogger().logError(this, methodName, request, "The required URL parameter 'method' is not provided.");
			//genErrorJson(999, "The required URL parameter 'method' is not provided.").serialize(response.getWriter());
			return;
		}

		requestMethod = PREFIX_METHOD + requestMethod;

		Method methodToInvoke = methodMap.get(requestMethod);
		if (methodToInvoke == null) {
			try {
				methodToInvoke = this.getClass().getMethod(requestMethod, PluginServiceCallbacks.class, HttpServletRequest.class, HttpServletResponse.class);
			} catch (NoSuchMethodException e) {
				response.setContentType(MIMETYPE_JSON);
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				//genErrorJson(999, "The method " + requestMethod + " is not found.").serialize(response.getWriter());
				callbacks.getLogger().logError(this, methodName, request, "The method " + requestMethod + " is not found.");
				Exception exp = new Exception("The method " + requestMethod + " is not found.");
				exp.initCause(e);
				throw exp;
			} catch (SecurityException e) {
				response.setContentType(MIMETYPE_JSON);
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				//genErrorJson(999, "The method " + requestMethod + " is not accessible.").serialize(response.getWriter());
				callbacks.getLogger().logError(this, methodName, request, "The method " + requestMethod + " is not accessible.");
				Exception exp = new Exception("The method " + requestMethod + " is not accessible.");
				exp.initCause(e);
				throw exp;
			}
			if (methodToInvoke == null) {
				callbacks.getLogger().logError(this, methodName, request, "Error happened in fetching the executable method. Terminate the request.");
				Exception exp = new Exception("Error happened in fetching the executable method. Terminate the request.");
				throw exp;
			}
			synchronized (methodMap) {
				if (!methodMap.containsKey(requestMethod)) {
					methodMap.put(requestMethod, methodToInvoke);
				}
			}
		}

		callbacks.getLogger().logDebug(this, methodName, request, "Invoking method " + requestMethod + " ...");
		long invokeStart = System.currentTimeMillis();
		try {
			methodToInvoke.invoke(this, callbacks, request, response);
		} catch (InvocationTargetException ite) {
			Throwable t = ite.getCause();
			if (t == null) {
				t = ite;
			}
			logger.error("Error occurred in invoking method " + requestMethod, t);
			callbacks.getLogger().logError(this, methodName, "Error occurred in invoking method " + requestMethod, t);
			if (t instanceof Exception) {
				throw (Exception) t;
			} else if (t instanceof RuntimeException) {
				throw (RuntimeException) t;
			} else {
				throw ite;
			}
		}
		long invokeEnd = System.currentTimeMillis();
		callbacks.getLogger().logDebug(this, methodName, request, "Method " + requestMethod + " completed. Time elapsed : " + (invokeEnd - invokeStart) + " msec");

		callbacks.getLogger().logDebug(this, methodName, request, "Post-execute process - prepare the templates");
		prepareTemplates();
		callbacks.getLogger().logDebug(this, methodName, request, "Post-execute process ends");
		callbacks.getLogger().logExit(this, methodName, request);
	}

	@Override
	public String getId() {
		return "EWFAdviceService";
	}

	public void method_listTemplate(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_listTemplate";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);
		response.setContentType(MIMETYPE_JSON);
		String caseType = request.getParameter("caseType");
		JSONObject jsonRoot = templateNamesToJson(EWFAdviceTemplateManager.getInstance().listTemplateNames(caseType, true));
		jsonRoot.serialize(response.getWriter());

		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}

	public void method_getTemplateData(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String methodName = "method_listAdviceField";
		logger.info("===========enter into method_getTemplateData====="+methodName);
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);
		logger.info("=============request in method_getTemplateData=============="+request);
		String caseId = request.getParameter("caseId");
		String templateName = request.getParameter("template");
		String repositoryId = request.getParameter("repositoryId");
		String prefillValue = request.getParameter("prefillValue");

		logger.debug("method_listAdviceField: repositoryId: " + repositoryId + 
				", caseId: " + caseId + 
				", templateName: " + templateName +
				"prefillValue: " + prefillValue);

		Subject subject = callbacks.getP8Subject(repositoryId);

		if (subject == null) {
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}

		UserContext.get().pushSubject(subject);
		ObjectStore os = callbacks.getP8ObjectStore(repositoryId);

		logger.debug("method_listAdviceField: connected to CE.");
		JSONObject jsonRoot = null;
		try {
			jsonRoot = listTemplateField(os, caseId, templateName, Boolean.TRUE.toString().equalsIgnoreCase(prefillValue));
		} finally {
			UserContext.get().popSubject();
		}
		
		response.setContentType(MIMETYPE_JSON);
		jsonRoot.serialize(response.getWriter());

		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	
	public void method_generateAdvice(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_generateAdvice";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);
		logger.info("=============request in method_generateAdvice=============="+request);
		String caseId = request.getParameter("caseId");
		//String templateName = request.getParameter("template");
		String repositoryId = request.getParameter("repositoryId");

		logger.debug("method_generateAdvice: repositoryId: " + repositoryId + ", caseId: " + caseId);

		Subject subject = callbacks.getP8Subject(repositoryId);

		if (subject == null) {
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}

		UserContext.get().pushSubject(subject);
		ObjectStore os = callbacks.getP8ObjectStore(repositoryId);

		logger.debug("method_generateAdvice: connected to CE.");
		JSONObject jsonRoot = null;
		String docId = null;
		try {
			Folder caseFolder = EWFActivityOp.fetchCaseFolderFromCe(os, caseId);
			String postContent = getContentStringFromRequest(request);
			if (postContent == null || postContent.isEmpty()) {
				throw new Exception("The post content is empty.");
			}
			
			JSONObject jsonPostContent = JSONObject.parse(postContent);
			
			logger.info("jsonPostContent in generate advice method: " + jsonPostContent);
			
			HashMap<String, String> adviceFieldMap = extractFieldsFromJson(jsonPostContent);
			
			logger.info("===#### adviceFieldMap ####==="+adviceFieldMap);
			
			String templateName = (String) EWFActivityUtil.validateJsonRequiredValue(jsonPostContent, JSONKEY_TEMPLATE);
						
			Template adviceTemplate = EWFAdviceTemplateManager.getInstance().getTemplate(templateName);
									
			byte[] adviceDocData = adviceTemplate.generateAdvice(adviceFieldMap);
			
			ByteArrayInputStream bis = new ByteArrayInputStream(adviceDocData);
			
			logger.debug("Saving advice document to CE.");
			// save to CE
			Document doc = Factory.Document.createInstance(os, adviceDocCeClass);
			ContentTransfer ctObject = Factory.ContentTransfer.createInstance();
			ContentElementList contentList = Factory.ContentTransfer.createList();
			ctObject.setCaptureSource(bis);
			String contentType = adviceTemplate.getContentType();
			if (contentType != null && !contentType.isEmpty()) {
				ctObject.set_ContentType(contentType);
			}
			ctObject.set_RetrievalName(adviceTemplate.getOutputFileName());
			contentList.add(ctObject);
			doc.set_ContentElements(contentList);
			doc.getProperties().putValue(EWFActivityUtil.CE_SYSPROP_DOCTITLE, adviceTemplate.getDisplayName());
			//Add the Document Type - Added during COA starts here
			doc.getProperties().putValue("DocumentType", "1079");
			doc.getProperties().putValue("SourceId", "EntryTemplate");
			//Add the Document Type - Added during COA ends here
			doc.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
			doc.save(RefreshMode.REFRESH);
			fileObjToFolder(doc, caseFolder);
			logger.debug("Advice document saved to case folder.");
			docId = doc.getClassName() + "," + os.get_Id().toString() + "," + doc.get_Id().toString();
			jsonRoot = genErrorJson(0, "Advice is saved successfully.");
			jsonRoot.put("docId", docId);
			
			String loginUser = EWFActivityUtil.getLoginUser(os);
			String commentText = genAdviceComment(adviceTemplate.getDisplayName(), loginUser);
			Annotation ceComment = addCommentToCase(os, caseFolder, EWFActivityUtil.COMMENT_ACTION_CASE, commentText);
			ceComment.save(RefreshMode.REFRESH);
			logger.debug("Advice comment added : " + commentText);
		} finally {
			UserContext.get().popSubject();
		}

		response.setContentType(MIMETYPE_JSON);
		jsonRoot.serialize(response.getWriter());

		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	
	private static HashMap<String, String> extractFieldsFromJson(JSONObject jsonTemplateData) {
		HashMap<String, String> adviceFields = new HashMap<String, String> ();
		JSONArray jsonFields = (JSONArray) jsonTemplateData.get(EWFActivityUtil.JSONKEY_PROP_ARRAY);
		if (jsonFields == null) {
			jsonFields = (JSONArray) jsonTemplateData.get(EWFActivityUtil.JSONKEY_PROP_ARRAY_FOR_ICN_CONTENT_LIST);
		}
		if (jsonFields == null) {
			return null;
		}
		for (int i = 0; i < jsonFields.size(); i++ ) {
			JSONObject jsonField = (JSONObject)jsonFields.get(i);
			String fieldName = (String)jsonField.get(EWFActivityUtil.JSONKEY_SYMBOLIC_NAME);
			if (fieldName == null || fieldName.isEmpty()) {
				fieldName = (String)jsonField.get(EWFActivityUtil.JSONKEY_SYMBOLIC_NAME_FOR_SAVE);
			}
			if (fieldName == null || fieldName.isEmpty()) {
				continue;
			}
			String fieldValue = null;
			Object jsonValue = jsonField.get(EWFActivityUtil.JSONKEY_VALUE);
			if (jsonValue != null) {
				fieldValue = jsonValue.toString();
			}
			if (fieldValue == null) {
				continue;
			}
			adviceFields.put(fieldName, fieldValue);
		}
		return adviceFields;
	}
	
//	private HashMap<String, String> extractFieldsFromGenerateAdviceJson(JSONObject jsonPostContent) {
//		HashMap<String, String> fieldsValueMap = new HashMap<String, String>();
//		JSONArray jsonPropArray = (JSONArray)EWFActivityUtil.validateJsonRequiredValue(jsonPostContent, EWFActivityUtil.JSONKEY_PROP_ARRAY);
//		Iterator iter = jsonPropArray.iterator();
//		while (iter.hasNext()) {
//			JSONObject jsonProp = (JSONObject)iter.next();
//			String propName = (String)EWFActivityUtil.validateJsonRequiredValue(jsonPostContent, EWFActivityUtil.JSONKEY_SYMBOLIC_NAME);
//			String propValue = (String)EWFActivityUtil.validateJsonRequiredValue(jsonPostContent, EWFActivityUtil.JSONKEY_VALUE);
//			fieldsValueMap.put(propName, propValue);
//		}
//		return fieldsValueMap;
//	}

	private static JSONObject genErrorJson(int errCode, String errMsg) {
		JSONObject jsonResp = new JSONObject();
		JSONObject jsonMsg = new JSONObject();

		jsonResp.put("messages", jsonMsg);
		jsonMsg.put("adminResponse", null);
		jsonMsg.put("moreInformation", null);
		jsonMsg.put("explanation", null);
		jsonMsg.put("number", Integer.toString(errCode));
		jsonMsg.put("userResponse", null);
		jsonMsg.put("text", errMsg);
		return jsonResp;
	}
	
	public static String getContentStringFromRequest(HttpServletRequest req) throws IOException {
		String line = null;
		StringBuffer strBuff = new StringBuffer();
		BufferedReader reader = null;
		InputStream inputStream = null;
		
		try {
			inputStream = req.getInputStream();
			if (inputStream != null) {
				reader = new BufferedReader(new InputStreamReader(inputStream));
				while ((line = reader.readLine()) != null) {
					strBuff.append(line).append("\n");
				}
			}
		} finally {
			if (inputStream != null) {
				try {inputStream.close();} catch (IOException e) {;}
				inputStream = null;
			}
			if (reader != null) {
				try {reader.close();} catch (IOException e) {;}
				reader = null;
			}
		}
		
		String str = strBuff.toString();
		return str;
	}

	private static void matchLogLevel(PluginLogger pluginLogger) {
		int newIcnLevel = pluginLogger.getLogLevel();
		if (newIcnLevel == icnLogLevel) {
			return;
		}
		synchronized (logLevelUpdateLocker) {
			if (newIcnLevel == icnLogLevel) {
				return;
			}
			Level log4jLevel = Level.ERROR;
			switch (newIcnLevel) {
			case PluginLogger.LOG_DEBUG:
			case PluginLogger.LOG_DEV:
			case PluginLogger.LOG_ENTRY:
			case PluginLogger.LOG_EXIT:
				log4jLevel = Level.DEBUG;
				break;
			case PluginLogger.LOG_INFO:
				//case PluginLogger.LOG_PERF:
				log4jLevel = Level.INFO;
				break;
			case PluginLogger.LOG_WARNING:
				log4jLevel = Level.WARN;
				break;
			case PluginLogger.LOG_ERROR:
				log4jLevel = Level.ERROR;
				break;
			default : 
				log4jLevel = Level.ERROR;
				break;
			}
			setLogLevelForLoggers(loggingPackageClassList, log4jLevel);
			setLogLevelForLoggers(docx4jPackages, Level.ERROR);
			icnLogLevel = newIcnLevel;
		}
	}
	
	private static void setLogLevelForLoggers(String[] loggerNameList, Level level) {
		for (String loggerName : loggerNameList) {
			if (loggerName == null || loggerName.isEmpty()) {
				continue;
			}
			Logger curLogger = Logger.getLogger(loggerName);
			if (!level.equals(curLogger.getLevel())) {
				curLogger.setLevel(level);
				/*
				Enumeration appenderEnum = curLogger.getAllAppenders();
				Appender appender = null;
				while (appenderEnum.hasMoreElements()) {
					appender = (Appender) appenderEnum.nextElement();
					if (appender instanceof org.apache.log4j.ConsoleAppender) {
						break;
					}
				}
				if (appender == null) {
					appender = new org.apache.log4j.ConsoleAppender();
					curLogger.addAppender(appender);
				}
				curLogger.isAttached(appender)
				appender.
				 */
			}
		}
	}

	public void method_test(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
	}

	private static JSONObject templateNamesToJson(Map<String, String> templateNames) {
		if (templateNames == null) {
			return null;
		}
		JSONObject jsonChoiceList = new JSONObject();
		JSONArray jsonChoiceArray = new JSONArray();
		jsonChoiceList.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, EWFActivityUtil.PSEUDO_CHOICELIST_ADVICE_TEMPLATE_LIST);
		jsonChoiceList.put(EWFActivityUtil.JSONKEY_CHOICES, jsonChoiceArray);
		for (String templateName : templateNames.keySet()) {
			JSONObject jsonChoice = new JSONObject();
			jsonChoice.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, templateNames.get(templateName));
			jsonChoice.put(EWFActivityUtil.JSONKEY_VALUE, templateName);
			jsonChoiceArray.add(jsonChoice);
		}
		return jsonChoiceList;
	}
	
	private static JSONArray listAdviceTemplateJson(ObjectStore os) throws Exception {
		EWFAdviceTemplateManager manager = EWFAdviceTemplateManager.getInstance();
		List<String> templateNameSet = manager.listTemplateNames();
		JSONArray jsonArray = new JSONArray();
		for (String templateName : templateNameSet) {
			JSONObject jsonTemplateName = new JSONObject();
			jsonTemplateName.put(EWFActivityUtil.JSONKEY_SYMBOLIC_NAME, templateName);
			jsonTemplateName.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, templateName);
			//jsonTemplateName.put(EWFActivityUtil.JSONKEY_ID, templateName);
			jsonArray.add(jsonTemplateName);
		}
		return jsonArray;
	}
	
	private static JSONObject listTemplateField(ObjectStore os, String caseId, String templateName, boolean prefillValue) throws Exception {
	
		/*EWFAdviceTemplateManager manager = EWFAdviceTemplateManager.getInstance();
		Template template = manager.getTemplate(templateName);
		LinkedHashMap<String, JSONObject> fieldsMap = null;
		Folder caseFolder = EWFActivityOp.fetchCaseFolderFromCe(os, caseId);
		logger.info("====@@@prefillValue@@@===== :"+prefillValue);
		if (prefillValue) {			
			fieldsMap = template.listFieldsWithValue(os, caseFolder);
		} else {
			fieldsMap = template.listFields();
		}
		logger.info("====fieldsMap********===== :"+fieldsMap);
		
		
		JSONObject jsonRoot = new JSONObject();
		jsonRoot.put(EWFActivityUtil.JSONKEY_TEMPLATE, template.getSymbolicName());
		jsonRoot.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, template.getDisplayName());
		jsonRoot.put(EWFActivityUtil.JSONKEY_RENDER_DIJIT_CLASS, template.getRenderDijitClass());
		//jsonRoot.put(EWFActivityUtil.JSONKEY_ID, template.getName());
		//jsonRoot.put(EWFActivityUtil.JSONKEY_DESCRIPTION, template.getName());
		JSONArray propArray = new JSONArray();
		jsonRoot.put(EWFActivityUtil.JSONKEY_PROP_ARRAY_FOR_ICN_CONTENT_LIST, propArray);
		Iterator<String> iter = fieldsMap.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			JSONObject jsonField = fieldsMap.get(key);
			propArray.add(jsonField);
		}
		logger.info("====jsonRoot###### ===== :"+jsonRoot);
		return jsonRoot;*/
		
		//added by suresh on 21st Nov for debit card development	
		EWFAdviceTemplateManager manager = EWFAdviceTemplateManager.getInstance();
		Template template = manager.getTemplate(templateName);
		LinkedHashMap<String, JSONObject> fieldsMap = null;
		Folder caseFolder = EWFActivityOp.fetchCaseFolderFromCe(os, caseId);
		if (prefillValue) {			
			fieldsMap = template.listFieldsWithValue(os, caseFolder);
			} else {
			fieldsMap = template.listFields();
			}
		logger.info("====== fieldsMap ====="+fieldsMap);
		HashMap<String, String> priorFillVars = new HashMap<String, String>();
		LinkedHashMap<String, JSONObject> fieldsList = new LinkedHashMap<String, JSONObject>();
		Set<String> keysList = fieldsMap.keySet();
		Iterator<String> keysListIterator = keysList.iterator();
		while (keysListIterator.hasNext()) {
		    	String key = (String) keysListIterator.next();
		    	Object value = fieldsMap.get(key).get("value");
		    	String val = value == null ? "" : value.toString();
		    	priorFillVars.put(key, val);		    			    	
			}
		String priorFillVarsString=template.getTemplateContentAsString(priorFillVars);
		logger.info("==== priorFillVarsString isss ==== "+priorFillVarsString);
		String caseType=caseFolder.get_ClassDescription().get_SymbolicName();
		String caseTypeAdvice = CommonUtils.getComponentConfig().get(EWFActivityUtil.CASE_TYPE_ADVICE_TEMPLATE_MAP);
		logger.info("caseTypeAdvice from properties :::::: " +caseTypeAdvice);
        Map<String, String> caseTypeAdviceMap = new LinkedHashMap<String, String>();
        caseTypeAdviceMap.put(caseTypeAdvice.split(":")[0], caseTypeAdvice.split(":")[1]);
		logger.info("caseTypeAdviceMap :::::: " +caseTypeAdviceMap);
		JSONObject jsonRoot = new JSONObject();
		if(caseTypeAdviceMap.containsKey(caseType) && caseTypeAdviceMap.get(caseType).equalsIgnoreCase(EWFActivityUtil.DATAPOST)) 
		  {
			jsonRoot.put(EWFActivityUtil.JSONKEY_TEMPLATE, template.getSymbolicName());
			jsonRoot.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, template.getDisplayName());
			jsonRoot.put(EWFActivityUtil.JSONKEY_RENDER_DIJIT_CLASS, template.getRenderDijitClass());
			//jsonRoot.put("content", priorFillVarsString);
			jsonRoot.put(EWFActivityUtil.DATAPOST_CONTENT, priorFillVarsString);
		 }
		else{
			jsonRoot.put(EWFActivityUtil.JSONKEY_TEMPLATE, template.getSymbolicName());
			jsonRoot.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, template.getDisplayName());
			jsonRoot.put(EWFActivityUtil.JSONKEY_RENDER_DIJIT_CLASS, template.getRenderDijitClass());
			JSONArray propArray = new JSONArray();
			jsonRoot.put(EWFActivityUtil.JSONKEY_PROP_ARRAY_FOR_ICN_CONTENT_LIST, propArray);
			Iterator<String> iter = fieldsMap.keySet().iterator();
			while (iter.hasNext()) {
				String key = iter.next();
				JSONObject jsonField = fieldsMap.get(key);
				propArray.add(jsonField);
			}
		}
			return jsonRoot;
	}
	
	public static void fileObjToFolder(IndependentlyPersistableObject ceObj, Folder folder) throws Exception {
		String fileTitle = null;
		if (ceObj instanceof Document) {
			fileTitle = ((Document)ceObj).getProperties().getStringValue(EWFActivityUtil.CE_SYSPROP_DOCTITLE);
		} else if (ceObj instanceof CustomObject) {
			fileTitle = ((CustomObject)ceObj).get_Id().toString();
		} else if (ceObj instanceof Folder) {
			fileTitle = ((Folder)ceObj).get_FolderName();
		} else {
			throw new Exception("Unsupported CE object : " + ceObj.getClass().getCanonicalName());
		}
		
		try {
			ReferentialContainmentRelationship rcr = folder.file(ceObj,
					AutoUniqueName.AUTO_UNIQUE, fileTitle,
					DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
			rcr.save(RefreshMode.REFRESH);
		} catch (EngineRuntimeException e) {
			Exception exp = new Exception("CE error occurred in filing object to folder");
			exp.initCause(e);
			throw exp;
		}
	}
//
//	private static String expandWasVariable(String wasVariableName) {  
//		com.ibm.websphere.management.AdminService as = com.ibm.websphere.management.AdminServiceFactory.getAdminService();  
//		String server = as.getProcessName();  
//		String expandResult = null;
//		String orgWasVariable = "${" + wasVariableName + "}";
//		try {
//			java.util.Set result;
//			result = as.queryNames(new javax.management.ObjectName("*:*,type=AdminOperations,process=" + server), null);
//			expandResult = (String)as.invoke((javax.management.ObjectName)result.iterator().next(),"expandVariable",new Object[] {orgWasVariable}, new String[] {"java.lang.String"});
//		} catch (Throwable e) {
//			;
//		}
//		if (orgWasVariable.equals(expandResult)) {
//			expandResult = null;
//		}
//		return expandResult;
//	}
//	
	public static void configAdviceTemplate(PluginService pluginService, PluginServiceCallbacks callbacks) throws Exception {
		if (EWFAdviceTemplateManager.isConfigured()) {
			return;
		}
		synchronized (configAdviceTemplateLocker) {
			if (EWFAdviceTemplateManager.isConfigured()) {
				return;
			}
			ComponentConfig config = CommonUtils.getComponentConfig();
			EWFAdviceTemplateManager.config(config, false);
			adviceDocCeClass = config.get(EWFActivityUtil.CONFIG_ADVICE_DOC_CLASS, DFT_CE_CLASS_ADVICE_DOC);
		}
	}
	public static void prepareTemplates() {
		if (!EWFAdviceTemplateManager.isConfigured()) {
			return;
		}
		EWFAdviceTemplateManager.getInstance().prepareAll(2);
	}
	
	private static String genAdviceComment(String adviceName, String userId) {
		// Action : Generate Advice -  Document: <file name> - Action Time : <Time>  - UserID : <UserID>
		
		StringBuilder sbComment = new StringBuilder();
		sbComment.append("Action : Generate Advice - Document: ").append(adviceName);
		sbComment.append(" - Action Time : ").append(EWFActivityUtil.dateToSgDateTimeString(new java.util.Date(System.currentTimeMillis())));
		sbComment.append(" - UserID : ").append(userId);
		return sbComment.toString();
	}
	
	private static Annotation addCommentToCase(ObjectStore os, Folder caseFolder, int commentAction, String commentText) {
		Annotation ceComment = Factory.Annotation.createInstance(os, EWFActivityUtil.CE_CLASS_CASE_COMMENT);
		ceComment.set_AnnotatedObject(caseFolder);
		ceComment.getProperties().putValue(EWFActivityUtil.CE_PROP_COMMENT_ACTION, commentAction);
		ceComment.getProperties().putValue(EWFActivityUtil.CE_PROP_COMMENT_TEXT, commentText);
		return ceComment;
	}
}
