package v11.com.ibm.icm.extension.ewf.services.casepropsfilter;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.filenet.api.constants.Cardinality;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.PropertyFilter;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;

import com.ibm.casemgmt.api.Case;
import com.ibm.casemgmt.api.constants.ModificationIntent;
import com.ibm.casemgmt.api.context.CaseMgmtContext;
import com.ibm.casemgmt.api.context.P8ConnectionCache;
import com.ibm.casemgmt.api.context.SimpleP8ConnectionCache;
import com.ibm.casemgmt.api.context.SimpleVWSessionCache;
import com.ibm.casemgmt.api.context.VWSessionCache;
import com.ibm.casemgmt.api.objectref.ObjectStoreReference;
import com.ibm.casemgmt.api.properties.CaseMgmtChoice;
import com.ibm.casemgmt.api.properties.CaseMgmtChoiceList;
import com.ibm.casemgmt.api.properties.CaseMgmtProperties;
import com.ibm.casemgmt.api.properties.CaseMgmtProperty;

import com.ibm.ecm.extension.PluginLogger;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;

import v11.com.ibm.ewf.cache.EWFCacheUtil;
import v11.com.ibm.ewf.casepropsfilter.EWFCaseFilterHandler;
import v11.com.ibm.ewf.config.ComponentConfig;

import v11.com.ibm.icm.extension.ewf.CommonUtils;
import v11.com.ibm.icm.extension.ewf.actions.activity.WASDynaCacheProvider;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.json.java.OrderedJSONObject;

public class EWFCaseService extends PluginService {

	final static private Logger logger = Logger.getLogger(EWFCaseService.class);
	
	static private int icnLogLevel = -99999;
	
	private final String ID_PARAM = "caseId";
	
	private final String CASE_TYPE = "caseType";
	
	private final String classDescProp = "ClassDescription";
	
	private final String dateModifiedProp = "DateLastModified";
	
	private final String RESPONSE_TEMPLATE = "_TEMPLATE";
	
	private final String CHOICE_LIST = "_CHOICELIST";
	
	private final String MODIFIED_DATE = "_MODIFIEDDATE";
	
	private final int minChoiceCountToStore = 25;
	
	final static private Object logLevelUpdateLocker = new Object();
	
	private static final String MIMETYPE_JSON = "application/json";
    
	private static final String CONFIG_DISABLE_CACHE = "service.cache.disabled";
	
	private static Map<Integer, String> intDataTypeMap = null;
	
	private CaseMgmtContext origCmctx = null;
	
	final private static String[] loggingPackageClassList = new String[] {
		"com.ibm.icm.extension.ewf.services.advice",
		"com.ibm.icm.extension.ewf.services.activity",
		"com.ibm.icm.extension.ewf.services.casepropsfilter",
		"com.ibm.ewf.activity",
		"com.ibm.ewf.cache"
	};
	
	
	public EWFCaseService() {
		
	}
	
	@Override
	public String getId() {
		return "EWFCaseService";
	}

	public void setIntDataTypeMap() {
		
		intDataTypeMap = new HashMap<Integer, String>(7);
		
		intDataTypeMap.put(TypeID.STRING.getValue(), "xs:string");
		
		intDataTypeMap.put(TypeID.BOOLEAN.getValue(), "xs:boolean");
		
		intDataTypeMap.put(TypeID.DATE.getValue(), "xs:timestamp");
		
		intDataTypeMap.put(TypeID.LONG.getValue(), "xs:integer");
		
		intDataTypeMap.put(TypeID.DOUBLE.getValue(), "xs:double");
		
		intDataTypeMap.put(TypeID.GUID.getValue(), "xs:guid");
		
		intDataTypeMap.put(TypeID.OBJECT.getValue(), "xs:object");
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		callbacks.getLogger().logEntry(this, "execute", request);
		
		matchLogLevel(callbacks.getLogger());
		
		String caseId = request.getParameter(ID_PARAM);
		
		String repositoryId = callbacks.getRepositoryId();
		
		String caseType = request.getParameter(CASE_TYPE);
		
		logger.info("caseId: " + caseId + " : repositoryId: " + repositoryId + " caseType: " + caseType);
		
		Subject subject = callbacks.getP8Subject(repositoryId);
		
		if (subject == null) {
			
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}
		
	    try {
	      
	    	//caseType = "COPC_CreditCardApplication";
	    	
	    	initCache(this, callbacks);
	    	
	    	UserContext.get().pushSubject(subject);
			
			ObjectStore objStore = callbacks.getP8ObjectStore(repositoryId);
			
			if(null == intDataTypeMap) {
				
				setIntDataTypeMap();
			}

			ComponentConfig config = CommonUtils.getComponentConfig();
			
			String filteredProps = config.get(caseType + ".filtered.props");
			
			String solFolderId = config.get(caseType + ".solution.folder.id");
			
			logger.info("ObjectStore retrieved successfully. filteredProps: " + filteredProps + " solFolderPath: " + solFolderId);
			
			PropertyFilter propFilter = new PropertyFilter();
			
			propFilter.addIncludeProperty(new FilterElement(null, null, true, dateModifiedProp, null));
			
			Folder solFolder = Factory.Folder.fetchInstance(objStore, solFolderId, propFilter);
			
			JSONArray cachedResponseTemplate = (JSONArray) EWFCacheUtil.get(caseType + RESPONSE_TEMPLATE);
			
			//Verify whether cache is up to date
			boolean isCacheUpToDate = isCachedTemplateUpToDate(caseType, filteredProps, solFolder, cachedResponseTemplate, objStore);
			
			if(!isCacheUpToDate) {
				
				try {
				
					logger.info("cached template is null or not up to date.Preparing responseTemplate data");
				
					createConnection();
					
					ObjectStoreReference targetOSRef = new ObjectStoreReference(objStore);
					
					propFilter = new PropertyFilter();
					
					propFilter.addIncludeProperty(new FilterElement(null, null, true, filteredProps + " " + classDescProp, null));
					
					Case caseInstance = Case.fetchInstance(targetOSRef, new Id(caseId), propFilter, ModificationIntent.NOT_MODIFY);
					
			    	CaseMgmtProperties props = caseInstance.getProperties();
			    	
			    	cachedResponseTemplate = getResponseTemplate(props.copyList(), caseType);
			    	
			    	//Remove and Put the new Response Template in cache 
			    	if(EWFCacheUtil.contains(caseType + RESPONSE_TEMPLATE)) {
			    	
			    		EWFCacheUtil.invalidate(caseType + RESPONSE_TEMPLATE);
			    	}
			    	
			    	EWFCacheUtil.put(caseType + RESPONSE_TEMPLATE, cachedResponseTemplate);
			    	
			    	Date lastModified = solFolder.get_DateLastModified();
			    	
			    	//Remove and Put the new modified date in cache 
			    	if(EWFCacheUtil.contains(caseType + MODIFIED_DATE)) {
				    	
			    		EWFCacheUtil.invalidate(caseType + MODIFIED_DATE);
			    	}
			    	
			    	EWFCacheUtil.put(caseType + MODIFIED_DATE, lastModified);
			    	
			    	logger.info("setting the responseTemplate and modified date in Cache.");
			    	
				} catch(Exception e) {
					
					e.printStackTrace();
			    	
			    	logger.error("Exception occurred in execute: " + e.getMessage(), e);
			    	
			    	throw e;
					
				} finally {
					
					destroy();
				}
			}
			
			JSONObject result = EWFCaseFilterHandler.getCaseInformation(objStore, caseId, caseType, filteredProps, classDescProp, cachedResponseTemplate);
			
			logger.info("final result: " + result);
			
	    	response.setContentType(MIMETYPE_JSON);
	    	
	    	result.serialize(response.getWriter());
			
	    } catch (Exception e) {
	      
	    	e.printStackTrace();
	    	
	    	logger.error("Exception occurred in execute: " + e.getMessage(), e);
	    	
	    	throw e;
	    
	    } finally {
	    	
	    	UserContext.get().popSubject();
	    }
	}
	
	public boolean isCachedTemplateUpToDate(String caseType, String filteredProps, Folder solFolder, JSONArray cachedResponseTemplate, ObjectStore objStore) {
	
		//Zero size template is never put to the cache - this is just the defensive code, and should go into normally.
		if (cachedResponseTemplate != null && cachedResponseTemplate.size() == 0) {
			
			cachedResponseTemplate = null;
			
			EWFCacheUtil.invalidate(caseType + RESPONSE_TEMPLATE);
			
			return false;
		}
		
		if(null == cachedResponseTemplate) {
		
			return false;
		}
		
		String[] arrFilteredProps = filteredProps.split(" ");
		
		logger.info("inside isCachedTemplateUpToDate arrFilteredProps: " + arrFilteredProps.length + " cachedResponseTemplate: " + cachedResponseTemplate.size());

		//check the size of the cached template array and filteredProps array. The size diff should be ClassDesc prop only (1).
		if(arrFilteredProps.length + 1 != cachedResponseTemplate.size()) {
		
			return false;
		}
		
		Date cachedLastModifiedDate = (Date) EWFCacheUtil.get(caseType + MODIFIED_DATE);
		
		if(null == cachedLastModifiedDate) {
			
			return false;
		}
		
		Date lastModifiedDate = solFolder.getProperties().getDateTimeValue(dateModifiedProp);

		logger.info("cachedLastModifiedDate: " + cachedLastModifiedDate + " lastModifiedDate: " + lastModifiedDate);
		
		//If both the dates are not equal then cache is not up to date
		if(null != lastModifiedDate && lastModifiedDate.compareTo(cachedLastModifiedDate) != 0) {
			
			return false;
		}
		
		return true;
	}
	
	public JSONArray getResponseTemplate(List<CaseMgmtProperty> acmProps, String caseType) {
	    
		JSONArray responseTemplate = new JSONArray();
	    
		for (int index = 0; index < acmProps.size(); index++) {
			
			CaseMgmtProperty acmProp = acmProps.get(index);
			
			OrderedJSONObject prop = generateJSONProperty(acmProp);
	    	
			//Special handling for class desc prop
	    	if(acmProp.getSymbolicName().equalsIgnoreCase(classDescProp)) {
	    		
	    		String propType = intDataTypeMap.get(acmProp.getPropertyType().getValue());
	    		
	    		prop.put("value", EWFCaseFilterHandler.getJSONableFromPropertyValue(propType, acmProp.getValue()));
	    	}
	    	
	    	responseTemplate.add(prop);
		}
		
	    logger.info("inside getResponseTemplate the responseTemplate: " + responseTemplate);
	    
	    return responseTemplate;
	}

	private OrderedJSONObject generateJSONProperty(CaseMgmtProperty acmProp) {
	    
		OrderedJSONObject prop = new OrderedJSONObject();
	    
		prop.put("symbolicName", acmProp.getSymbolicName());
	    
		prop.put("displayName", acmProp.getDisplayName());
	    
	    prop.put("dataType", intDataTypeMap.get(acmProp.getPropertyType().getValue()));

	    if (acmProp.getCardinality() == Cardinality.SINGLE) {
	      
	    	prop.put("cardinality", "SINGLE");
	    
	    } else {
	      
	    	prop.put("cardinality", "LIST");
	      
	    	prop.put("requiresUniqueElements", Boolean.valueOf(acmProp.getRequiresUniqueElements()));
	    }

	    prop.put("system", Boolean.valueOf(acmProp.isSystemOwned()));

	    //condition to retrieve choice list values
	    if((acmProp.getPropertyType() == TypeID.LONG || acmProp.getPropertyType() == TypeID.STRING) && (null != acmProp.getChoiceList())) {
	    	
	    	generateChoiceList(acmProp, prop);
	    }
	    //End
	    
	    return prop;
	}

	public void generateChoiceList(CaseMgmtProperty acmProp, OrderedJSONObject prop) {
	
		OrderedJSONObject choiceListInfo = new OrderedJSONObject();
		
		choiceListInfo.put("displayName", acmProp.getChoiceList().getDisplayName());
		
		CaseMgmtChoiceList acmChoiceList = acmProp.getChoiceList();
			
		List<CaseMgmtChoice> acmChoiceItems = acmChoiceList.getChoices();
			
		//If the number of choice items is less send all the choice values back to client
		if(null != acmChoiceItems && acmChoiceItems.size() <= minChoiceCountToStore) {
				
			JSONArray jsonChoices = new JSONArray();

			for (int index = 0; index < acmChoiceItems.size(); index++) {
					
				OrderedJSONObject jsonChoice = new OrderedJSONObject();
			        
				CaseMgmtChoice choice = (CaseMgmtChoice) acmChoiceItems.get(index);
			        
				Object choiceVal = (acmChoiceList.getDataType() == TypeID.LONG) ? choice.getIntegerChoice() : choice.getStringChoice();
					
				jsonChoice.put("displayName", choice.getDisplayName());
				
				jsonChoice.put("value", choiceVal.toString());
					
				jsonChoices.add(jsonChoice);
			}
				
			choiceListInfo.put("choices", jsonChoices);
			
			logger.info("choice list " + choiceListInfo.get("displayName") + " size is less. storing all choice values in response. " + acmChoiceItems.size() + 
					"<" + minChoiceCountToStore);
			
			//If the number of choice values are high store in cache
		} else if(null != acmChoiceItems && acmChoiceItems.size() > minChoiceCountToStore) {
				
			Map<String, String> choiceValueNameMap = new HashMap<String, String>();
				
			for (int index = 0; index < acmChoiceItems.size(); index++) {
					
				CaseMgmtChoice choice = (CaseMgmtChoice) acmChoiceItems.get(index);
			        
				Object choiceVal = (acmChoiceList.getDataType() == TypeID.LONG) ? choice.getIntegerChoice() : choice.getStringChoice();
					
				choiceValueNameMap.put(choiceVal.toString(), choice.getDisplayName());
			}
				
			if(EWFCacheUtil.contains(acmProp.getSymbolicName() + CHOICE_LIST)) {
				
				EWFCacheUtil.invalidate(acmProp.getSymbolicName() + CHOICE_LIST);
			}
				
			EWFCacheUtil.put(acmProp.getSymbolicName() + CHOICE_LIST, choiceValueNameMap);
			
			choiceListInfo.put("dynamicChoices", true);
			
			logger.info("choice list " + choiceListInfo.get("displayName") + " size is big. storing the choices in cache");
		}
		
		prop.put("choiceList", choiceListInfo);
	}
	
	public void createConnection() throws Exception {
		
		logger.debug("Enter ICMConnection.createConnection.");
		
		try {
			
			// Performance benchmark
			long timeElapsed = 0L;
			
			if (logger.isDebugEnabled()) {
				
				timeElapsed = System.currentTimeMillis();
			}
			
			P8ConnectionCache connCache = new SimpleP8ConnectionCache();
			
			VWSessionCache vwSessCache = new SimpleVWSessionCache();
			
			CaseMgmtContext icmContext = new CaseMgmtContext(vwSessCache, connCache);
			
			this.origCmctx = CaseMgmtContext.set(icmContext);
			
			// Performance benchmark
			if (logger.isDebugEnabled()) {
				
				logger.debug("Connected to ICM. Time elapsed : " + (System.currentTimeMillis() - timeElapsed) + " msec");
			}
			
		} finally {
			
		}
		
		logger.debug("Exit ICMConnection.createConnection.");
	}

	public void destroy() {
		
		if (this.origCmctx != null) {
			
			CaseMgmtContext.set(this.origCmctx);
			
			this.origCmctx = null;
		}
		
		logger.debug("ICMConnection.destroy() : icm connection destroyed.");
	}
	
	public static void initCache(PluginService pluginService, PluginServiceCallbacks callbacks) {
		
		if (EWFCacheUtil.isCacheInitalized()) {
			
			return;
		}
		
		String toDisableCache = null;
		
		ComponentConfig config = CommonUtils.getComponentConfig();
		
		toDisableCache = config.get(CONFIG_DISABLE_CACHE, "FALSE");
		
		if ("TRUE".equalsIgnoreCase(toDisableCache)) {
			
			logger.debug("Cache is disabled.");
			
			callbacks.getLogger().logDebug(pluginService, "initCache", "Cache is disabled.");
			
			return;
		}
		
		if (WASDynaCacheProvider.isDynaCacheAvailable()) {
			
			logger.debug("Initialize the WAS dyanmic cache.");
			
			callbacks.getLogger().logDebug(pluginService, "initCache", "Initialize the WAS dyanmic cache.");
			
			EWFCacheUtil.initCache(WASDynaCacheProvider.class);
			
		} else {
			
			callbacks.getLogger().logDebug(pluginService, "initCache", "Initialize the default cache.");
			
			logger.debug("Initialize the default cache.");
			
			EWFCacheUtil.initCache();
		}
	}
	
	private static void matchLogLevel(PluginLogger pluginLogger) {
		
		int newIcnLevel = pluginLogger.getLogLevel();
		
		if (newIcnLevel == icnLogLevel) {
			
			return;
		}
		
		synchronized (logLevelUpdateLocker) {
			
			if (newIcnLevel == icnLogLevel) {
				
				return;
			}
			
			Level log4jLevel = Level.ERROR;
			
			switch (newIcnLevel) {
			
				case PluginLogger.LOG_DEBUG:
				
				case PluginLogger.LOG_DEV:
				
				case PluginLogger.LOG_ENTRY:
				
				case PluginLogger.LOG_EXIT:
					
					log4jLevel = Level.DEBUG;
					
					break;
			
				case PluginLogger.LOG_INFO:
			
					log4jLevel = Level.INFO;
				
					break;
			
				case PluginLogger.LOG_WARNING:
				
					log4jLevel = Level.WARN;
				
					break;
			
				case PluginLogger.LOG_ERROR:
				
					log4jLevel = Level.ERROR;
				
					break;
			
				default : 
				
					log4jLevel = Level.ERROR;
				
					break;
			}
			
			setLogLevelForLoggers(loggingPackageClassList, log4jLevel);
			
			icnLogLevel = newIcnLevel;
		}
	}
	
	
	private static void setLogLevelForLoggers(String[] loggerNameList, Level level) {
		
		for (String loggerName : loggerNameList) {
			
			if (loggerName == null || loggerName.isEmpty()) {
				
				continue;
			}
			
			Logger curLogger = Logger.getLogger(loggerName);
			
			if (!level.equals(curLogger.getLevel())) {
				
				curLogger.setLevel(level);
				
			}
		}
	}
	
}
