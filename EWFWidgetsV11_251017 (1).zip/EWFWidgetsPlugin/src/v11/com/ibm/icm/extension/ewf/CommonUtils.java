/**
 * 
 */
package v11.com.ibm.icm.extension.ewf;

import v11.com.ibm.ewf.config.ComponentConfig;

/**
 * 
 *
 */
public class CommonUtils {

public static final String REST_UMM_CREDENTIAL = "umm.rest";	
public static final String REST_UMM_URL = "umm.rest.url";	
private final static String ewficnpluginConfigName = "ewficnplugin";
public static ComponentConfig compConfig = null;
	
	public static ComponentConfig getComponentConfig()
	{
		if(compConfig == null)
		{
			compConfig = ComponentConfig.getInstance(ewficnpluginConfigName);
		}
		return compConfig;
	}
}
