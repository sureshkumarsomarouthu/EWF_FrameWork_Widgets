package v11.com.ibm.icm.extension.ewf.layout;

import java.util.Locale;

import com.ibm.ecm.extension.PluginLayout;

public class EWFLayout extends PluginLayout {

	@Override
	public String getId() {
		return "EWFPluginLayoutv11";
	}

	@Override
	public String getName(Locale locale) {
		return "EWF Layout v11";
	}

	@Override
	public String getLayoutClass() {
		return "v11.ewf.layout.EWFLayout" ;
	}

}
