console.log("Getting inside the EWF Widgets Plugin Scope");

if(typeof icmglobal === "undefined"){
	icmglobal={};
}

var icmContextRoot = "/EWFWidgetsv11";

var loadCSS = function(cssFileUrl){
	if (dojo.isIE) {
		document.createStyleSheet(cssFileUrl);
	} else {
		var head = document.getElementsByTagName("head")[0];
		var link = document.createElement("link");
		link.rel = "stylesheet";
		link.type = "text/css";
		link.href = cssFileUrl;
		head.appendChild(link);
	}
};

var loadJS = function(scriptUri) {
	try {
		dojo._loadUri(scriptUri);
	} catch (e) {
		console.log("EWFWidgetsPlugin loading script fail ... " + scriptUri);
	}
};

var jsFileUris = [
// "dojo/dojo-all.js"
];

for ( var i in jsFileUris) {
	var jsFileUri = jsFileUris[i];
	loadJS(jsFileUri);
}

// setup ICM runtime
dojo.setObject("ecmwdgt.contextRoot", icmContextRoot);

var paths = {
	"v11" : "/EWFWidgetsv11/v11",
	"v11/ewf" : "/EWFWidgetsv11/v11/ewf",
	"icm" : "/ICMClient/icm",
	"ecm" : "/navigator/ecm"
};
require({ paths : paths });

//is debug mode?
var currentLocation = location.href;
var isDebug = true;
if(currentLocation.indexOf("debug=true") > 0) {
	isDebug = true;
}

var cssFileUris;
if(!isDebug) {
	cssFileUris = [
		icmContextRoot + "/v11/ewf/css/ewf.css.jgz"
    ];
} else {
	cssFileUris = [
		icmContextRoot + "/v11/ewf/css/ewf.css"
    ];
}

for(var i in cssFileUris){
	var cssFileUri = cssFileUris[i];
	loadCSS(cssFileUri);
}


console.log("EWF v11 Plugin Scope: start to require files");

/*require([ "dojo/_base/declare", "dijit/_Widget", "dijit/_Templated", "dijit/_WidgetsInTemplateMixin"],
		function(declare, _Widget, _Templated, _WidgetsInTemplateMixin, parser){
			console.log("ICM Plugin Scope: end to require files");
			console.log("ICM Plugin Scope - End");
		});
*/
// modified by rahul added new DR constans file to load 
if(!isDebug) {
	console.log("EWF Widgets v11 plugin scope: no debug start");
	require(["v11/ewf/ewf", "v11/ewf/base/Constants", "v11/ewf/ewfg/base/Constants"], function(ewf, Constants, ewfgConstants){
		Constants.EWFG = ewfgConstants;
		console.log("EWF Widgets v11 plugin scope: no debug end");
	});
} else {
	console.log("EWF Widgets v11 plugin scope: debug start");	
	require([ "v11/ewf/base/Constants", "v11/ewf/ewfg/base/Constants"], function( Constants, ewfgConstants){
		console.log("EWF Widgets V11 for  plugin scope: source loaded");
		Constants.EWFG = ewfgConstants;
		console.log("EWF Widgets V11 for  plugin scope: debug end");
	});
}
require(["dojo/_base/lang","icm/util/Util","ecm/model/ProcessRole","icm/model/Solution"], function(lang,ICMUtil,ProcessRole,Solution){

var methodToOverride = function(solution1, role1, solution2, callback){
            var role2 = role1, len = 0;

            if( solution1.getPrefix() !== solution2.getPrefix() ||
                (solution1.getTargetOS().id !== solution2.getTargetOS().id)){
                    solution2.retrieveRoles(function(roles){
                        len = roles.length;
                        role2 = (len > 0) ? "Branch Enquiry Operator" : null;
                        for(i=0; i<len; i++){
                            //Assume the ecm.model.ProcessRole name is pure the pe role name without any prefix or post fix
                            if(role1.name === roles[i].name){
                                role2 = roles[i];
                                break;
                            }
                        }
                         if(callback){
                            callback(role2);
                        }
                  });
            }else{
                if(callback){
                    callback(role2);
                }
            }
        };
		ICMUtil.getMatchedRole = methodToOverride;
	});

console.log("v11 debug end");
