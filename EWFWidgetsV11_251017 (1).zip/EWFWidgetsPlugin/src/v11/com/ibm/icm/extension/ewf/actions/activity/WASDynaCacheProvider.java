package v11.com.ibm.icm.extension.ewf.actions.activity;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;

import org.apache.log4j.Logger;
import com.filenet.apiimpl.meta.Cache;
import v11.com.ibm.ewf.cache.CacheProvider;
import v11.com.ibm.ewf.config.ComponentConfig;
import v11.com.ibm.icm.extension.ewf.CommonUtils;
import com.ibm.websphere.cache.DistributedMap;

public class WASDynaCacheProvider implements CacheProvider {
	final private static String DFT_CACHE_JNDI = "services/cache/ewf_service_cache";
	final private static String CONFIG_WAS_DYNACACHE_JNDI = "dynacache.jndi";
	final private static Logger logger = Logger.getLogger(WASDynaCacheProvider.class);
	private DistributedMap cacheInstance = null;
	private static final String[] NON_SERIALIZE_PATTERNS = new String[] {
		"java.",
		"javax.",
		"sun."
	};
	
	private static final byte[] SERIALIZED_TAG = new byte[] {
		'_', '_', 'S', 'E', 'R', 'I', 'A', 'L', 'I', 'Z', 'E', 'D', '_', '_'
	};
	public static String getDynaCacheJndi() {
		String cacheJndi = DFT_CACHE_JNDI;
		ComponentConfig config = CommonUtils.getComponentConfig();
		if (config != null) {
			cacheJndi = config.get(CONFIG_WAS_DYNACACHE_JNDI, DFT_CACHE_JNDI);
		}
		return cacheJndi;
	}
	public static boolean isDynaCacheAvailable() {
		String cacheJndi = getDynaCacheJndi();
		logger.debug("isDynaCacheAvailable: cache instance JNDI : <" + cacheJndi + ">");
		boolean isCacheAvailable = false;
		try {
			InitialContext ic = new InitialContext();
			DistributedMap _cacheInstance = (DistributedMap)ic.lookup(cacheJndi);
			isCacheAvailable = (_cacheInstance != null);
		} catch (NameNotFoundException e) {
			logger.debug("isDynaCacheAvailable: dynamic cache " + cacheJndi + " is not configued.");
			isCacheAvailable = false;
		} catch (Throwable e) {
			logger.error("isDynaCacheAvailable: error occurred when detecting the dynamic cache.", e);
			isCacheAvailable = false;
		}
		logger.debug("isDynaCacheAvailable: result: " + isCacheAvailable);
		return isCacheAvailable;
	}
	
	public WASDynaCacheProvider() throws Exception {
		logger.debug("Enter WASDynCacheProvider() - the constructor");
		String cacheJndi = getDynaCacheJndi();
		logger.debug("Cache instance JNDI : <" + cacheJndi + ">");
		
		try {
			InitialContext ic = new InitialContext();
			cacheInstance = (DistributedMap)ic.lookup(cacheJndi);
		} catch (Throwable e) {
			logger.error("Error occurred in getting the cache instance. cacheJndi : " + cacheJndi, e);
			Exception exp = new Exception("Error occurred in getting the cache instance. cacheJndi : " + cacheJndi);
			exp.initCause(e);
			throw exp;
		}
		logger.debug("Exit WASDynCacheProvider() - the constructor");
	}
	
	@Override
	public void clear() {
		cacheInstance.clear();
	}

	@Override
	public boolean contains(String key) {
		return cacheInstance.containsKey(key);
	}

	@Override
	public Object get(String key) {
		Object cachedObj = null;
		cachedObj = this.cacheInstance.get(key);
		if (cachedObj != null) {
			if (cachedObj instanceof byte[] && hasSerializedTag((byte[])cachedObj)) {
				try {
					cachedObj = deserializeFromByteArray((byte[])cachedObj);
				} catch (Throwable e) {
					logger.error("Error occurred in deserializing the object from cache. The object will not be returned. Key: " + key, e);
					cachedObj = null;
				}
			}
		}
		
		return cachedObj;
	}

	@Override
	public Object invalidate(String key) {
		Object targetObj = this.get(key);
		cacheInstance.invalidate(key);
		return targetObj;
	}

	@Override
	public Object put(String key, Object cacheObj) {
		if (key == null || key.isEmpty()) {
			throw new RuntimeException("The input key is not set. Key : " + key);
		}
		if (cacheObj == null) {
			throw new RuntimeException("The input cache object is null.");
		}
		if (!(cacheObj instanceof Serializable)) {
			throw new RuntimeException("The input object does not implement Serializable. Input object class : " + cacheObj.getClass().getCanonicalName());
		}

		if (needToSerialize(cacheObj)) {
			try {
				cacheObj = serializeToByteArray(cacheObj);
			} catch (IOException e) {
				logger.error("Error occurred in serializing the object. The object will not be put the cache. Key: " 
						+ key + ", object class: " + Cache.class.getCanonicalName(), e);
				return null;
			}
		}
		Object oldObj = this.get(key);
		this.cacheInstance.put(key, cacheObj);
		return oldObj;
	}
	
	private static byte[] serializeToByteArray(Object object) throws IOException {
		if (object == null) {
			return null;
		}
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		ObjectOutputStream out = null;
		byte[] ret = null;
		try {
			byteStream.write(SERIALIZED_TAG);
			out = new ObjectOutputStream(byteStream);
			out.writeObject(object);
			out.flush();
			ret = byteStream.toByteArray();
		} finally {
			if (out != null) {
				try {out.close();} catch (Throwable e) {}
				out = null;
			}
			try {byteStream.close();} catch (Throwable e) {}
			byteStream = null;
		}
		
		return ret;
	}
	
	private static Object deserializeFromByteArray(byte[] byteArray) throws IOException, ClassNotFoundException {
		boolean hasTag = hasSerializedTag(byteArray);
		if (byteArray == null || byteArray.length == 0 || (hasTag && byteArray.length == SERIALIZED_TAG.length)) {
			return null;
		}
		ByteArrayInputStream byteStream = null;
		if (hasTag) {
			byteStream = new ByteArrayInputStream(byteArray, 
					SERIALIZED_TAG.length, byteArray.length - SERIALIZED_TAG.length);
		} else {
			byteStream = new ByteArrayInputStream(byteArray);
		}
		
		ObjectInputStream ins = null;
		Object ret = null;
		try {
			ins = new ObjectInputStream(byteStream);
			ret = ins.readObject();
		} finally {
			if (ins != null) {
				try {ins.close();} catch (Throwable e) {}
				ins = null;
			}
			try {byteStream.close();} catch (Throwable e) {}
			byteStream = null;
		}
		//logger.debug("GlobalCacheUtil: deserialized object of " + ret.getClass().getCanonicalName());
		return ret;
	}
	
	private static boolean hasSerializedTag(byte[] byteArray) {
		if (byteArray == null || byteArray.length < SERIALIZED_TAG.length) {
			return false;
		}
		boolean ret = true;
		for (int i = 0; i < SERIALIZED_TAG.length; i++) {
			if (byteArray[i] != SERIALIZED_TAG[i]) {
				ret = false;
				break;
			}
		}
		return ret;
	}
	
	private static boolean needToSerialize(Object obj) {
		String className = obj.getClass().getCanonicalName();
		boolean ret = true;
		for (String packagePrefix : NON_SERIALIZE_PATTERNS) {
			if (className.startsWith(packagePrefix)) {
				ret = false;
				break;
			}
		}
		return ret;
	}
}
