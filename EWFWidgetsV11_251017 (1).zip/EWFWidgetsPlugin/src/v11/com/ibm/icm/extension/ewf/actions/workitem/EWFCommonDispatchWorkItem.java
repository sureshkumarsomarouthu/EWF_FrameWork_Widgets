package v11.com.ibm.icm.extension.ewf.actions.workitem;

import java.io.IOException;
import java.util.Locale;

import com.ibm.ecm.extension.PluginAction;
import com.ibm.json.java.JSONObject;

public class EWFCommonDispatchWorkItem extends PluginAction
{
	private final static String CONST_ACTION_ICON = "CloseAndGetNextWorkItem.gif";

	@Override
	public String getId() {
		return "v11.ewf.action.workitem.EWFCommonDispatchWorkItem";
	}

	@Override
	public String getIcon() {
		return CONST_ACTION_ICON;
	}

	@Override
	public String getPrivilege() {
		return "";
	}

	@Override
	public boolean isMultiDoc() {
		return false;
	}

	public boolean isGlobal() {
		return false;
	}

	@Override
	public String getActionModelClass() {
		return "v11.ewf.action.workitem.EWFCommonDispatchWorkItem";
	}

	@Override
	public String getActionFunction() {
		return "performaAction";
	}

	@Override
	public String getName(Locale arg0) {
		return "Close And Get Next Work Item";
	}

	@Override
	public String getServerTypes() {
		return "p8";
	}

	@Override
	public JSONObject getAdditionalConfiguration(Locale locale) {
		String jsonString = "{\r\n" +
				"	        \"ICM_ACTION_COMPATIBLE\": true,\r\n" +
				"	        \"type\": \"iterator\",\r\n" +
				"	        \"context\": [[\"WorkItemPage\",\"Coordination\"]],\r\n" +
				"            \"name\": \"EWF Common Dispatch work item action for Credit Card Application\",\r\n" +
				"	    \"description\": \"Dispatches the work item from Credit Card Application. If the next work item is not opened automatically, this action also closes the current Work Details page. (v11)\",\r\n" +
				"            \"properties\": [\r\n" +
				"                {\r\n" +
				"                    \"id\": \"label\",\r\n" +
				"                    \"title\": \"Label\",\r\n" +
				"                    \"defaultValue\": \"Complete\",\r\n" +
				"                    \"type\": \"string\",\r\n" +
				"                    \"isLocalized\":false\r\n" +
				"                },\r\n" +
				"                {\r\n" +
				"                    \"id\": \"GetNext\",\r\n" +
				"                    \"title\": \"Automatically get the next work item\",\r\n" +
				"                    \"defaultValue\": false,\r\n" +
				"                    \"type\": \"boolean\"\r\n" +
				"                },\r\n" +
				"                {\r\n" +
				"                    \"id\": \"flat\",\r\n" +
				"                    \"title\": \"flat\",\r\n" +
				"                    \"defaultValue\": true,\r\n" +
				"                    \"type\": \"boolean\"\r\n" +
				"                }\r\n" +
				"            ],\r\n" +
				"            \"events\":[\r\n" +
				"                {\r\n" +
				"                \"id\":\"icm.WorkItemDispatched\",\r\n" +
				"                \"title\":\"Work item dispatched\",\r\n" +
				"                \"direction\":\"published\",\r\n" +
				"                \"type\":\"wiring\",\r\n" +
				"                \"description\":\"Dispatches the current work item.\"\r\n" +
				"                },\r\n" +
				"                {\r\n" +
				"                \"id\":\"icm.ClosePage\",\r\n" +
				"                \"title\":\"Close page\",\r\n" +
				"                \"direction\":\"published\",\r\n" +
				"                \"type\":\"broadcast\",\r\n" +
				"                \"description\":\"Closes the current Work Details page.\"\r\n" +
				"                }\r\n" +
				"            ]\r\n" +
				"	}";
			
		try {
			return JSONObject.parse(jsonString);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}

