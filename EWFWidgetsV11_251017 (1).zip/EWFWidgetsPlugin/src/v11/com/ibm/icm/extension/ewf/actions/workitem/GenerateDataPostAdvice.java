package v11.com.ibm.icm.extension.ewf.actions.workitem;

import java.io.IOException;
import java.util.Locale;

import com.ibm.ecm.extension.PluginAction;
import com.ibm.json.java.JSONObject;

public class GenerateDataPostAdvice extends PluginAction
{
	private final static String CONST_ACTION_ICON = "GenerateDataPostAdvice.gif";

	@Override
	public String getId() {
		return "v11.ewf.action.workitem.GenerateDataPostAdvice";
	}

	@Override
	public String getIcon() {
		return CONST_ACTION_ICON;
	}

	@Override
	public String getPrivilege() {
		return "";
	}

	@Override
	public boolean isMultiDoc() {
		return false;
	}

	public boolean isGlobal() {
		return false;
	}

	@Override
	public String getActionModelClass() {
		return "v11.ewf.action.workitem.GenerateDataPostAdvice";
	}

	@Override
	public String getActionFunction() {
		return "performaAction";
	}

	@Override
	public String getName(Locale arg0) {
		return "Generate DataPost Advice Letter";
	}

	@Override
	public String getServerTypes() {
		return "p8";
	}

	@Override
	public JSONObject getAdditionalConfiguration(Locale locale) {
		String jsonString = "{\r\n" +
				"	        \"ICM_ACTION_COMPATIBLE\": true,\r\n" +
				"	        \"context\": [[\"WorkItemPage\",\"Coordination\"]],\r\n" +
				"            \"name\": \"Generate DataPost advice letter\",\r\n" +
				"	    \"description\": \"The action is for invoking a dialog to generate an advice to data post. (v11)\",\r\n" +
				"            \"properties\": [\r\n" +
				"                {\r\n" +
				"                    \"id\": \"label\",\r\n" +
				"                    \"title\": \"Generate data post advice letter\",\r\n" +
				"                    \"defaultValue\": \"Advice\",\r\n" +
				"                    \"type\": \"string\",\r\n" +
				"                    \"isLocalized\":false\r\n" +
				"                }\r\n" +
				"            ],\r\n" +
				"            \"events\":[\r\n" +
				"            ]\r\n" +
				"	}";
			
		try {
			return JSONObject.parse(jsonString);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}

