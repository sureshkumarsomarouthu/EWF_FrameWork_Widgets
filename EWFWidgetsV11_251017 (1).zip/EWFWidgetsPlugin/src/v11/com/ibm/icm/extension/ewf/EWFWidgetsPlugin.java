package v11.com.ibm.icm.extension.ewf;

import java.util.Locale;


import com.ibm.ecm.extension.Plugin;
import com.ibm.ecm.extension.PluginAction;
import com.ibm.ecm.extension.PluginLayout;
import com.ibm.ecm.extension.PluginService;
import v11.com.ibm.icm.extension.ewf.actions.activity.Complete;
import v11.com.ibm.icm.extension.ewf.actions.activity.HideDetail;
import v11.com.ibm.icm.extension.ewf.actions.activity.FollowUp;
import v11.com.ibm.icm.extension.ewf.actions.activity.Confirmed;
import v11.com.ibm.icm.extension.ewf.actions.activity.Denied;
import v11.com.ibm.icm.extension.ewf.actions.activity.Rework;
import v11.com.ibm.icm.extension.ewf.actions.activity.Reviewed;
import v11.com.ibm.icm.extension.ewf.actions.activity.OverrideOrFail;

import v11.com.ibm.icm.extension.ewf.services.activity.EWFActivityService;
import v11.com.ibm.icm.extension.ewf.services.advice.EWFAdviceService;
import v11.com.ibm.icm.extension.ewf.services.email.EWFEmailService;
import v11.com.ibm.icm.extension.ewf.actions.workitem.CloseAndGetNextWorkItem;
import v11.com.ibm.icm.extension.ewf.actions.workitem.GenerateAdviceLetter;
import v11.com.ibm.icm.extension.ewf.actions.workitem.GenerateDataPostAdvice;
import v11.com.ibm.icm.extension.ewf.actions.auditviewer.AuditPrint;
import v11.com.ibm.icm.extension.ewf.actions.workitem.DispatchMPWorkItemAndClosePage;
import v11.com.ibm.icm.extension.ewf.actions.workitem.DispatchSignatureProcessingWorkItemAndClosePage;
import v11.com.ibm.icm.extension.ewf.actions.workitem.DispatchReviewWorkItemAndClosePage;
import v11.com.ibm.icm.extension.ewf.actions.workitem.DispatchCallBackWorkItemAndClosePage;
import v11.com.ibm.icm.extension.ewf.actions.workitem.DispatchDRWorkItemAndClosePage;
import v11.com.ibm.icm.extension.ewf.actions.workitem.DispatchExceptionHandlingWorkItemAndClosePage;
import v11.com.ibm.icm.extension.ewf.actions.callback.CallBackCheckList;
import v11.com.ibm.icm.extension.ewf.layout.EWFLayout;
import v11.com.ibm.icm.extension.ewf.services.umm.EWFUMMService;
import v11.com.ibm.icm.extension.ewf.services.casepropsfilter.EWFCaseService;
import v11.com.ibm.icm.extension.ewf.services.bulkprint.BulkPrintPluginService;
import v11.com.ibm.icm.extension.ewf.actions.workitem.EWFCommonDispatchWorkItem;

public class EWFWidgetsPlugin extends Plugin {

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return "EWFWidgetsPluginv11";
	}

	@Override
	public String getName(Locale locale) {
		// TODO Auto-generated method stub
		String name = NLSResources.getMessage(locale, "icm.plugin.name");
		return name;
	}

	@Override
	public String getVersion() {
		// TODO Auto-generated method stub
		return "1.0";
	}

	@Override
	public PluginAction[] getActions() {
		return new PluginAction[] { new Complete(), new HideDetail(), new FollowUp(), 
			new Confirmed(), new Denied(),
			new Rework(), new Reviewed(), new OverrideOrFail(),
			new CloseAndGetNextWorkItem(),
			new GenerateAdviceLetter(),
			new GenerateDataPostAdvice(),
			new AuditPrint(),
			new DispatchMPWorkItemAndClosePage(),
			new DispatchSignatureProcessingWorkItemAndClosePage(),
			new DispatchReviewWorkItemAndClosePage(),
			new DispatchCallBackWorkItemAndClosePage(),
			new DispatchExceptionHandlingWorkItemAndClosePage(),
			new CallBackCheckList(),
			new EWFCommonDispatchWorkItem(),
			new DispatchDRWorkItemAndClosePage()};
			
	}

	@Override
	public String getScript() {
		return "EWFWidgetsPluginv11.js";
	}
	
	@Override
	public PluginLayout[] getLayouts() {
		return new PluginLayout[] { new EWFLayout() };
	}
	
	@Override
	public PluginService[] getServices() {
		return new PluginService[] {new EWFActivityService(), new EWFAdviceService(), new EWFEmailService(), new EWFUMMService(), new EWFCaseService(), 
									new BulkPrintPluginService()};
	}

}
