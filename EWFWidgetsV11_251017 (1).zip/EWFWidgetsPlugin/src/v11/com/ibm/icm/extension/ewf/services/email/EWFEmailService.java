package v11.com.ibm.icm.extension.ewf.services.email;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Annotation;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.CustomObject;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.IndependentlyPersistableObject;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.util.UserContext;
import com.ibm.ecm.extension.PluginLogger;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import v11.com.ibm.ewf.activity.EWFActivityOp;
import v11.com.ibm.ewf.activity.EWFActivityUtil;
import v11.com.ibm.ewf.email.EWFEmailTemplateManager;
import v11.com.ibm.ewf.advice.Template;
import v11.com.ibm.ewf.config.ComponentConfig;
import v11.com.ibm.icm.extension.ewf.CommonUtils;
import v11.com.ibm.icm.extension.ewf.services.activity.EWFActivityService;
import v11.com.ibm.ewf.util.DAOUtil;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class EWFEmailService extends PluginService {

	final static private Logger logger = Logger.getLogger(EWFEmailService.class);
	static private int icnLogLevel = -99999;
	final static private Object logLevelUpdateLocker = new Object();

	private static final String URLPARM_REPOSITORY_ID = "repositoryId";
	private static final String URLPARM_CASE_ID = "caseId";
	private static final String URLPARM_METHOD = "method";

	private static final String PREFIX_METHOD = "method_";
	private static final String MIMETYPE_JSON = "application/json";
	private static final String JSONKEY_TEMPLATE = "template";
	private static final String DFT_CE_CLASS_EMAIL_DOC = "NonScannedDocument";
	
	private static final Object configEmailTemplateLocker = new Object();
	
	private static String emailDocCeClass = DFT_CE_CLASS_EMAIL_DOC;

	final private static String[] loggingPackageClassList = new String[] {
		"v11.com.ibm.icm.extension.ewf.services.email",
		"v11.com.ibm.icm.extension.ewf.services.activity",
		"v11.com.ibm.ewf.activity",
		"v11.com.ibm.ewf.cache"
	};
	
	final private static String[] docx4jPackages = new String[] {
		"org.docx4j",
		"o.d",
		"com.topologi"
	};

	private static final HashMap<String, Method> methodMap = new HashMap<String, Method> ();

	public EWFEmailService() {
		;
	}


	@SuppressWarnings("rawtypes")
	@Override
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String methodName = "execute";
		callbacks.getLogger().logEntry(this, methodName, request);
		matchLogLevel(callbacks.getLogger());
		EWFActivityService.initCache(this, callbacks);
		configEmailTemplate(this, callbacks);

		String requestMethod = request.getParameter(URLPARM_METHOD);
		if (requestMethod == null || requestMethod.trim().isEmpty()) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			callbacks.getLogger().logError(this, methodName, request, "The required URL parameter 'method' is not provided.");
			//genErrorJson(999, "The required URL parameter 'method' is not provided.").serialize(response.getWriter());
			return;
		}

		requestMethod = PREFIX_METHOD + requestMethod;

		Method methodToInvoke = methodMap.get(requestMethod);
		if (methodToInvoke == null) {
			try {
				methodToInvoke = this.getClass().getMethod(requestMethod, PluginServiceCallbacks.class, HttpServletRequest.class, HttpServletResponse.class);
			} catch (NoSuchMethodException e) {
				response.setContentType(MIMETYPE_JSON);
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				//genErrorJson(999, "The method " + requestMethod + " is not found.").serialize(response.getWriter());
				callbacks.getLogger().logError(this, methodName, request, "The method " + requestMethod + " is not found.");
				Exception exp = new Exception("The method " + requestMethod + " is not found.");
				exp.initCause(e);
				throw exp;
			} catch (SecurityException e) {
				response.setContentType(MIMETYPE_JSON);
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				//genErrorJson(999, "The method " + requestMethod + " is not accessible.").serialize(response.getWriter());
				callbacks.getLogger().logError(this, methodName, request, "The method " + requestMethod + " is not accessible.");
				Exception exp = new Exception("The method " + requestMethod + " is not accessible.");
				exp.initCause(e);
				throw exp;
			}
			if (methodToInvoke == null) {
				callbacks.getLogger().logError(this, methodName, request, "Error happened in fetching the executable method. Terminate the request.");
				Exception exp = new Exception("Error happened in fetching the executable method. Terminate the request.");
				throw exp;
			}
			synchronized (methodMap) {
				if (!methodMap.containsKey(requestMethod)) {
					methodMap.put(requestMethod, methodToInvoke);
				}
			}
		}

		callbacks.getLogger().logDebug(this, methodName, request, "Invoking method " + requestMethod + " ...");
		long invokeStart = System.currentTimeMillis();
		try {
			methodToInvoke.invoke(this, callbacks, request, response);
		} catch (InvocationTargetException ite) {
			Throwable t = ite.getCause();
			if (t == null) {
				t = ite;
			}
			logger.error("Error occurred in invoking method " + requestMethod, t);
			callbacks.getLogger().logError(this, methodName, "Error occurred in invoking method " + requestMethod, t);
			if (t instanceof Exception) {
				throw (Exception) t;
			} else if (t instanceof RuntimeException) {
				throw (RuntimeException) t;
			} else {
				throw ite;
			}
		}
		long invokeEnd = System.currentTimeMillis();
		callbacks.getLogger().logDebug(this, methodName, request, "Method " + requestMethod + " completed. Time elapsed : " + (invokeEnd - invokeStart) + " msec");

		callbacks.getLogger().logDebug(this, methodName, request, "Post-execute process - prepare the templates");
		prepareTemplates();
		callbacks.getLogger().logDebug(this, methodName, request, "Post-execute process ends");
		callbacks.getLogger().logExit(this, methodName, request);
	}

	@Override
	public String getId() {
		return "EWFEmailService";
	}

	public void method_listTemplate(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_listTemplate";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);
		response.setContentType(MIMETYPE_JSON);
		String caseType = request.getParameter("caseType");
		JSONObject jsonRoot = templateNamesToJson(EWFEmailTemplateManager.getInstance().listTemplateNames(caseType, true));
		jsonRoot.serialize(response.getWriter());

		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}

	public void method_getTemplateData(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_listEmailField";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);

		String caseId = request.getParameter("caseId");
		String templateName = request.getParameter("template");
		String repositoryId = request.getParameter("repositoryId");
		String prefillValue = request.getParameter("prefillValue");

		logger.debug("method_listEmailField: repositoryId: " + repositoryId + 
				", caseId: " + caseId + 
				", templateName: " + templateName +
				"prefillValue: " + prefillValue);

		Subject subject = callbacks.getP8Subject(repositoryId);

		if (subject == null) {
			throw new Exception("Cannot get the subject for repositoryId : " + repositoryId);
		}

		UserContext.get().pushSubject(subject);
		ObjectStore os = callbacks.getP8ObjectStore(repositoryId);

		logger.debug("method_listEmailField: connected to CE.");
		JSONObject jsonRoot = null;
		try {
			jsonRoot = listTemplateField(os, caseId, templateName, Boolean.TRUE.toString().equalsIgnoreCase(prefillValue));
		} finally {
			UserContext.get().popSubject();
		}

		response.setContentType(MIMETYPE_JSON);
		jsonRoot.serialize(response.getWriter());

		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	// Added by Rahul to get ToEmail from Database for Notify to Scan HUB response
	public void method_getTemplateToEmail(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String methodName = "method_getTemplateToEmail";
		callbacks.getLogger().logEntry(this, methodName, request);
		logger.debug("Enter " + methodName);

		String caseId = request.getParameter("caseId");
		String templateName = request.getParameter("template");
		String repositoryId = request.getParameter("repositoryId");
		String caseType = request.getParameter("caseType");
		String prefillValue = request.getParameter("prefillValue");
		logger.debug("method_getTemplateToEmail: repositoryId: " + repositoryId + 
				", caseId: " + caseId + 
				", templateName: " + templateName +
				"prefillValue: " + prefillValue +
				"caseType: " + caseType);
		
		ComponentConfig config = CommonUtils.getComponentConfig();
		String sqlQuery = config.get("notifyscanhub.to.email.db.query");
		logger.debug("sqlQuery ->"+sqlQuery);
		JSONObject jsonRoot = null;
		
		jsonRoot = DAOUtil.getInstance().getToEmailFromDB(templateName, caseType, sqlQuery);

		response.setContentType(MIMETYPE_JSON);
		jsonRoot.serialize(response.getWriter());

		callbacks.getLogger().logExit(this, methodName, request);
		logger.debug("Exit " + methodName);
	}
	
	
	private static JSONObject genErrorJson(int errCode, String errMsg) {
		JSONObject jsonResp = new JSONObject();
		JSONObject jsonMsg = new JSONObject();

		jsonResp.put("messages", jsonMsg);
		jsonMsg.put("adminResponse", null);
		jsonMsg.put("moreInformation", null);
		jsonMsg.put("explanation", null);
		jsonMsg.put("number", Integer.toString(errCode));
		jsonMsg.put("userResponse", null);
		jsonMsg.put("text", errMsg);
		return jsonResp;
	}
	
	private static void matchLogLevel(PluginLogger pluginLogger) {
		int newIcnLevel = pluginLogger.getLogLevel();
		if (newIcnLevel == icnLogLevel) {
			return;
		}
		synchronized (logLevelUpdateLocker) {
			if (newIcnLevel == icnLogLevel) {
				return;
			}
			Level log4jLevel = Level.ERROR;
			switch (newIcnLevel) {
			case PluginLogger.LOG_DEBUG:
			case PluginLogger.LOG_DEV:
			case PluginLogger.LOG_ENTRY:
			case PluginLogger.LOG_EXIT:
				log4jLevel = Level.DEBUG;
				break;
			case PluginLogger.LOG_INFO:
				//case PluginLogger.LOG_PERF:
				log4jLevel = Level.INFO;
				break;
			case PluginLogger.LOG_WARNING:
				log4jLevel = Level.WARN;
				break;
			case PluginLogger.LOG_ERROR:
				log4jLevel = Level.ERROR;
				break;
			default : 
				log4jLevel = Level.ERROR;
				break;
			}
			setLogLevelForLoggers(loggingPackageClassList, log4jLevel);
			setLogLevelForLoggers(docx4jPackages, Level.ERROR);
			icnLogLevel = newIcnLevel;
		}
	}
	
	private static void setLogLevelForLoggers(String[] loggerNameList, Level level) {
		for (String loggerName : loggerNameList) {
			if (loggerName == null || loggerName.isEmpty()) {
				continue;
			}
			Logger curLogger = Logger.getLogger(loggerName);
			if (!level.equals(curLogger.getLevel())) {
				curLogger.setLevel(level);
				/*
				Enumeration appenderEnum = curLogger.getAllAppenders();
				Appender appender = null;
				while (appenderEnum.hasMoreElements()) {
					appender = (Appender) appenderEnum.nextElement();
					if (appender instanceof org.apache.log4j.ConsoleAppender) {
						break;
					}
				}
				if (appender == null) {
					appender = new org.apache.log4j.ConsoleAppender();
					curLogger.addAppender(appender);
				}
				curLogger.isAttached(appender)
				appender.
				 */
			}
		}
	}

	public void method_test(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
	}

	private static JSONObject templateNamesToJson(Map<String, String> templateNames) {
		if (templateNames == null) {
			return null;
		}
		JSONObject jsonChoiceList = new JSONObject();
		JSONArray jsonChoiceArray = new JSONArray();
		jsonChoiceList.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, EWFActivityUtil.PSEUDO_CHOICELIST_EMAIL_TEMPLATE_LIST);
		jsonChoiceList.put(EWFActivityUtil.JSONKEY_CHOICES, jsonChoiceArray);
		for (String templateName : templateNames.keySet()) {
			JSONObject jsonChoice = new JSONObject();
			jsonChoice.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, templateNames.get(templateName));
			jsonChoice.put(EWFActivityUtil.JSONKEY_VALUE, templateName);
			jsonChoiceArray.add(jsonChoice);
		}
		return jsonChoiceList;
	}
	
	private static JSONObject listTemplateField(ObjectStore os, String caseId, String templateName, boolean prefillValue) throws Exception {
		EWFEmailTemplateManager manager = EWFEmailTemplateManager.getInstance();
		Template template = manager.getTemplate(templateName);
		LinkedHashMap<String, JSONObject> fieldsMap = null;
		if (prefillValue) {
			Folder caseFolder = EWFActivityOp.fetchCaseFolderFromCe(os, caseId);
			fieldsMap = template.listFieldsWithValue(os, caseFolder);
		} else {
			fieldsMap = template.listFields();
		}
		
		//Only for Email Service
//		java.util.List<String> paragraphs = template.getTemplateContentAsString(fieldsMap);
//		JSONObject fieldJson = new JSONObject();
//		fieldJson.put("TemplateData", (paragraphs != null) ? paragraphs.toString(): "No data retrieved");
//		fieldsMap.put("TemplateData", fieldJson);
		//Only for Email Service
		HashMap<String, String> fieldsMapForTemplateContent = new HashMap<String, String> ();
		
		//Only for Email Service
				for (String fieldName : fieldsMap.keySet()) {
					if((fieldsMap != null) && (fieldsMap.get(fieldName) != null)){
						JSONObject tmp = fieldsMap.get(fieldName);
						System.out.println("Getting Field --> " + fieldName + " --> " + tmp.get(EWFActivityUtil.JSONKEY_VALUE));
						fieldsMapForTemplateContent.put(fieldName, (String)tmp.get(EWFActivityUtil.JSONKEY_VALUE));
					} else
						fieldsMapForTemplateContent.put(fieldName, "");
				}
				String templateContent = template.getTemplateContentAsString(fieldsMapForTemplateContent);
				JSONObject fieldJson = new JSONObject();
				fieldJson.put("TemplateData", (templateContent != null) ? templateContent: "No data retrieved");
				fieldsMap.put("TemplateData", fieldJson);
		//Only for Email Service		
		
		
		JSONObject jsonRoot = new JSONObject();
		jsonRoot.put(EWFActivityUtil.JSONKEY_TEMPLATE, template.getSymbolicName());
		jsonRoot.put(EWFActivityUtil.JSONKEY_DISPLAY_NAME, template.getDisplayName());
		jsonRoot.put(EWFActivityUtil.JSONKEY_RENDER_DIJIT_CLASS, template.getRenderDijitClass());
		//jsonRoot.put(EWFActivityUtil.JSONKEY_ID, template.getName());
		//jsonRoot.put(EWFActivityUtil.JSONKEY_DESCRIPTION, template.getName());
		JSONArray propArray = new JSONArray();
		jsonRoot.put(EWFActivityUtil.JSONKEY_PROP_ARRAY_FOR_ICN_CONTENT_LIST, propArray);
		Iterator<String> iter = fieldsMap.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			JSONObject jsonField = fieldsMap.get(key);
			propArray.add(jsonField);
		}
		return jsonRoot;
	}
	

	public static void configEmailTemplate(PluginService pluginService, PluginServiceCallbacks callbacks) throws Exception {
		if (EWFEmailTemplateManager.isConfigured()) {
			return;
		}
		synchronized (configEmailTemplateLocker) {
			if (EWFEmailTemplateManager.isConfigured()) {
				return;
			}
			ComponentConfig config = CommonUtils.getComponentConfig();
			EWFEmailTemplateManager.config(config, false);
			emailDocCeClass = config.get(EWFActivityUtil.CONFIG_EMAIL_DOC_CLASS, DFT_CE_CLASS_EMAIL_DOC);
		}
	}
	public static void prepareTemplates() {
		if (!EWFEmailTemplateManager.isConfigured()) {
			return;
		}
		EWFEmailTemplateManager.getInstance().prepareAll(2);
	}

}
