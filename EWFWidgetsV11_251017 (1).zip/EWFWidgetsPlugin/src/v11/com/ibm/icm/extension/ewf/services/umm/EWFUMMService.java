/**
 * 
 */
package v11.com.ibm.icm.extension.ewf.services.umm;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.ibm.ecm.extension.PluginLogger;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import v11.com.ibm.ewf.config.Credential;
import v11.com.ibm.icm.extension.ewf.CommonUtils;
import com.ibm.json.java.JSONObject;

/**
 * @author HD
 * 
 */
public class EWFUMMService extends PluginService {
	
	private DefaultHttpClient httpclient = new DefaultHttpClient();
	private final static String ummConCookies = "UMM_COOKIES";
	//private String sessionId;
	//private final static String tokenName = "LtpaToken2";
	private String token;
	//private String protocol = "http";
	//private String hostName;
	//private int port;
	private String userName;
	private String password;
	private String domain;
	private String ummURL;
	static private int icnLogLevel = -99999;
	private final static Object logLevelUpdateLocker = new Object();
	private final static String[] loggingPackageClassList = new String[] { "v11.com.ibm.icm.extension.ewf.services.umm" };
	private Map<String, String> cookies = new HashMap<String, String>();

	private int retryTimes = 0;

	public static final String MIMETYPE_JSON = "application/json";

	public static final String ParamSubUmmPathName = "subUmmPath";

	/**
	 * 
	 */
	public EWFUMMService() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seecom.ibm.ecm.extension.PluginService#execute(com.ibm.ecm.extension.
	 * PluginServiceCallbacks, javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		String methodName = "execute";
		callbacks.getLogger().logEntry(this, methodName, request);
		matchLogLevel(callbacks.getLogger());
		try {
			HashMap<String, List<String>> requestParams = getRequestParams(request);
			if (requestParams == null) {
				callbacks.getLogger().logError(this, methodName, request, "requestParams is null.");
				outputBadRequest(response, "subUmmPath is not specified.");
				return;
			} else {
				List<String> vValues = requestParams.get(EWFUMMService.ParamSubUmmPathName);
				if (vValues.size() > 0) {
					String subUmmPath = vValues.get(0);
					if (subUmmPath == null || subUmmPath.trim().length() == 0) {
						callbacks.getLogger().logError(this, methodName, request, "subUmmPath is not specified.");
						outputBadRequest(response, "subUmmPath is not specified.");
						return;
					} else {
						initUmmParameters();
						String fullUmmURL = ummURL + URLDecoder.decode(subUmmPath, "UTF-8");
						callbacks.getLogger().logDebug(this, methodName, request,
								"The full UMM service URL  is:  " + fullUmmURL);
						String result = null;

						result = callUmm(callbacks,request, fullUmmURL, request.getMethod());
						callbacks.getLogger()
								.logDebug(this, methodName, request, "UMM service response is:  " + result);
						if (result == null) {
							outputBadRequest(response, "response is null, UMM service API does not work correctly.");
							callbacks.getLogger().logError(this, methodName, request,
									"response is null, UMM service API does not work correctly.");

						} else {
							response.setStatus(HttpServletResponse.SC_OK);
							response.setBufferSize(result.length());
							response.getWriter().write(result);
							response.flushBuffer();

						}
					}
				} else {
					outputBadRequest(response, "subUmmPath is not specified.");
					callbacks.getLogger().logError(this, methodName, request, "subUmmPath is not specified.");

				}
			}
		} catch (Exception e) {
			callbacks.getLogger().logError(this, methodName, request,
					"Error occurs when processing UMM service invocation", e);
			outputBadRequest(response, "Error occurs when processing UMM service invocation");
		} 
		
		callbacks.getLogger().logExit(this, methodName, request);
	}

	/**
	 * @param response
	 * @param message
	 * @throws IOException
	 */
	private void outputBadRequest(HttpServletResponse response, String message) throws IOException {
		response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
		JSONObject jo = new JSONObject();
		jo.put("status", "Bad reqeust");
		jo.put("message", message);
		jo.serialize(response.getWriter());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ibm.ecm.extension.PluginService#getId()
	 */
	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return "EWFUMMService";
	}

	private HashMap<String, List<String>> getRequestParams(HttpServletRequest request) {

		/**
		 * 2008/8/13: Q: need to set the character encoding to UTF-8 for correct
		 * decoding of the param. This requires that the query string or form
		 * POST to be url-encoded of UTF-8 encoded strings.
		 */
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		HashMap<String, List<String>> res = new HashMap<String, List<String>>(5);

		// get all the request header?, or just a few..
		if (request == null) {
			return null;
		}
		Enumeration<String> headerNamesEnum = request.getHeaderNames();
		while (headerNamesEnum.hasMoreElements()) {
			String s = (String) headerNamesEnum.nextElement();

			Enumeration<String> valuesEnum = request.getHeaders(s);
			List<String> vValues = new ArrayList<String>(1);
			int count = 0;
			while (valuesEnum.hasMoreElements())
				vValues.add((String) valuesEnum.nextElement());

			res.put(s, vValues);
		}

		// get the other parameters from query String
		// if the query string is something like this:
		// opt=opt1,opt2&num=1,2,3
		//
		// prefers that opt to have a List<String> with {opt1, opt2}
		//
		Enumeration<String> paramNamesEnum = request.getParameterNames();
		while (paramNamesEnum.hasMoreElements()) {
			String s = (String) paramNamesEnum.nextElement();
			String[] values = request.getParameterValues(s);
			int nValues = values == null ? 0 : values.length;
			List<String> vValues = new ArrayList<String>(nValues);

			for (int i = 0; i < nValues; i++)
				vValues.add(values[i]);
			res.put(s, vValues);
		}

		return res;
	}

	private static void configSSL(final HttpsURLConnection httpsConnection) {
		/*
		 * Modify verifier to not verify the host. Siteminder uses a proxy
		 * server, so the final request will go to a different server than the
		 * initial request. This means that the server we need to connect to
		 * will change, which can cause an issue if we do not disable host name
		 * checking.
		 */
		httpsConnection.setHostnameVerifier(new X509HostnameVerifier() {
			public void verify(String string, SSLSocket ssls) throws IOException {
			}

			public void verify(String string, X509Certificate xc) throws SSLException {
			}

			public void verify(String string, String[] strings, String[] strings1) throws SSLException {
			}

			public boolean verify(String string, SSLSession ssls) {
				return true;
			}
		});
		final javax.net.ssl.X509TrustManager xtm = new javax.net.ssl.X509TrustManager() {

			public void checkClientTrusted(final X509Certificate[] chain, final String authType)
					throws CertificateException {
			}

			public void checkServerTrusted(final X509Certificate[] chain, final String authType)
					throws CertificateException {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

		};

		final javax.net.ssl.TrustManager mytm[] = { xtm };
		javax.net.ssl.SSLContext ctx;
		try {
			ctx = javax.net.ssl.SSLContext.getInstance("SSL");
			ctx.init(null, mytm, null);
			final javax.net.ssl.SSLSocketFactory sf = ctx.getSocketFactory();
			httpsConnection.setSSLSocketFactory(sf);
		} catch (final NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		} catch (final KeyManagementException e) {
			throw new RuntimeException(e);
		}
	}

	public static void extractCookie(final HttpURLConnection connection, final Map<String, String> cookies) {
		final Map<String, List<String>> headers = connection.getHeaderFields();
		final List<String> setCookies = headers.get("Set-Cookie");
		if (setCookies != null) {
			for (String cookie : setCookies) {
				if (cookie.indexOf(";") != -1) {
					cookie = cookie.substring(0, cookie.indexOf(";"));
					final int index = cookie.indexOf('=');
					if (index != -1) {
						final String cookieName = cookie.substring(0, index);
						final String cookieValue = cookie.substring(index + 1);
						cookies.put(cookieName, cookieValue);
					}
				}
			}
		}

	}

	public void initUmmParameters() {
		
		ummURL = CommonUtils.getComponentConfig().get(CommonUtils.REST_UMM_URL);
		Credential cr =  CommonUtils.getComponentConfig().getCredentialStore().get(CommonUtils.REST_UMM_CREDENTIAL);
		userName = cr.getUsername();
		password = cr.getPassword();
		
		System.out.println("ummURL = " + ummURL);
		System.out.println("userName  = "+ userName);
		
//		ummURL = "https://9.112.249.46:9444/uam";
//		domain = "NTSGPDOM";
//		domain = null;
//		userName = "ewfusr06";
//		// userName="EWFUICMADM";
//		userName = "EWFUUMMADM";
//		password = "P@ssw0rd";
	}

	/**
	 * @param urlString
	 * @return
	 * @throws IOException
	 */
	public static HttpURLConnection getURLConnection(final String urlString) throws IOException {

		final URL url = new URL(urlString);
		final HttpURLConnection connection = (HttpURLConnection) url.openConnection();

		if (connection instanceof HttpsURLConnection) {
			EWFUMMService.configSSL((HttpsURLConnection) connection);
		}

		connection.setDefaultUseCaches(false);
		connection.setUseCaches(false);
		connection.setReadTimeout(100000);
		final java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z",
				java.util.Locale.US);
		format.setTimeZone(java.util.TimeZone.getTimeZone("GMT"));
		final String date = format.format(new java.util.Date());
		connection.setRequestProperty("Date", date);

		return connection;

	}

	/**
	 * @param callbacks
	 * @throws Exception
	 */
	public void logonUmm(PluginServiceCallbacks callbacks, HttpServletRequest request) throws Exception {
		String methodName = "logonUmm";
		callbacks.getLogger().logEntry(this, methodName);
		callbacks.getLogger().logDebug(this, methodName, "ummURL = "+ummURL);
		callbacks.getLogger().logDebug(this, methodName, "domain = "+domain+ "userName = "+userName);
		String location = null;

		HttpURLConnection connectionPost = null;
		try {

			connectionPost = EWFUMMService.getURLConnection(ummURL + "/j_security_check");
			connectionPost.setRequestMethod("POST");
			connectionPost.setDoOutput(true);
			connectionPost.setDoInput(true);
			connectionPost.setInstanceFollowRedirects(false);
			if (token != null) {
				connectionPost.setRequestProperty("Authorization", "Negotiate " + token);
			}
			connectionPost.connect();

			final PrintWriter output = new PrintWriter(new OutputStreamWriter(connectionPost.getOutputStream()));
			output.print("j_domain=");
			output.print((domain == null) ? "" : domain);
			output.print("&");
			output.print("j_username=");
			output.print((domain == null) ? userName : userName + "@" + domain);
			output.print("&");
			output.print("j_password=");
			output.print(password);
			output.flush();

			final int status = connectionPost.getResponseCode();
			callbacks.getLogger().logDebug(this, methodName,"Logon UMM status code =  " + status);
			location = connectionPost.getHeaderField("Location");
			callbacks.getLogger().logDebug(this, methodName, "Location = "+ location);
			//System.out.println("Location = " + location);
			if (location != null) {
				callbacks.getLogger().logDebug(this, methodName,"MashupMakerProxy.loginMashupMaker() - Redirecting to : " + location);
			}
			EWFUMMService.extractCookie(connectionPost, cookies);
			request.getSession().setAttribute(ummConCookies, EWFUMMService.toCookieString(cookies));
			callbacks.getLogger().logDebug(this, methodName,"cookies : " + cookies);
			//System.out.println(this.toCookieString(cookies));
			output.close();
		} finally {
			if (connectionPost != null) {
				connectionPost.disconnect();
			}
			callbacks.getLogger().logExit(this, methodName);
		}
	}

	private void logout(PluginServiceCallbacks callbacks) {
		String url = ummURL + "/logout";
		String methodName = "logout";
		callbacks.getLogger().logEntry(this, methodName);
		callbacks.getLogger().logDebug(this, methodName, "url = "+url);
		HttpResponse response = null;
		HttpGet getMethod = new HttpGet(url);
		String responseStr = null;
		try {
			response = this.httpclient.execute(getMethod);

			callbacks.getLogger().logDebug(this, methodName,"Logout = " + response.getStatusLine().getStatusCode());
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			responseStr = responseHandler.handleResponse(response);
		} catch (ClientProtocolException e) {
			callbacks.getLogger().logError(this, methodName,e);
			//e.printStackTrace();
		} catch (IOException e) {
			callbacks.getLogger().logError(this, methodName,e);
		} finally {

		}
	}

	/**
	 * @param userName
	 * @return
	 */
//	private String getUserDetails0(String userName) {
//		HttpResponse response = null;
//		HttpGet getMethod = new HttpGet(ummURL + "/uamusers/userdetails?username=" + userName);
//		String responseStr = null;
//		try {
//			response = this.httpclient.execute(getMethod);
//
//			Header[] headers = response.getAllHeaders();
//			for (int i = 0; i < headers.length; i++) {
//				Header h = headers[i];
//				if (h.getName().equalsIgnoreCase("Location")) {
//					System.out.println("Location = " + h.getValue());
//				}
//				System.out.println(h.getName() + " = " + h.getValue());
//			}
//			System.out.println(response.getStatusLine().getStatusCode());
//			System.out.println("=======================");
//			ResponseHandler<String> responseHandler = new BasicResponseHandler();
//			responseStr = responseHandler.handleResponse(response);
//			// System.out.println(responseStr);
//
//			if (response == null) {
//
//				// throw acme;
//			}
//		} catch (ClientProtocolException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} finally {
//			return responseStr;
//		}
//
//	}

	@SuppressWarnings("finally")
	private String callUmm(PluginServiceCallbacks callbacks,HttpServletRequest request, String fullUmmURL, String method) throws Exception {
		String methodName = "execute";
		callbacks.getLogger().logEntry(this, methodName);
		callbacks.getLogger().logDebug(this, methodName, "fullUmmURL = "+fullUmmURL+" ; method = "+ method);
		String content = null;
		HttpURLConnection connection = null;
		try {
			if(request.getSession().getAttribute(ummConCookies)== null){
				callbacks.getLogger().logDebug(this, methodName, "Calling logonUMM()");
				this.logonUmm(callbacks, request);
			}

			connection = EWFUMMService.getURLConnection(fullUmmURL);
			connection.setRequestMethod(method);
			connection.setInstanceFollowRedirects(false);
			connection.setDoOutput(true);
			connection.setRequestProperty("Cookie", (String)request.getSession().getAttribute(ummConCookies));
			callbacks.getLogger().logDebug(this, methodName, "calling UMM rest service using cookies: "+ EWFUMMService.toCookieString(cookies));
			connection.connect();
			int responseCode = connection.getResponseCode();
			String responseStr = connection.getResponseMessage();
			callbacks.getLogger().logDebug(this, methodName, "responseCode: "+ responseCode);
			callbacks.getLogger().logDebug(this, methodName, "responseStr: "+ responseStr);
			System.out.println("responseCode = " + responseCode);
			System.out.println("responseStr = " + responseStr);
			if (responseCode == 200) {
				InputStream is = connection.getInputStream();

				int i = -1;
				byte[] b = new byte[1024];
				StringBuffer sb = new StringBuffer();
				while ((i = is.read(b)) != -1) {
					sb.append(new String(b, 0, i));
				}
				content = sb.toString();
				callbacks.getLogger().logDebug(this, methodName, "response content: "+ content);
				is.close();
			} else if (responseCode == 302 && retryTimes<2) {
				request.getSession().setAttribute(ummConCookies, null);
				retryTimes++;
				String location = connection.getHeaderField("Location");
				System.out.println("Location00 = " + location);
				content = callUmm(callbacks, request, fullUmmURL, method);
			} 

		} catch (Exception e) {
			callbacks.getLogger().logError(this, methodName, e);
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
			// logout();
			callbacks.getLogger().logExit(this, methodName);
			return content;
		}

	}

	/**
	 * @param userName
	 * @return
	 */
	private String getUserDetails(String userName) {
		String url = ummURL + "/uamusers/userdetails?username=" + userName;

		String content = null;
		try {
			HttpURLConnection connection = EWFUMMService.getURLConnection(url);
			connection.setRequestMethod("GET");
			connection.setInstanceFollowRedirects(false);
			connection.setDoOutput(true);
			connection.setRequestProperty("Cookie", EWFUMMService.toCookieString(cookies));
			connection.connect();

			int responseCode = connection.getResponseCode();
			String responseStr = connection.getResponseMessage();
			System.out.println("responseCode = " + responseCode);
			System.out.println("responseStr = " + responseStr);
			if (responseCode == 200) {
				InputStream is = connection.getInputStream();

				int i = -1;
				byte[] b = new byte[1024];
				StringBuffer sb = new StringBuffer();
				while ((i = is.read(b)) != -1) {
					sb.append(new String(b, 0, i));
				}
				content = sb.toString();
				System.out.println("content = " + content);
				is.close();
			} else if (retryTimes < 2) {

				retryTimes++;
				this.getUserDetails(userName);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return content;

	}

	/**
	 * @param pluginLogger
	 */
	private static void matchLogLevel(PluginLogger pluginLogger) {
		int newIcnLevel = pluginLogger.getLogLevel();
		if (newIcnLevel == icnLogLevel) {
			return;
		}
		synchronized (logLevelUpdateLocker) {
			if (newIcnLevel == icnLogLevel) {
				return;
			}
			Level log4jLevel = Level.ERROR;
			switch (newIcnLevel) {
			case PluginLogger.LOG_DEBUG:
			case PluginLogger.LOG_DEV:
			case PluginLogger.LOG_ENTRY:
			case PluginLogger.LOG_EXIT:
				log4jLevel = Level.DEBUG;
				break;
			case PluginLogger.LOG_INFO:
				// case PluginLogger.LOG_PERF:
				log4jLevel = Level.INFO;
				break;
			case PluginLogger.LOG_WARNING:
				log4jLevel = Level.WARN;
				break;
			case PluginLogger.LOG_ERROR:
				log4jLevel = Level.ERROR;
				break;
			default:
				log4jLevel = Level.ERROR;
				break;
			}
			setLogLevelForLoggers(loggingPackageClassList, log4jLevel);

			icnLogLevel = newIcnLevel;
		}
	}

	/**
	 * @param loggerNameList
	 * @param level
	 */
	private static void setLogLevelForLoggers(String[] loggerNameList, Level level) {
		for (String loggerName : loggerNameList) {
			if (loggerName == null || loggerName.isEmpty()) {
				continue;
			}
			Logger curLogger = Logger.getLogger(loggerName);
			if (!level.equals(curLogger.getLevel())) {
				curLogger.setLevel(level);
				/*
				 * Enumeration appenderEnum = curLogger.getAllAppenders();
				 * Appender appender = null; while
				 * (appenderEnum.hasMoreElements()) { appender = (Appender)
				 * appenderEnum.nextElement(); if (appender instanceof
				 * org.apache.log4j.ConsoleAppender) { break; } } if (appender
				 * == null) { appender = new org.apache.log4j.ConsoleAppender();
				 * curLogger.addAppender(appender); }
				 * curLogger.isAttached(appender) appender.
				 */
			}
		}
	}

	/**
	 * @param cookies
	 * @return
	 */
	private static String toCookieString(final Map<String, String> cookies) {
		final StringWriter sw = new StringWriter();
		for (final Entry<String, String> entry : cookies.entrySet()) {
			sw.write(entry.getKey());
			sw.write("=");
			sw.write(entry.getValue());
			sw.write(";");
		}
		String result = sw.toString();
		if (result.endsWith(";")) {
			result = result.substring(0, result.length() - 1);
		}
		System.out.println("cookies = " + result);
		return result;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EWFUMMService umm = new EWFUMMService();
		try {
			// umm.execute(null, null, null);
			umm.initUmmParameters();
			String fullUmmURL = "https://9.112.249.46:9444/uam/uamusers/userdetails?username=ewfusr02";
			//String str = umm.callUmm(null,fullUmmURL, "GET");

			//System.out.println(str);
			// umm.initHttpClient();
			// umm.getUserDetails2("ewfusr01");
			// umm.getUserDetails("ewfusr02");
			// umm.getUserDetails("ewfusr03");
			// umm.getUserDetails("ewfusr04");
			// umm.getUserDetails("ewfusr05");
			// umm.getUserDetails("ewfusr06");
			// umm.getUserDetails("ewfusr07");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
