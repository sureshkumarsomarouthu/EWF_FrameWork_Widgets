/**
 * IBM Confidential
 * 
 * OCO Source Materials
 * 
 * 5724-R76
 * 
 * (C) Copyright IBM Corp. 2001, 2009
 * 
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package v11.com.ibm.icm.servlet.filter;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class CompressedResponseWrapper extends HttpServletResponseWrapper {

	protected HttpServletResponse origResponse;
	protected ServletOutputStream stream;
	protected PrintWriter writer;

	public CompressedResponseWrapper(HttpServletResponse response) {
		super(response);
		origResponse = null;
		stream = null;
		writer = null;
		origResponse = response;
	}

	public ServletOutputStream createOutputStream() throws IOException {
		return new CompressedResponseStream(origResponse);
	}

	public void finishResponse() {
		try {
			if (writer != null)
				writer.close();
			else if (stream != null)
				stream.close();
		} catch (IOException ioexception) {
		}
	}

	public void flushBuffer() throws IOException {
		stream.flush();
	}

	public ServletOutputStream getOutputStream() throws IOException {
		if (writer != null)
			throw new IllegalStateException(
					"getWriter() has already been called!");
		if (stream == null)
			stream = createOutputStream();
		return stream;
	}

	public PrintWriter getWriter() throws IOException {
		if (writer != null)
			return writer;
		if (stream != null) {
			throw new IllegalStateException(
					"getOutputStream() has already been called!");
		} else {
			stream = createOutputStream();
			writer = new PrintWriter(new OutputStreamWriter(stream, "UTF-8"));
			return writer;
		}
	}
}
