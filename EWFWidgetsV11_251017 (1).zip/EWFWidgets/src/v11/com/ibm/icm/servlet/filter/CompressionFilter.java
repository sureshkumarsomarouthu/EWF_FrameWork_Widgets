/**
 * IBM Confidential
 * 
 * OCO Source Materials
 * 
 * 5724-R76
 * 
 * (C) Copyright IBM Corp. 2001, 2009
 * 
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package v11.com.ibm.icm.servlet.filter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;


public class CompressionFilter implements Filter {
	
	private ServletContext servletContext;
	private Map<String, byte[]> gzipFileCache = new Hashtable<String, byte[]>();
	private long startupTime;
	
	public void destroy() {
	}

	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		if (req instanceof HttpServletRequest) {
			HttpServletRequest httpreq = (HttpServletRequest) req;
			HttpServletResponse response = (HttpServletResponse) res;
			
			if (httpreq.getMethod().equals("GET") && !response.isCommitted()) {
				String requestURI = httpreq.getRequestURI();
				if (requestURI.endsWith("ewf.js")) {
					requestURI += ".jgz";
				} 
				if (requestURI.endsWith("jgz")) {
					String pathInfo = requestURI.substring(httpreq.getContextPath().length());
					String nonGzipPathInfo = pathInfo.substring(0, pathInfo.length() - 4);
					if (pathInfo.endsWith("js.jgz")) {
						response.setHeader("Content-Encoding", "gzip");
						response.setContentType("application/x-javascript; charset=UTF-8");
					} else if (pathInfo.endsWith("css.jgz")) {
						response.setHeader("Content-Encoding", "gzip");
						response.setContentType("text/css; charset=UTF-8");
					}
					byte[] content = null;
					if (gzipFileCache.containsKey(pathInfo)) {
						content = gzipFileCache.get(pathInfo);
					} else {
						synchronized (gzipFileCache) {
							if (gzipFileCache.containsKey(pathInfo)) {
								content = gzipFileCache.get(pathInfo);
							} else {
								InputStream fileInputStream = null;
								fileInputStream = servletContext.getResourceAsStream(pathInfo);
								// for development purposes, fallback on the non-gzipped versions
								if (fileInputStream == null) {
									fileInputStream = servletContext.getResourceAsStream(nonGzipPathInfo);
									response.setHeader("Content-Encoding", "");
									ByteArrayOutputStream bytes = new ByteArrayOutputStream(1024 * 1024);
									int length = 0;
									byte[] buf = new byte[65536];
									while (length >= 0) {
										length = fileInputStream.read(buf);
										if (length > 0) {
											bytes.write(buf, 0, length);
										}
									}
									fileInputStream.close();
									content = bytes.toByteArray();
								} else {
									ByteArrayOutputStream bytes = new ByteArrayOutputStream(1024 * 1024);
									int length = 0;
									byte[] buf = new byte[65536];
									while (length >= 0) {
										length = fileInputStream.read(buf);
										if (length > 0) {
											bytes.write(buf, 0, length);
										}
									}
									fileInputStream.close();
									content = bytes.toByteArray();
									gzipFileCache.put(pathInfo, content);
								}
							}
						}
					}

					// Commenting out next line, on WebLogic it causes the following exception:
					// java.net.ProtocolException: Didn't meet stated Content-Length, wrote: '0' bytes instead of stated: 'xxx' bytes.
					//res.setContentLength(content.length);

					response.setDateHeader("Last-Modified", startupTime);
					long modifiedSinceTime = httpreq.getDateHeader("If-Modified-Since");
					if (modifiedSinceTime + 1000 > startupTime) {
						response.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
					} else {
						ServletOutputStream servletOutputStream = res.getOutputStream();
						servletOutputStream.write(content);
						servletOutputStream.flush();
						servletOutputStream.close();
					}
					return;
				}
			}
					
		}
		chain.doFilter(req, res);
	}

	public void init(FilterConfig filterconfig) throws ServletException {
		this.servletContext = filterconfig.getServletContext();
		startupTime = System.currentTimeMillis();
	}
}
