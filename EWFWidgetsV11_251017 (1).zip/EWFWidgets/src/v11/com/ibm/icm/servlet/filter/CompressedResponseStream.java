/**
 * IBM Confidential
 * 
 * OCO Source Materials
 * 
 * 5724-R76
 * 
 * (C)  Copyright IBM Corp. 2001, 2009
 * 
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package v11.com.ibm.icm.servlet.filter;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPOutputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

public class CompressedResponseStream extends ServletOutputStream {
	protected ByteArrayOutputStream baos;
	protected GZIPOutputStream gzipstream;
	protected boolean closed;
	protected HttpServletResponse response;
	protected ServletOutputStream output;

	public CompressedResponseStream(HttpServletResponse response)
			throws IOException {
		baos = null;
		gzipstream = null;
		closed = false;
		this.response = null;
		output = null;
		closed = false;
		this.response = response;
		output = response.getOutputStream();
		baos = new ByteArrayOutputStream();
		gzipstream = new GZIPOutputStream(baos);
	}

	public void close() throws IOException {
		if (closed) {
			throw new IOException("This output stream has already been closed");
		} else {
			gzipstream.finish();
			byte bytes[] = baos.toByteArray();
			response
					.addHeader("Content-Length", Integer.toString(bytes.length));
			response.addHeader("Content-Encoding", "gzip");
			output.write(bytes);
			output.flush();
			output.close();
			closed = true;
			return;
		}
	}

	public void flush() throws IOException {
		if (closed) {
			throw new IOException("Cannot flush a closed output stream");
		} else {
			gzipstream.flush();
			return;
		}
	}

	public void write(int b) throws IOException {
		if (closed) {
			throw new IOException("Cannot write to a closed output stream");
		} else {
			gzipstream.write((byte) b);
			return;
		}
	}

	public void write(byte b[]) throws IOException {
		write(b, 0, b.length);
	}

	public void write(byte b[], int off, int len) throws IOException {
		if (closed) {
			throw new IOException("Cannot write to a closed output stream");
		} else {
			gzipstream.write(b, off, len);
			return;
		}
	}

	public boolean closed() {
		return closed;
	}

}
