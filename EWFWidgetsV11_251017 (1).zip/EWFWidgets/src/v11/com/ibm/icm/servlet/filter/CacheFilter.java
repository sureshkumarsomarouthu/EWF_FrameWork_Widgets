/**
 * IBM Confidential
 * 
 * OCO Source Materials
 * 
 * 5724-R76
 * 
 * (C) Copyright IBM Corp. 2001, 2009
 * 
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package v11.com.ibm.icm.servlet.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

/**
 * Setup the cache control header for max-age and expires
 * 
 * @author tianxj
 * 
 */
public class CacheFilter implements Filter {

	// use one day expiration
	private static long maxHttpCacheAge = 24 * 60 * 60;

	public CacheFilter() {
	}

	public void destroy() {
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if (!response.isCommitted()
				&& (response instanceof HttpServletResponse)) {
			// add 'Cache-control: public' to trigger browser cache files over
			// https into its disk cache
			// max-age will override expires for http 1.1 client.
			// But, expires will work for http 1.0 client. So, as a general
			// purpose cache filter, we add them both.
			((HttpServletResponse) response).setHeader("Cache-control",
					(new StringBuilder("max-age=")).append(
							Long.toString(maxHttpCacheAge)).toString()
							+ ", public");
			((HttpServletResponse) response).setDateHeader("Expires", System
					.currentTimeMillis()
					+ maxHttpCacheAge * 1000L);
		}
		chain.doFilter(request, response);
	}

	public void init(FilterConfig config) throws ServletException {
		String sTimeoutSeconds = config.getInitParameter("maxHttpCacheAge");
		if (sTimeoutSeconds != null)
			maxHttpCacheAge = Long.valueOf(sTimeoutSeconds).longValue();
	}

}
