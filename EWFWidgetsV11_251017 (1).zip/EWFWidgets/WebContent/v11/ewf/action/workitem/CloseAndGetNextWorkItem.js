define([
        "dojo/_base/declare", 
        "dojo/_base/lang",
    	"icm/util/WorkItemHandler",
        "icm/action/Action"
], function(declare, lang, WorkItemHandler, Action) {

	/**
	 * @name ewf.action.workitem.CloseAndGetNextWorkItem
	 * @class Closes the current Work Details page without saving any changes. If the Get Next 
	 *        option on Work Item Toolbar is selected, the next unlocked work item is opened, 
	 *        otherwise the current page is closed.<br>
	 *        Context required by this action: [['WorkItemPage', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'BEFORECANCEL'
	 * <li> 'CANCEL' 
	 * <li> 'AFTERCANCEL'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORWORKITEM': true
	 * </ul>
	 * @augments icm.action.Action
	 */
	return declare("v11.ewf.action.workitem.CloseAndGetNextWorkItem", [Action], {
	/** @lends ewf.action.workitem.CloseAndGetNextWorkItem.prototype */
		
		isEnabled: function()
		{
            var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}

			return true;

		},

		execute: function()
		{
            var context = [];
            context[this.icmBaseConst.WKIM] = true;

			var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}

	        //TODO: start coordinator to detect whether there are some modified properties and attachments from other page.
			//Once there is any change, an alert pop up dialog should be shown to end users
			coordination[0].step(this.icmBaseConst.BEFORECANCEL, 
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in commit step callback, results");
	        			this.logInfo("execute", results);
						next();
						

	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in commit step errback, errors");
	        			this.logInfo("execute", errors);
	        			this.showConfirmationDialog("InstructMessageUnSavedDialog", "ConfirmationMessageUnSaveDialog", errors, next, skip);
	        		})
	        ).step(this.icmBaseConst.CANCEL, 
	            lang.hitch(this, function(results, next, skip){
					var uiState = this.getActionContext("UIState");
					var readonly = false;
					if(uiState !== null && uiState.length > 0){
					    readonly = uiState[0].get("workItemReadOnly");
					}	
					if(readonly){
			            next();
					}else{
				        WorkItemEditable[0].abortStep(lang.hitch(this, function(){
				        	this.cleanActionContext("WorkItemPage");//RTC defect 56464 avoiding  being still handled by other actions or components. 
			                next();
			            }));
					}
	             }), 
	             lang.hitch(this, function(errors, next, skip){
    			    this.logInfo("execute", "in cancel step errback, errors");
    			    this.logInfo("execute", errors);
	            	this.showErrDialog("actionExecutedErr", errors);
	            })
	        ).step(this.icmBaseConst.AFTERCANCEL,
	        		lang.hitch(this, function(results, next, skip){ 
    			        this.logInfo("execute", "in afterSave step callback, results");
    			        this.logInfo("execute", results);
    			        next();
						
						// Determine if need to get the next work item
						var handleNext = false;
						var uiState = this.getActionContext("UIState");
			            if( uiState !== null && uiState.length > 0 && uiState[0].get("GetNextCfg") === true){
						//if Open next work item action is confogured, then use it
			                 handleNext = uiState[0].get("GetNext");
			            }						
						
						this.cleanActionContext("WorkItemPage");//Avoiding the dispatched work item still handled by other actions or components. 
						if(handleNext){
						    var handler = new WorkItemHandler(this.getWidget());
			                handler.handleNextWorkItem(WorkItemEditable[0].getWorkItem());	
						}else{		
							delete icmglobal._openItems[WorkItemEditable[0].getCaseTaskId()];
							this.broadcastEvent(
								 "icm.ClosePage"
							 );
						}						
    		        }),
    		        lang.hitch(this, function(errors, next, skip){
    			        this.logInfo("execute", "in aftercancel step errback, errors");
    			        this.logInfo("execute", errors);
    			        this.showErrDialog("actionExecutedErr", errors);
    		       })

    	    ).start(context);
		},
	
		_eoc_:null
		
	});
	
});