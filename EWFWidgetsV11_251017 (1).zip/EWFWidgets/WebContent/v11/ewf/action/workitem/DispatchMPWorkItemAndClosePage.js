define([
        "dojo/_base/declare", 
        "dojo/_base/lang",
    	"icm/util/WorkItemHandler",
        "icm/action/Action",    	
    	"ecm/model/ResultSet",
    	"v11/ewf/dialog/activitydialog/EmailActivityDialog",
		"v11/ewf/util/Util",
		"dojo/_base/array"
], function(declare, lang, WorkItemHandler, Action, ResultSet, EmailActivityDialog, Util, baseArray) {

	/**
	 * @name ewf.action.workitem.DispatchMPWorkItemAndClosePage
	 * @class Dispatches the current work item. If the next work item is not opened automatically, this action also closes the current Work Details page. <br>
	 *        Context required by this action: [['WorkItemPage', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'COMMIT'
	 * <li> 'VALIDATE' 
	 * <li> 'BEFORECOMPLETE'
	 * <li> 'COMPLETE'
	 * <li> 'AFTERCOMPLETE'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORWORKITEM': true
	 * <li> 'FORRESPONSE': the response id end-users choose for dispatching
	 * </ul>
	 * @augments icm.action.Action
	 */
	return declare("v11.ewf.action.workitem.DispatchMPWorkItemAndClosePage", [Action], {
	/** @lends ewf.action.workitem.DispatchMPWorkItemAndClosePage.prototype */
		
		executing: false,

		isVisible: function()
		{
			return true;
		},
	
		isEnabled: function()
		{
			// keep action disabled during execution
			if (this.executing)
			{
				return false;
			}

			var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}

			var uiState = this.getActionContext("UIState");
			
			if( uiState !== null && uiState.length > 0){
			    var readonly = uiState[0].get("workItemReadOnly");
				if(readonly){
				    return false;
				}
			}
			
			return true;
		},		
		
		
		execute: function()
		{
			this.logInfo("execute", "Processing response '" + this.getArgument('item').title + "' with 'Get Next'=" + this.getArgument('getnext'));
			var context = [];
            context[this.icmBaseConst.WKIM] = true;
			context[this.icmBaseConst.WKITEMRESPONSE] = this.getArgument('item').id; 

            var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}
			
			// disable action during execution
			this.executing = true;
			this.setEnabled(false);

	        coordination[0].step(Util.getConstant("EWF_CoordTopic").MANUALPROCESSINGROUTEHANDLE, 
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in commit step callback, results");
	        			this.logInfo("execute", results);
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in commit step errback, errors");
	        			this.logInfo("execute", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
	        	).step(this.icmBaseConst.COMMIT, 
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in commit step callback, results");
	        			this.logInfo("execute", results);
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in commit step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
	        	).step(this.icmBaseConst.VALIDATE,
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in validate step callback, results");
	        			this.logInfo("execute", results);
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in validate step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedFailureVailidate", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})

	        	).step(this.icmBaseConst.BEFORECOMPLETE,
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in beforeSave step callback, results");
	        			this.logInfo("execute", results);
	        			next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in beforeSave step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})

	        	).step(this.icmBaseConst.COMPLETE,
	        	    lang.hitch(this, function(results, next, skip){
					    //TODO:collect the modified properties and attachments from other page widgets to stored as properties for completeStep.
						// Other page widgets should set these modified properties and attachments in somewhere 
		                //now we change to use work item model to save the modification on work item
	        	    	WorkItemEditable[0].setSelectedResponse(this.getArgument('item').id);
				        WorkItemEditable[0].completeStep(
				        	lang.hitch(this, function(response, fieldErrors) {
								this.logInfo("execute", "Launch work item response:'" + this.getArgument('item').title + "'");
								this.publishEvent(
										"icm.WorkItemDispatched",
										{'workItemEditable': WorkItemEditable[0]}
								);
								next();
							}),
							lang.hitch(this, function(response, fieldErrors) {
								// enable action if failed
								this.executing = false;
								this.setEnabled(true);
								skip();
							})
						);
                    }), 
                    lang.hitch(this, function(errors, next, skip){
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})
	        	).step(this.icmBaseConst.AFTERCOMPLETE,
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in afterSave step callback, results");
	        			this.logInfo("execute", results);
						
                        next();
						
						var uiState = this.getActionContext("UIState");
						var handleNext = false;
						var getnext = this.getArgument('item').GetNext || false;
						
						if(getnext){
						    handleNext = getnext;
						}
						
			            if( uiState !== null && uiState.length > 0 && uiState[0].get("GetNextCfg") === true){
						//if Open next work item action is confogured, then use it
			                 handleNext = uiState[0].get("GetNext");
			            }
						this.cleanActionContext("WorkItemPage");//RTC defect 55423 avoiding the dispatched work item still handled by other actions or components. 
						if(handleNext){
						    var handler = new WorkItemHandler(this.getWidget());
			                handler.handleNextWorkItem(WorkItemEditable[0].getWorkItem());	
						}else{		
							delete icmglobal._openItems[WorkItemEditable[0].getCaseTaskId()];
	        			    this.broadcastEvent(
								"icm.ClosePage"
						    );
						}
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in afterSave step errback, errors");
	        			this.logInfo("execute", errors);
						this.showErrDialog("actionExecutedErr", errors);
						// enable action if failed
						this.executing = false;
						this.setEnabled(true);
    			        skip();
	        		})

	        	).start(context);
	
		},
		
		getIterator: function()
		{
			var items = [];

            var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}

			var responses = WorkItemEditable[0].getResponses();
	/*		var i;
	
	        var attributes =  this.getWidget().workItem.getWorkClass()._propertyDefinitions;
			for ( i in attributes) {
				if (attributes[i].getId() === "F_Responses") {
					responses = attributes[i].getAllowedValues();
					break;
				}
			}
	*/
			
			//Begin change -- Added by Purna for hiding any reponses using this action. configured as RESPONSES_TO_HIDE in process specific constants
			var solPrefix,stepName;
			if(this.widget && this.widget.solution && this.widget.solution.prefix) {
				solPrefix = this.widget.solution.prefix;
			}
			if(WorkItemEditable[0] && WorkItemEditable[0].icmWorkItem && WorkItemEditable[0].icmWorkItem.stepName) {
				stepName = WorkItemEditable[0].icmWorkItem.stepName;
			}
			
			var responsesConfig = Util.getConstant("Responses_To_Hide", solPrefix, WorkItemEditable[0]);
			var responsesToHide = [];
			if(responsesConfig && stepName && responsesConfig[stepName]) {
				responsesToHide = responsesConfig[stepName];
			}
			// added by rahul to enable Notify to Scan Hub response based on below parameters. If below parameters are empty hide the "NOTIFYSCANHUB" response
				//this change should apply across all solutions 
			if(WorkItemEditable[0].propertiesCollection){
				var properties = WorkItemEditable[0].propertiesCollection;
				if(properties['EWS_Futurerequestdate'] == undefined || properties['EWS_ApproverName'] == undefined || properties['EWS_Careofname'] == undefined){
					responsesToHide.push(Util.getConstant("EWF_DISPATCH").NOTIFYSCANHUB);
				}
				if(properties != null && properties['EWS_Futurerequestdate'] && properties['EWS_ApproverName'] &&  properties['EWS_Careofname'] && 
					properties['EWS_Futurerequestdate'].value == "" && properties['EWS_ApproverName'].value == "" && properties['EWS_Careofname'].value == ""){
					responsesToHide.push(Util.getConstant("EWF_DISPATCH").NOTIFYSCANHUB);
				}
			}
			//End
			
			if(responses.length === 0){
			     items.push({"id": "", 
	                         "title": this.getArgument('label')
				 });
			}else{
				for ( i = 0; i < responses.length; i++) {
					//Begin change -- Check if the responsesToHide is empty or not. If not empty add the response to the list if it is not found
					//in the hide response list
					if(responsesToHide instanceof Array && responsesToHide.length > 0) {
						var index = baseArray.indexOf(responsesToHide, responses[i]);
						if(index == -1) {
							items.push({"id": responses[i], 
								"title": responses[i]
							});
						} else {
							console.log('Hiding the response: ', responses[i], ' stepName: ', stepName);
						}
					} else {
					//End
						items.push({"id": responses[i], 
							"title": responses[i]
						});
					}
	             }
			}
	
			return items;
		},
		
		_eoc_:null
		
	});
	
});