define([
        "dojo/_base/declare", 
        "dojo/_base/lang",
    	"v11/ewf/action/_MessageDialogMixin",
    	"icm/action/workitem/DispatchWorkItemAndClosePage"
], function(declare, lang, _MessageDialogMixin, DispatchWorkItemAndClosePageAction) {

	/**
	 * @name ewf.action.workitem.EWFCommonDispatchWorkItem
	 * @class The EWF version of dispatch work item action. The only thing added so far is for a custom error dialog.<br>
	 * 		  All the others remain the same as the default one. <br>
	 * @augments icm.action.workitem.DispatchWorkItemAndClosePageAction
	 */
	return declare("v11.ewf.action.workitem.EWFCommonDispatchWorkItem", [DispatchWorkItemAndClosePageAction, _MessageDialogMixin], {
	/** @lends ewf.action.workitem.EWFCommonDispatchWorkItem.prototype */
		_eoc_:null
		
	});
	
});