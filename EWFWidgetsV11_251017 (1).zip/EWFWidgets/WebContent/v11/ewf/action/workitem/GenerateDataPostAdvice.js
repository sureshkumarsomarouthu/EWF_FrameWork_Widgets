define([
        "dojo/_base/declare", 
        "dojo/_base/lang",
        "dojo/dom-style",
    	"icm/util/WorkItemHandler",
        "icm/action/Action",
    	"ecm/widget/dialog/MessageDialog",
    	"v11/ewf/dialog/advicedialog/DataPostAdviceDialog",
		"v11/ewf/util/Util"
], function(declare, lang, domStyle, WorkItemHandler, Action, MessageDialog, AdviceDialog, Util) {

	/**
	 * @name ewf.action.workitem.GenerateDataPostAdvice
	 * @class invoke a dialog to generate advice letter according to template predefined for the case that work item belongs to.<br>
	 *        Context required by this action: [['WorkItemPage', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'BEFOREADVICE'
	 * <li> 'DATAPOSTADVICE' 
	 * <li> 'AFTERADVICE'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORWORKITEM': true
	 * </ul>
	 * @augments icm.action.Action
	 */
	return declare("v11.ewf.action.workitem.GenerateDataPostAdvice", [Action], {
	/** @lends ewf.action.workitem.GenerateDataPostAdvice.prototype */
		
		isEnabled: function()
		{
            var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}

			return true;

		},

		execute: function()
		{
            var context = [];
            context[this.icmBaseConst.WKIM] = true;

			var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}

	        //TODO: start coordinator to detect whether there are some modified properties and attachments from other page.
			//Once there is any change, an alert pop up dialog should be shown to end users
			coordination[0].step(Util.getConstant("EWF_CoordTopic").BEFOREADVICE, 
	        		lang.hitch(this, function(results, next, skip){
	        			this.logInfo("execute", "in before advice step callback, results");
	        			this.logInfo("execute", results);
						next();
	        		}),
	        		lang.hitch(this, function(errors, next, skip){
	        			this.logInfo("execute", "in commit step errback, errors");
	        			this.logInfo("execute", errors);
	        			this.showConfirmationDialog("InstructMessageUnSavedDialog", "ConfirmationMessageUnSaveDialog", errors, next, skip);
	        		})
	        ).step(Util.getConstant("EWF_CoordTopic").DATAPOSTADVICE, 
	            lang.hitch(this, function(results, next, skip){
	            		            	
	            	//invoke the dialog to generate the letter
	            	var adviceDialog = new AdviceDialog({
	    				repository: WorkItemEditable[0].getCaseType().getSolution().getTargetOS(),
	    				parentCase: WorkItemEditable[0].getCase(),
	    				workItemEditable: WorkItemEditable[0]
	    			});
	    			adviceDialog.show();
	    			domStyle.set(adviceDialog.domNode, 'top', '60px');
	    			domStyle.set(adviceDialog.domNode, 'width', '877px');
	    			domStyle.set(adviceDialog.domNode, 'left', '355px');
	    			next();
	             }), 
	             lang.hitch(this, function(errors, next, skip){
    			    this.logInfo("execute", "in advice step errback, errors");
    			    this.logInfo("execute", errors);
	            	this.showErrDialog("actionExecutedErr", errors);
	            })
	        ).step(Util.getConstant("EWF_CoordTopic").AFTERADVICE,
	        		lang.hitch(this, function(results, next, skip){ 
    			        this.logInfo("execute", "in after advice step callback, results");
    			        this.logInfo("execute", results);
    			        next();	
    		        }),
    		        lang.hitch(this, function(errors, next, skip){
    			        this.logInfo("execute", "in aftercancel step errback, errors");
    			        this.logInfo("execute", errors);
    			        this.showErrDialog("actionExecutedErr", errors);
    		       })

    	    ).start(context);
		},
	
		_eoc_:null
		
	});
	
});