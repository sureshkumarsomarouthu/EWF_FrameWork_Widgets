require([ "dojo/_base/lang", "icm/util/WorkItemHandler" ], function(lang, WorkItemHandler) {

    // ////////////////////////////////////////////////////////////////////////////////
    // This file define a new handleNextWorkItem function that will replace the
    // original handleNextWorkItem
    // function in WorkItemHandler class. If the parameters added in Push
    // inbasket are found,
    // then the new method will be reused to query Inbasket again to get the
    // latest work item.
    // If the parameters are not found, then will fall back to the original
    // method.
    // ////////////////////////////////////////////////////////////////////////////////

    // Backup the original handleNextWorkItem method
    var originalHandleNextItemFunc = WorkItemHandler.prototype.handleNextWorkItem;
    /**
     * A method to handle get next work item function specically. It will not
     * use the native getNext function, instead it will try to get the original
     * Inbasket query and run the query again to find the next work item. The
     * parameters are added via the PushInbasket. If the parameters are not
     * found, it will fall back to the original handleNextWorkItem function.
     * 
     * @param {object}
     *                icmWorkItem Instance of icm.model.WorkItem
     */
    var handleNextWorkItemFunc = function(icmWorkItem) {

	var pushInbasket = (icmWorkItem && icmWorkItem.ecmWorkItem && icmWorkItem.ecmWorkItem.parent) || null;

	if (pushInbasket && pushInbasket.__ewfPushStatus) {
	    var pushStatus = pushInbasket.__ewfPushStatus;

	    var originalInbasket = pushInbasket;
	    var inbasketQueryParams = pushStatus.inbasketQueryParams || null;
	    var originalSolution = pushStatus.originalSolution || null;
	    var lockByMyselfLength = pushStatus.lockByMyselfLength || 0;

	    if (lockByMyselfLength > 0) {
		lockByMyselfLength--;
		pushStatus.lockByMyselfLength = lockByMyselfLength;
	    }

	    if (originalInbasket && inbasketQueryParams && originalSolution && lockByMyselfLength === 0) {
		var self = this;
		originalInbasket.retrieveWorkItems(function(rs) {
		    if (!rs || !rs.items || rs.items.length === 0) {
			self._showNoNextItem(icmWorkItem);
		    } else {
			var ecmWorkItem = rs.items[0];
			var _nextIcmWorkItem = icm.model.WorkItem.fromWorkItem(originalSolution, ecmWorkItem);

			self._isNext = true;
			self.handleWorkItem(_nextIcmWorkItem, true);
		    }
		}, inbasketQueryParams.orderBy, inbasketQueryParams.descending, inbasketQueryParams.refresh, inbasketQueryParams.filters,
			inbasketQueryParams.queryFilter, inbasketQueryParams.substitutionVars, inbasketQueryParams.queryFlags);

	    } else {
		originalHandleNextItemFunc.call(this, icmWorkItem);
	    }
	} else {
	    originalHandleNextItemFunc.call(this, icmWorkItem);
	}
    };

    console.log("------------------------------------------------------");
    console.log("Dynamically inject the handleNext method!");
    WorkItemHandler.prototype.handleNextWorkItem = handleNextWorkItemFunc;
    console.log("------------------------------------------------------");
});