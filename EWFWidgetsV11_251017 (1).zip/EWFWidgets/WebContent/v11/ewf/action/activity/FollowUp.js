define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/connect",
	"dojo/_base/array",
	"icm/action/Action",
	"v11/ewf/dialog/activitydialog/ActivityDialog",
	"dojo/i18n!../../nls/common",
	"v11/ewf/util/Util"
	], function(declare, lang, connect, array, Action, ActivityDialog, resources, Util) {
	/**
	 * @name v11.ewf.action.activity.FollowUp
	 * @class make the follow up operation on a activity. <br>
	 *        Context required by this action: [['ActivityEditable', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'COMMIT'
	 * <li> 'VALIDATE' 
	 * <li> 'BEFOREFOLLOWUP'
	 * <li> 'FOLLOWUP'
	 * <li> 'AFTERFOLLOWUP'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORACTIVITY': true
	 * </ul>
	 * @augments icm.action.Action
	 */
		return declare("v11.ewf.action.activity.FollowUp", [Action], {
			
			executing: false,
			discard: false,
			
			getNLSValue : function(name){
				return resources.Actions[name] || null;
			},
						
			setDiscard: function(discard)
			{
				this.discard = discard;
			},
			
			getDiscard: function()
			{
				return this.discard;
			},

			isVisible: function()
			{
				return true;
			},
		
			isEnabled: function()
			{ 
				// keep action disabled during execution
				if (this.executing)
				{
					return false;
				}

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}

				var uiState = this.getActionContext("UIState");
				
				if( uiState !== null && uiState.length > 0){
					var readonly = uiState[0].get("ActivityReadOnly");
					if(readonly){
						return false;
					}
				}
			
				return true;
			},
			
			showFailureDialog: function(next, skip){
				var title = this.getNLSValue("title_ValidationFailure");
				var text = this.getNLSValue("text_ValidationFailure");
				var buttonsCollection = {};
				var dialog = new ActivityDialog({
								title: title, // DEV: to be localized
								text: text,
								containReason: false,
								buttonsCollection: buttonsCollection,
								onCancel: lang.hitch(this, function() {
									this.executing = false;
									this.setEnabled(true);
									skip();
								})
				});
				dialog.setWidth(480);
				dialog.cancelButton.set("label", this.getNLSValue("label_Failure"));
				dialog.show();
			},	
			
			validateHandle: function(activityEditable, results, next, skip){
				var text = this.getNLSValue("text_em_cb");
				var title = null;
				var showDialog = false;
				var isFailed = false;
				var dialog = null;
				var buttonsCollection = {};
				
				if(results.length === 0){
					isFailed = false;
				}else{
					var activityType = activityEditable.getActivityType();
					var activityId = activityEditable.getActivityId();
					
					if(array.some(results, function(result) {
							if(result[1] !== undefined 
								&& result[1]["isValid"] === false 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						isFailed = true;
					}
				}
				
				if(isFailed){
					this.showFailureDialog(next, skip);
				}else{
				
					if(this.arguments["emOpt"]){
						var EmailButtonObj = {};
						EmailButtonObj.buttonLabel = this.getNLSValue("label_Email");
						
						//reason is optional for the activity with 'flagged'
						EmailButtonObj.disabled = false;
						/*if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
							EmailButtonObj.disabled = true;
						}*/
						
						EmailButtonObj.onExecute = lang.hitch(this, function() {
													activityEditable.setCurrentComment(dialog.reason.get("value") || "");
													activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM);
													//alert("Reason for EMAIL:" + dialog.reason.get("value"));
													next();
												});
						buttonsCollection.EMAIL = EmailButtonObj;
					}
					
					if(this.arguments["cbOpt"]){
						//call back is not available for the activity with 'flagged'.
						//based on latest version, call back is available for the activity with 'flagged'.
						//if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
							var CBButtonObj = {};
							CBButtonObj.buttonLabel = this.getNLSValue("label_cb");
							CBButtonObj.disabled = false;
							CBButtonObj.onExecute = lang.hitch(this, function() {
														activityEditable.setCurrentComment(dialog.reason.get("value") || "");
														activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").FOLLOWUPCB);
														//alert("Reason for Call Back:" + dialog.reason.get("value"));
														next();
													});
							buttonsCollection.CALLBACK = CBButtonObj;
						//}
					}
					
					if(this.arguments["emOpt"] && this.arguments["cbOpt"]){
						text = this.getNLSValue("text_em_cb");
					}else if(this.arguments["emOpt"]){
						text = this.getNLSValue("text_Email");
					}else if(this.arguments["cbOpt"]){
						text = this.getNLSValue("text_cb");
					}
						
					
					dialog = new ActivityDialog({
											title: this.getNLSValue("title_followUpOptions"), // DEV: to be localized
											text: text,
											buttonsCollection: buttonsCollection,
											onCancel: lang.hitch(this, function() {
												this.executing = false;
												this.setEnabled(true);
												skip();
										})
					});
					dialog.show();
				}
			},

			execute: function()
			{
				this.logInfo("Activity Complete is being executed");

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}
				
				var context = [];
				context[Util.getConstant("EWF_CoordContext").ACTIVITY] = true;
				context[Util.getConstant("EWF_CoordContext").ACTIVITYTYPE] = ActivityEditable[0].getActivityType();
				context[Util.getConstant("EWF_CoordContext").ACTIVITYID] = ActivityEditable[0].getActivityId();
				
				//Added By Gopi to capture the the response selected by the user
				
				if(null!=this.getArgument('label'))
					context[Util.getConstant("EWF_CoordContext").ACTIVITYRESPONSE] = this.getArgument('label');
					
				//End By Gopi
				
				// disable action during execution
				this.executing = true;
				this.setEnabled(false);

				coordination[0].step(Util.getConstant("EWF_CoordTopic").COMMIT, 
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in commit step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in commit step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").VALIDATE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in validate step callback, results");
							this.logInfo("execute", results);
							
							this.validateHandle(ActivityEditable[0], results, next, skip);
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in validate step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").BEFOREFOLLOWUP,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in beforeSave step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in beforeSave step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").FOLLOWUP,
						lang.hitch(this, function(results, next, skip){
							//TODO:collect the modified properties.
							ActivityEditable[0].save(
								lang.hitch(this, function(response, fieldErrors) {
									this.logInfo("execute", "complete operation on activity");
									this.publishEvent(
											"icm.ewfActivityFollowUp",
											{'ActivityEditable': ActivityEditable[0]}
									);
									next();
								}),
								lang.hitch(this, function(response, fieldErrors) {
									// enable action if failed
									this.executing = false;
									this.setEnabled(true);
									skip();
								}),
								this.arguments["label"],
								this.getDiscard()
							);
						}), 
						lang.hitch(this, function(errors, next, skip){
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").AFTERFOLLOWUP,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in afterComplete step callback, results");
							this.logInfo("execute", results);
							this.executing = false;
							this.setEnabled(this.isEnabled());
							this.refreshMenus();
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in afterSave step errback, errors");
							this.logInfo("execute", errors);
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).start(context);
			},
			
			

			_eoc_:null

		});
});