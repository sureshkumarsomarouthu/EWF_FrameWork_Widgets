define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/connect",
	"dojo/_base/array",
	"icm/action/Action",
	"v11/ewf/dialog/activitydialog/ActivityDialog",
	"dojo/i18n!../../nls/common",
	"v11/ewf/util/Util"
	], function(declare, lang, connect, array, Action, ActivityDialog, resources, Util) {
	/**
	 * @name v11.ewf.action.activity.Rework
	 * @class make the Rework operation on a activity. <br>
	 *        Context required by this action: [['ActivityEditable', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'COMMIT'
	 * <li> 'VALIDATE' 
	 * <li> 'BEFORECOMPLETE'
	 * <li> 'COMPLETE'
	 * <li> 'AFTERCOMPLETE'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORACTIVITY': true
	 * </ul>
	 * @augments icm.action.Action
	 */
		return declare("v11.ewf.action.activity.Rework", [Action], {
			
			executing: false,
			discard: false,
			
			getNLSValue : function(name){
				return resources.Actions[name] || null;
			},
			
			setDiscard: function(discard)
			{
				this.discard = discard;
			},
			
			getDiscard: function()
			{
				return this.discard;
			},

			isVisible: function()
			{
				return true;
			},
		
			isEnabled: function()
			{ 
				// keep action disabled during execution
				if (this.executing)
				{
					return false;
				}

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}

				var uiState = this.getActionContext("UIState");
				
				if( uiState !== null && uiState.length > 0){
					var readonly = uiState[0].get("ActivityReadOnly");
					if(readonly){
						return false;
					}
				}
			
				return true;
			},
			
			warnMessageHandle: function(errors){
				var text ="";
				var messages= {};
				var error;
				var message;
				var items;
				var i, j;
				var key;

				for(i = 0; i < errors.length; i++){
					if(errors[i][0] === true){
						error = errors[i][1];
						if(error !== undefined && error !== null && error.message !== undefined && error.message !== null){
							message= messages[error.message];
							if(!message){
								message = messages[error.message] = {};
							}
							items = error.items;
							if(items){
								for(j = 0; j < items.length; j++){
									item = items[j];
									message[item] = item;
								}
							}
						}
					}
				}



				for(message in messages){
					if(messages.hasOwnProperty(message)){
						text = text + message;
						i = 0;
						for(key in messages[message]){
							if(messages[message].hasOwnProperty(key)){
								i++;
								if ( i <= 5){
									text = text + "&nbsp;&nbsp;" + messages[message][key] + "<br>";
								}else{
									text = text + "&nbsp;&nbsp;" + this.resourceBundle["Others"]  + "<br>";
								}
							}
		
						}
					}
				}

				return text;
			},
			
			validateHandle: function(activityEditable, results, next, skip){
				var text = this.getNLSValue("text_Rework");
				var title = this.getNLSValue("title_Rework");
				
				var dialog = null;
				var buttonsCollection = {};
				var ReworkButtonObj = {};
				ReworkButtonObj.buttonLabel = this.getNLSValue("label_Rework");
				ReworkButtonObj.disabled = true;
				ReworkButtonObj.onExecute = lang.hitch(this, function() {
											activityEditable.setCurrentComment(dialog.reason.get("value"));
											activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREPAIR);
											//alert("Reason for Reviewed:" + dialog.reason.get("value"));
											next();
									});
				buttonsCollection.Rework = ReworkButtonObj;
				dialog = new ActivityDialog({
										title: title, // DEV: to be localized
										text: text,
										buttonsCollection: buttonsCollection,
										onCancel: lang.hitch(this, function() {
											this.executing = false;
											this.setEnabled(true);
											skip();
										})
				});
				dialog.show();
			},

			execute: function()
			{
				this.logInfo("Activity Complete is being executed");

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}
				
				var context = [];
				context[Util.getConstant("EWF_CoordContext").ACTIVITY] = true;
				context[Util.getConstant("EWF_CoordContext").ACTIVITYTYPE] = ActivityEditable[0].getActivityType();
				context[Util.getConstant("EWF_CoordContext").ACTIVITYID] = ActivityEditable[0].getActivityId();
				
				//Added By Gopi to capture the the response selected by the user
				
				if(null!=this.getArgument('label'))
					context[Util.getConstant("EWF_CoordContext").ACTIVITYRESPONSE] = this.getArgument('label');
					
				//End By Gopi
				
				// disable action during execution
				this.executing = true;
				this.setEnabled(false);

				coordination[0].step(Util.getConstant("EWF_CoordTopic").COMMIT, 
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in commit step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in commit step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").VALIDATE,//TODO: skip the validation and keep the original values
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in validate step callback, results");
							this.logInfo("execute", results);
							
							this.validateHandle(ActivityEditable[0], results, next, skip);
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in validate step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").BEFORECOMPLETE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in beforeSave step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in beforeSave step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").COMPLETE,
						lang.hitch(this, function(results, next, skip){
							//TODO:collect the modified properties.
							ActivityEditable[0].save(
								lang.hitch(this, function(response, fieldErrors) {
									this.logInfo("execute", "complete operation on activity");
									this.publishEvent(
											"icm.ewfActivityRework",
											{'ActivityEditable': ActivityEditable[0]}
									);
									next();
								}),
								lang.hitch(this, function(response, fieldErrors) {
									// enable action if failed
									this.executing = false;
									this.setEnabled(true);
									skip();
								}),
								this.arguments["label"],
								this.getDiscard()
							);
						}), 
						lang.hitch(this, function(errors, next, skip){
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").AFTERCOMPLETE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in afterComplete step callback, results");
							this.logInfo("execute", results);
							this.executing = false;
							this.setEnabled(this.isEnabled());
							this.refreshMenus();
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in afterSave step errback, errors");
							this.logInfo("execute", errors);
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).start(context);
			},
			
			

			_eoc_:null

		});
});