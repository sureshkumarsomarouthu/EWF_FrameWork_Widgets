define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/connect",
	"dojo/_base/array",
	"icm/action/Action",
	"v11/ewf/dialog/activitydialog/ActivityDialog",
	"dojo/i18n!../../nls/common",
	"v11/ewf/util/Util"
	], function(declare, lang, connect, array, Action, ActivityDialog, resources, Util) {
	/**
	 * @name ewf.action.activity.Complete
	 * @class make the complete operation on a activity. <br>
	 *        Context required by this action: [['ActivityEditable', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'COMMIT'
	 * <li> 'VALIDATE' 
	 * <li> 'BEFORECOMPLETE'
	 * <li> 'COMPLETE'
	 * <li> 'AFTERCOMPLETE'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORACTIVITY': true
	 * </ul>
	 * @augments icm.action.Action
	 */
		return declare("v11.ewf.action.activity.Complete", [Action], {
			
			executing: false,
			discard: false,
			
			getNLSValue : function(name){
				return resources.Actions[name] || null;
			},
			
			setDiscard: function(discard)
			{
				this.discard = discard;
			},
			
			getDiscard: function()
			{
				return this.discard;
			},

			isVisible: function()
			{
				return true;
			},
		
			isEnabled: function()
			{ 
				// keep action disabled during execution
				if (this.executing)
				{
					return false;
				}

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}

				var uiState = this.getActionContext("UIState");
				
				if( uiState !== null && uiState.length > 0){
					var readonly = uiState[0].get("ActivityReadOnly");
					if(readonly){
						return false;
					}
				}
			
				return true;
			},
			
			warnMessageHandle: function(errors){
				var text ="";
				var messages= {};
				var error;
				var message;
				var items;
				var i, j;
				var key;
				
				for(i = 0; i < errors.length; i++){
					if(errors[i][0] === true){
						error = errors[i][1];
						if(error !== undefined && error !== null && error.message !== undefined && error.message !== null){
							message= messages[error.message];
							if(!message){
								message = messages[error.message] = {};
							}
							items = error.items;
							if(items){
								for(j = 0; j < items.length; j++){
									item = items[j];
									message[item] = item;
								}
							}
						}
					}
				}



				for(message in messages){
					if(messages.hasOwnProperty(message)){
						text = text + message;
						i = 0;
						for(key in messages[message]){
							if(messages[message].hasOwnProperty(key)){
								i++;
								if ( i <= 5){
									text = text + "&nbsp;&nbsp;" + messages[message][key] + "<br>";
								}else{
									text = text + "&nbsp;&nbsp;" + this.resourceBundle["Others"]  + "<br>";
								}
							}
		
						}
					}
				}

				return text;
			},
			
			showFailureDialog: function(next, skip){
				var title = this.getNLSValue("title_ValidationFailure");
				var text = this.getNLSValue("text_ValidationFailure");
				var buttonsCollection = {};
				var dialog = new ActivityDialog({
								title: title, // DEV: to be localized
								text: text,
								containReason: false,
								buttonsCollection: buttonsCollection,
								onCancel: lang.hitch(this, function() {
									this.executing = false;
									this.setEnabled(true);
									skip();
								})
				});
				dialog.setWidth(480);
				dialog.cancelButton.set("label", this.getNLSValue("label_Failure"));
				dialog.show();
			},
			
			validateHandle: function(activityEditable, results, next, skip){
				var text = this.warnMessageHandle(results);
				var title = this.getNLSValue("title_Review");
				var showDialog = true;
				var isFailed = false;//include business validation failure or controller or view validation failure
				var isModified = false; //current UI modification behaviour
				var isBackEndUpdated = false;  //data modification marked by back-end;
				var isBizValid = true;// business validation failure
				var isValid = true; //controller or view validation failure
				
				var anyAPRuleFailed = false; //Any rules failed in the AP Rule Matrix Info
				var anyAPRuleOverride = false; ////Any rules Override in the AP Rule Matrix Info
				
				var activityType = activityEditable.getActivityType();
				var activityId = activityEditable.getActivityId();
				
				if(results.length === 0){
					title = this.getNLSValue("title_Review");
					showDialog = true;
					isFailed = false;
					text = this.getNLSValue("text_Review");
				}else{
					//First-Level Validation
					if(array.some(results, function(result) {
							if(result[1] !== undefined 
								&& result[1]["isValid"] === false 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						title = this.getNLSValue("title_Failure");
						showDialog = true;
						isFailed = true;
						isValid = false;
					}else{
						//Any Field Modified
						if(array.some(results, function(result) {
								if(result[1] !== undefined 
									&& result[1]["isModified"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							isModified = true;
							showDialog = false;
						}else if((activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").PENDREPAIR) &&
								 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED) &&
								 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").ERROR) &&
								 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM)){
							showDialog = false;
					    }
					}
					
					if(isValid){
						//Second-Level Validation (Part 1)
						/*based on business rules*/
						if(array.some(results, function(result){
								if(result[1] !== undefined 
									&& result[1]["bizValid"] === false 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							title = this.getNLSValue("title_Failure");
							showDialog = true;
							isFailed = true;
							isBizValid = false;
						}else{
							if(array.some(results, function(result) {
									if(result[1] !== undefined 
										&& result[1]["backEndUpdated"] === true 
										&& result[1]["activityType"] === activityType
										&& result[1]["activityId"] === activityId){
										return true;
									}
							})){
								isBackEndUpdated = true;
								showDialog = false;
							}else if((activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").PENDREPAIR) &&
									 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED) &&
									 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").ERROR) &&
									 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM)){
								showDialog = false;
							}
						}
					}
					
					if(isValid && !isFailed){
						//Second-Level Validation (Part 2)
						/*based on AP Rules Matrix Info*/
						if(array.some(results, function(result){
								if(result[1] !== undefined 
									&& result[1]["anyAPRuleFailed"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							title = this.getNLSValue("title_Failure");
							showDialog = true;
							isFailed = true;
							isBizValid = false;
							anyAPRuleFailed = true;
						}
					}
					
					if(isValid){
						/*based on AP Rules Matrix Info*/
						if(array.some(results, function(result){
								if(result[1] !== undefined 
									&& result[1]["anyAPRuleOverride"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							anyAPRuleOverride = true;
						}
					}
				}
				
				//Added by Purna -- instead of adding OR condition for all future processes, making it configurable in Base Constants.
				var pthActivities = Util.getConstant("PTH_Activities");
				//End
				
				//Special Handling required on Complete for PTH Activities starts here (COA & OAO Specific).
				if(activityType && ((activityType.indexOf('AMT_COA_PTH') > -1) || (activityType.indexOf('AMT_OAO_PTH') > -1))){
					activityEditable.setCurrentComment("");
					activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
					next();
				//Special Handling required on Complete for PTH Activities Ends here (COA & OAO Specific).
				
				//Added by Purna -- check if the PTH activity is configured for special handling in base
				} else if(pthActivities instanceof Array && pthActivities.length > 0 && activityType && 
					array.indexOf(pthActivities, activityType) > -1) {
					
					activityEditable.setCurrentComment("");
					activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
					next();
				//End
				
				}else if(isValid){
					//SNP
					var caseTypeId = "";
					console.log("Complete for SNP:",activityEditable);
					if(activityEditable.parentCase && activityEditable.parentCase.caseType && activityEditable.parentCase.caseType.id){
						caseTypeId = activityEditable.parentCase.caseType.id;
					}
					//End SNP
					if(isModified){
						activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
						next();
					}
					//Added for SNP for status setting as Pend Review
					else if(caseTypeId=="EWFSV_ScanAndPost"){
						if(activityEditable.getCurrentStatus() != "Reviewed"){
							activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
						}
						next();
					}
					//End Added for SNP for status setting as Pend Review
					 else if(showDialog){
						var dialog = null;
						var buttonsCollection = {};
						if(!isFailed){
							//Commented this out during COA DEV as it will never enter this code block
							
							/*var ReviewButtonObj = {};
							ReviewButtonObj.buttonLabel = this.getNLSValue("label_Reviewed");
							if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
								ReviewButtonObj.disabled = true;
							}else{
								ReviewButtonObj.disabled = false;
							}
							ReviewButtonObj.onExecute = lang.hitch(this, function() {
								activityEditable.setCurrentComment(dialog.reason.get("value"));
								activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
								//alert("Reason for Reviewed:" + dialog.reason.get("value"));
								next();
							});
							buttonsCollection.Reviewed = ReviewButtonObj;*/
							
							//Added during COA Dev to bypass the dialog in case of Reviewed and no changes made
							activityEditable.setCurrentComment("");
							activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
							next();
						}else{
							if(isValid){
								title = this.getNLSValue("title_Failure");
								text = this.getNLSValue("text_Failure");
								var OverrideButtonObj = {};
								OverrideButtonObj.buttonLabel =  this.getNLSValue("label_Override");
								/*if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
									OverrideButtonObj.disabled = true;
								}else{
									OverrideButtonObj.disabled = false;
								}*/
								OverrideButtonObj.disabled = false;
								
								OverrideButtonObj.onExecute = lang.hitch(this, function() {
													activityEditable.setCurrentComment(dialog.reason.get("value"));
													activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").OVERRIDEN);
													next();
												});
								buttonsCollection.Override = OverrideButtonObj;
								
								var FailedButtonObj = {};
								FailedButtonObj.buttonLabel = this.getNLSValue("label_Failed");
								/*if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
									FailedButtonObj.disabled = true;
								}else{
									FailedButtonObj.disabled = false;
								}*/
								FailedButtonObj.disabled = false;
								
								FailedButtonObj.onExecute = lang.hitch(this, function() {
													activityEditable.setCurrentComment(dialog.reason.get("value"));
													activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").FAILED);
													//alert("Reason for Failed:" + dialog.reason.get("value"));
													this.setDiscard(false);
													next();
												});
								buttonsCollection.Failed = FailedButtonObj;
							}
						}
						
						if(!isFailed && anyAPRuleOverride){
							//If any AP rule is Overridden, Set Activity Status as Overridden and Proceed the work item
							activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").OVERRIDEN);
							next();
						}else if(isFailed){
							dialog = new ActivityDialog({
												title: title, // DEV: to be localized
												text: text,
												buttonsCollection: buttonsCollection,
												onCancel: lang.hitch(this, function() {
													this.executing = false;
													this.setEnabled(true);
													skip();
												})
								});
							dialog.show();
						}
					} else {
						//no any update and the task with the status other than Pend-Repair, Error and Flagged. Do nothing.
						if(!isModified && !isBackEndUpdated){
							if(anyAPRuleOverride){
								activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").OVERRIDEN);
								next();
							}else{
								if(activityEditable.getCurrentStatus() === Util.getConstant("EWF_AcitivityStatus").FOLLOWUPCB){
									/*var buttonsCollection = {};
									var ReviewButtonObj = {};
									ReviewButtonObj.buttonLabel = this.getNLSValue("label_Reviewed");
									
									ReviewButtonObj.onExecute = lang.hitch(this, function() {
														activityEditable.setCurrentComment(dialog.reason.get("value"));
														activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
														//alert("Reason for Reviewed:" + dialog.reason.get("value"));
														next();
													});
									buttonsCollection.Reviewed = ReviewButtonObj;
									dialog = new ActivityDialog({
														title: title, // DEV: to be localized
														text: text,
														buttonsCollection: buttonsCollection,
														onCancel: lang.hitch(this, function() {
															this.executing = false;
															this.setEnabled(true);
															skip();
														})
										});
									//dialog.setWidth(480);
									dialog.show();*/
									if(dialog && dialog.reason && dialog.reason.get)
										activityEditable.setCurrentComment(dialog.reason.get("value"));
									else
										activityEditable.setCurrentComment("");
									activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
									//alert("Reason for Reviewed:" + dialog.reason.get("value"));
									next();
									
								} else{
									this.executing = false;
									this.setEnabled(true);
									skip();
								}
							}
						}else{
							//just back-end updated and the task with status pend-reviewed, do nothing
							if(!isModified && isBackEndUpdated && (activityEditable.getCurrentStatus() === Util.getConstant("EWF_AcitivityStatus").PENDREVIEW)){
								this.executing = false;
								this.setEnabled(true);
								skip();
							}else{
								//DEV: Need Clean-up. Probably the checks will never progress until here. Need to Remove
								activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
								next();
							}
						}
					}
				}else{
					this.showFailureDialog(next, skip);
				}
			},

			validateHandle_OTT: function(activityEditable, results, next, skip){
				var text = this.warnMessageHandle(results);
				var title = this.getNLSValue("title_Review");
				var showDialog = true;
				var isFailed = false;//include business validation failure or controller or view validation failure
				var isModified = false; //current UI modification behaviour
				var isBackEndUpdated = false;  //data modification marked by back-end;
				var isBizValid = true;// business validation failure
				var isValid = true; //controller or view validation failure
				
				if(results.length === 0){
					title = this.getNLSValue("title_Review");
					showDialog = true;
					isFailed = false;
					text = this.getNLSValue("text_Review");
				}else{
					var activityType = activityEditable.getActivityType();
					var activityId = activityEditable.getActivityId();
					
					if(array.some(results, function(result) {
							if(result[1] !== undefined 
								&& result[1]["isValid"] === false 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						title = this.getNLSValue("title_Failure");
						showDialog = true;
						isFailed = true;
						isValid = false;
					}else{
						if(array.some(results, function(result) {
								if(result[1] !== undefined 
									&& result[1]["isModified"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							isModified = true;
							showDialog = false;
						}else if((activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").PENDREPAIR) &&
								 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED) &&
								 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").ERROR) &&
								 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM)){
							showDialog = false;
					    }
					}
					
					if(isValid){
						/*based on business rules*/
						if(array.some(results, function(result) {
								if(result[1] !== undefined 
									&& result[1]["bizValid"] === false 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							title = this.getNLSValue("title_Failure");
							showDialog = true;
							isFailed = true;
							isBizValid = false;
						}else{
							if(array.some(results, function(result) {
									if(result[1] !== undefined 
										&& result[1]["backEndUpdated"] === true 
										&& result[1]["activityType"] === activityType
										&& result[1]["activityId"] === activityId){
										return true;
									}
							})){
								isBackEndUpdated = true;
								showDialog = false;
							}else if((activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").PENDREPAIR) &&
									 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED) &&
									 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").ERROR) &&
									 (activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM)){
								showDialog = false;
							}
						}
					}
				}
				
				if(isValid){
					if(showDialog){
						var dialog = null;
						var buttonsCollection = {};
						if(!isFailed){
							var ReviewButtonObj = {};
							ReviewButtonObj.buttonLabel = this.getNLSValue("label_Reviewed");
							if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
								ReviewButtonObj.disabled = true;
							}else{
								ReviewButtonObj.disabled = false;
							}
							ReviewButtonObj.onExecute = lang.hitch(this, function() {
												activityEditable.setCurrentComment(dialog.reason.get("value"));
												activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
												//alert("Reason for Reviewed:" + dialog.reason.get("value"));
												next();
											});
							buttonsCollection.Reviewed = ReviewButtonObj;
						}else{
							if(isValid){
								title = this.getNLSValue("title_Failure");
								text = this.getNLSValue("text_Failure");
								var OverrideButtonObj = {};
								OverrideButtonObj.buttonLabel =  this.getNLSValue("label_Override");
								if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
									OverrideButtonObj.disabled = true;
								}else{
									OverrideButtonObj.disabled = false;
								}
								OverrideButtonObj.onExecute = lang.hitch(this, function() {
													activityEditable.setCurrentComment(dialog.reason.get("value"));
													activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").OVERRIDEN);
													//alert("Reason for Override:" + dialog.reason.get("value"));
													next();
												});
								buttonsCollection.Override = OverrideButtonObj;
								
								var FailedButtonObj = {};
								FailedButtonObj.buttonLabel = this.getNLSValue("label_Failed");
								if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").FLAGGED){
									FailedButtonObj.disabled = true;
								}else{
									FailedButtonObj.disabled = false;
								}
								
								FailedButtonObj.onExecute = lang.hitch(this, function() {
													activityEditable.setCurrentComment(dialog.reason.get("value"));
													activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").FAILED);
													//alert("Reason for Failed:" + dialog.reason.get("value"));
													this.setDiscard(false);
													next();
												});
								buttonsCollection.Failed = FailedButtonObj;
							}
						}
						dialog = new ActivityDialog({
											title: title, // DEV: to be localized
											text: text,
											buttonsCollection: buttonsCollection,
											onCancel: lang.hitch(this, function() {
												this.executing = false;
												this.setEnabled(true);
												skip();
											})
							});
						//dialog.setWidth(480);
						dialog.show();
					}else{
					//no any update and the task with the status other than Pend-Repair, Error and Flagged. Do nothing.
						if(!isModified&&!isBackEndUpdated){
							if(activityEditable.getCurrentStatus() === Util.getConstant("EWF_AcitivityStatus").FOLLOWUPCB){
								var buttonsCollection = {};
								var ReviewButtonObj = {};
								ReviewButtonObj.buttonLabel = this.getNLSValue("label_Reviewed");
								
								ReviewButtonObj.onExecute = lang.hitch(this, function() {
													activityEditable.setCurrentComment(dialog.reason.get("value"));
													activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
													//alert("Reason for Reviewed:" + dialog.reason.get("value"));
													next();
												});
								buttonsCollection.Reviewed = ReviewButtonObj;
								dialog = new ActivityDialog({
													title: title, // DEV: to be localized
													text: text,
													buttonsCollection: buttonsCollection,
													onCancel: lang.hitch(this, function() {
														this.executing = false;
														this.setEnabled(true);
														skip();
													})
									});
								//dialog.setWidth(480);
								dialog.show();
							} else {
								this.executing = false;
								this.setEnabled(true);
								skip();
							}
						}else{
							//just back-end updated and the task with status pend-reviewed, do nothing
							if(!isModified&&isBackEndUpdated&&(activityEditable.getCurrentStatus() === Util.getConstant("EWF_AcitivityStatus").PENDREVIEW)){
								this.executing = false;
								this.setEnabled(true);
								skip();
							}else{
								activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
								next();
							}
						}
					}
				}else{
					this.showFailureDialog(next, skip);
				}
			},
			
			execute: function()
			{
				this.logInfo("Activity Complete is being executed");

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}
				
				var context = [];
				context[Util.getConstant("EWF_CoordContext").ACTIVITY] = true;
				context[Util.getConstant("EWF_CoordContext").ACTIVITYTYPE] = ActivityEditable[0].getActivityType();
				context[Util.getConstant("EWF_CoordContext").ACTIVITYID] = ActivityEditable[0].getActivityId();
				
				//Added By Gopi to capture the response selected by the user
				
				if(null!=this.getArgument('label'))
					context[Util.getConstant("EWF_CoordContext").ACTIVITYRESPONSE] = this.getArgument('label');
					
				//End By Gopi
					
				// disable action during execution
				this.executing = true;
				this.setEnabled(false);

				coordination[0].step(Util.getConstant("EWF_CoordTopic").COMMIT, 
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in commit step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in commit step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").VALIDATE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in validate step callback, results");
							this.logInfo("execute", results);
							
							//Added by Purna on 17/01/2017 for OTT - As OTT should work like v1.0 complete call other method if sol prefix is EWF
							//this.validateHandle(ActivityEditable[0], results, next, skip); //instead of calling it directly depend on the new condition
							var solPrefix = "";
							var activityEditable = ActivityEditable[0];
							if(activityEditable.parentCase && activityEditable.parentCase.propertiesCollection && activityEditable.parentCase.propertiesCollection.SolutionPrefix
									&& activityEditable.parentCase.propertiesCollection.SolutionPrefix.value){
								solPrefix = activityEditable.parentCase.propertiesCollection.SolutionPrefix.value;
							}
							if(solPrefix == "EWF") {
								this.validateHandle_OTT(ActivityEditable[0], results, next, skip);
							} else {
								this.validateHandle(ActivityEditable[0], results, next, skip);
							}
							//End change by Purna
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in validate step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").BEFORECOMPLETE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in beforeSave step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in beforeSave step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").COMPLETE,
						lang.hitch(this, function(results, next, skip){
							//TODO:collect the modified properties.
							ActivityEditable[0].save(
								lang.hitch(this, function(response, fieldErrors) {
									this.logInfo("execute", "complete operation on activity");
									this.publishEvent(
											"icm.ewfActivityComplete",
											{'ActivityEditable': ActivityEditable[0]}
									);
									next();
								}),
								lang.hitch(this, function(response, fieldErrors) {
									// enable action if failed
									this.executing = false;
									this.setEnabled(true);
									skip();
								}),
								this.arguments["label"],
								this.getDiscard()
							);
						}), 
						lang.hitch(this, function(errors, next, skip){
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").AFTERCOMPLETE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in afterComplete step callback, results");
							this.logInfo("execute", results);
							// enable action if complete
							this.executing = false;
							this.setEnabled(this.isEnabled());
							this.refreshMenus();
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in afterSave step errback, errors");
							this.logInfo("execute", errors);
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).start(context);
			},

			_eoc_:null

		});
});