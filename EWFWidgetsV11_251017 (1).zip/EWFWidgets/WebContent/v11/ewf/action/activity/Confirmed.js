define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/connect",
	"dojo/_base/array",
	"icm/action/Action",
	"v11/ewf/dialog/activitydialog/ActivityDialog",
	"dojo/i18n!../../nls/common",
	"v11/ewf/util/Util"
	], function(declare, lang, connect, array, Action, ActivityDialog, resources, Util) {
	/**
	 * @name v11.ewf.action.activity.Confirmed
	 * @class make the Confirmed operation on a activity. <br>
	 *        Context required by this action: [['ActivityEditable', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'COMMIT'
	 * <li> 'VALIDATE' 
	 * <li> 'BEFORECOMPLETE'
	 * <li> 'COMPLETE'
	 * <li> 'AFTERCOMPLETE'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORACTIVITY': true
	 * </ul>
	 * @augments icm.action.Action
	 */
		return declare("v11.ewf.action.activity.Confirmed", [Action], {
			
			executing: false,
			discard: false,
			
			getNLSValue : function(name){
				return resources.Actions[name] || null;
			},
			
			setDiscard: function(discard)
			{
				this.discard = discard;
			},
			
			getDiscard: function()
			{
				return this.discard;
			},

			isVisible: function()
			{
				return true;
			},
		
			isEnabled: function()
			{ 
				// keep action disabled during execution
				if (this.executing)
				{
					return false;
				}

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}

				var uiState = this.getActionContext("UIState");
				
				if( uiState !== null && uiState.length > 0){
					var readonly = uiState[0].get("ActivityReadOnly");
					if(readonly){
						return false;
					}
				}
			
				return true;
			},
			
			warnMessageHandle: function(errors){
				var text ="";
				var messages= {};
				var error;
				var message;
				var items;
				var i, j;
				var key;

				for(i = 0; i < errors.length; i++){
					if(errors[i][0] === true){
						error = errors[i][1];
						if(error !== undefined && error !== null && error.message !== undefined && error.message !== null){
							message= messages[error.message];
							if(!message){
								message = messages[error.message] = {};
							}
							items = error.items;
							if(items){
								for(j = 0; j < items.length; j++){
									item = items[j];
									message[item] = item;
								}
							}
						}
					}
				}



				for(message in messages){
					if(messages.hasOwnProperty(message)){
						text = text + message;
						i = 0;
						for(key in messages[message]){
							if(messages[message].hasOwnProperty(key)){
								i++;
								if ( i <= 5){
									text = text + "&nbsp;&nbsp;" + messages[message][key] + "<br>";
								}else{
									text = text + "&nbsp;&nbsp;" + this.resourceBundle["Others"]  + "<br>";
								}
							}
		
						}
					}
				}

				return text;
			},
			
			showFailureDialog: function(next, skip){
				var title = this.getNLSValue("title_ValidationFailure");
				var text = this.getNLSValue("text_ValidationFailure");
				var buttonsCollection = {};
				var dialog = new ActivityDialog({
								title: title, // DEV: to be localized
								text: text,
								containReason: false,
								buttonsCollection: buttonsCollection,
								onCancel: lang.hitch(this, function() {
									this.executing = false;
									this.setEnabled(true);
									skip();
								})
				});
				dialog.setWidth(480);
				dialog.cancelButton.set("label", this.getNLSValue("label_Failure"));
				dialog.show();
			},
			
			showBizInValidDialog: function(activityEditable, next, skip){
				var title = this.getNLSValue("title_bizInValid");
				var text = this.getNLSValue("text_bizInValid");
				var dialog = null;
				var buttonsCollection = {};
				var CompleteButtonObj = {};
				CompleteButtonObj.buttonLabel = this.getNLSValue("label_bizInValid");
				CompleteButtonObj.disabled = true;
				CompleteButtonObj.onExecute = lang.hitch(this, function() {
												activityEditable.setCurrentComment(dialog.reason.get("value"));
												activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREPAIR);
												next();
				});
				buttonsCollection.Complete = CompleteButtonObj;
				var dialog = new ActivityDialog({
								title: title, // DEV: to be localized
								text: text,
								buttonsCollection: buttonsCollection,
								onCancel: lang.hitch(this, function() {
									this.executing = false;
									this.setEnabled(true);
									skip();
								})
				});
				dialog.show();
			},			
			
			validateHandle: function(activityEditable, results, next, skip){
				var isFailed = false;//include business validation failure or controller or view validation failure
				var isModified = false; //current UI modification behaviour
				var isBackEndUpdated = false;  //data modification marked by back-end;
				var isBizValid = true;// business validation failure
				var isValid = true; //controller or view validation failure
				
				var anyAPRuleFailed = false; //Any rules failed in the AP Rule Matrix Info
				var anyAPRuleOverride = false; ////Any rules Override in the AP Rule Matrix Info
				
				
				if(results.length === 0){
					isFailed = false;
				}else{
					var activityType = activityEditable.getActivityType();
					var activityId = activityEditable.getActivityId();
					
					//First-Level Validation
					if(array.some(results, function(result) {
							if(result[1] !== undefined 
								&& result[1]["isValid"] === false 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						isFailed = true;
						isValid = false;
					}else{
						//Any Field Modified
						if(array.some(results, function(result) {
								if(result[1] !== undefined 
									&& result[1]["isModified"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							isModified = true;
						}
					}
					
					/*based on business rules validation and back-end updated*/
					if(array.some(results, function(result) {
							if(result[1] !== undefined 
								&& result[1]["bizValid"] === false 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						isFailed = true;
						isBizValid = false;
					}else{
						if(array.some(results, function(result) {
								if(result[1] !== undefined 
									&& result[1]["backEndUpdated"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							isBackEndUpdated = true;
						}
					}
				}
				
				if(isValid && !isFailed){
					//Second-Level Validation (Part 2)
					/*based on AP Rules Matrix Info*/
					if(array.some(results, function(result){
							if(result[1] !== undefined 
								&& result[1]["anyAPRuleFailed"] === true 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						title = this.getNLSValue("title_Failure");
						isFailed = true;
						isBizValid = false;
						anyAPRuleFailed = true;
					}
				}
				
				if(isValid){
					/*based on AP Rules Matrix Info*/
					if(array.some(results, function(result){
							if(result[1] !== undefined 
								&& result[1]["anyAPRuleOverride"] === true 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						anyAPRuleOverride = true;
					}
				}
				
				if((activityType === 'AMT_COA_CallBackAuthenticationCheck') || (activityType === 'EWF_CallBackAuthenticationCheck')){
					var valueToCheck = activityEditable.propertiesCollection['CallbackUpdate'].getValue();
					if((valueToCheck === 'authenticated') || (valueToCheck === 'not required')){
						activityEditable.setCurrentComment("");
						activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
					} else{
						activityEditable.setCurrentComment("");
						activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREPAIR);
					}
					next();
				} else if(activityType === 'EWFSV_SNPPerformCallBackCheck'){
					var valueToCheck = activityEditable.propertiesCollection['UTCode'].getValue();	
					if((valueToCheck === 'authenticated') || (valueToCheck === 'not required')){
						activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
					}else if((valueToCheck === 'pend for retry') || (valueToCheck === 'failed authentication')){
						activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREPAIR);
					}
					next();
				}else if(isValid){
					if(isModified){
						activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
						next();
					}else if(isFailed){
						this.showBizInValidDialog(activityEditable, next, skip);
					}else if(isBackEndUpdated){
						if(!isModified && (activityEditable.getCurrentStatus() === Util.getConstant("EWF_AcitivityStatus").PENDREVIEW)){
							this.executing = false;
							this.setEnabled(true);
							skip();
						} else if(anyAPRuleFailed){
								activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREPAIR);
								next();
						}else if(anyAPRuleOverride){
								activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").OVERRIDEN);
								next();
						}else {
							//TODO: Probably will never reach here
							this.executing = false;
							this.setEnabled(true);
							skip();
						}
					}else{
						activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
						next();
					}
				}else{
					this.showFailureDialog(next, skip);
				}
				
			},

			validateHandle_OTT: function(activityEditable, results, next, skip){
				var isFailed = false;//include business validation failure or controller or view validation failure
				var isModified = false; //current UI modification behaviour
				var isBackEndUpdated = false;  //data modification marked by back-end;
				var isBizValid = true;// business validation failure
				var isValid = true; //controller or view validation failure		
				
				if(results.length === 0){
					isFailed = false;
				}else{
				
					var activityType = activityEditable.getActivityType();
					var activityId = activityEditable.getActivityId();
					
					if(array.some(results, function(result) {
							if(result[1] !== undefined 
								&& result[1]["isValid"] === false 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						isFailed = true;
						isValid = false;
					}else{
						if(array.some(results, function(result) {
								if(result[1] !== undefined 
									&& result[1]["isModified"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							isModified = true;
						}
					}
					
					/*based on business rules validation and back-end updated*/
					if(array.some(results, function(result) {
							if(result[1] !== undefined 
								&& result[1]["bizValid"] === false 
								&& result[1]["activityType"] === activityType
								&& result[1]["activityId"] === activityId){
								return true;
							}
					})){
						isFailed = true;
						isBizValid = false;
					}else{
						if(array.some(results, function(result) {
								if(result[1] !== undefined 
									&& result[1]["backEndUpdated"] === true 
									&& result[1]["activityType"] === activityType
									&& result[1]["activityId"] === activityId){
									return true;
								}
						})){
							isBackEndUpdated = true;
						}
					}
				}
				if(isValid){
					if(isFailed){
						this.showBizInValidDialog(activityEditable, next, skip);
					}else{
						if(isModified || isBackEndUpdated){
							if(!isModified && (activityEditable.getCurrentStatus() === Util.getConstant("EWF_AcitivityStatus").PENDREVIEW)){
								this.executing = false;
								this.setEnabled(true);
								skip();
							} else {
								/* Defect ID's: 3767, 3470
								 * OTT Specific Action for Call Back Authentication Check activity (in Call Back step only): 
								 * Status to be updated as "Reviewed" if 
								 *  --> "Callback Authentication Decision" drop down value is Authenticated / Not Required
								 * 
								 * otherwise
								 * --> Follow the default behavior
								 * 
								 * Values in choice list --> None, authenticated, not required, failed authentication
								 */
								if(activityType === 'EWF_CallBackAuthenticationCheck'){
									var valueToCheck = activityEditable.propertiesCollection['CallbackUpdate'].getValue();
									if((valueToCheck === 'authenticated') || (valueToCheck === 'not required')){
										activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
									} else {
										activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
									}
								} else {
									activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").PENDREVIEW);
								}
							}
						} else if(activityEditable.getCurrentStatus() !== Util.getConstant("EWF_AcitivityStatus").PENDREVIEW){
							/* 
							 * OTT Specific --> Defect ID: 3828 Added the above check for OTT since "isBackEndUpdated" flag is not coming as true even though the activity is updated in backend
							 * For CCA activities, the flag is coming as true
							 */
							activityEditable.setCurrentStatus(Util.getConstant("EWF_AcitivityStatus").REVIEWED);
						}
						next();
					}
				}else{
					this.showFailureDialog(next, skip);
				}
				
			},
			
			execute: function()
			{
				this.logInfo("Activity Complete is being executed");

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}
				
				var context = [];
				context[Util.getConstant("EWF_CoordContext").ACTIVITY] = true;
				context[Util.getConstant("EWF_CoordContext").ACTIVITYTYPE] = ActivityEditable[0].getActivityType();
				context[Util.getConstant("EWF_CoordContext").ACTIVITYID] = ActivityEditable[0].getActivityId();
				
				//Added By Gopi to capture the the response selected by the user
				
				if(null!=this.getArgument('label'))
					context[Util.getConstant("EWF_CoordContext").ACTIVITYRESPONSE] = this.getArgument('label');
					
				//End By Gopi
				
				// disable action during execution
				this.executing = true;
				this.setEnabled(false);

				coordination[0].step(Util.getConstant("EWF_CoordTopic").COMMIT, 
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in commit step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in commit step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").VALIDATE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in validate step callback, results");
							this.logInfo("execute", results);
							
							//Added by Purna on 17/01/2017 for OTT - As OTT should work like v1.0 complete call other method if sol prefix is EWF
							//this.validateHandle(ActivityEditable[0], results, next, skip); //instead of calling it directly depend on the new condition
							var solPrefix = "";
							var activityEditable = ActivityEditable[0];
							if(activityEditable.parentCase && activityEditable.parentCase.propertiesCollection && activityEditable.parentCase.propertiesCollection.SolutionPrefix
									&& activityEditable.parentCase.propertiesCollection.SolutionPrefix.value){
								solPrefix = activityEditable.parentCase.propertiesCollection.SolutionPrefix.value;
							}
							if(solPrefix == "EWF") {
								this.validateHandle_OTT(ActivityEditable[0], results, next, skip);
							} else {
								this.validateHandle(ActivityEditable[0], results, next, skip);
							}
							//End change by Purna
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in validate step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").BEFORECOMPLETE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in beforeSave step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in beforeSave step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").COMPLETE,
						lang.hitch(this, function(results, next, skip){
							//TODO:collect the modified properties.
							ActivityEditable[0].save(
								lang.hitch(this, function(response, fieldErrors) {
									this.logInfo("execute", "complete operation on activity");
									this.publishEvent(
											"icm.ewfActivityConfirmed",
											{'ActivityEditable': ActivityEditable[0]}
									);
									next();
								}),
								lang.hitch(this, function(response, fieldErrors) {
									// enable action if failed
									this.executing = false;
									this.setEnabled(true);
									skip();
								}),
								this.arguments["label"],
								this.getDiscard()
							);
						}), 
						lang.hitch(this, function(errors, next, skip){
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").AFTERCOMPLETE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in afterComplete step callback, results");
							this.logInfo("execute", results);
							this.executing = false;
							this.setEnabled(this.isEnabled());
							this.refreshMenus();
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in afterSave step errback, errors");
							this.logInfo("execute", errors);
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).start(context);
			},
			
			

			_eoc_:null

		});
});