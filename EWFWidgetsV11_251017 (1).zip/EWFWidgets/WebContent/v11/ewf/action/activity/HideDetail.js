define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/connect",
	"dojo/_base/array",
	"icm/action/Action",
	"v11/ewf/dialog/activitydialog/ActivityDialog",
	"v11/ewf/util/Util"
	], function(declare, lang, connect, array, Action, ActivityDialog, Util) {
	/**
	 * @name v11.ewf.action.activity.HideDetail
	 * @class make the hide detail screen operation on a activity. <br>
	 *        Context required by this action: [['ActivityEditable', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'BEFOREHIDE'
	 * <li> 'HIDE'
	 * <li> 'AFTERHIDE'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORACTIVITY': true
	 * </ul>
	 * @augments icm.action.Action
	 */
		return declare("v11.ewf.action.activity.HideDetail", [Action], {
			
			executing: false,

			isVisible: function()
			{
				return true;
			},
		
			isEnabled: function()
			{ 
				// keep action disabled during execution
				if (this.executing)
				{
					return false;
				}

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}
				
				return true;
			},
			

			execute: function()
			{
				this.logInfo("Activity Complete is being executed");

				var ActivityEditable = this.getActionContext("ActivityEditable");
				if(ActivityEditable === null || ActivityEditable.length == 0) {
					return false;
				}

				var coordination = this.getActionContext("Coordination");
				if(coordination === null || coordination.length == 0) {
					return false;
				}
				
				var context = [];
				context[Util.getConstant("EWF_CoordContext").ACTIVITY] = true;
				context[Util.getConstant("EWF_CoordContext").ACTIVITYTYPE] = ActivityEditable[0].getActivityType();
				context[Util.getConstant("EWF_CoordContext").ACTIVITYID] = ActivityEditable[0].getActivityId();
				
				//Added By Gopi to capture the the response selected by the user
				
				if(null!=this.getArgument('label'))
					context[Util.getConstant("EWF_CoordContext").ACTIVITYRESPONSE] = this.getArgument('label');
					
				//End By Gopi
				
				// disable action during execution
				this.executing = true;
				this.setEnabled(false);

				coordination[0].step(Util.getConstant("EWF_CoordTopic").BEFOREHIDE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in beforeHide step callback, results");
							this.logInfo("execute", results);
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in beforeHide step errback, errors");
							this.logInfo("execute", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).step(Util.getConstant("EWF_CoordTopic").HIDE,
						lang.hitch(this, function(results, next, skip){
							//TODO:collect the modified properties.
							this.logInfo("execute", "Hide detail screen operation on activity");
							this.publishEvent(
									"icm.HideDetailOnActivity",
									{'ActivityEditable': ActivityEditable[0]}
							);
							next();//TODO: once save API is ready, we will remove this;
						}), 
						lang.hitch(this, function(errors, next, skip){
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})
					).step(Util.getConstant("EWF_CoordTopic").AFTERHIDE,
						lang.hitch(this, function(results, next, skip){
							this.logInfo("execute", "in afterComplete step callback, results");
							this.logInfo("execute", results);
							// enable action if success
							this.executing = false;
							this.setEnabled(this.isEnabled());
							this.refreshMenus();
							next();
						}),
						lang.hitch(this, function(errors, next, skip){
							this.logInfo("execute", "in afterSave step errback, errors");
							this.logInfo("execute", errors);
							this.showErrDialog("actionExecutedErr", errors);
							// enable action if failed
							this.executing = false;
							this.setEnabled(true);
							skip();
						})

					).start(context);
			},
			
			

			_eoc_:null

		});
});