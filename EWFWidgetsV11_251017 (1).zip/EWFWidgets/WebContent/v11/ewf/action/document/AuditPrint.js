define([
        "dojo/_base/declare", 
        "dojo/_base/lang",
        "icm/action/Action"
], function(declare, lang, Action) {

	
	return declare("v11.ewf.action.document.AuditPrint", [Action], {
	/** @lends ewf.action.workitem.CloseAndGetNextWorkItem.prototype */
		
		isEnabled: function()
		{
			return true;

		},

		isVisible: function()
		{
			return true;
		},

		execute: function()
		{
           
		},
	
		_eoc_:null
		
	});
	
});