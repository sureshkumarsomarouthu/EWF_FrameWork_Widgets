define([ "dojo/_base/declare", 
"dojo/_base/lang",
"dojo/on",
"ecm/widget/dialog/BaseDialog", 
"v11/ewf/util/Util" ],
function(declare, lang, on, BaseDialog, Util) {
    return declare("v11.ewf.action._MessageDialogMixin", null, {
        showErrDialog : function(message_topic, errors) {
            var bundle = Util.getResourceBundle("Actions");
            var title = (bundle && bundle.errDialogTitle) || "Incomplete";
            var text = (bundle && bundle.errDialogText) || "Invalid data detected in the fields, please correct!";

            var errorDialog = new BaseDialog({
                title : title
            });

            errorDialog.own(on(errorDialog, "hide", function() {
                errorDialog.destroy();
            }));

            errorDialog.setMessage(text, "warning");

            errorDialog.show();
        },

        _eoc_ : null

    });

});
