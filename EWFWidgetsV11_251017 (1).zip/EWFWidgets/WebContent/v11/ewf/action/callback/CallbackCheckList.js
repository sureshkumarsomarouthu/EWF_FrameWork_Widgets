define([
        "dojo/_base/declare", 
        "dojo/_base/lang",
    	"icm/util/WorkItemHandler",
        "icm/action/Action",
    	"ecm/widget/dialog/MessageDialog",
    	"v11/ewf/dialog/callbackchecklistdialog/CallbackCheckListDialog",
		"v11/ewf/util/Util"
], function(declare, lang, WorkItemHandler, Action, MessageDialog, CallBackCheckListDialog, Util) {

	/**
	 * @name ewf.action.callback.CallBackCheckList
	 * @class invoke a dialog to generate advice letter according to template predefined for the case that work item belongs to.<br>
	 *        Context required by this action: [['WorkItemPage', 'Coordination']] <br>
	 *        A series of topics of coordination as follows will be started in sequence. <br>
	 * <ul>      
	 * <li> 'BEFOREADVICE'
	 * <li> 'ADVICE' 
	 * <li> 'AFTERADVICE'
	 * </ul>
	 *        The coordination will be started with the following context. <br>
	 * <ul>      
	 * <li> 'FORWORKITEM': true
	 * </ul>
	 * @augments icm.action.Action
	 */
	return declare("v11.ewf.action.callback.CallbackCheckList", [Action], {
	/** @lends ewf.action.callback.CallBackCheckList.prototype */
		

		
		

		
		isEnabled: function()
		{
            var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}
			return true;

		},
		
	

		execute: function()
		{
            var context = [];
            context[this.icmBaseConst.WKIM] = true;
			var WorkItemEditable = this.getActionContext("WorkItemPage");
			if(WorkItemEditable === null || WorkItemEditable.length == 0) {
			    return false;
			}

			var coordination = this.getActionContext("Coordination");
			if(coordination === null || coordination.length == 0) {
			    return false;
			}


			var dialog = null;
			var buttonsCollection = {};
			var callBackButtonObj = {};

			buttonsCollection.CallBack = callBackButtonObj;

			
			dialog = new CallBackCheckListDialog({
				editable: WorkItemEditable,
				coordination : coordination,
				title: "Call Back Check List", // DEV: to be localized
				buttonsCollection: buttonsCollection,
				readOnly: false
			});
			dialog.show();	
			

		},
	
		_eoc_:null
		
	});
	
});