define(["dojo/_base/declare", "dojo/date/stamp", "dojo/date/locale"], function(declare, dojoDateStamp, dojoLocale){
	var Constants = declare("v11.ewf.ewfg.base.Constants", null, {
		// The additional definition for properties that are field items 
		EWF_FieldAttributes : {
			// Receipt Date
			"EWFSV_ProcessingTeam" : {
				"label": "Pend Doc Processing Center",
				"initStrLength" : 0,
				"propertyExtensionType" : "suggestionList",
				"suggestionList" : {
					"ref" : "depcode"
				},
				"instruction" : "Key in Pend Doc Processing Center"
			},
			"QualityReviewerId":{
				"label": "Quality Reviewer ID"
			},
			"EWS_RequestorDepartment":{
				"label": "Last Pend Doc Processing Center",
				"required": false
			},	
			"EWFSV_RejectReason" : {
				"label": "Reject Reason",
				"fieldWidth": "200px",
				//"propertyExtensionType" : "textarea",
				"editor": "pvr/widget/editors/TextareaEditor",
				"editorParams": {
					"requiredCase": 'upper',
					"autoAdjustCase":true
				},
				"regExp" : "^.{0,150}$",
				"invalidMessage" : "Cant Exceed 150 Characters.",
				"instruction" : ""
			}
			
		},
		
	
		"EWFG_DocumentRendezvous" :
		{	
			'Document Rendezvous Operator': 
			{ 
				'fields': ['EWFSV_ProcessingTeam', 'QualityReviewerId', 'EWS_RequestorDepartment', 'EWFSV_RejectReason'], 
				'modes': [false, true, true, true]
			},
			'DR Orphan': 
			{ 
				'fields': ['EWFSV_ProcessingTeam','QualityReviewerId'], 
				'modes': [true, true]
			},
			'DR Processing Center': 
			{ 
				'fields': ['EWFSV_ProcessingTeam','QualityReviewerId'], 
				'modes': [true, true]
			}
		},
		
		"DR_SEARCH_CASE_STATUS": ['Manual Processing', 'Manual Processing Pend', 'Review','Review Pend','MP-PLCE STATUS','MP-PEND DOC COPC','MP-PEND DOC PFS']
		
	});
	return new Constants();
});