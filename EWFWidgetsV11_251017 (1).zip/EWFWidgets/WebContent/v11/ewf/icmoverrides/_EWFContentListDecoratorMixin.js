require([ "dojo/_base/lang", "dojo/_base/array", 'dojo/dom-geometry', 'dojo/dom-style', 'dojo/aspect', "ecm/model/ContentItem", "ecm/model/SearchTemplate", "ecm/model/ResultSet" ], function(lang, baseArray, domGeom, domStyle, dojoAspect, ContentItem, SearchTemplate, ResultSet) {
	
	/*
	 *
	 * This method overrides the dijit.BackgroundIframe._showSubBgIframes method behaviour which is causing the "Add Button" 
	 * in Documents Pane to not load when getNext is checked.
	 * Catching the error in case when the bgIframe is null and showing in the console
	 * 
	 * 
	 */
	console.log("------------------------------------------------------");
    console.log("Dynamically inject the dijit.BackgroundIframe._showSubBgIframes method!");
    console.log("------------------------------------------------------");
	dijit.BackgroundIframe.prototype._showSubBgIframes = function(node){
		var array = require('dojo/_base/array');
		var domGeom = require('dojo/dom-geometry');
		var domStyle = require('dojo/dom-style');
		baseArray.forEach(this._subBgIframes, function(subBgIframe){
			var nodePos = domGeom.position(node);
			var framePos = domGeom.position(subBgIframe.frame);
			nodePos.x -= framePos.x;
			nodePos.y -= framePos.y;try{
			domStyle.set(subBgIframe.bgIframe, {
				left: nodePos.x + "px",
				top: nodePos.y + "px",
				width: nodePos.w + "px",
				height: nodePos.h + "px",
				display: ""
			});}catch(e){console.log('Error in dijit.BackgroundIframe._showSubBgIframes ', e)}
		});
	}
 	
	/*
	 * 
	 * This method overrides the default _retrieveFolderCompleted function in ContentList widget
	 * We'll be hiding the columns which are having the decorators 'DetailsViewDecorator.mimeTypeDecorator'
	 * or 'DetailsViewDecorator.multiStateDecorator'
	 * 
	 */
	// Backup the original _retrieveFolderCompleted method
    var originalRetrieveFolderCompletedFunc = ContentItem.prototype._retrieveFolderCompleted;
    var newRetrieveFolderCompleted = function(response, filterType, noCache, teamspaceId, parent, callback) {
    	if(response && response.columns && response.columns.cells && (response.columns.cells.length > 0) && (response.columns.cells[0].length > 1) 
    			&& (response.columns.cells[0][1]['decorator']) && (response.columns.cells[0][1]['decorator'].indexOf('DetailsViewDecorator') > -1)){
    		//response.columns.cells[0][1]['decorator'] = 'DetailsViewDecorator.multiStateDecorator';
    		var newColumnsArray = new Array();
    		baseArray.forEach(response.columns.cells[0], function(column){
    			if((column['decorator'] === 'DetailsViewDecorator.mimeTypeDecorator')/* || (column['decorator'] === 'DetailsViewDecorator.multiStateDecorator')*/){
    				console.log('Removing Column from results ', column);
    			}else{
    				newColumnsArray.push(column);
    			}
    		});
    		response.columns.cells[0] = newColumnsArray;
    	}
    	var parentItem = parent ? parent : this;
        response.repository = this.repository;
        response.parentFolder = parentItem;
        response.teamspaceId = teamspaceId;
        var resultSet = ContentItem.createResultSet(response);
        if (!noCache && this._folderContents) {
            this._folderContents[filterType] = resultSet;
        }
        callback(resultSet);
    };

    console.log("------------------------------------------------------");
    console.log("Dynamically inject the ContentItem._retrieveFolderCompleted method!");
    ContentItem.prototype._retrieveFolderCompleted = newRetrieveFolderCompleted;
    console.log("------------------------------------------------------");
    
    var originalSearchCompletedFunc = SearchTemplate.prototype._searchCompleted;
    var newSearchCompletedFunc = function(response, callback, teamspace) {
    	if(response && response.columns && response.columns.cells && (response.columns.cells.length > 0) && (response.columns.cells[0].length > 1) 
    			&& (response.columns.cells[0][1]['decorator']) && (response.columns.cells[0][1]['decorator'].indexOf('DetailsViewDecorator') > -1)){
    		//response.columns.cells[0][1]['decorator'] = 'DetailsViewDecorator.multiStateDecorator';
    		var newColumnsArray = new Array();
    		baseArray.forEach(response.columns.cells[0], function(column){
    			if((column['decorator'] === 'DetailsViewDecorator.mimeTypeDecorator')/* || (column['decorator'] === 'DetailsViewDecorator.multiStateDecorator')*/){
    				console.log('Removing Column from results ', column);
    			}else{
    				newColumnsArray.push(column);
    			}
    		});
    		response.columns.cells[0] = newColumnsArray;
    	}
    	response.repository = this.repository;
        response.parentFolder = this;
        response.searchTemplate = this;
        response.teamspaceId = this.teamspaceId;
        var results = new ecm.model.ResultSet(response);
        if (this.moreOptions && this.moreOptions.versionOption) {
            results._versionLookup = {};
            results._versionLookup[this.repository.id] = this.moreOptions.versionOption;
        }
        if (callback) {
            callback(results);
        }
        this.onSearchCompleted(results);
    };

    console.log("------------------------------------------------------");
    console.log("Dynamically inject the SearchTemplate._searchCompleted method!");
    SearchTemplate.prototype._searchCompleted = newSearchCompletedFunc;
    console.log("------------------------------------------------------");
    
    try{
    	icmglobal = icmglobal || {};
    	icmglobal && icmglobal.logoffHook && icmglobal.logoffHook.remove && icmglobal.logoffHook.remove(); 
    	icmglobal.logoffHook = dojoAspect.after(ecm.model.desktop, 'logoff', function(method, args){
    		if(icmglobal && icmglobal.ewfCurrentUser && icmglobal.ewfCurrentUser.email)
    			icmglobal.ewfCurrentUser.email = null;
	    }, true);
    }catch(e){console.log('Error in Logoff Hook ', e);}
});