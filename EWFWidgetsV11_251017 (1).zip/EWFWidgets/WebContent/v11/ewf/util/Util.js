define([
        "dojo/_base/declare",
        "dojo/_base/lang",
		"v11/ewf/base/Constants",
		"dojo/i18n!../nls/common"
], function(declare, lang, Constants, commonResourceBundle) {

    /**
     * @name ewf.util.Util
     * @class Utility Class that provides some common functions.
     */
    var Utils = declare("v11.ewf.util.Util", null, {
        /** @lends ewf.util.Util */

       /**
        * Retrieving resource bundle for a component.
        * @name ewf.util.Util.getResourceBundle
        * @function
        * @static
        *
        * @param {string} section
        *        The section id defined in ewf/nls/common.js
        */
        getResourceBundle: function(section) {
			if (section)
				return commonResourceBundle[section];
			return commonResourceBundle;
        },
		
       /**
        * Return the symbolic name for a property by adding the solution prefix.
		* For example, return "COPC_CardType" for the "CardType" property
        */
		getSymbolicName: function(solution, propertyName){
			if (!propertyName || propertyName.length === 0)
				return;
			var prefix = solution.prefix;
			var symbolicName;
			
			//New logic added for E2E and for future processes where the props are being reused from diff sol
			if(Constants['Solution_Reused_Prefixes'] && Constants['Solution_Reused_Prefixes'][prefix]) {
				var reusedPrefixes = Constants['Solution_Reused_Prefixes'][prefix];
				
				for(var i=0; i<reusedPrefixes.length; i++) {
					if(propertyName.indexOf(reusedPrefixes[i]) === 0) {
						symbolicName = propertyName;
						return symbolicName;
					}
				}
			}
			//End
			
			//Continue with the existing logic for all other solutions not configured in constants
			if (prefix && (prefix.length > 0) && (propertyName.indexOf(prefix) === -1) && (propertyName.indexOf("EWS_") === -1) && (propertyName.indexOf("EWFSV_") === -1)) 
				symbolicName = prefix + '_' + propertyName;
			else
				symbolicName = propertyName;
			return symbolicName;
		},
		
       /**
        * Return the short name for a property by removing the solution prefix.
		* For example, return "CardType" for the "COPC_CardType" property
        */
		getShortName: function(solution, propertyName){
			if (!propertyName || propertyName.length === 0)
				return;
			var prefix = solution.prefix;
			var shortName;
			if (prefix && prefix.length > 0 && propertyName.indexOf(prefix) === 0) 
				shortName = propertyName.substring(prefix.length + 1);
			else
				shortName = propertyName;		
			return shortName;
		},
		
       /**
        * Return the type of a Data Entry work item. 
		* @param properties A collection of icm.model.PropertyEditable objects from a WorkItemEditable model, or a collection of attributes from 
		*                   a WorkItem model.
        */
		getWorkItemType: function(properties){
			if (properties[this.getConstant("EWF_PropertyName").SPECIAL_SECTION_COORDINATES]) 
				return this.getConstant("EWF_WorkItemType").SPECIAL_SECTION;
			else if (properties[this.getConstant("EWF_PropertyName").SECTION_COORDINATES])
				return this.getConstant("EWF_WorkItemType").SECTION;
			else 
				return this.getConstant("EWF_WorkItemType").FIELD;
		},
		
		/*
		 * use to merge configuration
		 */
		merge: function(dest, source){
			var name, s;
			if(lang.isObject(source) && !lang.isFunction(source)){
				for(name in source){
					s = source[name];
					if(!(name in dest)){
						dest[name] = s;
					}else if( dest[name] !== s ){
						dest[name] = this.merge(dest[name], s);
					}
				}
			}else{
				dest = source;
			}
			return dest;
		},
		
		/**
        * Return the value of a key from the constants file
        */
        //Modified by Purna -- Adding the extra optional parameter CaseEditable/WorkItemEditable/CaseType. When present get the Case Type specific constants
		getConstant: function(key, solutionPrefix, editable){
			
			//Added by Purna - Check if the optional param is CaseEditable and get the caseType name.
			if(editable) {
				var caseTypeName = '';
				if(editable['declaredClass'] === 'icm.model.CaseEditable' && editable.caseType && editable.caseType.id) {
					caseTypeName = editable.caseType.id;
				//Check if the optional param is CaseType name (spl condition for decision widget)
				} else if(typeof editable === "string" && editable.length > 0) {
					caseTypeName = editable;
				//Check if the optional param is WorkitemEditable and get the caseType name
				} else if(editable.icmWorkItem && editable.icmWorkItem._caseTypeName) {
					caseTypeName = editable.icmWorkItem._caseTypeName;
				}
			
				if(caseTypeName != '' && typeof caseTypeName != 'undefined' && Constants["Global_Constants_Prefix"]) {
					var prefixMaps = Constants["Global_Constants_Prefix"];
					if(prefixMaps[caseTypeName] && Constants[prefixMaps[caseTypeName]] && Constants[prefixMaps[caseTypeName]][key]) {
						return Constants[prefixMaps[caseTypeName]][key];
					}
				}
			}
			//End
		
			if (solutionPrefix && Constants[solutionPrefix] && Constants[solutionPrefix][key]) {
				// Get constants for the solution
				return Constants[solutionPrefix][key];
			} else {
				// Get common constants
				return Constants[key];
			} 		
		}	
		//End
    });

    v11.ewf.util.Util = new Utils();
    return v11.ewf.util.Util;
});