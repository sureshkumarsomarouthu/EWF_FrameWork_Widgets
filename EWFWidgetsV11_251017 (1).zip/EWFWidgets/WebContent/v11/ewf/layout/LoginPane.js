/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
	"dojo/_base/declare", //
	"dojo/_base/connect", //
	"dojo/_base/json", //
	"dojo/_base/lang", //
	"dojo/_base/sniff", //
	"dojo/cookie", //
	"dojo/string", // 
	"dojo/dom-attr", //
	"dojo/dom-class", //
	"dojo/dom-construct", //
	"dojo/dom-style", //
	"dojo/keys", //
	"dijit/_Widget", //
	"dijit/_TemplatedMixin", //
	"dijit/_WidgetsInTemplateMixin", //
	"dijit/form/Button", //
	"dijit/form/Select", //
	"dijit/form/ValidationTextBox", //
	"dijit/layout/ContentPane", //
	"idx/html", //
	"ecm/widget/LoginPane",
	"ecm/model/Desktop",
	"ecm/LoggerMixin", //
	"ecm/model/Container", //
	"ecm/widget/dialog/ErrorDialog", //
	"ecm/widget/dialog/ChangePasswordDialog", 
	"dojo/store/Memory",
	"dojo/text!./templates/LoginPane.html"
], //
function(declare, //
connect, //
dojojson, //
lang, //
has, //
cookie, //
string, //
domAttr, //
domClass, //
domConstruct, //
domStyle, //
keys, //
_Widget, //
_TemplatedMixin, //
_WidgetsInTemplateMixin, //
Button, //
Select, //
ValidationTextBox, //
ContentPane, //
idxHtml, //
ecmLoginPane,
Desktop,
LoggerMixin,
Container,
ErrorDialog,
ChangePasswordDialog,
Memory,
template) {

	/**
	 * @name ecm.widget.LoginPane
	 * @class Provides a widget that is used to log in to a content management server. This widget prompts the user for
	 *        credentials to authenticate to the server.
	 * @augments dijit._Widget
	 */
	return declare("v11.ewf.layout.LoginPane", [
		//_TemplatedMixin,
		//_WidgetsInTemplateMixin,
		ecmLoginPane
	], {
		/** @lends ecm.widget.LoginPane.prototype */

		templateString: template,
		widgetsInTemplate: true,
		urlAddressablePage: false,

		constructor: function() {
			this.inherited(arguments);
		},

		postCreate: function() {
			this.logEntry("postCreate");
			this.inherited(arguments);

			var domainChoices = [];
			domainChoices.push({
				label: "-Select-",
				value: ""
			});
			domainChoices.push({
				label: "NTGHRDOM",
				value: "@NTGHRDOM"
			});
			domainChoices.push({
				label: "NTIDPDOM",
				value: "@NTIDPDOM"
			});
			domainChoices.push({
				label: "NTMYPDOM",
				value: "@NTMYPDOM"
			});
			domainChoices.push({
				label: "NTSGPDOM",
				value: "@NTSGPDOM"
			});
			domainChoices.push({
				label: "NTTHPDOM",
				value: "@NTTHPDOM"
			});
			domainChoices.push({
				label: "NTTSTDOM",
				value: "@NTTSTDOM"
			});
			domainChoices.push({
				label: "UOBNET",
				value: "@UOBNET"
			});

			var domainStore = new Memory({idProperty: "value", data: domainChoices});
			this.domain.labelAttr = "label";
			this.domain.setStore(domainStore, null);
		
		},

// commented the below unused override code on 23/10/2016 as part of 5.2.1 migration changes 	
		/**
		 * Places focus on the first field of the LoginPane. This could be either the server selector or the userid.
		 */
	/*	focus: function() {
			this.logEntry("focus");

			if (this.username.get("value").length > 0) {
				this.password.focus();
			} else {
				this.username.focus();
			}

			this.logExit("focus");
		},*/


	


		/**
		 * Clears the text message at the top of the dialog, under the dialog's introduction text.
		 * <p>
		 * NOTE: This method was copied from BaseDialog.js.
		 */
	/*	clearMessage: function() {
			this.logEntry("clearMessage");
			// Hide the message.
			domStyle.set(this.inlineMessage, "display", "none");
			// Restore to default of error.
			domAttr.set(this.inlineMessage, "class", "inlineMessage inlineMessageError");
			// Remove the text.
			if (this.messageText.firstChild) {
				this.messageText.removeChild(this.messageText.firstChild);
				// This is not needed (or implemented) for the login pane. 
				// this.resize();
			}
			if (this.messageText.lastChild) {
				this.messageText.removeChild(this.messageText.lastChild);
			}
			this.logExit("clearMessage");
		},*/
	//commented by Suresh (MITS) for unused methods for MY Upgrade
	/*	_showMessage: function(message) {
			this.logEntry("_showMessage");
			if (message.level > 0) {
				if (message.number == 1004) {
					var repository = this._getLoginRepository();
					var changePasswordDialog = new ChangePasswordDialog();
					changePasswordDialog.show(repository, true, this.password.get("value"));
				} else {
					this.setMessage(message, "error");
				}
				ecm.model.desktop.onMessageAdded = this._originalMessageAddedHandler;
			}
			this.logExit("_showMessage");
		},*/
		/**
		 * This ideally should come from the default repository and it should have getDefaultRepository only. It needs
		 * to be cleaned in the next release
		 */
		 //commented by Suresh (MITS) for unused methods for MY Upgrade
	/*	_getLoginRepository: function(message) {
			var repository = null;
			if (ecm.model.desktop.getInitialRepository()) {
				repository = ecm.model.desktop.getInitialRepository();//this causing it to always login to initial repository irrespective of the server selection
				if (!this.server.get("disabled") && repository.id != this.server.get("value")) { // ...but if it is disabled, don't use its value (fixes the url addressable viewer)
					repository = ecm.model.desktop.getRepository(this.server.get("value"));
					ecm.model.desktop.setInitialRepository(repository); //changing the initial repository to the selected repository
				}
			} else if (!ecm.model.desktop.getAuthenticatingRepositoryId()) {
				//Do not Set the initial repository If the Authenticating repository is CONTAINER 
				repository = ecm.model.desktop.getRepository(this.server.get("value"));
				ecm.model.desktop.setInitialRepository(repository);
			} else if (ecm.model.desktop.getAuthenticatingRepositoryId() && ecm.model.desktop.getAuthenticatingRepositoryId() != "CONTAINER") {
				repository = ecm.model.desktop.getAuthenticatingRepository(); //the Authenticating repository is same as the Default repository
				ecm.model.desktop.setInitialRepository(repository);
			}
			return repository;
		},*/
			
		/**
		 * Performs the initial repository login
		 */
		_login: function() {
			this.logEntry("_login");
			//added by Suresh (MITS) for MY Upgrade
			if (this._handlingLogin) {
				return;
			}
			this._handlingLogin = true;
			//added by Suresh (MITS) for MY Upgrade
			
			if (!ecm.model.desktop.disableCookies && !ecm.model.desktop.disableAutocomplete && cookie.isSupported()) {
				var loginPaneCookie = {
					server: this.server.get("value"),
					userId: this.username.get("value")+this.domain.get("value")
				};
				var cookieKey = this._getLoginPaneCookieKey();
				cookie(cookieKey, dojojson.toJson(loginPaneCookie), {
					expires: 365
				});
			}
			this.clearMessage();

			if (this.username.get("value") != null && this.password.get("value") != null) {
				// This call is still needed to set the initialRepository.
				this._getLoginRepository();

				// if errors occur, show them on the panel (rather than a popup)
				//if condition added by Suresh (MITS) for MY Upgrade
				if (!this._originalMessageAddedHandler) {
					this._originalMessageAddedHandler = ecm.model.desktop.onMessageAdded;
				}
				ecm.model.desktop.onMessageAdded = lang.hitch(this, this._showMessage);

				ecm.model.desktop.userId = this.username.get("value")+this.domain.get("value");
				ecm.model.desktop.logon(this.password.get("value"), lang.hitch(this, function() {
					this.logEntry("_logonCallback");

					if (ecm.model.desktop.connected) {
						this.loginButton.focus(); // to avoid tooltip showing up on password reset
						this.password.reset();
						this.loginButton.set("disabled", true);
						ecm.model.desktop.onMessageAdded = this._originalMessageAddedHandler;
					}
					this._loginAttemptCompleted(); //added by Suresh (MITS) for MY Upgrade
					this.logExit("_logonCallback");
				}));
			//added by Suresh (MITS) for MY Upgrade
			} else {
				this.loginButton.set("disabled", true);
				delete this._handlingLogin;
			//end added by Suresh (MITS) for MY Upgrade
			}
			this.logExit("_login");
		}
// commented the below unused override code on 23/10/2016 as part of 5.2.1 migration changes 
		/**
		 * Determines if the login button should be enabled.
		 
		_enableLogin: function() {
			if (this.username.get("value") != null && this.username.get("value").length > 0 && this.password.get("value") != null && this.password.get("value").length > 0)
				this.loginButton.set("disabled", false);
			else
				this.loginButton.set("disabled", true);
		}*/
	});
});
