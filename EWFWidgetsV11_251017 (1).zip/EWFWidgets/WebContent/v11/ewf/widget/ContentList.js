/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012, 2013 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/event",
	"ecm/widget/listView/ContentList",
	"gridx/Grid",
	"dojo/on",
	"dojo/aspect",
	"ecm/widget/listView/gridModules/Async",
	"dojo/dom-construct"
], function(declare, lang, event, ContentList, Grid, on, aspect, Cache, domConstruct) {

	/**
	 * @name v11.ewf.widget.ContentList
	 * @class Extends ContentList widget for Bulk Print.
	 * @augments ContentList
	 */
	var ContentList = declare("v11.ewf.widget.ContentList", [ContentList],
	{
		grid: null,
		_customInbasketThis: null,
		setCustomInbasketScope: function(_this)
		{
			this._customInbasketThis = _this;
		},
		_createGrid: function() {
			if (this._resultSet != null) {
				var structure = this._getGridStructure();

				// Clear grid connections and destroy grid
				if (this.grid) {
					this._clearGridConnections();
					this.grid.destroyRecursive();
				}

				if (this._detailsView)
					this._addDetailsViewColumnDecorators();
				if (this._magazineView)
					this._hitchViewDecorators(this._magazineView);

				// Destroying the grid does not free the store; must take
				// care of that manually.
				if (this.store)
					this.store = null;
				this.store = this._resultSet.getStore();

				this.grid = new Grid({
					cacheClass: Cache,
					pageSize: 100,
					paginationPagesize: 100,
					paginationInitialPageSize: 100,
					store: this.store,
					structure: structure,
					selectRowTriggerOnCell: true,
					
					modules: this._getModules()
				});
				this.grid.body._loadFail = lang.hitch(this, function(e) {
				});
				this.grid.contentList = this;
				this._grid = this.grid;
				this._createGridConnections();

				domConstruct.place(this.grid.domNode, this.gridArea.domNode, "only");
				this.grid.startup();
			}
		},
		_createGridConnections: function() {
			if (!this.gridConnections)
				this.gridConnections = [];
			// Uncommenting this code prevents the ability of swipping cell data (for copying / pasting cell data).
			this.gridConnections.push(on(this.grid.domNode, "mousedown", function(e) {
				e.preventDefault();
				e.stopPropagation();
			})); 

			this.gridConnections.push(aspect.after(this.grid.body, "onRender", lang.hitch(this, "onRender"), true));
			this.gridConnections.push(aspect.after(this.grid, "resize", lang.hitch(this, "onGridResize"), true));
			this.gridConnections.push(aspect.after(this.grid, "onModulesLoaded", lang.hitch(this, "onModulesLoaded"), true));
			this.gridConnections.push(aspect.after(this.grid, "onRowDblClick", lang.hitch(this, function(evt) {
				this.onRowDblClick(this.grid.row(evt.rowIndex).item(), evt);
				event.stop(evt);
			}), true));
			this.gridConnections.push(aspect.after(this.grid, "onRowClick", lang.hitch(this, function(evt) {
				this.onRowClick(this.grid.row(evt.rowIndex).item(), evt);
				event.stop(evt);
			}), true));
			this.gridConnections.push(aspect.after(this.grid.domNode, "onkeydown", lang.hitch(this, "_onKeyDown"), true));
           // this.gridConnections.push(aspect.after(this.grid.select.row, "onHighlightChange", lang.hitch(this._customInbasketThis, "_onHighlightChange")));
			this.gridConnections.push(aspect.after(this.grid.select.row, "onSelectionChange", lang.hitch(this, function(selected) { // enhanced row select module calls this
				this.onRowSelectionChange(this._getItems(selected));
			}), true));
			this.gridConnections.push(aspect.after(this.grid.select.row, "onSelected", lang.hitch(this, function(selected) { // row select module (used for single select) calls this
				if (selected) {
					this.onRowSelectionChange([
						selected.item()
					]);
				}
			}), true));
			this.gridConnections.push(aspect.after(this.grid.body, "collectCellWrapper", lang.hitch(this, "_createCellWrapper"), true));
		}
	});


	return ContentList;
});
