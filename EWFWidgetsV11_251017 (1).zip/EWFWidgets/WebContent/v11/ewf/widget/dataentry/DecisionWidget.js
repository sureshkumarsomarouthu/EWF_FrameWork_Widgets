define([ "dojo/_base/declare", 
	//"pvr/widget/editors/TextBoxEditor",
	"v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
	"dojo/text!./templates/DecisionWidget.html", 
	"ecm/LoggerMixin",
	"v11/ewf/util/Util",
	"dojo/_base/lang",
	"dijit/form/Form",
	"dijit/form/CheckBox",
	"dijit/form/Button",
	"dojo/dom-style",
	"dojo/dom-construct",
	"dojo/on",
	"dijit/form/SimpleTextarea",
	"dojo/_base/array"
	], function(declare, TextBoxEditor, template, LoggerMixin, Util, lang, Form, CheckBox, Button, domStyle, domConstruct, on, Textarea, array){
	return declare("v11.ewf.widget.dataentry.DecisionWidget", [TextBoxEditor, LoggerMixin], {
		
		templateString: template,				
		widgetsInTemplate: true,
		isPanelBuild: false,
		staffSGNMatch: '',
		
		//Added by Purna for handling other textbox in the reasons
		othersTextBox: null,
		otherReasons: [],
		//End
		
		matchResults: [],
		spReasons: [],
		
		//Added by Purna for readonly mode implementation
		customerCheckBoxes: [],
		staffCheckBoxes: [],
		//End
		
		
		constructor: function() {
			this.acctInfoList = [];
		},

		postCreate: function() {
			this.inherited(arguments);
		},
		
		resize: function() {
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			domStyle.set(this.stateNode, "width", "100%");
		},

		_setPanelAttr: function(panel) {	
			this.panel = panel;
			if(!this.isPanelBuild){
				this.buildPanels();
			}
		},
		
		_setPrefixAttr: function(prefix) {	
			this.prefix = prefix;
			if(!this.isPanelBuild){
				this.buildPanels();
			}
		},
		
		_setCaseTypeAttr: function(caseType) {	
			this.caseType = caseType;
			if(!this.isPanelBuild){
				this.buildPanels();
			}
		},
		
		_setValueAttr: function(value) {
			var _this = this;
			if(!this.isPanelBuild){
				array.forEach(value, function(item) {
					_this.acctInfoList.push(dojo.fromJson(item));
				});
				this.buildPanels();
			}
			else
				this.inherited(arguments);
		},

		_getValueAttr: function() {
			if(!this.isPanelBuild)
				return this.inherited(arguments);
			var _this = this;
			var newValue = [];
			array.forEach(this.acctInfoList, function(acctData, index) {
				if(index == 0)
				{
					acctData[_this.SP_CONSTANTS.DECISION_PANEL_COLUMNS.STAFF_MATCH] = _this.staffSGNMatch;
				}
				acctData[_this.SP_CONSTANTS.DECISION_PANEL_COLUMNS.MATCH_RESULT] = _this.matchResults[index];
				var spReasonsValue = _this.spReasons[index];
				if(spReasonsValue instanceof Array)
					acctData[_this.SP_CONSTANTS.DECISION_PANEL_COLUMNS.SP_REASONS] = _this.spReasons[index];
				else
					acctData[_this.SP_CONSTANTS.DECISION_PANEL_COLUMNS.SP_REASONS] = [];
					
				//Added by Purna - get the OthersReason value and store it in JSON
				//Modified by suresh for production issue--unable to get others reasons
				if(_this.otherReasons && _this.otherReasons[index] && _this.otherReasons[index] != null) {
					acctData["OtherReason"] = _this.otherReasons[index];
				}
				//End
				
				newValue.push(dojo.toJson(acctData));
			});
			return newValue;
		},
		
		//Added by Purna - implementing readonly mode for the decision widget
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			if(this.isPanelBuild && this.customerCheckBoxes instanceof Array && this.staffCheckBoxes instanceof Array) {
				array.forEach(this.customerCheckBoxes, function(chkBox) {
					chkBox.set("readOnly", readOnly);
				});
				array.forEach(this.staffCheckBoxes, function(chkBox) {
					chkBox.set("readOnly", readOnly);
				});
			}
		},
		//End
		
		destroy: function(){
			this.inherited(arguments);
			this.resetFields();
		},
		
		isValid: function(isFocusd) {
			if(this.acctInfoList.length > 0 && (this.staffSGNMatch == null || this.staffSGNMatch == '')) {
				for(var i = 0; i < this.matchResults.length; i ++) {
					if(this.matchResults[i] == null || this.matchResults[i] == '')
						return	false;
				}
			} 
			return true;
		},

		buildPanels: function() {
			if(this.prefix && this.caseType && this.panel && this.acctInfoList.length > 0)
			{
				this.resetFields();
				
				//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
				//this.SP_CONSTANTS = Util.getConstant("SP_CONSTANTS", this.prefix)[this.caseType];
				this.SP_CONSTANTS = Util.getConstant("SP_CONSTANTS", this.prefix, this.caseType)[this.caseType];
				//End
				
				this.headings =  this.panel == "activity" ? {MATCH:"Matched ?",UNAMTCHREASONS:"Unmatched Reason(s)"} : this.SP_CONSTANTS.DECISION_PANEL_HEADINGS;
				this.columns = this.panel == "activity" ? {} : this.SP_CONSTANTS.DECISION_PANEL_COLUMNS;
				domConstruct.empty(this.decisionPanel);
				this.buildCustomerPanel();
				this.buildStaffPanel();
				this.isPanelBuild = true;
				domStyle.set(this.stateNode, "border", "none");
				domConstruct.empty(this.labelWrap);
			}else{
				if(this.caseType && this.caseType == "EWFSV_ScanAndPost"){
					domConstruct.empty(this.decisionPanel);
					var customerTable = domConstruct.create('table', { "style": 'width: 100%; height: 100%; text-align: left; border-collapse: collapse;', 'border': 1, 'cellpadding': 3, 'cellspacing': 0}, this.decisionPanel);
					var tr = domConstruct.create('tr', {style: 'height: 5%; width: 100%; background-color:lightgrey; color:black;'}, customerTable);
					domConstruct.create('th', {innerHTML: "Information from BWCIF cannot be retrieved, either account is closed or not belong to the CIF.", style: 'font-weight: bold; text-align: center; width: 5%;'}, tr);
					
				}
			}
		},

		resetFields: function() {
			this.isPanelBuild = false;
			this.staffSGNMatch = '';
			this.matchResults = [];
			this.spReasons = [];
			this.otherReasons = [];
			
			//Added by Purna -- destroy the checkBoxes and reset
			try {
				array.forEach(this.customerCheckBoxes, function(chkBox) {
					chkBox.destroy();
				});
				array.forEach(this.staffCheckBoxes, function(chkBox) {
					chkBox.destroy();
				});
			} catch(e) {console.log('Exception occurred in resetFields destroy', e);}
			
			this.customerCheckBoxes = [];
			this.staffCheckBoxes = [];
			//End
		},
		
		buildCustomerPanel: function() {
			var _this = this;
			var decisionCols = this.SP_CONSTANTS.DECISION_PANEL_COLUMNS;
			var customerTable = domConstruct.create('table', { "style": 'width: 100%; height: 100%; text-align: left; border-collapse: collapse;', 'border': 1, 'cellpadding': 3, 'cellspacing': 0}, this.decisionPanel);
			var tr = domConstruct.create('tr', {style: 'height: 5%; width: 100%; background-color:lightgrey; color:black;'}, customerTable);
			
			//Add Match Header
			domConstruct.create('th', {innerHTML: _this.headings.MATCH, style: 'font-weight: bold; text-align: center; width: 5%;'}, tr);
			
			if(!(_this.panel == "activity")){
				//Add Account Number Header
				domConstruct.create('th', {innerHTML: _this.headings.ACCTNUMBER, style: 'font-weight: bold; text-align: center; width: 10%;'}, tr);
				
				//Add Acc Signature Condition Header
				domConstruct.create('th', {innerHTML: _this.headings.ACCTSIGNCONDITION, style: 'font-weight: bold; text-align: center; width: 15%;'}, tr);
				
				//Add Debiting Account Type Header
				domConstruct.create('th', {innerHTML: _this.headings.DEBTACCTTYPE, style: 'font-weight: bold; text-align: center; width: 15%;'}, tr);
				
				//Add CCP Indicator Header
				domConstruct.create('th', {innerHTML: _this.headings.CCPINDICATOR, style: 'font-weight: bold; text-align: center; width: 10%;'}, tr);
				
				//Add Account Name1 Header
				domConstruct.create('th', {innerHTML: _this.headings.ACCTNAME1, style: 'font-weight: bold; text-align: center; width: 15%;'}, tr);
				
				//Add Account Name2 Header
				domConstruct.create('th', {innerHTML: _this.headings.ACCTNAME2, style: 'font-weight: bold; text-align: center; width: 15%;'}, tr);
			}
				
			//Add Unmatched Reasons Header
			domConstruct.create('th', {innerHTML: _this.headings.UNAMTCHREASONS, style: 'font-weight: bold; text-align: center; width: 15%;'}, tr);
			
			//Iterate over acctinfo list
			array.forEach(this.acctInfoList, function(acctInfo, index) {
				if(acctInfo[decisionCols.MATCH_RESULT] && acctInfo[decisionCols.MATCH_RESULT] != "")
					_this.matchResults.push(acctInfo[decisionCols.MATCH_RESULT]);
				else
					_this.matchResults.push(_this.SP_CONSTANTS.SP_MATCH_RESULTS.NONE_SPECIFIED);
				if(acctInfo[decisionCols.SP_REASONS] && acctInfo[decisionCols.SP_REASONS] != "")
					_this.spReasons.push(acctInfo[decisionCols.SP_REASONS]);
				else
					_this.spReasons.push(_this.SP_CONSTANTS.SP_MATCH_RESULTS.NONE_SPECIFIED);
				
				//Added by Purna - Capture the Others reasons values
				if(acctInfo["OtherReason"] && acctInfo["OtherReason"] != "")
					_this.otherReasons.push(acctInfo["OtherReason"]);
				else
					_this.otherReasons.push("");
				//End
				
				var tr = domConstruct.create('tr', {style: 'width: 100%;'}, customerTable);
				var td = domConstruct.create('td', {innerHTML: '', style: 'text-align: center; width: 5%;'}, tr);
				var checkbox = _this.createCheckBox(index, acctInfo[decisionCols.MATCH_RESULT]);
				domConstruct.place(checkbox.domNode, td);
				
				if(!(_this.panel == "activity")){
					//Add Account Number
					domConstruct.create('td', {innerHTML: acctInfo[_this.columns.ACCTNUMBER], style: 'text-align: center; width: 10%;'}, tr);
					
					//Add Account Signature Condition
					domConstruct.create('td', {innerHTML: acctInfo[_this.columns.ACCTSIGNCONDITION], style: 'text-align: center; width: 15%;'}, tr);
					
					//Add Debiting Account Type
					domConstruct.create('td', {innerHTML: acctInfo[_this.columns.DEBTACCTTYPE], style: 'text-align: center; width: 15%;'}, tr);
					
					//Add CCP Indicator
					domConstruct.create('td', {innerHTML: acctInfo[_this.columns.CCPINDICATOR], style: 'text-align: center; width: 10%;'}, tr);
					
					//Add Account Name1
					domConstruct.create('td', {innerHTML: acctInfo[_this.columns.ACCTNAME1], style: 'text-align: left; width: 15%; padding-left: 5px;'}, tr);
					
					//Add Account Name2
					domConstruct.create('td', {innerHTML: acctInfo[_this.columns.ACCTNAME2], style: 'text-align: left; width: 15%; padding-left: 5px;'}, tr);
				}
				// Unmatched Reasons
				var td = domConstruct.create('td', {style: 'text-align: center; width: 15%;'}, tr);
				var reasonsLink = domConstruct.create('span', {id: "reasonLink_" + index, innerHTML: 'Select', style: 'cursor:pointer; color:blue; text-decoration:underline;'}, td);
				on(reasonsLink, "click", lang.hitch(_this, "showReasonsDialog"));
			});
		},
		
		createCheckBox: function(index, matchResult) {
			var _this = this;
			
			//Added by Purna -- set the readonly mode for checkbox
			//var checkbox = new CheckBox({value: index, checked: matchResult == 'Matched' ? true : false});
			var checkbox = new CheckBox({value: index, checked: matchResult == 'Matched' ? true : false, readOnly: this.readOnly});
			this.customerCheckBoxes.push(checkbox);
			//End
			
			on(checkbox, "change", function(checked) {
				var index = this.value;
				if(dojo.byId("reasonLink_" + index)) {
					if (checked) {					
						_this.spReasons[index] = [];
						_this.otherReasons[index] = "";
						_this.matchResults[index] = _this.SP_CONSTANTS.SP_MATCH_RESULTS.MATCHED;
						dojo.style(dojo.byId("reasonLink_" + index), "display", "none");
					} else {			
						_this.matchResults[index] = _this.SP_CONSTANTS.SP_MATCH_RESULTS.NONE_SPECIFIED;
						dojo.style(dojo.byId("reasonLink_" + index), "display", "block");
					}
				}
			});
			return checkbox;
		},

		showReasonsDialog: function(event) {
			var _this = this;
			var dialogBox = new dijit.Dialog({title: 'Not Matched Reasons', style: 'height: 280px; width: 280px;'});
			var formInDialog = new Form({});
			var anchorId = event.target.id;
			var index = anchorId.slice(anchorId.indexOf("_") + 1);
			var selectedReasons = this.spReasons[index];
			console.log("selectedReasons are : ",selectedReasons);
			
			//Added by Purna - destroy the TextBox if it is not null
			this.othersTextBox && this.othersTextBox.destroy && this.othersTextBox.destroy();
			this.othersTextBox = null;
			//End
			
			array.forEach(this.SP_CONSTANTS.SP_REASONS, function(reason, innerIndex) {
				var reasonChecked = array.some(selectedReasons, function(selReason) {
					return (dojo.string.trim(selReason) == dojo.string.trim(reason));
				});
				
				//Added by Purna - if the reason is Others handle it specially
				var checkBox;
				if(reason == "Others") {
					checkBox = new CheckBox({value: reason, name: 'SPReasons', style: 'padding-top: 5px;', readOnly: _this.readOnly});
					checkBox.startup();
					on(checkBox, "change", lang.hitch(_this, "onOthersCheckboxClick", formInDialog, dialogBox, index));
					checkBox.set("checked", reasonChecked);
				} else {
					checkBox = new CheckBox({value: reason, name: 'SPReasons', checked: reasonChecked, style: 'padding-top: 5px;', readOnly: _this.readOnly});
				}
				//End
				
				domConstruct.place(checkBox.domNode, formInDialog.domNode);
				domConstruct.create("label", {innerHTML: reason, 'for': checkBox.id, style: 'padding-top: 5px;'}, formInDialog.domNode);
				domConstruct.create('br', null, formInDialog.domNode);
			});
			domConstruct.create('br', null, formInDialog.domNode);
			var buttonsDiv = domConstruct.create('span',{style: 'position: absolute; right: 15px;'}, formInDialog.domNode);
			var okButton = new Button({label: 'OK', disabled: _this.readOnly});
			on(okButton, "click", function() {
				var reasons = [];
				array.forEach(formInDialog.get('value')['SPReasons'], function(reason) {
					reasons.push(reason);
					if(reason == "Others" && _this.othersTextBox && _this.othersTextBox.get) {
						_this.otherReasons[index] = _this.othersTextBox.get("value");
						console.log('Setting other reasons at :', index, ' to: ', _this.otherReasons[index]);
					}
				});
				_this.spReasons[index] = reasons;
				_this.matchResults[index] = reasons.length >= 1 ? _this.SP_CONSTANTS.SP_MATCH_RESULTS.UNMATCHED : _this.SP_CONSTANTS.SP_MATCH_RESULTS.NONE_SPECIFIED;
				_this.othersTextBox && _this.othersTextBox.destroy && _this.othersTextBox.destroy();
				dialogBox.destroy();
			});
			var cancelButton = new Button({label: 'Cancel'});
			on(cancelButton, "click", function() {
				_this.othersTextBox && _this.othersTextBox.destroy && _this.othersTextBox.destroy();
				dialogBox.destroy();
			});

			domConstruct.place(okButton.domNode, buttonsDiv);
			domConstruct.place(cancelButton.domNode, buttonsDiv);
			dialogBox.set('content', formInDialog);
			dialogBox.show();
		},

		buildStaffPanel: function() {
			var _this = this;
			domConstruct.create("div", {innerHTML: "Staff Signature Verification", style:"font-weight: bold; background-color:white; text-decoration: underline; padding: 5px;"}, this.decisionPanel);
			var staffTable = '';
			if(this.panel === 'activity'){
				staffTable = domConstruct.create('table', { "style": 'width: 100%; height: 100%; text-align: left; border-collapse: collapse;', 'border': 1, 'cellpadding': 3, 'cellspacing': 0}, this.decisionPanel);
			}else {
				staffTable = domConstruct.create('table', { "style": 'width: 40%; height: 100%; text-align: left; border-collapse: collapse;', 'border': 1, 'cellpadding': 3, 'cellspacing': 0}, this.decisionPanel);
			}
			
			var tr_staff = domConstruct.create('tr', {style: 'width: 100%; background-color:lightgrey; color:black;'}, staffTable);
			domConstruct.create('th', {innerHTML: 'Staff Signature Matched ?', style: 'font-weight: bold; text-align: center;'}, tr_staff);
			domConstruct.create('th', {innerHTML: 'Staff Signature Not Matched ?', style: 'font-weight: bold; text-align: center;'}, tr_staff);
			
			//Modified by Purna - as the key for storing staff sign result is diff for DC getting the key from constants
			//this.staffSGNMatch = this.acctInfoList[0] && this.acctInfoList[0]["StaffSGNMatch"] ? this.acctInfoList[0]["StaffSGNMatch"] : '';
			var staffMatchKey = this.SP_CONSTANTS["DECISION_PANEL_COLUMNS"]["STAFF_MATCH"];
			this.staffSGNMatch = this.acctInfoList[0] && this.acctInfoList[0][staffMatchKey] ? this.acctInfoList[0][staffMatchKey] : '';
			//End
			
			//Modified by Purna - set the readonly attribute on the checkbox
			//var staffMatchCheckbox = new CheckBox({checked: this.staffSGNMatch == 'Matched' ? true : false});
			var staffMatchCheckbox = new CheckBox({checked: this.staffSGNMatch == 'Matched' ? true : false, readOnly: this.readOnly});
			//End
			
			on(staffMatchCheckbox, "change", function(value) {
				if(value) {
					staffUnMatchCheckbox.set('value', !value);
					_this.staffSGNMatch = _this.SP_CONSTANTS.SP_MATCH_RESULTS.MATCHED;
				} else if(!staffUnMatchCheckbox.checked) {
					_this.staffSGNMatch = _this.SP_CONSTANTS.SP_MATCH_RESULTS.NONE_SPECIFIED;
				}
			});
			
			//Modified by Purna - set the readonly attribute on the checkbox
			//var staffUnMatchCheckbox = new CheckBox({checked: this.staffSGNMatch == 'Unmatched' ? true : false});
			var staffUnMatchCheckbox = new CheckBox({checked: this.staffSGNMatch == 'Unmatched' ? true : false, readOnly: this.readOnly});
			//End
			
			on(staffUnMatchCheckbox, "change", function(value) {
				if(value){
					staffMatchCheckbox.set('value', !value);
					_this.staffSGNMatch = _this.SP_CONSTANTS.SP_MATCH_RESULTS.UNMATCHED;
				} else if(!staffMatchCheckbox.checked) {
					_this.staffSGNMatch = _this.SP_CONSTANTS.SP_MATCH_RESULTS.NONE_SPECIFIED;
				}
			});
			var tr2_staff = domConstruct.create('tr', {style: 'width: 100%;'}, staffTable);
			var td = domConstruct.create('td', {innerHTML: '', style: 'width: 50%; vertical-align: top; text-align: center;'}, tr2_staff);
			domConstruct.place(staffMatchCheckbox.domNode, td);
			td = domConstruct.create('td', {innerHTML: '', style: 'width: 50%; padding-left: 10px; text-align: center;'}, tr2_staff);
			domConstruct.place(staffUnMatchCheckbox.domNode, td);
			
			//Modified by Purna - push the checkboxes into array
			this.staffCheckBoxes.push(staffMatchCheckbox);
			this.staffCheckBoxes.push(staffUnMatchCheckbox);
			//End
			
		},

		onOthersCheckboxClick: function(formInDialog, dialogBox, index, value) {
			console.log('index:', index, ' this.otherReasons[index]:', this.otherReasons[index]);
			if(value) {
				var otherReason = this.otherReasons[index];
				this.othersTextBox = new Textarea({
					"maxLength": 250,
					"hint": 'Others Reason Details (Max 250 chars)',
					"hintPosition": "inside",
					"style": "width: 220px;height: 50px;",
					"value": otherReason,
					"readOnly": this.readOnly
		        });
				this.othersTextBox.startup();
				domConstruct.place(this.othersTextBox.domNode, formInDialog.domNode);
			} else {
				this.othersTextBox && this.othersTextBox.destroy && this.othersTextBox.destroy();
				this.othersTextBox = null;
				this.otherReasons[index] = '';
			}
		}
	});
});
