define([ 
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojox/data/QueryReadStore"
], function(declare, lang, QueryReadStore, Memory) {
    return declare("v11.ewf.widget.dataentry.DependencySuggestionListReadStore", [QueryReadStore], {
		initStrLength: 2,
		fetch: function(request){
			if(!(request && request.hasOwnProperty('query') && request.query.hasOwnProperty('count')))
				request.query.count = 1;
			return this.inherited('fetch', arguments);
		},
		fetchItemByIdentity: function(keywordArgs){
			this.inherited('fetchItemByIdentity', arguments);
		},
		_filterResponse: function(data){
			var _this = this;
			
			//Defect ID: 4343
			var startParam = -1;
			var countParam = 1;
			try{ startParam = _this._lastServerQuery.start; }catch(e){}
			try{ countParam = _this._lastServerQuery.count; }catch(e){}
			//Defect ID: 4343
			
			var dataToReturn = {identity: 'id', identifier: 'id', label: 'label', items: [], numRows: 0};
			dojo.forEach(data.items, function(item){
				dataToReturn.items.push({id: item.key, label: item.name, name: item.name});
			});
			dataToReturn.numRows = data.numRows;
			
			//Defect ID: 4343
			if(dataToReturn && dataToReturn.numRows > 0){
				if((startParam >= 0) && (countParam > 0)){
					if((data.items.length > 0) && (data.items.length <= countParam)){
						dataToReturn.numRows = startParam + data.items.length;
					} else if(data.items.length > 0){
						dataToReturn.numRows = startParam + countParam + 1;
					}
				}
			}
			//Defect ID: 4343
			
			return dataToReturn;
		}
	});
});