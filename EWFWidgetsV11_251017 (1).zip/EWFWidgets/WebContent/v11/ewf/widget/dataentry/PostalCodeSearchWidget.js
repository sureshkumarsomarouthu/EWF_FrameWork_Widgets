define([ "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/parser",
         "dojo/query",
         "dojo/dom-class",
         "dojo/dom-style",
         "dojo/dom-construct",
         //"idx/form/TextBox",
         "v11/ewf/idx/form/TextBox",
         "dijit/form/Button",
        // "pvr/widget/editors/TextBoxEditor",
        "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
         "dojo/text!./templates/PostalCodeSearchWidget.html",
         "ecm/LoggerMixin",
         "dojox/lang/functional",
         "dojo/on",
         "dojo/request"
       ], function(declare, lang, array, parser, query, domClass, domStyle, domConstruct, TextBox, Button, TextBoxEditor, template, LoggerMixin, functional, on, request){
	return declare("v11.ewf.widget.dataentry.PostalCodeSearchWidget", [TextBoxEditor], {
		
		width: "100%",
		
		templateString: template,
		
		widgetsInTemplate: true,
		
		textBoxWidget: null,
		
		textBoxWidgetConnects: [],
		
		searchButtonWidget: null,
		
		constructor: function(){
			this.textBoxWidget = null;
			this.textBoxWidgetConnects = [];
			this.searchButtonWidget = null;
		},
		
		postCreate: function(){
			this.inherited(arguments);
		},		
		
		resize: function(){
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			if((this.textBoxWidget !== null) && (this.searchButtonWidget!== null)){
				this.textBoxWidget && this.textBoxWidget.resize && this.textBoxWidget.resize();
				this.searchButtonWidget && this.searchButtonWidget.resize && this.searchButtonWidget.resize();
			}
		},
						
		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
		},
		
		_setCodePatternAttr: function(pattern){
			this.codePattern = pattern;
		},
		
		_setPopulateLogicAttr: function(populateLogic){
			this.populateLogic = populateLogic;
			if(this.textBoxWidget == null){
				this.updateUI();
			}
		},

		updateUI: function(){
			var _this = this;
			this.textBoxWidget && this.textBoxWidget.destroyRecursive && this.textBoxWidget.destroyRecursive();
			this.searchButtonWidget && this.searchButtonWidget.destroyRecursive && this.searchButtonWidget.destroyRecursive();
			
			if(this.textBoxWidgetConnects instanceof Array && this.textBoxWidgetConnects.length >= 1) {
				array.forEach(this.textBoxWidgetConnects, lang.hitch(this, function(textBoxWidgetConnect) {
					try {
						this.disconnect(textBoxWidgetConnect);
					} catch(e){console.log('Exception occurred during disconnect:', e);}
					
				}));
			}
			
			this.textBoxWidget = null;
			this.textBoxWidgetConnects = [];
			this.searchButtonWidget = null;
			//Added by Purna cautious -- checking whether the readOnly attribute is set or not before this method is called
			if(typeof this.readOnly === 'undefined') {
				this.readOnly = false;
			}
			//end
			this.textBoxWidget = new TextBox({
				labelAlignment: "horizontal",
				label: "",
				hint: this.hint || '',
				hintPosition: this.hintPosition || "inside",
				tooltipPosition: ["above"],
				ewficonNode:this.ewficonNode,
				readOnly: this.readOnly
			});
			if(this.codePattern)
				this.textBoxWidget.set('pattern', this.codePattern);
			this.postalCodeSearchTextBox.appendChild(this.textBoxWidget.domNode);
			
			this.textBoxWidget.startup();
			
			//Modified by Suresh - BUG 355 in SIT interactively change the button status if invalid postal code entered 
			this.textBoxWidgetConnects.push(this.connect(this.textBoxWidget, "onKeyUp", "onKeyUp"));
			this.textBoxWidgetConnects.push(this.connect(this.textBoxWidget, "onChange", "onChange"));
			
			this.searchButtonWidget = new Button({
		        label: "Validate",
		        disabled: this.readOnly,
		        onClick: function(){
		        	
		        	_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #8E0909; font-style: italic; font-weight: bold; text-decoration: underline;"><img src="ecm/widget/resources/images/loadingAnimation.gif"/>** Fetching Data from Singpost.</span>';
		        	
		        	var solutionPrefix = '';
					var propertiesBinding = null;
		        	try{
						//Alternate way to get the solution prefix is to strip the string until the first 'underscore'
						solutionPrefix = _this.property.controller.collectionController.model.icmWorkItem._solutionPrefix;
					}catch(e){
						var localPropertyObj = _this.property;
						if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.model){
							solutionPrefix = localPropertyObj.collectionController.model.getCaseType().solution.prefix;
						}else {
							//Extract the prefix from property Binding
						 try{
							//solutionPrefix = _this.property.get('binding').split('_')[0];
							// handling F_CaseFolder properties.
							    if(_this.property.get('binding').indexOf("F_CaseFolder") > -1)
							    {
							        propertiesBinding = _this.property.get('binding').split('.')[1];
								    solutionPrefix = propertiesBinding.split('_')[0];
							    }
							   else{
							        solutionPrefix = _this.property.get('binding').split('_')[0];
							     }
							//End handling F_CaseFolder properties.
							}catch(e){
								
							}
						}
					}
		        	
		        	//Invoke the Callback's first (if any)
					var participantCallBack = _this.populateLogic['callbackOnSearch'];
					if(participantCallBack){
						functional.forIn(functional.keys(participantCallBack), lang.hitch(this, function(propertyName){
							// added  by rahul to work for reuse properties
							var _propSymbName = propertyName;
							var propertySymbolicName = solutionPrefix + propertyName;
							var callBackFunction = participantCallBack[propertyName] || '';
							_this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
							// Start handling F_CaseFolder properties.
							        if(_this.property.get('binding').indexOf("F_CaseFolder") > -1)
							          {
							             propertiesBinding = property.get('binding').split('.')[1];
							          }
							       else{
							             propertiesBinding = property.get('binding');
							          }
							 //End handling F_CaseFolder properties.
								//if((property.get('binding') === propertySymbolicName || property.get('binding') === _propSymbName) && lang.isFunction(callBackFunction)){
								if((propertiesBinding === propertySymbolicName || propertiesBinding === _propSymbName) && lang.isFunction(callBackFunction)){
									lang.hitch(this, callBackFunction)(property);
								}
							})});
						}));
					}
		        	request.get(_this.populateLogic.url + _this.textBoxWidget.get('value'), {
		            	handleAs: 'json'
		            }).then(lang.hitch(_this, function(data){
		            	var valueFound = false;
		            	//var solutionPrefix = '';
		            	
		            	//Step 1: Clear all the values
		            	var responseMapForProperties = _this.populateLogic['responseMap'];
		            	functional.forIn(functional.keys(responseMapForProperties), function(property){
		            		var propertyName = responseMapForProperties[property];
		            		/*try{
								//Alternate way to get the solution prefix is to strip the string until the first 'underscore'
								solutionPrefix = _this.property.controller.collectionController.model.icmWorkItem._solutionPrefix;
							}catch(e){
								var localPropertyObj = _this.property;
								if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.model){
									solutionPrefix = localPropertyObj.collectionController.model.getCaseType().solution.prefix;
								}else {
									//Extract the prefix from property Binding
									try{
										solutionPrefix = _this.property.get('binding').split('_')[0];
									}catch(e){
										
									}
								}
							}*/
							if(_this && _this.property && _this.property.view){
								_this.property.view.forEachProperty({callback: function(property, i){
									var propertySymbolicName = solutionPrefix + '_' + propertyName;
									// added  by rahul to work for reuse properties
									var _propSymbName = propertyName;
									// Start handling F_CaseFolder properties.
							        if(_this.property.get('binding').indexOf("F_CaseFolder") > -1)
							          {
							             propertiesBinding = property.get('binding').split('.')[1];
							          }
							       else{
							             propertiesBinding = property.get('binding');
							          }
							 //End handling F_CaseFolder properties.
									//if(property.get('binding') === propertySymbolicName || property.get('binding') === _propSymbName){
									if(propertiesBinding === propertySymbolicName || propertiesBinding === _propSymbName){
										property.controller.set('value', "");
										property.editorWidget.set('value', "");
									}
								}});
							}
		            	});
		            	
		            	//Step2: Populate values from the response into the Fields. 
		            	if(data && data.hasOwnProperty('addressInfoMap') && data.hasOwnProperty('hasErrors') && (data['hasErrors'] === false)){
		            		var postalCodeObjectsReturned = data['addressInfoMap'];
		            		functional.forIn(functional.keys(postalCodeObjectsReturned), function(postalCodeKey){
		            			//TODO: Add logic here to check if the entered postal code is the same in returned response  
		            			var postalCodesArray = postalCodeObjectsReturned[postalCodeKey];
		            			if(postalCodesArray.length == 1){
		            				//handle the case when only 1 record is returned for the key'd-in postal code.
		            				valueFound = true;
		            				var postalCodeDataToMap = postalCodesArray[0];
		            				functional.forIn(functional.keys(postalCodeDataToMap), function(propertyInResponse){
		            					if(propertyInResponse && responseMapForProperties.hasOwnProperty(propertyInResponse)){
		            						var propertyName = responseMapForProperties[propertyInResponse];
		            						var propertyValueToPopulate = postalCodeDataToMap[propertyInResponse];
		            						if(_this && _this.property && _this.property.view){
	        									_this.property.view.forEachProperty({callback: function(property, i)
	        									{
	        										if(!((postalCodeDataToMap['addressFormat'] === 'C') && (propertyInResponse === 'blockExt')))
													{
		        										if(_this.property.get('binding').indexOf("F_CaseFolder") > -1)
														{
															
															 var solutionPrefix1=property.get('binding').split('.')[1];
															  solutionPrefix=solutionPrefix1.split('_')[0];
															  propertyBinding=property.get('binding').split('.')[1];

															 var propertySymbolicName = solutionPrefix + '_' + propertyName;
														     //added by rahul to handle reused properties
																var _propSymbName = propertyName;
																//if(property.get('binding') === propertySymbolicName  || property.get('binding') === _propSymbName){
																if(propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName)
																{
																	//console.log("F______++++++++++++++++"+propertySymbolicName+" :  property.get('binding') : "+property.get('binding')+" _propSymbName :"+_propSymbName);
																	property.controller.set('value', propertyValueToPopulate);
																    property.editorWidget.set('value', propertyValueToPopulate);
																}
																//else
																//{
																	//console.log("F___________*********************************"+propertySymbolicName+" :  property.get('binding') : "+property.get('binding')+" _propSymbName :"+_propSymbName);
																//}
															 		  
														}
		        										else
														{
															var prefix = property.get('binding').split('_')[0];
			        										//var propertySymbolicName = solutionPrefix + '_' + propertyName;
			        										var propertySymbolicName = prefix + '_' + propertyName;
															// added  by rahul to work for reuse properties
															var _propSymbName = propertyName;
			        										if(property.get('binding') === propertySymbolicName || property.get('binding') === _propSymbName){
			        											property.controller.set('value', propertyValueToPopulate);
			        											property.editorWidget.set('value', propertyValueToPopulate);
			        										}
	        										   }
	        										}
	        									}}); 
	        								}
		            					}
		            					
		            				});
		            				_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #097326; font-style: italic; font-weight: bold; text-decoration: underline;">Address Details below are updated from Singpost DB</span>';
		            			}else if(postalCodesArray.length > 0){
		            				valueFound = true;
		            				//handle the case if returned response contains more than one record.
		            				//default: Map the common properies in the response.
		            				var postalCodeDataToMap = postalCodesArray[0];
		            				functional.forIn(functional.keys(postalCodeDataToMap), function(propertyInResponse){
		            					if(propertyInResponse && responseMapForProperties.hasOwnProperty(propertyInResponse)){
		            						var propertyName = responseMapForProperties[propertyInResponse];
		            						var propertyValueToPopulate = postalCodeDataToMap[propertyInResponse];
		            						//Iterate through all the responses and map only the common data
		            						for(var i=1; i<postalCodesArray.length; i++){
		            							if(postalCodesArray[i][propertyInResponse] !== propertyValueToPopulate){
		            								propertyValueToPopulate = "";
		            								break;
		            							}
		            						}
		            						if(_this && _this.property && _this.property.view){
	        									_this.property.view.forEachProperty({callback: function(property, i){
											// Handling F_CaseFolder properties.
							                 if(_this.property.get('binding').indexOf("F_CaseFolder") > -1)
							                 {
							                       propertiesBinding = property.get('binding').split('.')[1];
								                   solutionPrefix = propertiesBinding.split('_')[0];
							                 }
							                else{
											      propertiesBinding = property.get('binding');
							                      solutionPrefix = property.get('binding').split('_')[0];
							                   }
							                //End handling F_CaseFolder properties.
	        									   // var prefix = property.get('binding').split('_')[0];
												  // provider = property.get('binding').split('.')[1];
								                   //prefix = provider.split('_')[0];
	        										var propertySymbolicName = solutionPrefix + '_' + propertyName;
	        										//var propertySymbolicName = prefix + '_' + propertyName;
													// added  by rahul to work for reuse properties
													var _propSymbName = propertyName;
	        										//if(property.get('binding') === propertySymbolicName || property.get('binding') === _propSymbName){
													if(propertiesBinding === propertySymbolicName || propertiesBinding === _propSymbName){
	        											property.controller.set('value', propertyValueToPopulate);
	        											property.editorWidget.set('value', propertyValueToPopulate);
	        										}
	        									}}); 
	        								}
		            					}
		            				});
		            				_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #097326; font-style: italic; font-weight: bold; text-decoration: underline;">Multiple Address Details retrieved from Singpost DB.</span>';
		            			}else{
		            				//handle the case if no data returned for the given postal code.
		            				valueFound = false;
		            			}
		            		});
		            	}else if(data.hasOwnProperty('hasErrors') && (data['hasErrors'] === true)){
		            		valueFound = true;
		            		//handle the case when hasErrors is true.
		            		//show the error code(errorCode) and error description(errorDesc) in postalCodeValidateResponse.
		            		if(data.errorDesc && ((data.errorDesc+'').length > 0 ))
		            			_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #8E0909; font-style: italic; font-weight: bold; text-decoration: underline;">**' + data.errorCode + ' &nbsp; &nbsp; ' + data.errorDesc + '.</span>';
		            		else
		            			_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #8E0909; font-style: italic; font-weight: bold; text-decoration: underline;">**' + "Invalid Postal Code" + '.</span>';
		            	}else{
		            		valueFound = true;
		            		//handle the case when the response map is not in the expected structure.
		            		_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #8E0909; font-style: italic; font-weight: bold; text-decoration: underline;">** Invalid Response received from service.</span>';
		            	}
		            	
		            	if(!valueFound)
		            		_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #8E0909; font-style: italic; font-weight: bold; text-decoration: underline;">**Invalid Postal Code. Please enter details manually.</span>';
		            }), lang.hitch(this, function(err){
		            	_this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #8E0909; font-style: italic; font-weight: bold; text-decoration: underline;">** Invalid Response received from service.</span>';
		            }), lang.hitch(this, function(evt){
		            	
		            }));
		        }
		    });
			this.postalCodeSearchButton.appendChild(this.searchButtonWidget.domNode);
			this.searchButtonWidget.startup();
			
			//Finally set the value after the UI is built
			this.set("value", this.value);
		},
		
		//added by Suresh - BUG 355 in SIT interactively change the button status if invalid postal code entered 
		onKeyUp : function(){
			var isValidString=this.textBoxWidget.isValid();
			if(isValidString == false){
				this.searchButtonWidget.set('disabled', true);
			}else{
				this.searchButtonWidget.set('disabled', false);
			}
		},
		
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			this.textBoxWidget && this.textBoxWidget.set && this.textBoxWidget.set('readOnly', this.readOnly);
			this.searchButtonWidget && this.searchButtonWidget.set && this.searchButtonWidget.set('disabled', this.readOnly);
		},
		
		_setValueAttr: function(value){
			var isValid = true;
			if((this.textBoxWidget == null) || value === null){
				if((this.textBoxWidget !== null) && value == null)
				this.textBoxWidget.set("value", null);
			} else{
				isValid = isValid && (this.textBoxWidget.state !== "Error");
				if (isValid === false)
					return;
				this.textBoxWidget.set("value", value);
			}
		},
		
		_getValueAttr: function(){
			if(this.textBoxWidget == null)
				return this.inherited(arguments);
			if(this.textBoxWidget.state !== "Error")
				return this.textBoxWidget.get("value");
			else
				return "";
		},
		
		destroy: function(){
			this.textBoxWidget && this.textBoxWidget.destroyRecursive && this.textBoxWidget.destroyRecursive();
			this.searchButtonWidget && this.searchButtonWidget.destroyRecursive && this.searchButtonWidget.destroyRecursive();
			
			this.textBoxWidget = null;
			this.textBoxWidgetConnects = [];
			this.searchButtonWidget = null;
			
			this.inherited(arguments);
		},
		
		isValid: function(isFocusd){
			var valid = this.inherited(arguments);
			if (!valid)
				return false;
			if(this.textBoxWidget && (this.textBoxWidget !== null))
				return (!(this.textBoxWidget.state === "Error"));
			else 
				return false;
		},

		// Set focus at the textbox widget when the editor is focused
		focus: function(){
			this.inherited(arguments);
			if(!this.focused && (this.textBoxWidget !== null)){
				this.textBoxWidget.focus();
			}
		}
	});
});
