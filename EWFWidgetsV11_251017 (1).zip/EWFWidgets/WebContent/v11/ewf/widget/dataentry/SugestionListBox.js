define(["dojo/_base/declare",
		"dojo/_base/lang",
		"dojo/_base/xhr",
		"dojo/_base/array",
		"dojo/_base/Deferred",
		"dojo/store/util/QueryResults",
		"dojo/store/Memory",
		"dojo/string",
		'dojox/lang/functional',
		"idx/form/FilteringSelect",
		"dojo/dom-construct",
		"ecm/widget/dialog/MessageDialog",
		"dijit/form/Button",
		//"pvr/widget/editors/mixins/_EditorMixin",
		"v11/ewf/model/properties/pvr/widget/editors/mixins/_EditorMixin",
		"pvr/widget/editors/mixins/_WidthMixin",
		"dojox/data/QueryReadStore",
		"v11/ewf/util/Util", 
		"ecm/LoggerMixin",
		"v11/ewf/widget/dataentry/SuggestionListReadStore",
		"v11/ewf/widget/dataentry/DependencySuggestionListReadStore",
		"dojo/when"
	], function(declare, lang, xhr, array, Deferred, QueryResults, Memory, string, functional, FilteringSelect,domConstruct,MessageDialog,Button,_EditorMixin, _WidthMixin, QueryReadStore, Util, LoggerMixin, SuggestionListReadStore, DependencySuggestionListReadStore, when){
	
	return declare("v11.ewf.widget.dataentry.SugestionListBox", [FilteringSelect, _EditorMixin, _WidthMixin, LoggerMixin], {
		
		labelAlignment: "vertical",
		
		picklistDeps: null,
		
		autoComplete : false,
		
		intermediateChanges : false,
		
		dropdownbutton: "",
		
		loadingImg: "<img src='ecm/widget/resources/images/loadingAnimation.gif'/>",
		
		choices: null,
		
		suggestionList: null,
		
		initStrLength: 2,
		
		invalidValueAttribute: "displayedValue",
		
		postCreate: function(){
			this.logInfo("postCreate");
			//console.log('SugestionList');
			this.inherited(arguments);
			
			try{this.dropdownbutton = this._buttonNode.innerHTML;}catch(e){}
			
			this.pageSize = 10; // Default value is: Infinity
			this.query = {
					name : ''
			};
			this.hasDownArrow = true;
			this.searchAttr = 'name';
			this.labelAttr = 'label';		
			
			// Set widget width as per the editor parameters
			this.style.width = this.fieldWidth;
			this.resourceBundle = Util.getResourceBundle("SuggestionList");
		},
		
		_setDisplayedValueAttr: function(label, priorityChange){
			this.inherited(arguments);
			if(label === ""){
				this.valueNode.value = label;
			}
		},
		
		_setValueAttr: function(/*String*/ value, /*Boolean?*/ priorityChange, /*String?*/ displayedValue, /*item?*/ item) {
			if( value && item === undefined ){
				this.tmpValue = value;
			}else{
				delete this.tmpValue;
			}
			//added by Suresh for production issue onChange is not triggering for suggestionlists
			this._onChangeActive = true;
			//End Change
			this.inherited(arguments);
		},	
		
		//Modified by Purna BEGIN changes for bug fix PETE-325 - remove the tmpValue immediately
		_getValueAttr: function() {
			if(this.tmpValue){
				var val = this.tmpValue;
				delete this.tmpValue;
				return val;
			}else{
				return this.inherited(arguments);
			}
		},
				
		_setBlurValue:function() {
            var newvalue = this.get("displayedValue");
            var trimValue = this.get("displayedValue").trim();
            var _this = this;
			if(newvalue.length > 0 && trimValue == 0)
			{
				var messageDialog = MessageDialog(
				{
					text: "Spaces Not Allowed",
					onCancel:lang.hitch(this, function()
					{
					    _this.set("displayedValue", trimValue);
					})
				});
				messageDialog.show();
			}
            var pw = this.dropDown;
            if (pw && (newvalue == pw._messages["previousMessage"] || newvalue == pw._messages["nextMessage"])) {
                this._setValueAttr(this._lastValueReported, true);
            } else {
                if (typeof this.item == "undefined") {
                    this.item = null;
                    this.set("displayedValue", newvalue);
                    //added by suresh for UAT validation issue at field/section data entry
                    this.validate(true);
					//Added by Purna - Add extra method call to populate the clear value change to the controller
					this._handleOnChange('', true);
					//End
                } else {
                    if (this.value != this._lastValueReported) {
                        this._handleOnChange(this.value, true);
                    }
                    this._refreshState();
                }
            }
            this.focusNode.removeAttribute("aria-activedescendant");
        },
		//End Changes
		
		_setMaxLengthAttr: function(maxLength) {
			this.maxLength = null; // Allow user to input the display value which is longer than the stored value
		},

		_setStoreAttr: function(store){
			// For backwards-compatibility, accept dojo.data store in addition to dojo/store/api/Store.  Remove in 2.0.
			if(!store.get){
				lang.mixin(store, {
					_oldAPI: true,
					get: function(id){
						// summary:
						//		Retrieves an object by it's identity. This will trigger a fetchItemByIdentity.
						//		Like dojo/store/DataStore.get() except returns native item.
						var deferred = new Deferred();
						this.fetchItemByIdentity({
							identity: id,
							onItem: function(object){
								deferred.resolve(object);
							},
							onError: function(error){
								deferred.reject(error);
							}
						});
						return deferred.promise;
					},
					query: function(query, options){
						// summary:
						//		Queries the store for objects.   Like dojo/store/DataStore.query()
						//		except returned Deferred contains array of native items.
						var deferred = new Deferred(function(){ fetchHandle && fetchHandle.abort && fetchHandle.abort(); });
						deferred.total = new Deferred();
						var fetchHandle = this.fetch(lang.mixin({
							query: query,
							onBegin: function(count){
								deferred.total.resolve(count);
							},
							onComplete: function(results){
								deferred.resolve(results);
							},
							onError: function(error){
								deferred.reject(error);
							}
						}, options));
						return QueryResults(deferred);
					}
				});
			}
			this._set("store", store);
		},
				
		_setSuggestionListAttr: function(suggestionList){
			console.log('Sugestion List');
			this.suggestionList = suggestionList;
			this.adjustStore();
		},
		
		_setInitStrLengthAttr: function(initStrLength){
			this.initStrLength = initStrLength;
			if(this.store) {
				this.store.initStrLength = initStrLength;
			}
		},
								
		checkForDependentValues: function(){
			var _this = this;
			var depValueAvailable = false;
			var fieldValue = '';
			if(_this.suggestionList && _this.suggestionList.hasOwnProperty('dependencies')){
				var queryToAppend = '';
				var dependenciesMap = _this.suggestionList.dependencies, prefix = 'EWF', propsCollection = {}, propertiesArray = [], dependentFieldsMap = {};
				functional.forIn(functional.keys(dependenciesMap), function(depKey){
					dependentFieldsMap[dependenciesMap[depKey]] = depKey;
				});
				var prefix = '';
				try{
					//Alternate way to get the solution prefix is to strip the string until the first 'underscore'
					prefix = _this.property.controller.collectionController.model.icmWorkItem._solutionPrefix;
				}catch(e){
					var localPropertyObj = _this.property;
					if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.model){
						prefix = localPropertyObj.collectionController.model.getCaseType().solution.prefix;
					}else {
						//Extract the prefix from property Binding
						try{
							//prefix = _this.property.get('binding').split('_')[0]; Chage Start,Commenetd As part of ICM 5.2.1 Upgrade
							if(_this.property.get('binding') && _this.property.get('binding').split('.')[1]){
								prefix = _this.property.get('binding').split('.')[1];
								
								prefix = prefix.split('_')[0];
							}else{
									prefix = _this.property.get('binding').split('_')[0];						
							}
							//Change End
						}catch(e){
							
						}
					}
				}
				try{propertiesArray = _this.property.view.properties;}catch(e){}
				array.forEach(propertiesArray, function(property){
					if((typeof property !== 'undefined') && property.hasOwnProperty('binding') && (typeof property.get('binding') !== 'undefined')){
						var propertyBinding = property.get('binding');
						//Added As part of ICM 5.2.1 upgrade. It is because of provider concept introduced in ICM 5.2.1
						if(propertyBinding && propertyBinding.split('.')[1]){
							propertyBinding = propertyBinding.split('.')[1];
						}//Change End
						if(dependentFieldsMap.hasOwnProperty(propertyBinding.substring(propertyBinding.indexOf('_') + 1)))
							propsCollection[propertyBinding] = property.hasOwnProperty('editorWidget') && property.editorWidget.hasOwnProperty('textbox') ? property.editorWidget.textbox.value : '';
					}
				});
				functional.forIn(functional.keys(dependenciesMap), function(depKey){
					var depValue = dependenciesMap[depKey];
					fieldValue = '';
					if(propsCollection && (typeof propsCollection[prefix+'_'+depValue] !== 'undefined')){
						fieldValue = propsCollection[prefix+'_'+depValue];
						if((typeof fieldValue !== 'undefined') && 
									(fieldValue !== null) && 
										((fieldValue+'').length>0)){
							depValueAvailable = true;
							queryToAppend +='&dref='+depKey+'&dvalue='+fieldValue;
						}
					}
				});
			}
			//return depValueAvailable;
			return {fieldValue: fieldValue, depValueAvailable: depValueAvailable, queryToAppend: queryToAppend};
		},
		
		adjustStore: function(){
			if(!this.suggestionList){
				return;
			}
			var _this = this;
			var listUrl = '';
			var depValueAvailable=false;

			var depValue = _this.checkForDependentValues();
			
			if(depValue.depValueAvailable){
				listUrl = "/v11/ewf/rest/dsuggest?ref=" + _this.suggestionList.ref + depValue.queryToAppend;
			}else {
				listUrl = "/v11/ewf/rest/suggest?ref=" + _this.suggestionList.ref;
			}
			
			var store = null;
			if(depValue.depValueAvailable)
				store = new DependencySuggestionListReadStore({url: listUrl, requestMethod: 'get', initStrLength: 0});
			else 
				store = new SuggestionListReadStore({url: listUrl, requestMethod: 'get', initStrLength: this.initStrLength});
			this.set("store", store);
		},
		
		_startSearch: function(key){
			var _this = this;
			var skipMinLengthCheck = false;
			var depValue = _this.checkForDependentValues();
			if(this.suggestionList.hasOwnProperty('dependencies') && depValue.depValueAvailable){
				skipMinLengthCheck = true;
			}
			try{
				//Defect ID: 3781 
				//Added this fix to clear the earlier selected value (for dependency suggestion list)
				if(!((!_this.readOnly) && (key.length >= _this.initStrLength))){
					if((!_this.readOnly) && (_this.get('value') && (_this.get('value')+'').length > 0)){
						var tmp = _this.store;
						_this.store = null;
						_this.reset();
						_this.store = tmp;
					}
					_this.closeDropDown();
				}
				//Until here
				
				if((!this.readOnly) && ((key.length >= this.initStrLength) || skipMinLengthCheck)){
					this.displayMessage("");
					this.adjustStore();
					this._updateButtonStateLoading();
					this.inherited(arguments);
				}else {
					if(!this.readOnly) {
						this.displayMessage(string.substitute(this.resourceBundle.initSearch, [this.initStrLength]));
					}
					return;
				}
			}catch(e){console.log('Error occurred in startSearch() method --> ', e);this.inherited(arguments);}
		},
		
		_showResultList: function(evt){
			this.logInfo("_showResultList");
			this._updateButtonStateDefault();
			this.inherited(arguments);
		},
		
		_updateButtonStateLoading: function(){
			this.logInfo("_updateButtonStateLoading");
			//set the loading image
			try{this._buttonNode.innerHTML = this.loadingImg;}catch(e){}
		},
		
		_updateButtonStateDefault: function(){
			this.logInfo("_updateButtonStateDefault");
			//set default dropdown button back
			try{this._buttonNode.innerHTML = this.dropdownbutton;}catch(e){}
		},
		
		// Callback when a search completes.
		_openResultList: function(/*Object*/ results, /*Object*/ query, /*Object*/ options){
			if(!results.length && options.start == 0){ // if no results and not just the previous choices button
				// Notify the user that no result is found
				this.displayMessage(this.resourceBundle.noQueryResult);
			};
			this._nextSearch = this.dropDown.onPage = lang.hitch(this, function(direction){
				results.nextPage(direction !== -1);
				this.focus();
			});
			this.inherited(arguments);
		},
		
		closeDropDown: function(){
			this.logInfo("closeDropDown");
			this._updateButtonStateDefault();
			this.inherited(arguments);
		},
		
		onFocus: function(){
			this.inherited(arguments);
			var _this = this;
			var depValue = lang.hitch(_this, _this.checkForDependentValues)();
			var depValueAvailable = depValue.depValueAvailable;
			var propertyValue = '';
			try{propertyValue = _this.property.editorWidget.textbox.value;}catch(e){}
			if(_this.suggestionList && _this.suggestionList.hasOwnProperty('dependencies')){
				if(((!_this.value) || (dojo.string.trim(_this.value+'').length == 0) || (dojo.string.trim(propertyValue).length == 0)) && depValueAvailable)
					_this.loadDropDown();
			}
		}
	});
});
