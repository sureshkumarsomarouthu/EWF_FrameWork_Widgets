define(["dojo/_base/declare",
		"dojo/_base/lang",
		"dojo/_base/xhr",
		"dojo/_base/array",
		"dojo/_base/Deferred",
		"dojo/store/util/QueryResults",
		"dojo/store/Memory",
		"dojo/string",
		"dijit/form/FilteringSelect",
		"v11/ewf/widget/dataentry/SuggestionListReadStore"
	], function(declare, lang, xhr, array, Deferred, QueryResults, Memory, string, FilteringSelect, SuggestionListReadStore){
	
	return declare("v11.ewf.widget.dataentry.SimpleSuggestionList", [FilteringSelect], {
		
		autoComplete : false,
		
		intermediateChanges : false,
		
		dropdownbutton: "",
		
		loadingImg: "<img src='ecm/widget/resources/images/loadingAnimation.gif'/>",
		
		ref: null,
		
		postCreate: function(){
			this.inherited(arguments);
			try{this.dropdownbutton = this._buttonNode.innerHTML;}catch(e){}
			this.pageSize = 10; // Default value is: Infinity
			//Begin changes by Purna for E2E -- Check if the ref attribute is passed. If Yes use the ref otherwise use the default ref
			if(this.ref == null){
				var store = new SuggestionListReadStore({url: "/v11/ewf/rest/suggest?ref=pea", requestMethod: 'get', initStrLength: 0});
				this.set("store", store);
			} else {
				var store = new SuggestionListReadStore({url: "/v11/ewf/rest/suggest?ref=" + this.ref, requestMethod: 'get', initStrLength: 0});
				this.set("store", store);
			}
			//End of changes by Purna
		},
		
		_setDisplayedValueAttr: function(label, priorityChange){
			// modified by rahul to handle remove value when user deleted the value from suggestion list box
			this.inherited(arguments);
			if(label === ""){
				this.valueNode.value = label;
			}
		},
		
		_setValueAttr: function(value, priorityChange, displayedValue, item) {
			if(value && item === undefined ){
				this.tmpValue = value;
			}else{
				delete this.tmpValue;
			}
			this.inherited(arguments);
		},	
		
		_getValueAttr: function() {
			if(this.tmpValue){
				return this.tmpValue;
			}else{
				return this.inherited(arguments);
			}
		},
		
		_setStoreAttr: function(store){
			// For backwards-compatibility, accept dojo.data store in addition to dojo/store/api/Store.  Remove in 2.0.
			if(!store.get){
				lang.mixin(store, {
					_oldAPI: true,
					get: function(id){
						// summary:
						//		Retrieves an object by it's identity. This will trigger a fetchItemByIdentity.
						//		Like dojo/store/DataStore.get() except returns native item.
						var deferred = new Deferred();
						this.fetchItemByIdentity({
							identity: id,
							onItem: function(object){
								deferred.resolve(object);
							},
							onError: function(error){
								deferred.reject(error);
							}
						});
						return deferred.promise;
					},
					query: function(query, options){
						// summary:
						//		Queries the store for objects.   Like dojo/store/DataStore.query()
						//		except returned Deferred contains array of native items.
						var deferred = new Deferred(function(){ fetchHandle && fetchHandle.abort && fetchHandle.abort(); });
						deferred.total = new Deferred();
						var fetchHandle = this.fetch(lang.mixin({
							query: query,
							onBegin: function(count){
								deferred.total.resolve(count);
							},
							onComplete: function(results){
								deferred.resolve(results);
							},
							onError: function(error){
								deferred.reject(error);
							}
						}, options));
						return QueryResults(deferred);
					}
				});
			}
			this._set("store", store);
		},
		
		_showResultList: function(evt){
			this._updateButtonStateDefault();
			this.inherited(arguments);
		},
		
		_updateButtonStateLoading: function(){
			//set the loading image
			try{this._buttonNode.innerHTML = this.loadingImg;}catch(e){}
		},
		
		_updateButtonStateDefault: function(){
			//set default dropdown button back
			try{this._buttonNode.innerHTML = this.dropdownbutton;}catch(e){}
		},
		
		// Callback when a search completes.
		_openResultList: function(results, query, options){
			if(!results.length && options.start == 0){ // if no results and not just the previous choices button
				// Notify the user that no result is found
				//this.displayMessage(this.resourceBundle.noQueryResult);
				console.log('_openResultList');
			};
			this._nextSearch = this.dropDown.onPage = lang.hitch(this, function(direction){
				results.nextPage(direction !== -1);
				this.focus();
			});
			this.inherited(arguments);
		},
		
		closeDropDown: function(){
			this._updateButtonStateDefault();
			this.inherited(arguments);
		}
	});
});
