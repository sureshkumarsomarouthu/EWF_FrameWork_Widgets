define([ "dojo/_base/declare", 
	"dijit/form/_FormValueWidget",
	"dojo/text!./templates/MultiValueWidget.html", 
	"ecm/LoggerMixin"
	], function(declare, _FormValueWidget, template, LoggerMixin){
	return declare("v11.ewf.widget.dataentry.MultiValueWidget", [_FormValueWidget, LoggerMixin], {
		templateString: template,				
		widgetsInTemplate: true,

		baseClass: "MultiValueWidget",
		progContentPane: null,
		returnArray: [],
		
		postCreate: function(){
			this.inherited(arguments);
			this.addAnotherValueLink();			
		},
		
		addAnotherValueLink: function(){
			this.logInfo("addAnotherValueLink");
			var _this = this;
			var dialog = new dijit.TooltipDialog({'title': 'Add Another Value', 'style': 'width: 230px; height: 90px;'});
			var textBox = new dijit.form.TextBox({style: 'width: 200px;'});
			var divWrapper = new dijit.form.Form({});
			divWrapper.domNode.appendChild(textBox.domNode);
			divWrapper.domNode.appendChild(dojo.create('br'));
			divWrapper.domNode.appendChild(dojo.create('br'));
			var buttonDiv = dojo.create('div', {style: 'padding-left: 105px;'});
			var okButton = new dijit.form.Button({'label': 'Add', onClick: function(){
					_this.returnArray.push(textBox.get('value'));
					_this.set('value', _this.returnArray);
					dialog.destroy();
				}
			});
			buttonDiv.appendChild(okButton.domNode);
			var returnButton = new dijit.form.Button({'label': 'Back', onClick: function(){
					_this.set('value', _this.returnArray);
					dialog.destroy();
				}
			});
			buttonDiv.appendChild(returnButton.domNode);
			divWrapper.domNode.appendChild(buttonDiv);
			
			dialog.set('content', divWrapper);
			textBox.startup();
			dialog.startup();
			
			var dropDownButton = new dijit.form.DropDownButton({
				label: "Add Value",
				dropDown: dialog,
				style: 'float: right;'
			});
			_this.multiLineWidgetParent.appendChild(dropDownButton.domNode);
			dropDownButton.startup();
			if(this.readOnly){
				dropDownButton.set('disabled', true);
			}else {
				dropDownButton.set('disabled', false);
			}
		},
		
		_onFocus: function(){
			this.inherited(arguments);
		},
		
		focus: function(){
			this.inherited(arguments);
		},

		_getValueAttr: function(){
			console.log("iwidgets.common.base.panel.FormDEPanel.MultiValueWidget", "_getValueAttr");
			return this.returnArray;
		},
		
		_setValueAttr: function(value){
			console.log("iwidgets.common.base.panel.FormDEPanel.MultiValueWidget", "_setValueAttr");
			var _this = this;
			this.inherited(arguments);
			this.returnArray = value;
			try{_this.progContentPane.destroyRecursive();}catch(e){}
			dojo.empty(_this.multiLineWidgetParent);
			var contentPane = new dijit.layout.ContentPane({});
			dojo.forEach(dojo.clone(this.returnArray), function(item){
				var spanElement = dojo.create('div', {'innerHTML': item, 'style': 'display: block;'});
				var imgElement = dojo.create('img',{
					title: 'Remove', 
					alt: 'Remove', 
					src: '/EWFWidgets/ewf/widget/dataentry/images/close-icon.gif', 
					style: 'vertical-align: middle; padding: 2px 3px 3px 10px;'});
				imgElement.value = item;
				if(!(_this.readOnly === true || _this.readOnly == 'true')){
					imgElement.onclick = function(){
						var _this2 = this;
						var newArray = [];
						dojo.forEach(dojo.clone(_this.returnArray), function(item){
							if(!(item == _this2.value))
								newArray.push(item);
						});
						_this.set('value', newArray);
					}
				}
				spanElement.appendChild(imgElement);
				contentPane.domNode.appendChild(spanElement);
			});
			_this.multiLineWidgetParent.appendChild(contentPane.domNode);
			_this.progContentPane = contentPane;
			_this.addAnotherValueLink();
		},

		validate: function(){
			console.log("iwidgets.common.base.panel.FormDEPanel.MultiValueWidget", "validate");
			return true;
		}		
	});
});
