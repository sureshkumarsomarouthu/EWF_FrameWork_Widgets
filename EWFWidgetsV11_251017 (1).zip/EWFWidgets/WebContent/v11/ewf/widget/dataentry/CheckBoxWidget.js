define([ "dojo/_base/declare", 
		"dojo/text!./templates/CheckBoxWidget.html", 
		"dojo/query", 
		"idx/util",
		"idx/form/CheckBox",
		"ecm/LoggerMixin",
		//"pvr/widget/editors/mixins/_EditorMixin"
		"v11/ewf/model/properties/pvr/widget/editors/mixins/_EditorMixin"
	], function(declare, template, query, iUtil, CheckBox, LoggerMixin, _EditorMixin){
	return declare("v11.ewf.widget.dataentry.CheckBoxWidget", [CheckBox, _EditorMixin], {
		
		templateString: template,				
		
		widgetsInTemplate: true,
		
		instantValidate: true,
		//Added As Part of 521 Upgrade
		valueAttribute: "value",

		editorClass: "CheckBoxWidget",
		
		postCreate: function(){
			this.inherited(arguments);
		},
		
		_setLabelAlignmentAttr: function(labelAlignment){
			this.labelAlignment = labelAlignment;
		},
		
		_setLabelWidthAttr: function(width){
			if(!width){ return; }
			var widthInPx = iUtil.normalizedLength(width);
			query(".idxLabel", this.domNode).style("width", widthInPx + "px");
		},
				
		_setRequiredAttr: function(required) {
			this._set("required", required);
		},
		
		applyNormalizedValue: function(value) {
			this.set("value", value === 'Y' ? 'Y' : 'N');
			//this.set(this.valueAttribute, checked);
		},

		_getValueAttr: function(){
			var checked = this.get("checked");
			this.logInfo("_getValueAttr -- checked: ", checked);
			return (checked === true ? 'Y' : 'N');
		},

		/**
		 * 	Replace dijit.form.CheckBox._setValueAttr() to set the check box according to string value ('Y' or 'N').
		 */
		_setValueAttr: function(/*String|Boolean*/ value, /*Boolean*/ priorityChange){
			this.inherited(arguments);
			this.logInfo("_setValueAttr -- value: ", value);
			if(this._created) {
				this.set("checked", value === 'Y' || false);
			}
		},
		_setRequiredAttr: function(required) {
			this.inherited(arguments, [
				false
			]); // Override the standard IDX behavior.
		},

		adjustWidth: function(widthSettings) {
			// Override the standard _EditorMixin behavior.
		},

		resetWidth: function() {
			// Override the standard _EditorMixin behavior.
		},
		adjustValue: function(value, editorParams) {
			return {
				value: value == null ? 'N' : 'Y',
				error: null
			};
		}
	
	});
});
