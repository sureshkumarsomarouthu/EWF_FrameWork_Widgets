define([ "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/parser",
         "dojo/query",
         "dojo/dom-class",
         "dojo/dom-style",
         "dojo/dom-construct",
         //"idx/form/TextBox",
          "v11/ewf/idx/form/TextBox",
         "idx/widget/HoverHelpTooltip",
         //"pvr/widget/editors/TextBoxEditor",
         "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
         "dojo/text!./templates/ContactNumberWidget.html",
         "ecm/LoggerMixin",
         "dojo/keys",
         "dojo/on",
         "dojo/dom-attr"
       ], function(declare, lang, array, parser, query, domClass, domStyle, domConstruct, TextBox, HoverHelpTooltip, TextBoxEditor, template, LoggerMixin, keys, on, domAttr){
	return declare("v11.ewf.widget.dataentry.ContactNumberWidget", [TextBoxEditor], {
		
		//Define the string seperator to combine the values while posting
		valueSeparator: '-',
		
		width: "100%",
		
		templateString: template,
		
		widgetsInTemplate: true,
		
		countryCodeWidget: null,
		
		countryCodeWidgetConnect: null,
		
		areaCodeWidget: null,
		
		areaCodeWidgetConnect: null,
		
		phoneNumberWidget: null,
		
		phoneNumberWidgetConnect: null,
		
		countryCodeWidgetPattern: "^([0-9]){0,4}$",
		
		areaCodeWidgetPattern: "^([0-9]){0,3}$",
		
		phoneNumberWidgetPattern: "^([0-9]){0,23}$",
		
		constructor: function(){
			this.countryCodeWidget = null;
			this.areaCodeWidget = null;
			this.phoneNumberWidget = null;
			this.countryCodeWidgetConnect = null;
			this.areaCodeWidgetConnect = null;
			this.phoneNumberWidgetConnect = null;
		},
		
		postCreate: function(){
			this.inherited(arguments);
		},
		        
		_setRegExpsAttr: function(regExps){
			this.regExps = regExps;
			if(regExps){
				if(regExps.hasOwnProperty('phoneNumberWidgetPattern')){
					this.phoneNumberWidgetPattern = regExps['phoneNumberWidgetPattern'];
					this.phoneNumberWidget && this.phoneNumberWidget.set && this.phoneNumberWidget.set('pattern', this.phoneNumberWidgetPattern);
				}
				if(regExps.hasOwnProperty('areaCodeWidgetPattern')){
					this.areaCodeWidgetPattern = regExps['areaCodeWidgetPattern'];
					this.areaCodeWidget && this.areaCodeWidget.set && this.areaCodeWidget.set('pattern', this.areaCodeWidgetPattern);
				}
				if(regExps.hasOwnProperty('countryCodeWidgetPattern')){
					this.countryCodeWidgetPattern = regExps['countryCodeWidgetPattern'];
					this.countryCodeWidget && this.countryCodeWidget.set && this.countryCodeWidget.set('pattern', this.countryCodeWidgetPattern);
				}
			}
		},
		
		resize: function(){
			var _this = this;
			this.inherited(arguments);
			
			domStyle.set(this.stateNode, "border", "none");
			if(this.countryCodeWidget && this.countryCodeWidget.resize)
				this.countryCodeWidget.resize();
			
			if(this.areaCodeWidget && this.areaCodeWidget.resize)
				this.areaCodeWidget.resize();
			
			if(this.phoneNumberWidget && this.phoneNumberWidget.resize)
				this.phoneNumberWidget.resize();
			
			setTimeout(lang.hitch(_this, function(){
				try{
				if(_this && _this.stateNode){
					var widthInPx = _this.stateNode.style.width || '';
					if(widthInPx.indexOf('px') > 0){
						try{
							var widthWOpx = _this.stateNode.style.width.split('px')[0];
							//domStyle.set(_this.stateNode, "width", (widthWOpx*0.99) + 'px');
							domStyle.set(_this.stateNode, "width", '330px');
						}catch(e){}
					}
				}
				if(_this.countryCodeWidget && _this.countryCodeWidget.resize)
					_this.countryCodeWidget.resize();
				
				if(_this.areaCodeWidget && _this.areaCodeWidget.resize)
					_this.areaCodeWidget.resize();
				
				if(_this.phoneNumberWidget && _this.phoneNumberWidget.resize)
					_this.phoneNumberWidget.resize();
				}catch(e){}
			}), 100);
		},
						
		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
			this.updateUI();
		},

		updateUI: function(){
			
			//Disconnect the events and destroy the widgets
			if(this.countryCodeWidget && this.countryCodeWidget.destroyRecursive){
				this.countryCodeWidgetConnect && this.disconnect(this.countryCodeWidgetConnect);
				this.countryCodeWidget.destroyRecursive();
			}
			
			if(this.areaCodeWidget && this.areaCodeWidget.destroyRecursive){
				this.areaCodeWidgetConnect && this.disconnect(this.areaCodeWidgetConnect);
				this.areaCodeWidget.destroyRecursive();
			}
			
			if(this.phoneNumberWidget && this.phoneNumberWidget.destroyRecursive){
				this.phoneNumberWidgetConnect && this.disconnect(this.phoneNumberWidgetConnect);
				this.phoneNumberWidget.destroyRecursive();
			}
			
			
			//Create the widgets and activate the listeners
			
			//Country Code Widget
			this.countryCodeWidget = new TextBox({
				labelAlignment: "horizontal",
				label: "+",
				readOnly: this.readOnly,
				pattern: this.countryCodeWidgetPattern,
				hintPosition: "inside",
				invalidMessage: "Invalid Country Code",
				tooltipPosition: ["above"],
				placeHolder: "Country",
				ewficonNode:this.ewficonNode
			});
			
			//domConstruct.place(this.countryCodeWidget.domNode, domConstruct.create('div', {class: 'country', style:'float: left; display: inline-block;'}, this.contactNumberContainer));
			
			var countryDomNode = domConstruct.create('div');
			domStyle.set(countryDomNode, "display", "inline-block");
			domClass.add(countryDomNode, "country");
			countryDomNode.appendChild(this.countryCodeWidget.domNode);
			domConstruct.place(countryDomNode,this.contactNumberContainer);
			this.countryCodeWidget.startup();
			
			this.countryCodeWidgetConnect = this.connect(this.countryCodeWidget, "onChange", "onChange");
			
			
			//Area Code Widget
			this.areaCodeWidget = new TextBox({
				labelAlignment: "horizontal",
				label: "-",
				readOnly: this.readOnly,
				pattern: this.areaCodeWidgetPattern,
				hintPosition: "inside",
				invalidMessage: "Invalid Area Code",
				tooltipPosition: ["above"],
				placeHolder: "Area",
				ewficonNode:this.ewficonNode
			});
			
			var areaDomNode = domConstruct.create('div');
			domStyle.set(areaDomNode, "display", "inline-block");
			domClass.add(areaDomNode, "area");
			areaDomNode.appendChild(this.areaCodeWidget.domNode);
			domConstruct.place(areaDomNode,this.contactNumberContainer);
			this.areaCodeWidget.startup();
			
			this.areaCodeWidgetConnect = this.connect(this.areaCodeWidget, "onChange", "onChange");
			
			//Phone Number Widget
			this.phoneNumberWidget = new TextBox({
				labelAlignment: "horizontal",
				label: "-",
				readOnly: this.readOnly,
				pattern: this.phoneNumberWidgetPattern,
				hintPosition: "inside",
				invalidMessage: "Invalid Phone Number",
				tooltipPosition: ["above"],
				placeHolder: "Number",
				ewficonNode:this.ewficonNode
			});
			
			var mobileDomNode = domConstruct.create('div');
			domStyle.set(mobileDomNode, "display", "inline-block");
			domClass.add(mobileDomNode, "mobile");
			mobileDomNode.appendChild(this.phoneNumberWidget.domNode);
			domConstruct.place(mobileDomNode,this.contactNumberContainer);
			this.phoneNumberWidget.startup();
			
			this.phoneNumberWidgetConnect = this.connect(this.phoneNumberWidget, "onChange", "onChange");
			
			
			//this.focusNode = this.countryCodeWidget.focusNode;
			//this.textbox = this.countryCodeWidget.textbox;
			
			//domAttr.set(this.focusNode, "tabindex", "0");
			//domAttr.set(this.areaCodeWidget.focusNode, "tabindex", "0");
			//domAttr.set(this.phoneNumberWidget.focusNode, "tabindex", "0");
			
			//Set the Value at last
			this.set("value", this.value);
		},
		
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			
			if(this.countryCodeWidget && this.countryCodeWidget.set)
				this.countryCodeWidget.set("readOnly", this.readOnly);
			
			if(this.areaCodeWidget && this.areaCodeWidget.set)
				this.areaCodeWidget.set("readOnly", this.readOnly);
			
			if(this.phoneNumberWidget && this.phoneNumberWidget.set)
				this.phoneNumberWidget.set("readOnly", this.readOnly);
		},
		
		//Done Until here
		_setValueAttr: function(value){
			if((value === null) || ((typeof this.countryCodeWidget === typeof undefined) || (typeof this.areaCodeWidget === typeof undefined) || (typeof this.phoneNumberWidget === typeof undefined))){
				this.inherited(arguments);
				if(value === null){
					//this.countryCodeWidget && this.countryCodeWidget.set && this.countryCodeWidget.set('value', null);
					//this.areaCodeWidget && this.areaCodeWidget.set && this.areaCodeWidget.set('value', null);
					//this.phoneNumberWidget && this.phoneNumberWidget.set && this.phoneNumberWidget.set('value', null);
				}
			}else{
				/*// Make sure that each widget is valid
				var isValid = true;
				if(this.countryCodeWidget)
					isValid = isValid && (this.countryCodeWidget.state !== "Error");
				
				if(this.areaCodeWidget)
					isValid = isValid && (this.areaCodeWidget.state !== "Error");
				
				if(this.phoneNumberWidget)
					isValid = isValid && (this.phoneNumberWidget.state !== "Error");
				
				if(isValid === false)
					return;
				*/	
				
				// Set value for each widget
				var valueArray = value.split(this.valueSeparator);
				array.forEach(valueArray, lang.hitch(this, function(value1, i){
					if(i === 0){
						this.countryCodeWidget && this.countryCodeWidget.set && this.countryCodeWidget.set("value", value1);
					}
					if(i === 1){
						this.areaCodeWidget && this.areaCodeWidget.set && this.areaCodeWidget.set("value", value1);
					}
					if(i === 2){
						this.phoneNumberWidget && this.phoneNumberWidget.set && this.phoneNumberWidget.set("value", value1);
					}
				}));
			}
		},
		
		_getValueAttr: function(){
			if((typeof this.countryCodeWidget === typeof undefined) || (typeof this.areaCodeWidget === typeof undefined) || (typeof this.phoneNumberWidget === typeof undefined))
				return this.inherited(arguments);
			
			var mergedValue = "", value;
			
			value = this.countryCodeWidget.get("value");
			if(value && value !== ''){
				mergedValue +=  value;
			}
			
			value = this.areaCodeWidget.get("value");
			if(value && value !== ''){
				mergedValue +=  this.valueSeparator + value;
			}else{
				mergedValue +=  this.valueSeparator + "";
			}
			
			value = this.phoneNumberWidget.get("value");
			if(value && value !== ''){
				mergedValue +=  this.valueSeparator + value;
			}else{
				mergedValue +=  this.valueSeparator + "";
			}
			
			if(mergedValue === '--')
				return "";
			
			return mergedValue;
		},
		
		destroy: function(){
			if(!((typeof this.countryCodeWidget === typeof undefined) || (typeof this.areaCodeWidget === typeof undefined) || (typeof this.phoneNumberWidget === typeof undefined))){
				if(this.countryCodeWidget && this.countryCodeWidget.destroyRecursive){
					this.countryCodeWidgetConnect && this.disconnect(this.countryCodeWidgetConnect);
					this.countryCodeWidget.destroyRecursive();
				}
				
				if(this.areaCodeWidget && this.areaCodeWidget.destroyRecursive){
					this.areaCodeWidgetConnect && this.disconnect(this.areaCodeWidgetConnect);
					this.areaCodeWidget.destroyRecursive();
				}
				
				if(this.phoneNumberWidget && this.phoneNumberWidget.destroyRecursive){
					this.phoneNumberWidgetConnect && this.disconnect(this.phoneNumberWidgetConnect);
					this.phoneNumberWidget.destroyRecursive();
				}
			}
			this.inherited(arguments);
		},
		
		isValid: function(isFocused){
			if(this.countryCodeWidget && this.areaCodeWidget && this.phoneNumberWidget){
				return this.countryCodeWidget.isValid && this.countryCodeWidget.isValid() && this.areaCodeWidget.isValid && this.areaCodeWidget.isValid() && this.phoneNumberWidget.isValid && this.phoneNumberWidget.isValid();
			}else 
				return true;
		},

		// Set focus at the first widget when the editor is focused
		focus: function(){
			console.log('Focused ', this.focused);
			if(!this.focused && (typeof this.countryCodeWidget !== typeof undefined)) {
				this.countryCodeWidget && this.countryCodeWidget.focus && this.countryCodeWidget.focus();
			}
			this.inherited(arguments);
		}
	});
});
