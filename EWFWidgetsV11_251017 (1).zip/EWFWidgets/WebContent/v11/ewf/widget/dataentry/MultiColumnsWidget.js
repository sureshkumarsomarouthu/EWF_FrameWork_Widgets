define([ "dojo/_base/declare", 
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/dom-construct",
         "dojo/parser",
         "dojo/on",
     	"dojo/dom-class",
     	"dojo/dom-style",
     	//"idx/form/TextBox",
     	"v11/ewf/idx/form/TextBox",
        //"pvr/widget/editors/TextBoxEditor",
        "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
        "dojo/text!./templates/MultiColumnsWidget.html", 
        "ecm/LoggerMixin",
        "v11/ewf/widget/dataentry/ContactNumberWidget",
        "dojox/lang/functional",
        "dijit/form/Button",
        "dojo/query",
        "dojo/Stateful",
        "dojo/NodeList-dom",
        "dojox/uuid/_base",
        "dojox/uuid/Uuid",
        "dojox/uuid/generateRandomUuid"
        
	], function(declare, lang, baseArray, domConstruct, parser, dojoOn, domClass, domStyle, TextBox, TextBoxEditor, 
			template, LoggerMixin, ContactNumber, functional, Button, query, Stateful){
	return declare("v11.ewf.widget.dataentry.MultiColumnsWidget", [TextBoxEditor, Stateful], {
		
		width: "100%",

		templateString: template,
		
		widgetsInTemplate: true,
		
		localDijits: null,
		
		buttonDijits: null,
		
		buttonConnects: null,
		
		localConnects: null,
		
		existingWidgetsInUIMap: null,
		
		participantsControllersMap: null,
		
		allowNullOrBlankValues: null,
		
		widgetsAdded: null,
		
		constructor: function(){
			this.localDijits = [];
			this.buttonDijits = [];
			this.buttonConnects = [];
			this.localConnects = [];
			this.existingWidgetsInUIMap = {};
			this.participantsControllersMap = {};
			this.widgetsAdded = 0;
			this.allowNullOrBlankValues = {};
		},
		_widgetsAddedGetter: function(){
			return this.widgetsAdded;
		},
		_widgetsAddedSetter: function(value){
			this.widgetsAdded = value;
		},
		
		_getWidgetsAddedAttr: function(){
			return this.widgetsAdded;
		},
		_setWidgetsAddedAttr: function(value){
			this.widgetsAdded = value;
		},
		
		postCreate: function(){
			this.inherited(arguments);
			this.updateWidgetUI();
			this.watch("widgetsAdded", lang.hitch(this, function(name, oldVal, newVal){
				setTimeout(lang.hitch(this, function(){
					if(newVal < this.widgetLimit){
						baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
							buttonDijit.set("disabled", this.readOnly);
						}));
					}else{
						baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
							buttonDijit.set("disabled", true);
						}));
					}
				}), 50);
			}));
		},		
		
		resize: function(){
			var _this = this;
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			if(this.localDijits.length > 0){
				baseArray.forEach(this.localDijits, lang.hitch(this, function(localDijit){
					localDijit && localDijit.resize && localDijit.resize();
				}));
			}
			this.highlightedDivNode.innerHTML = '';
			//Hide all the participants in resize() method
			functional.forIn(functional.keys(this.participantsConfig), lang.hitch(this, function(propertySymbolicName){
				if(this.property && this.property.view){
					this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
						if((property.get('binding') === propertySymbolicName) && (property.get('binding') !== _this.property.get('binding'))){
							property.controller.set("hidden", true);
							domStyle.set(property.domNode, "display", "none");
						}
						if(property.get('binding') === propertySymbolicName){
							if(property.controller.get("failureType") || property.controller.get("updated")){
								var spanElement = domConstruct.create('span');
								spanElement.style.paddingRight = "10px";
								dojo.addClass(spanElement, "ewfHighlighted");

								//Add the Property Name here
								var failureLabel = dojo.create("label");
								dojo.addClass(failureLabel, "ewfHighlighted");
								failureLabel.innerHTML = this.participantsConfig[propertySymbolicName]['label'];
								spanElement.appendChild(failureLabel);
								
								//To Check for Highlighted / Failure Type
								if(property.controller.get("failureType") && !property.controller.get("updated")){
									var failureLabel = dojo.create("label");
									dojo.addClass(failureLabel, "ewfHighlighted");
									dojo.addClass(failureLabel, "ewfFailureType");
									failureLabel.innerHTML = " " + property.controller.get("failureType");
									spanElement.appendChild(failureLabel);
								}
								
								if(property.controller.get("updated")){
									var failureLabel = dojo.create("label");
									dojo.addClass(failureLabel, "ewfHighlighted");
									dojo.addClass(failureLabel, "ewfFailureType");
									failureLabel.innerHTML = " Updated";
									spanElement.appendChild(failureLabel);
								}
								
								this.highlightedDivNode.appendChild(spanElement);
							}
						}
					})}); 
				}
			}));
		},
		
		//Set focus at the first line when the editor is focused
		focus: function(){
			//console.log('Inside Focus --> Multi Columns Widget');
			try{
				if(!this.focused && (this.buttonDijits.length > 0)){
					for(var i=0; i<this.buttonDijits.length; i++){
						if(this.buttonDijits[i] && this.buttonDijits[i].focus){
							this.buttonDijits[i].focus();
							break;
						}
					}
				}
			}catch(e){console.log('Error occurred while focus ', e);}
			this.inherited(arguments);
		},

		_setParticipantsConfigAttr: function(participantsConfig){
			this.participantsConfig = participantsConfig;
		},
		
		_setAllowNullOrBlankValuesAttr: function(allowNullOrBlankValues){
			this.allowNullOrBlankValues = allowNullOrBlankValues;
		},
		
		_setButtonLabelAttr: function(buttonLabel){
			this.buttonLabel = buttonLabel;
		},
		
		_setWidgetLimitAttr: function(widgetLimit){
			this.widgetLimit = widgetLimit;
		},

		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
		},
		
		_setReadOnlyAttr: function(readOnly){	
			this.readOnly = readOnly;
			baseArray.forEach(this.localDijits, function(localDijit){
				localDijit && localDijit.set && localDijit.set("readOnly", readOnly);
			});
			baseArray.forEach(this.buttonDijits, function(button){
				button && button.set && button.set("disabled", readOnly);
			});
			if(readOnly === true){
				query(".idxTooltipDialogCloseIcon", this.columnsContainer).style("display", "none");
			}else{
				query(".idxTooltipDialogCloseIcon", this.columnsContainer).style("display", "");
			}
		},
		
		addContact: function(valuesMap){
			var _this = this;
			if(this.widgetsAdded >= this.widgetLimit){
				baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
					buttonDijit.set("disabled", true);
				}));
				return;
			}
			var specialHandlingMap = this.allowNullOrBlankValues;
			//if(functional.keys(this.existingWidgetsInUIMap).length < this.widgetLimit){
				//this.buttonDijits[0].set('disabled', false);
				valuesMap = valuesMap || {};
				var elementsToDelete = [];
				var divElement = dojo.create('div', {'style': "height: auto; display: inline-block; border: 1px solid #ddd; padding: 3px; margin: 3px; position: relative; border-radius: 5px;"});
				var spanElement = domConstruct.toDom('<div class="idxTooltipDialogCloseIcon" role="button" tabindex="-1" aria-label="Close"><div class="idxTooltipDialogCloseText">x</div></div>');
				domStyle.set(spanElement, "top", "-3px");
				domStyle.set(spanElement, "right", "-3px");
				divElement.appendChild(spanElement);
				var randomUUID = dojox.uuid.generateRandomUuid();
				this.existingWidgetsInUIMap[randomUUID] = true;
				functional.forIn(functional.keys(this.participantsConfig), lang.hitch(this, function(propertySymbolicName){
					var editorDiv, editorWidget, label;
					editorDiv = dojo.create('div');
					var widgetConfig = this.participantsConfig[propertySymbolicName];
					var widgetClass = require(widgetConfig['widgetClass']);
					
					var editorWidget = new widgetClass({
						labelAlignment: "horizontal",
						label: widgetConfig['label']+': ',
						labelWidth: "65px",
						fieldWidth: widgetConfig['fieldWidth'] || null,
						hint: this.hint || '',
						hintPosition: this.hintPosition || "inside",
						tooltipPosition: ["above"],
						ewficonNode:this.ewficonNode,
						pattern: widgetConfig['regExp'] || null,
						regExps: widgetConfig['regExps'] || null,
						readOnly: this.readOnly,
						invalidMessage: widgetConfig['invalidMessage'] ||"Invalid Data Provided",
						style: "width:100%; display:block;"
					});
					
					if(widgetConfig['label'] === 'Name'){
						editorWidget.textbox.onblur = function(){
							this.value = this.value.toUpperCase();
						};
					}
					
					editorWidget['propertySymbolicNameForMappingBack'] = propertySymbolicName;
					editorWidget['uuidCustom'] = randomUUID;
					
					if(editorWidget.id.indexOf('ContactNumberWidget') > -1)
						domClass.add(editorWidget.labelWrap, "customLabelWidth");
					editorWidget.stateNode.style.width='350px';
					this.localDijits.push(editorWidget);
					editorWidget.startup();
					editorWidget && editorWidget.resize && editorWidget.resize();
					editorDiv.appendChild(editorWidget.domNode);
					divElement.appendChild(editorDiv);
					elementsToDelete.push(editorWidget);
					
					//Attach the listeners
					//var connect = editorWidget.on('change', lang.hitch(this, this.onChange));
					//this.localConnects.push(connect);
					
					//Set value if anything is provided in the arguments
					if(valuesMap && valuesMap.hasOwnProperty(propertySymbolicName)){
						editorWidget.set('value', valuesMap[propertySymbolicName]);
					}
					
					if(specialHandlingMap && specialHandlingMap.hasOwnProperty(propertySymbolicName) && (specialHandlingMap[propertySymbolicName] === true)){
						domStyle.set(spanElement, "top", "-15px");
						domStyle.set(spanElement, "right", "-15px");
					}
				}));
				
				dojoOn(spanElement, 'click', lang.hitch(this, function(uuid){
					if(this.readOnly === false){
						baseArray.forEach(elementsToDelete, lang.hitch(this, function(editor){
							if(this.localDijits.length > 0){
								baseArray.forEach(this.localDijits, lang.hitch(this, function(localDijit, index){
									if(editor && localDijit && (editor.id === localDijit.id))
										delete this.localDijits[index];
								}));
							}
							editor && editor.destroyRecursive && editor.destroyRecursive();
						}));
						domConstruct.empty(divElement);
						domConstruct.destroy(divElement);
						this.set("widgetsAdded", this.get("widgetsAdded") - 1);
					}
					if(this.widgetsAdded >= this.widgetLimit){
						baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
							buttonDijit.set("disabled", true);
						}));
						return;
					}else{
						baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
							buttonDijit.set("disabled", this.readOnly);
						}));
					}
					console.log("widgets added count is : ",this.get("widgetsAdded"));
					if(this.get("widgetsAdded") ==0){
					//this.columnsContainer.appendChild(divElement);
					var valuesMapToSetNew = {};
					var propertySymbolicNameNew="EWS_AccountNos";
					valuesMapToSetNew[propertySymbolicNameNew] = "";
					this.addContact(valuesMapToSetNew);
					}
				}, randomUUID));
				this.columnsContainer.appendChild(divElement);
				//this.columnsContainer.appendChild(domConstruct.create('br'));
				this.set("widgetsAdded", this.get("widgetsAdded") + 1);
				
				//For special handling @ UCOE DE starts here
				if(specialHandlingMap){
					if(this.widgetsAdded && (this.widgetsAdded % 4 === 0)){
						this.columnsContainer.appendChild(domConstruct.create('br'));
					}
				}else{
					/*if(this.widgetsAdded && (this.widgetsAdded % 2 === 0)){
						this.columnsContainer.appendChild(domConstruct.create('br'));
					}*/
				}
				//For special handling @ UCOE DE ends here
				
				if(this.widgetsAdded >= this.widgetLimit){
					baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
						buttonDijit.set("disabled", true);
					}));
					return;
				}else{
					baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
						buttonDijit.set("disabled", this.readOnly);
					}));
				}
			//}else{
				//this.buttonDijits[0].set('disabled', true);
			//}

				if(this.widgetsAdded >= this.widgetLimit){
					baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
						buttonDijit.set("disabled", true);
					}));
					return;
				}
				
				this.resize();
		},
		
		updateWidgetUI: function(){
			//Cleanup first
			baseArray.forEach(this.localDijits, function(localDijit){
				localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
			});
			this.localDijits = [];
			
			this.set("widgetsAdded", 0);
			
			baseArray.forEach(this.localConnects, function(localDijitConnect){
				localDijitConnect && localDijitConnect.remove && localDijitConnect.remove();
			});
			this.localConnects = [];
			
			var button = new Button({'label': this.buttonLabel || "Add"}, this.addButtonNode);
			
			this.buttonDijits.push(button);
			
			button.startup();
			
			var connect = button.on('click', lang.hitch(this, this.addContact));
			
			this.buttonConnects.push(connect);
			
			//this.set('value', this.value);
		},
		
		_setValueAttr: function(value){
			//console.log('_setValueAttr() ');
			if(value === null){
				//console.log('_setValueAttr() 1 ');
				this.value=[];
			}else{
				if(value){
					//console.log('_setValueAttr() 2');
					if(value && (value !== null) && ((value.constructor === Array) || (value instanceof Array))){
						//console.log('_setValueAttr() 3');
						this.value=value;
						var propertyBinding = null;
						//this.set("value", this.value);
						//Cleanup all the existing ones
						baseArray.forEach(this.localDijits, function(localDijit){
							//console.log('_setValueAttr() 44');
							localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
						});
						this.localDijits = [];
						
						//console.log('_setValueAttr() 555');
						this.set("widgetsAdded", 0);
						//console.log('_setValueAttr() 666');
						this.columnsContainer.innerHTML = "";
						//console.log('_setValueAttr() 77');
						baseArray.forEach(this.localConnects, function(localDijitConnect){
							localDijitConnect && localDijitConnect.remove && localDijitConnect.remove();
						});
						this.localConnects = [];
						
						//Check if the value is instance of Array
						//Get all the participants' Property Controllers'
						var _this = this;
						this.participantsControllersMap = {};
						//var propertyWithoutProvider =this.property.get('binding').split('.');
						this.participantsControllersMap[this.property.get('binding')] = this.property.controller;
						//this.participantsControllersMap[propertyWithoutProvider[1]] = this.property.controller;
						functional.forIn(functional.keys(this.participantsConfig), lang.hitch(this, function(propertySymbolicName){
							if(this.property && this.property.view){
								this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
								    if(this.property.get('binding').indexOf("F_CaseFolder") > -1){
									  propertyBinding = property.get('binding').split('.')[1];
									  
									 }
									  else{
									 propertyBinding=property.get('binding');
								   }
									if(propertyBinding === propertySymbolicName){
									//if(propertyWithoutProvider[1] === propertySymbolicName){
										this.participantsControllersMap[propertySymbolicName] = property.controller;
									}
								})}); 
							}
						}));
						
						//Once the property controllers' are retrieved, populate the values in the UI
						//Step 1: Determine the max of length of all the controllers
						var widgetsCounter = 0;
						functional.forIn(functional.keys(this.participantsControllersMap), lang.hitch(this, function(propertySymbolicName){
									  if(this.property.get('binding').indexOf("F_CaseFolder") > -1){
											propertyBinding = this.property.get('binding').split('.')[1];
									  
									 }
									  else{
										  propertyBinding=this.property.get('binding');
									  }
						if(propertyBinding !== propertySymbolicName){
							//if(propertyWithoutProvider[1] !== propertySymbolicName){
								var participantPropertyController = this.participantsControllersMap[propertySymbolicName];
								if(participantPropertyController.get && participantPropertyController.get('value') && (participantPropertyController.get('value').length > widgetsCounter))
									widgetsCounter = participantPropertyController.get('value').length;
							}else{
								if(value.length > widgetsCounter)
									widgetsCounter = value.length;
							}
						}));
						
						if(widgetsCounter === 0)
							widgetsCounter++;
						
						//Step 2: Populate the values map and create the widgets as per the widgetsCounter
						var valuesMapToSet = {};
						for(var i=0; i<widgetsCounter; i++){
							functional.forIn(functional.keys(this.participantsControllersMap), lang.hitch(this, function(propertySymbolicName){
							   if(this.property.get('binding').indexOf("F_CaseFolder") > -1){
									     propertyBinding = this.property.get('binding').split('.')[1];
									 }
								else{
									   propertyBinding=this.property.get('binding');
								   }
								if(propertyBinding !== propertySymbolicName){
								//if(propertyWithoutProvider[1] !== propertySymbolicName){
									var participantPropertyController = this.participantsControllersMap[propertySymbolicName];
									var valuesArray = participantPropertyController.get('value');
									valuesMapToSet[propertySymbolicName] = valuesArray[i] || "";
								}else {
									valuesMapToSet[propertySymbolicName] = value[i] || "";
								}
							}));
							this.addContact(valuesMapToSet);
						}
						this.set("readOnly", this.readOnly);
					}
				}
			}
			//added as part of icm 5.2.1 upgrade property value is not getting updated when property validation fails
			this.inherited(arguments);
		},
		
		_getValueAttr: function(){
			
			var propertyProvider = null;
			//console.log('_getValueAttr() ');
			var specialHandlingMap = this.allowNullOrBlankValues;
			var returnValue = this.inherited(arguments);
			var propertyBinding = null;
			//console.log('_getValueAttr() 1');
			if((this.localDijits.length == 0) && (this.value !== null)){
				//console.log('_getValueAttr() 2');
				return this.value;
			}else if(this.localDijits.length == 0){
				//console.log('_getValueAttr() 3');
				return [];
			}
			//console.log('_getValueAttr() 4');
			//var localDijit;
			/*for(var i=0; i<this.localDijits.length; i++){
				//console.log('_getValueAttr() 5');
				localDijit = this.localDijits[i];
				//console.log('_getValueAttr() 6');
				if(localDijit && localDijit.state === "Error"){
					//console.log('_getValueAttr() 7');
					//return [];
				}
			}*/
			//console.log('_getValueAttr() 8');
			//Gather values from all the widgets and update the respective property controllers.
			var valuesMapGathered = {}, localDijit;
			for(var i=0; i<this.localDijits.length; i++){
				//console.log('_getValueAttr() 9');
				localDijit = this.localDijits[i];
				if(typeof localDijit !== typeof undefined){
					//console.log('_getValueAttr() 10');
					if(!(valuesMapGathered.hasOwnProperty(localDijit['uuidCustom'])))
						//console.log('_getValueAttr() 11');
						valuesMapGathered[localDijit['uuidCustom']] = {};
						//console.log('_getValueAttr() 12');
						valuesMapGathered[localDijit['uuidCustom']][localDijit['propertySymbolicNameForMappingBack']] = localDijit.get('value') || null;
						//console.log('_getValueAttr() 13');
				}
			}
			//console.log('_getValueAttr() 14');
			//Get all the participants' Property Controllers'
			this.participantsControllersMap = {};
			functional.forIn(functional.keys(this.participantsConfig), lang.hitch(this, function(propertySymbolicName){
				//console.log('_getValueAttr() 15');
				if(this.property && this.property.view){
					//console.log('_getValueAttr() 16');
					this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
						//console.log('_getValueAttr() 17');
						            if(this.property.get('binding').indexOf("F_CaseFolder") > -1){
								          propertyBinding =property.get('binding').split('.')[1];
								          
								         }
								     else{
								           propertyBinding=property.get('binding');
								       }
						if(propertyBinding === propertySymbolicName){
							//if(propertyWithoutProvider[1] === propertySymbolicName){
							//console.log('_getValueAttr() 18');
							this.participantsControllersMap[propertySymbolicName] = property.controller;
						}
					})}); 
				}
			}));
			//console.log('_getValueAttr() 19');
			var participantsMapWithValues = {};
			functional.forIn(functional.keys(this.participantsConfig), lang.hitch(this, function(propertySymbolicName){
				//console.log('_getValueAttr() 20');
				participantsMapWithValues[propertySymbolicName] = [];
				functional.forIn(functional.keys(valuesMapGathered), lang.hitch(this, function(uuid){
					//console.log('_getValueAttr() 21');
					//Inject the code for special handling here (whether to allow spaces / null values or not in the widget)
					if(specialHandlingMap && specialHandlingMap.hasOwnProperty(propertySymbolicName) && (specialHandlingMap[propertySymbolicName] === true)){
						if(valuesMapGathered[uuid][propertySymbolicName] && ((valuesMapGathered[uuid][propertySymbolicName]+'').length>0)){
							participantsMapWithValues[propertySymbolicName].push(valuesMapGathered[uuid][propertySymbolicName]);
							/*if(participantsMapWithValues[propertySymbolicName] && participantsMapWithValues[propertySymbolicName]!== null && (participantsMapWithValues[propertySymbolicName].length > 0))
								participantsMapWithValues[propertySymbolicName] = participantsMapWithValues[propertySymbolicName].sort();*/
						}
					}else
						participantsMapWithValues[propertySymbolicName].push(valuesMapGathered[uuid][propertySymbolicName]);
				}));
			}));
			//console.log('_getValueAttr() 22');
			functional.forIn(functional.keys(this.participantsConfig), lang.hitch(this, function(propertySymbolicName){
				//console.log('_getValueAttr() 23');
				var propertyController = this.participantsControllersMap[propertySymbolicName];
				if(participantsMapWithValues[propertySymbolicName] && (participantsMapWithValues[propertySymbolicName]['length'] === 0)){
					participantsMapWithValues[propertySymbolicName].push("");
				}
				  if(this.property.get('binding').indexOf("F_CaseFolder") > -1){
					 propertyBinding = this.property.get('binding').split('.')[1];
					}
					else{
						 propertyBinding = this.property.get('binding');
					 }
				if(propertyBinding !== propertySymbolicName)
				//if(propertyWithoutProvider[1] !== propertySymbolicName)
					propertyController && propertyController.set && propertyController.set('value', participantsMapWithValues[propertySymbolicName]);
			}));
			return participantsMapWithValues[propertyBinding];
			
		},
		
		destroy: function(){
			//Cleanup first
			baseArray.forEach(this.localDijits, function(localDijit){
				localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
			});
			this.localDijits = [];
			
			baseArray.forEach(this.buttonDijits, function(localDijit){
				localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
			});
			this.buttonDijits = [];
			
			domConstruct.empty(this.columnsContainer);
			
			baseArray.forEach(this.localConnects, function(localDijitConnect){
				localDijitConnect && localDijitConnect.remove && localDijitConnect.remove();
			});
			this.localConnects = [];
			this.set("widgetsAdded", 0);
			this.inherited(arguments);
		},
		
		isValid: function(isFocusd) {
			var localDijit;
			var returnValue = true;
			for(var i=0; i<this.localDijits.length; i++){
				localDijit = this.localDijits[i];
				returnValue = returnValue && localDijit.isValid();
			}
			return returnValue;
		}		
	});
});
