define([ "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/parser",
         "dojo/query",
         "dojo/dom-class",
         "dojo/dom-style",
         "dojo/dom-construct",
         "idx/form/CheckBox",
        // "pvr/widget/editors/TextBoxEditor",
        "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
         "dojo/text!./templates/ShowOrHidePropertiesWidget.html",
         "ecm/LoggerMixin",
         "dojox/lang/functional",
         "dojo/on",
         "dijit/registry",
		 "idx/form/FilteringSelect",
		 "dojo/store/Memory",
		 "dojo/_base/connect",
		 "dojo/data/ItemFileReadStore"
       ], function(declare, lang, array, parser, query, domClass, domStyle, domConstruct, CheckBox, TextBoxEditor, template, LoggerMixin, functional, on, registry, FilteringSelect,Memory,connect,ItemFileReadStore){
	return declare("v11.ewf.widget.dataentry.ShowOrHidePropertiesWidget", [TextBoxEditor,FilteringSelect], {
		
		width: "100%",
		
		templateString: template,
		
		widgetsInTemplate: true,
		contentString: template,
		
		chkBoxWidgets: null,
		
		chkBoxWidgetConnects: null,
		
		solutionPrefix: null,
		
		onChangeTriggered: null,
		
		constructor: function(){
			this.chkBoxWidgets = [];
			this.chkBoxWidgetConnects = [];
			this.solutionPrefix = "";
			this.onChangeTriggered = false;
		},
		
		postCreate: function(){
			this.inherited(arguments);
			//this.hasDownArrow = true;
			
			//Added by sravanthi for july QR
			this.searchAttr = 'name';
			this.identifier = 'value';
			//End changes by srvanthi.
},		
		
		rerunCallbacks: function(){
			var _this = this;
			//Re-apply all the show / Hide rules here
			var solutionPrefix = '';
			try{
				//Alternate way to get the solution prefix is to strip the property binding until the first 'underscore'
				//solutionPrefix = _this.property.controller.collectionController.model.icmWorkItem._solutionPrefix;
				solutionPrefix = _this.property.collectionController.collections.F_CaseFolder.model.icmWorkItem._solutionPrefix;
			}catch(e){
				var localPropertyObj = _this.property;
				if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.collections){
					//solutionPrefix = localPropertyObj.collectionController.model.getCaseType().solution.prefix;
					solutionPrefix = localPropertyObj.collectionController.collections.F_CaseFolder.model.parentCase.caseType.solution.prefix;
				}else {
					//Extract the prefix from property Binding
					try{
						//solutionPrefix = _this.property.get('binding').split('_')[0];
						//added by suresh as part of 5.2.1 upgrade jira issue PEWFSGUPGS-216
						if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
						    solutionPrefix = _this.property.get('binding').split('.')[1];
						}else{
							solutionPrefix = _this.property.get('binding').split('_')[0];
						}
						//End change
						
					}catch(e){
						
					}
				}
			}
			var currentValue;
			if(this.isDropdown&&this.selectBox)
			{
				currentValue = this.selectedValue;
			}
			else{
			currentValue = this.get('value');
			}
			if(solutionPrefix){
				functional.forIn(functional.keys(this.checkBoxLogic.checkBoxes), lang.hitch(this, function(checkBoxKey){
					if(currentValue === this.checkBoxLogic.checkBoxes[checkBoxKey]['value']){
						//Hide the Properties
						array.forEach(this.checkBoxLogic.checkBoxes[checkBoxKey]['hide'], lang.hitch(this, function(propertyName){
							if(this && this.property && this.property.view){
								this.property.view.forEachProperty({callback: function(property, i){
								    //added by suresh for jira issue PEWFSGUPGS-216
								    var solutionPrefix='';
								    var propertyBinding='';
								    if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								        var tmpSolutionPrefix=property.get('binding').split('.')[1];
								        solutionPrefix=tmpSolutionPrefix.split('_')[0];
								        propertyBinding=property.get('binding').split('.')[1];
								    }
								    else{
								          solutionPrefix=property.get('binding').split('_')[0];
								          propertyBinding=property.get('binding');
								    }
									var propertySymbolicName = solutionPrefix + '_' + propertyName;
									//added by rahul to handle reused properties
									var _propSymbName = propertyName;
									//if(property.get('binding') === propertySymbolicName || property.get('binding') === _propSymbName){
									if(propertyBinding === propertySymbolicName || propertyBinding === _propSymbName){
										try{
											//Extra Check required for DE extra spaces
											if(property.view.templateString.indexOf('data-dojo-type="pvr/widget/MultiColumnContainer"') > -1){
												if(property.domNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.className.indexOf('pvrMultiColumnContainer') === 0){
													property.domNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.style.display = 'none';
													//property.resize && property.resize();
													setTimeout(lang.hitch(this, function() {
					                                    property.resize && property.resize();
				                                    }, 200));
												}
											}else{
												property.domNode.style.display = 'none';
												//property.resize && property.resize();
												setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
											}
										}catch(e){
											property.domNode.style.display = 'none';
											//property.resize && property.resize();
											setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
										}
									}
								}});
							}
						}));
						
						//Show the Properties
						array.forEach(_this.checkBoxLogic.checkBoxes[checkBoxKey]['show'], lang.hitch(this, function(propertyName){
							if(_this && _this.property && _this.property.view){
								_this.property.view.forEachProperty({callback: function(property, i){
								    //added by suresh for jira issue PEWFSGUPGS-148
								    var solutionPrefix='';
								    var propertyBinding='';
								    if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								         var tmpSolutionPrefix=property.get('binding').split('.')[1];
								         solutionPrefix=tmpSolutionPrefix.split('_')[0];
								         propertyBinding=property.get('binding').split('.')[1];
								         
								    }
								    else{
								         solutionPrefix=property.get('binding').split('_')[0];
								         propertyBinding=property.get('binding');
								    }
									var propertySymbolicName = solutionPrefix + '_' + propertyName;
									//added by rahul
									var _propSymbName = propertyName;
									//if(property.get('binding') === propertySymbolicName || property.get('binding') === _propSymbName){
									if(propertyBinding === propertySymbolicName || propertyBinding === _propSymbName){
										try{
											//Extra Check required for DE extra spaces
											if(property.view.templateString.indexOf('data-dojo-type="pvr/widget/MultiColumnContainer"') > -1){
												if(property.domNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.className.indexOf('pvrMultiColumnContainer') === 0){
													property.domNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.style.display = 'block';
													//property.resize && property.resize();
													setTimeout(lang.hitch(this, function() {
					                                   property.resize && property.resize();
				                                      }, 200));
												}
											}else{
												property.domNode.style.display = 'block';
												//property.resize && property.resize();
												setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
											}
										}catch(e){
											property.domNode.style.display = 'block';
											//property.resize && property.resize();
											setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
										}
									}
								}});
							}
						}));
						
						//Invoke the Participants' Callback
						var participantCallBack = _this.checkBoxLogic.checkBoxes[checkBoxKey]['participantCallback'];
						if(participantCallBack)
							functional.forIn(functional.keys(participantCallBack), lang.hitch(this, function(propertyName){
								//added by rahul to handle reused properties
								var solutionPrefix='';
								try{
				                     solutionPrefix = _this.property.collectionController.collections.F_CaseFolder.model.icmWorkItem._solutionPrefix;
			                       }catch(e){
				                        var localPropertyObj = _this.property;
				                        if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.collections){
					                     solutionPrefix = localPropertyObj.collectionController.collections.F_CaseFolder.model.parentCase.caseType.solution.prefix;
				                        }
			                       }
								var _propSymbName = propertyName;
								var propertyBinding='';
								    if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								          var tmpSolutionPrefix=_this.property.get('binding').split('.')[1];
								          //solutionPrefix=tmpSolutionPrefix.split('_')[0];
								          propertyBinding=_this.property.get('binding').split('.')[1];
								    }
								    else{
								       propertyBinding=_this.property.get('binding');
								       //solutionPrefix=_this.property.get('binding').split('_')[0];
								    }
								var propertySymbolicName = solutionPrefix + '_' + propertyName;
								var callBackFunction = participantCallBack[propertyName] || '';
								_this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
									if((property.get('binding') === propertySymbolicName || property.get('binding') === _propSymbName) && lang.isFunction(callBackFunction)){
									//if((propertyBinding === propertySymbolicName || propertyBinding === _propSymbName) && lang.isFunction(callBackFunction)){
										lang.hitch(this, callBackFunction)(property);
									}
									if(property.get('binding').indexOf("F_CaseFolder") > -1){
										if((property.get('binding').split('.')[1] === propertySymbolicName  || property.get('binding').split('.')[1] === _propSymbName) && lang.isFunction(callBackFunction)){
										//if((propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName) && lang.isFunction(callBackFunction)){
											lang.hitch(this, callBackFunction)(property);
										}
										
										}
								})});
							}));
					}
				}));
			}
		},
		
		resize: function(){
			var _this = this;
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			array.forEach(this.chkBoxWidgets, lang.hitch(this, function(widget, i){
				widget && widget.resize && widget.resize();
			}));
			this.rerunCallbacks();
		},
						
		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
		},
		
		_setCheckBoxLogicAttr: function(checkBoxLogic){
			this.checkBoxLogic = checkBoxLogic;
			this.updateUI();
		},
		//Added by sravanthi
		_setIsDropdownAttr: function(isDropdown){
			this.isDropdown = isDropdown;
		},
       //End by sravanthi

		updateUI: function(){
		    //added by suresh for jira issue PEWFSGUPGS-107 as part of upgrade supplementary applicant2 local address is not checked bydefault at Form DE 
		    // Begin change
		    if(this._initialValue == "N"){
		        this._initialValue="L";
		    }
		    //End change
			var _this = this;
			//Disconnect the events and destroy the widgets
			array.forEach(this.chkBoxWidgets, lang.hitch(this, function(widget, i){
				widget && widget.destroyRecursive && widget.destroyRecursive();
				this.disconnect(this.chkBoxWidgetConnects[i]);
			}));
			
			if(this.checkBoxLogic && this.checkBoxLogic.hasOwnProperty('checkBoxes')){
			//Declared variables by sravanthi as perjuly QR
			    var options =[];
				var checkBoxDetailsObject;
			//End Declaration by sravanthi as perjuly QR
				functional.forIn(functional.keys(this.checkBoxLogic.checkBoxes), lang.hitch(this, function(checkBoxKey){
					checkBoxDetailsObject = this.checkBoxLogic.checkBoxes[checkBoxKey];
					//Added by Purna cautious -- checking whether the readOnly attribute is set or not 
					if(typeof this.readOnly === 'undefined') {
						this.readOnly = false;
					}
					//End
					//Added by sravanthi for July_QR
		       if(this.isDropdown)
			    {
					 options.push({"value":checkBoxDetailsObject['value'],"name":checkBoxDetailsObject['label']});
				
                } 
					  //End by sravanthi for July_QR and else condition too added.
				 else
				 {
					var cbWidget = new CheckBox({
						labelAlignment: "horizontal",
						label: checkBoxDetailsObject['label'],
						checked: false,
						readOnly: this.readOnly//Added by Purna -- Set the readonly attribute to disable the checkbox
					});
					cbWidget.startup();
					cbWidget.sourceKey = checkBoxKey;
					cbWidget.valueToSet = checkBoxDetailsObject['value'];
					//cbWidget.set("checked", this.checkBoxLogic.defaultChecked === checkBoxKey);
					var cbDomNode = domConstruct.create('div');
					domStyle.set(cbDomNode, "display", "inline-block");
					cbDomNode.appendChild(cbWidget.domNode);
					domConstruct.place(cbDomNode,this.showHidePropertiesContainer);
					on(cbWidget, 'change', function(isChecked){
						console.log('On Change Triggered');
						this.onChangeTriggered = true;
						var _thisCB = this;
						if(isChecked){
							array.forEach(_this.chkBoxWidgets, lang.hitch(this, function(chkBox){
								if(chkBox && (chkBox.id !== _thisCB.id) && chkBox.get("checked"))
									chkBox.set("checked", false);
							}));
							
							//Extract the Solution Prefix
							var solutionPrefix = '';
							try{
								//Alternate way to get the solution prefix is to strip the string until the first 'underscore'
								solutionPrefix = _this.property.controller.collectionController.model.icmWorkItem._solutionPrefix;
							}catch(e){
								var localPropertyObj = _this.property;
								if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.model){
									solutionPrefix = localPropertyObj.collectionController.model.getCaseType().solution.prefix;
								}else {
									//Extract the prefix from property Binding
									try{
										//solutionPrefix = _this.property.get('binding').split('_')[0];
										if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
							                  solutionPrefix = _this.property.get('binding').split('.')[1];
						                    }else{
							                      solutionPrefix = _this.property.get('binding').split('_')[0];
						                         }
									}catch(e){
										
									}
								}
							}
							_this.solutionPrefix = solutionPrefix;
							//Hide the Properties
							array.forEach(_this.checkBoxLogic.checkBoxes[_thisCB.sourceKey]['hide'], lang.hitch(this, function(propertyName){
								if(_this && _this.property && _this.property.view){
									_this.property.view.forEachProperty({callback: function(property, i){
									   //added by suresh for jira issue PEWFSGUPGS-141
									    var solutionPrefix='';
								        var propertyBinding='';
								       if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								         var solutionPrefix1=property.get('binding').split('.')[1];
								          solutionPrefix=solutionPrefix1.split('_')[0];
								          propertyBinding=property.get('binding').split('.')[1];
								          
								         }
								          else{
								          solutionPrefix=property.get('binding').split('_')[0];
								          propertyBinding=property.get('binding');
								       }
										var propertySymbolicName = solutionPrefix + '_' + propertyName;
										//added by rahul to handle reused properties
										var _propSymbName = propertyName;
										//if(property.get('binding') === propertySymbolicName  || property.get('binding') === _propSymbName){
										if(propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName){
											property.domNode.style.display = 'none';
											//property.resize && property.resize();
											setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
										}
									}});
								}
							}));
							//Show the Properties
							array.forEach(_this.checkBoxLogic.checkBoxes[_thisCB.sourceKey]['show'], lang.hitch(this, function(propertyName){
								if(_this && _this.property && _this.property.view){
									_this.property.view.forEachProperty({callback: function(property, i){
									   //added by suresh for jira issue PEWFSGUPGS-141
									    var solutionPrefix='';
								        var propertyBinding='';
								       if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								          var tmpSolutionPrefix=property.get('binding').split('.')[1];
								          solutionPrefix=tmpSolutionPrefix.split('_')[0];
								          propertyBinding=property.get('binding').split('.')[1];
								          
								         }
								          else{
								         solutionPrefix=property.get('binding').split('_')[0];
								         propertyBinding=property.get('binding');
								       }
										var propertySymbolicName = solutionPrefix + '_' + propertyName;
										//added by rahul
										var _propSymbName = propertyName;
										//if(property.get('binding') === propertySymbolicName  || property.get('binding') === _propSymbName){
										if(propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName){
											property.domNode.style.display = 'block';
											//property.resize && property.resize();
											setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
										}
									}});
								}
							}));
							
							//Prefill values (if any)
							/*var prefilledValues = {};
							functional.forIn(functional.keys(_this.checkBoxLogic.checkBoxes), lang.hitch(this, function(checkBoxKey){
								var objectDataToPopulate = _this.checkBoxLogic.checkBoxes[checkBoxKey]['populate'];
								functional.forIn(functional.keys(objectDataToPopulate), lang.hitch(this, function(propertyName){
									if(propertyName !== 'OverWrite'){
										var propertyValueToPopulate = objectDataToPopulate[propertyName] || '';
										if(propertyValueToPopulate)
											prefilledValues[propertyValueToPopulate]="";
									}
								}));
							}));
							
							var objectDataToPopulate = _this.checkBoxLogic.checkBoxes[_thisCB.sourceKey]['populate'];
							if(objectDataToPopulate){
								var booleanToOverWrite = objectDataToPopulate['OverWrite'];
								functional.forIn(functional.keys(objectDataToPopulate), lang.hitch(this, function(propertyName){
									if(propertyName !== 'OverWrite'){
										var propertySymbolicName = solutionPrefix + '_' + propertyName;
										var propertyValueToPopulate = objectDataToPopulate[propertyName] || '';
										_this.property.view.forEachProperty({callback: function(property, i){
											if(property.get('binding') === propertySymbolicName){
												if(booleanToOverWrite){
													if(((propertyName === 'MailAddrFormatType') && (property.controller.get('value')==='F')) ||
															((propertyName === 'ResAddrFormatType') && (property.controller.get('value')==='F'))){
														property.controller.set('value', propertyValueToPopulate);
														property.editorWidget.set('value', propertyValueToPopulate);
													}else if(((propertyName === 'MailAddrFormatType') && (property.controller.get('value')!=='F')) ||
															((propertyName === 'ResAddrFormatType') && (property.controller.get('value')!=='F'))){
														//Do Nothing
														
													}else{
														property.controller.set('value', propertyValueToPopulate);
														property.editorWidget.set('value', propertyValueToPopulate);
													}
												}else{
													if(property.controller.get('value') && (property.controller.get('value').length > 0) && (!prefilledValues.hasOwnProperty(property.controller.get('value')))){
														property.controller.set('value', property.controller.get('value'));
														property.editorWidget.set('value', property.controller.get('value'));
													}else{
														property.controller.set('value', propertyValueToPopulate);
														property.editorWidget.set('value', propertyValueToPopulate);
													}
												}
											}
										}});
									}
								}));
							}*/
							
							//Invoke the Participants' Callback
							var participantCallBack = _this.checkBoxLogic.checkBoxes[_thisCB.sourceKey]['participantCallback'];
							if(participantCallBack)
								functional.forIn(functional.keys(participantCallBack), lang.hitch(this, function(propertyName){
								    var solutionPrefix='';
								    try{
				                         solutionPrefix = _this.property.collectionController.collections.F_CaseFolder.model.icmWorkItem._solutionPrefix;
			                       }catch(e){
				                        var localPropertyObj = _this.property;
				                        if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.collections){
					                     solutionPrefix = localPropertyObj.collectionController.collections.F_CaseFolder.model.parentCase.caseType.solution.prefix;
				                        }
			                       }
								    var propertyBinding='';
								       if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								         //var tmpSolutionPrefix=_this.property.get('binding').split('.')[1];
								         //solutionPrefix=tmpSolutionPrefix.split('_')[0];
								         propertyBinding=_this.property.get('binding').split('.')[1];
								         }
								          else{
								          //solutionPrefix=_this.property.get('binding').split('_')[0];
								          propertyBinding=_this.property.get('binding');
								       }
									var propertySymbolicName = solutionPrefix + '_' + propertyName;
									//added by rahul to handle reused properties
									var _propSymbName = propertyName;
									var callBackFunction = participantCallBack[propertyName] || '';
									//console.log("_this.property.view",_this.property.view);
									_this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
										
										if((property.get('binding') === propertySymbolicName  || property.get('binding') === _propSymbName) && lang.isFunction(callBackFunction)){
										//if((propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName) && lang.isFunction(callBackFunction)){
											lang.hitch(this, callBackFunction)(property);
										}
										if(property.get('binding').indexOf("F_CaseFolder") > -1){
										if((property.get('binding').split('.')[1] === propertySymbolicName  || property.get('binding').split('.')[1] === _propSymbName) && lang.isFunction(callBackFunction)){
										//if((propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName) && lang.isFunction(callBackFunction)){
											lang.hitch(this, callBackFunction)(property);
										}
										
										}
										
									})});
								}));
								
							//Added by Purna during E2E dev - query the activityPanel node and retrieve the ActivityPanel obj. Using the object resize the grid to fix 
							//the issue with scrollbars during option change 
							if(!_this.pgwidget) {
								query(".ewfActivityPanel").forEach(function(node, index) {
									_this.pgwidget = registry.byId(node.id);
								});
							}
							_this.pgwidget && _this.pgwidget.activityList && _this.pgwidget.activityList.activityListGrid && _this.pgwidget.activityList.activityListGrid.resize();
							//End
							
						}
					});
					this.chkBoxWidgets.push(cbWidget);
					var cbWidgetConnect = this.connect(cbWidget, "onChange", "onChange");
					this.chkBoxWidgetConnects.push(cbWidgetConnect);
				}
				}));
			//Added block by sravanthi for July QR Request-48261.
				if(this.isDropdown)
				{
				    var choices = {
						identifier: "value",
						label: "name",
						items: options
				       };
				    var templateStore = new ItemFileReadStore({data: choices});	
				    var _this =this;
				    var selectBox = new idx.form.FilteringSelect({
								 store:templateStore,
								 searchAttr:"name",
								 style: "display: inline-block;"
							},this.showHidePropertiesContainer);
					selectBox.startup();
					this.selectBox = selectBox;
					//this.selectBox.valueToSet = checkBoxDetailsObject['value'];
				 if(this._initialValue ==null || this._initialValue =="L" )
				  {
				   var defaultOption = this.checkBoxLogic.defaultChecked;
				   this.selectedValue = defaultOption;
				  } 
				  else{
					  this.selectedValue=this._initialValue;
				  }
					this.connect(this.selectBox, "onChange", lang.hitch(this,this.renderProperties));
				}
			//End block by sravanthi for July QR Request-48261.	
							
			}
			//this.set("value", this.value);
		},
	//Added block by sravanthi for July QR Request-48261.	
		renderProperties:function(selectedValue){
			console.log("inside selctedValues::selected",selectedValue);
			var _this = this;
			this.onChangeTriggered = true;
			var _thisCB = this;
			console.log("_thisCB this",_thisCB);
			this.selectedValue = selectedValue;
			this.rerunCallbacks();
			         /*  //Extract the Solution Prefix
							var solutionPrefix = '';
							try{
								//Alternate way to get the solution prefix is to strip the string until the first 'underscore'
								solutionPrefix = _this.property.controller.collectionController.model.icmWorkItem._solutionPrefix;
								console.log("solutionPrefix in onchange::::",solutionPrefix);
							}catch(e){
								var localPropertyObj = _this.property;
								console.log("localPropertyObj in onchange::::",localPropertyObj);
								if(localPropertyObj && localPropertyObj.collectionController && localPropertyObj.collectionController.model){
									solutionPrefix = localPropertyObj.collectionController.model.getCaseType().solution.prefix;
									console.log("solutionPrefix in if condition onchange::::",solutionPrefix);
								}else {
								console.log("solutionPrefix in else condition onchange::::",solutionPrefix);
									//Extract the prefix from property Binding
									try{
										//solutionPrefix = _this.property.get('binding').split('_')[0];
										if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
							                  solutionPrefix = _this.property.get('binding').split('.')[1];
											  console.log("solutionPrefix in if condition F_CaseFolder onchange::::",solutionPrefix);
						                    }else{
							                      solutionPrefix = _this.property.get('binding').split('_')[0];
												  console.log("solutionPrefix in else condition F_CaseFolder onchange::::",solutionPrefix);
						                         }
									}catch(e){
										
									}
								}
							}
							_this.solutionPrefix = solutionPrefix;
							console.log("this.selected:::::",this.selectedValue);
							//Hide the Properties
							array.forEach(_this.checkBoxLogic.checkBoxes[this.selectedValue]['hide'], lang.hitch(this, function(propertyName){
							console.log("Inside forEach loop");
								if(_this && _this.property && _this.property.view){
									_this.property.view.forEachProperty({callback: function(property, i){
									   //added by suresh for jira issue PEWFSGUPGS-141
									    var solutionPrefix='';
								        var propertyBinding='';
								       if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								         var solutionPrefix1=property.get('binding').split('.')[1];
								          solutionPrefix=solutionPrefix1.split('_')[0];
								          propertyBinding=property.get('binding').split('.')[1];
								          
								         }
								          else{
								          solutionPrefix=property.get('binding').split('_')[0];
								          propertyBinding=property.get('binding');
								       }
										var propertySymbolicName = solutionPrefix + '_' + propertyName;
										//added by rahul to handle reused properties
										var _propSymbName = propertyName;
										//if(property.get('binding') === propertySymbolicName  || property.get('binding') === _propSymbName){
										if(propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName){
											property.domNode.style.display = 'none';
											//property.resize && property.resize();
											setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
										}
									}});
								}
							}));
							console.log("this.selected:::::",this.selectedValue);
							//Show the Properties
							array.forEach(_this.checkBoxLogic.checkBoxes[this.selectedValue]['show'], lang.hitch(this, function(propertyName){
								if(_this && _this.property && _this.property.view){
									_this.property.view.forEachProperty({callback: function(property, i){
									   //added by suresh for jira issue PEWFSGUPGS-141
									    var solutionPrefix='';
								        var propertyBinding='';
								       if(_this.property.get('binding').indexOf("F_CaseFolder") > -1){
								          var tmpSolutionPrefix=property.get('binding').split('.')[1];
								          solutionPrefix=tmpSolutionPrefix.split('_')[0];
								          propertyBinding=property.get('binding').split('.')[1];
								          
								         }
								          else{
								         solutionPrefix=property.get('binding').split('_')[0];
								         propertyBinding=property.get('binding');
								       }
										var propertySymbolicName = solutionPrefix + '_' + propertyName;
										//added by rahul
										var _propSymbName = propertyName;
										//if(property.get('binding') === propertySymbolicName  || property.get('binding') === _propSymbName){
										if(propertyBinding === propertySymbolicName  || propertyBinding === _propSymbName){
											property.domNode.style.display = 'block';
											//property.resize && property.resize();
											setTimeout(lang.hitch(this, function() {
					                             property.resize && property.resize();
				                              }, 200));
										}
									}});
								}
							}));
							
							if(!_this.pgwidget) {
								query(".ewfActivityPanel").forEach(function(node, index) {
									_this.pgwidget = registry.byId(node.id);
								});
							}
							_this.pgwidget && _this.pgwidget.activityList && _this.pgwidget.activityList.activityListGrid && _this.pgwidget.activityList.activityListGrid.resize(); */
		},
	//End block by sravanthi for July QR Request-48261.
	
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			array.forEach(this.chkBoxWidgets, lang.hitch(this, function(widget, i){
				widget && widget.set && widget.set("readOnly", this.readOnly);
			}));
			if(this.isDropdown)
			{
			this.selectBox.set("readOnly", this.readOnly);
			}
			
		},
		
		//Done Until here
		_setValueAttr: function(value){
			//Added Condition by sravanthi for July QR Request-48261
		 if(this.isDropdown && this.selectBox)
		 {    
				this.inherited(arguments);
				this.selectBox.set("value",value);
		}
		
		//End by sravanthi.
		else{		  
			if(value === null){
				this.inherited(arguments);
				var defaultCheckedOption = this.checkBoxLogic.defaultChecked;
				var valueToSet = "", chkBoxWdgt;
				if(typeof defaultCheckedOption !== typeof undefined){
					array.forEach(this.chkBoxWidgets, lang.hitch(this, function(chkBox, i){
						if(chkBox && chkBox.sourceKey && (typeof chkBox.sourceKey !== typeof undefined) && (chkBox.sourceKey === defaultCheckedOption)){
							chkBoxWdgt = chkBox;
							valueToSet = chkBox.valueToSet;
						}
					}));
				}
				this.value = valueToSet;
				chkBoxWdgt && chkBoxWdgt.set && chkBoxWdgt.set('checked', true);
			}else if(value && (value.length > 0)){
				array.forEach(this.chkBoxWidgets, lang.hitch(this, function(chkBox, i){
					if(chkBox && chkBox.valueToSet && (chkBox.valueToSet === value)){
						chkBox.set('checked', true);
						this.value = value;
					}
				}));
			}
		}
			this.rerunCallbacks();
		},
		
		_getValueAttr: function(){
		//Added Condition by sravanthi for July QR Request-48261
		if(this.isDropdown && this.selectBox)
		{
		var selectedValue = this.selectedValue;
		console.log("selectedValue:::",selectedValue);
		return selectedValue;
		}
		//End by sravanthi.
		else{
			if(this.chkBoxWidgets.length === 0)
				return this.inherited(arguments);
			
			var valueToReturn = "";
			array.forEach(this.chkBoxWidgets, lang.hitch(this, function(chkBox, i){
				if(chkBox && chkBox.get && chkBox.get('checked'))
					valueToReturn = chkBox.valueToSet;
			}));
			return valueToReturn;
		}
		},
		
		destroy: function(){
			array.forEach(this.chkBoxWidgets, lang.hitch(this, function(widget, i){
				widget && widget.destroyRecursive && widget.destroyRecursive();
				this.disconnect(this.chkBoxWidgetConnects[i]);
			}));
			this.inherited(arguments);
		},
		
		isValid: function(isFocusd){
			return true;
		},

		// Set focus at the first widget when the editor is focused
		focus: function(){
			var children = this.chkBoxWidgets;
			var childFocused = false;
			childFocused = dojo.some(children, function(child){
				return child.focused;
			});
			if(!childFocused && children.length > 0){
				children[0].focus();
			}
		}
		});
	});	