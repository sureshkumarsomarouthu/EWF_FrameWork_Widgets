define([ "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/parser",
         "dojo/query",
         "dojo/dom-class",
         "dojo/dom-style",
         "dojo/dom-construct",
         "idx/form/TextBox",
         "dijit/form/Select",
        // "pvr/widget/editors/TextBoxEditor",
        "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
         "dojo/text!./templates/AdditionalNumbersWidget.html",
         "v11/ewf/widget/dataentry/ContactNumberWidget",
         "ecm/LoggerMixin",
         "v11/ewf/widget/dataentry/SimpleSuggestionList"
       ], function(declare, lang, array, parser, query, domClass, domStyle, domConstruct, TextBox, Select, TextBoxEditor, template, ContactNumber, LoggerMixin, SuggestionListBox){
	return declare("v11.ewf.widget.dataentry.AdditionalNumbersWidget", [TextBoxEditor], {
		
		valueSeparator: '@@@',
		
		width: "100%",

		templateString: template,				
		
		widgetsInTemplate: true,
		
		widgetsCount: 4,
		
		selectWidgets: [],
		
		contactNumberWidgets: [],
		
		widgetConnects: [],
		
		constructor: function(){
			this.selectWidgets = [];
			this.contactNumberWidgets = [];
			this.widgetConnects = [];
		},
		
		postCreate: function(){
			this.inherited(arguments);						
		},		
		
		resize: function(){
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			var selWidget, contactNumberWidget;
			if(this.selectWidgets.length > 0){
				for (var i=0; i<this.selectWidgets.length; i++) {
					selWidget = this.selectWidgets[i];
					selWidget && selWidget.resize && selWidget.resize();
					
					contactNumberWidget = this.contactNumberWidgets[i];
					contactNumberWidget && contactNumberWidget.resize && contactNumberWidget.resize();
					contactNumberWidget.stateNode.style.width='350px';
				}
			}
			
			setTimeout(lang.hitch(this, function(){
				try{
					var widthWOpx = this.stateNode.style.width.split('px')[0];
					domStyle.set(this.stateNode, "width", (widthWOpx*0.99) + 'px');
				}catch(e){}
			}), 100);
		},
						
		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
			this.updateUI();
		},

		updateUI: function(){
			if(this.selectWidgets.length > 1){
				array.forEach(this.selectWidgets, lang.hitch(this, function(widget, i){
					this.widgetConnects[i] && this.disconnect(this.widgetConnects[i]);
					widget && widget.destroyRecursive && widget.destroyRecursive();
					var contactNumberWidget = this.contactNumberWidgets[i];
					contactNumberWidget && contactNumberWidget.destroyRecursive && contactNumberWidget.destroyRecursive();
				}));
				this.selectWidgets = [];
				this.contactNumberWidgets = [];
				this.widgetConnects = [];
			}
			
			for(var i=0; i<this.widgetsCount; i++) {
				/*var selectOptions = [
				                     	{ label: "Home", value: "PH"},
							            { label: "Office", value: "PO"},
							            { label: "Mobile", value: "PM"},
							            { label: "Fax", value: "FX"},
							            { label: "Email", value: "IN"},
							            { label: "Additional", value: "PA"}
							        ];
				var selectBox = new Select({
			        options: selectOptions
			    });*/
				
				var selectBox = new SuggestionListBox({style: "width: 150px;"}, domConstruct.create('div'));
				
				var contactNumber = new ContactNumber({
					invalidMessage: "Invalid Number Entered",
					fieldWidth: "330px",
					style: "width: 330px; display:block;"
				});
				
				var customView = domConstruct.create('div', {style:'display: block;'}, this.additionalNumbersContainer);
				var innerDivForSelectBox = domConstruct.create('div', {style:'width: 160px; display: inline-block;'}, customView);
				var innerDivForTextBox = domConstruct.create('div', {style:'padding-left: 5px; display: inline-block;'}, customView);
				selectBox.startup();
				contactNumber.startup();
				domConstruct.place(selectBox.domNode, innerDivForSelectBox);
				domConstruct.place(contactNumber.domNode, innerDivForTextBox);
				this.selectWidgets.push(selectBox);
				this.contactNumberWidgets.push(contactNumber);
				//var connect = this.connect(contactNumber, "onChange", "onChange");
				//this.widgetConnects.push(connect);
				contactNumber.stateNode.style.width='330px';
				selectBox.resize && selectBox.resize();
			}
			
			this.set("value", this.value);
		},
		
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			
			var selWidget, contactNumberWidget;
			if(this.selectWidgets.length > 0){
				for (var i=0; i<this.selectWidgets.length; i++) {
					selWidget = this.selectWidgets[i];
					selWidget.set("readOnly", this.readOnly);
					
					contactNumberWidget = this.contactNumberWidgets[i];
					contactNumberWidget.set("readOnly", this.readOnly);
				}
			}
		},
		
		_setValueAttr: function(value){
			value = value || "";
			var selWidget, contactNumberWidget;
			if((this.selectWidgets.length == 0) || (value === null)){
				this.inherited(arguments);
				if((this.selectWidgets.length > 0) && value === null){
					array.forEach(this.selectWidgets, lang.hitch(this, function(selectWidget, i){
						var contactNumberWidget = this.contactNumberWidgets[i];
						contactNumberWidget.set("value", null);
					}));
				}
			}else{
				// Make sure that each widget is valid
				var isValid = true;
				
				for (var i=0; i<this.selectWidgets.length; i++) {
					selWidget = this.selectWidgets[i];
					isValid = isValid && (selWidget.state !== "Error");
				}
				
				for (var i=0; i<this.contactNumberWidgets.length; i++) {
					contactNumberWidget = this.contactNumberWidgets[i];
					isValid = isValid && (contactNumberWidget.state !== "Error");
				}
				
				if (isValid === false)
					return;
					
				// Set value for each widget
				var valueArray = value.split(this.valueSeparator), tmpValue;
				for (var i=0; i<this.selectWidgets.length; i++) {
					selWidget = this.selectWidgets[i];
					contactNumberWidget = this.contactNumberWidgets[i];
					tmpValue = valueArray[i];
					if(tmpValue){
						selWidget && selWidget.set && selWidget.set("value", tmpValue.split("|||")[0] || 'PA');
						contactNumberWidget && contactNumberWidget.set && contactNumberWidget.set("value", tmpValue.split("|||")[1] || null);
					}else{
						selWidget && selWidget.set && selWidget.set("value", "PA");
						contactNumberWidget && contactNumberWidget.set && contactNumberWidget.set("value", null);
					}
				}
			}
		},
		
		_getValueAttr: function(){
			if(this.selectWidgets.length == 0)
				return this.inherited(arguments);
			var mergedValue = "", selWidget, contactNumberWidget, value, firstValueAdded = false;
			for(var i=0; i<this.selectWidgets.length; i++){
				value = null;
				contactNumberWidget = this.contactNumberWidgets[i];
				selWidget = this.selectWidgets[i];
				if (contactNumberWidget.state === "Error") {
					return "";
				}
				if (selWidget.state === "Error") {
					return "";
				}
				
				var tmpVal = contactNumberWidget.get("value");
				if(tmpVal)
					value = selWidget.get('value') + '|||' + tmpVal;
				
				if(value){
					if(!firstValueAdded){
						firstValueAdded = true;
						mergedValue +=  value;
					}else{
						mergedValue +=  this.valueSeparator + value;
					}
				}else{
					//Skip. Don't add null value to the final list.
					//The UI will fill in all the null values with valid values (if any) filled in later
				}
			}
			
			return mergedValue;
		},
		
		destroy: function(){
			if(this.selectWidgets.length > 0){
				array.forEach(this.selectWidgets, lang.hitch(this, function(selWidget, i){
					this.widgetConnects[i] && this.disconnect(this.widgetConnects[i]);
					selWidget.destroyRecursive();
					var contactNumberWidget = this.contactNumberWidgets[i];
					contactNumberWidget.destroyRecursive();
				}));
				this.selectWidgets = [];
			}
			this.inherited(arguments);
		},
		
		isValid: function (isFocusd) {
			var valid = this.inherited(arguments); 					
			if (!valid)
				return false;
			for (var i=0; i<this.contactNumberWidgets.length; i++) {
				var contactNumWidget = this.contactNumberWidgets[i];
				if (!contactNumWidget.isValid()){
					return false;
				}
			}
			return true;
		},

		// Set focus at the first textbox when the editor is focused
		focus: function(){
			if(!this.focused && (this.contactNumberWidgets.length > 0)){
				var contactNumWidget = this.contactNumberWidgets[0];
				contactNumWidget.focus && contactNumWidget.focus();
			}
			this.inherited(arguments);
		}
	});
});
