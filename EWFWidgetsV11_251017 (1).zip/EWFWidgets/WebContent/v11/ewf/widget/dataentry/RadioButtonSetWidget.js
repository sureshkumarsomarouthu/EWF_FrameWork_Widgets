define(["dojo/_base/declare",
        "dojo/_base/lang",
        "pvr/widget/editors/RadioButtonSetEditor"]
	,  function (declare, lang, RadioButtonSetEditor){
	
	return declare("v11.ewf.widget.dataentry.RadioButtonSetWidget", [RadioButtonSetEditor], {
		labelAlignment: "horizontal",

		groupAlignment: "horizontal",
		
		options: null,
		
		postMixInProperties: function() {
			this.inherited(arguments);			
		},
		
		postCreate: function(){
			this.inherited(arguments);		
		},
				
		_setOptionsAttr: function(options) {
			this.set("choices", options);
		}
	});
});