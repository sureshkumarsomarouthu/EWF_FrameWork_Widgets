define([ "dojo/_base/declare", 
	"dijit/form/ValidationTextBox",
	"dijit/form/SimpleTextarea",
	"ecm/LoggerMixin"
	], function(declare, ValidationTextBox, SimpleTextarea, LoggerMixin){
	return declare("v11.ewf.widget.dataentry.ValidationTextarea", [ValidationTextBox, SimpleTextarea, LoggerMixin], {
		pattern: '(.|\\s)*',
		postCreate: function() {
			this.inherited(arguments);
		},
		validate: function() {
			if (arguments.length==0) {
				return this.validate(false);
			}
			return this.inherited(arguments);
		},
		onFocus: function() {
			if (!this.isValid()) {
				this.displayMessage(this.getErrorMessage());
			}
		},
		onBlur: function() {
			if (!this.isValid()){ 
			  this.displayMessage(this.getErrorMessage()); 
			} 
		}
	
	});
});
