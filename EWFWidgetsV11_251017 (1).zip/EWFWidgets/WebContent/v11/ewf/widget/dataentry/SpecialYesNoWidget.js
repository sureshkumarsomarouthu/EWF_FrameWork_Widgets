define([ "dojo/_base/declare", 
     	"dojo/dom-class",
      	"icm/util/Util",
      	"v11/ewf/widget/dataentry/CheckBoxListWidget",
	"ecm/LoggerMixin"
	], function(declare, domClass, icmUtil, CheckBoxListWidget, LoggerMixin){
	return declare("v11.ewf.widget.dataentry.SpecialYesNoWidget", [CheckBoxListWidget, LoggerMixin], {
		
		groupAlignment: "horizontal",
		
		multiple: false,
		
		options: [{
				value: 'Y',
				label: 'Yes'
			},{
				value: 'N',
				label: 'No'
			}],
		
		postCreate: function(){
			this.inherited(arguments);
		},
								
		_setRequiredAttr: function(required) {
			this._set("required", required); // Force false.
		}
	
	});
});
