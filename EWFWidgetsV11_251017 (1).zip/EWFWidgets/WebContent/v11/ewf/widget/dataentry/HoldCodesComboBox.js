define([ 
    "dojo/_base/lang",
    "dojo/_base/declare",
    "v11/ewf/widget/dataentry/SimpleSuggestionList",
    "v11/ewf/widget/dataentry/SuggestionListReadStore"
], function(lang, declare, SimpleSuggestionList, SuggestionListReadStore) {
    return declare("v11.ewf.widget.dataentry.HoldCodesComboBox", [SimpleSuggestionList], {
    	postCreate: function(){
	    	this.inherited(arguments);
	        /*var wid = this;
	        var staticStore = new Memory({
	        								data: [
	        								       	{name:"--select--", id:"choose"},
	        								       	{name:"31 TLR OVR TXN", id:"opt1"},
	        								       	{name:"30 COL IRD", id:"opt2"},
	        								       	{name:"Hold Code1", id:"opt3"},
	        								       	{name:"Hold Code2", id:"opt4"}
	        								      ]
	        });
	        wid.set("store",staticStore);
	        wid.set('value', 'choose');*/
	        //if store is static get storeObj from a json file
	        //if store comes from backend, make the call here and get storeObj
	        /*dojo.xhrGet({
	            url: "filenameOrUrl",
	            handleAs: "json"
	        }).then(function(result){
	            var storeObj = new Memory(result);
	            wid.set("store",storeObj);
	        });*/
	    	try{this.dropdownbutton = this._buttonNode.innerHTML;}catch(e){}
			this.pageSize = 10; // Default value is: Infinity
			var store = new SuggestionListReadStore({url: "/v11/ewf/rest/suggest?ref=fehldn", requestMethod: 'get', initStrLength: 0});
			this.set("store", store);
	    }
    });
});