define([
	"dojo/_base/declare",
	"pvr/widget/editors/DateTextBoxEditor",
	"v11/ewf/widget/dataentry/Calendar"
], function(declare, DateTextBoxEditor, ewfCalendar) {
	
	return declare("v11.ewf.widget.dataentry.DateTextBoxWidget", [DateTextBoxEditor], {
		
		editorClass: "ewfDateTextBoxWidget",
		
		popupClass: "v11.ewf.widget.dataentry.Calendar",

		_adjustConstraints: function() {
			this.inherited(arguments);
			if (this.editorReady) {
				var constraints = this.get("constraints");
				if (constraints) {
					if (this.strict == null || this.strict == undefined) {
						this.strict  = true;
					}
					constraints.strict = this.strict;					
				}				
				// Set the constraints.
				this.set("constraints", constraints);				
			}
		},
		
		_setStrictAttr: function(strict){
			this.strict = strict;
		},

		_getStrictAttr: function(){
			return this.strict;
		}		
		
	});
	
});

