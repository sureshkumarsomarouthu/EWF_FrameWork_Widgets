define([ "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/parser",
         "dojo/query",
         "dojo/dom-class",
         "dojo/dom-style",
         "dojo/dom-construct",
         //"idx/form/TextBox",
		 "v11/ewf/idx/form/TextBox",
         "dijit/form/Button",
		"idx/form/CheckBox",		 
        // "pvr/widget/editors/TextBoxEditor",
        "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
		 //"idx/form/NumberTextBox",
		 "v11/ewf/idx/form/NumberTextBox",
         "dojo/text!./templates/CPFStatementWidget.html",
         "ecm/LoggerMixin",
         "dojox/lang/functional",
         "dojo/on",
         "dojo/request",
         "dojo/json",
         "dijit/registry"
	], function(declare, lang, array, parser, query, domClass, domStyle, domConstruct, TextBox, Button, CheckBox, TextBoxEditor, NumberTextBox, template, LoggerMixin, functional, on, request,json, registry){
	return declare("v11.ewf.widget.dataentry.CPFStatementWidget", [TextBoxEditor], {
		
		width: "100%",
		
		templateString: template,				
				
		widgetsInTemplate: true,
		
		textBoxWidget: null,
		
		textBoxWidgetConnect: null,
		
		populateButtonWidget: null,
		
		cpfStatmentValue : null,
		
		participantsControllersMap: null,
		
		tableRenderSuccess: false,
		
		textBoxDate : null,
		
		months : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		
		constructor: function(){
			//console.log("entered into constructor of CPFStatementWidget");
			this.textBoxWidget = null;
			this.textBoxWidgetConnect = null;
			this.populateButtonWidget = null;
		},
		
		postCreate: function(){	
			//console.log("entered into postCreate of CPFStatementWidget");
			this.inherited(arguments);						
		},
			
		resize: function(){
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			if((this.textBoxWidget !== null) && (this.populateButtonWidget!== null)){
				this.textBoxWidget && this.textBoxWidget.resize && this.textBoxWidget.resize();
				this.populateButtonWidget && this.populateButtonWidget.resize && this.populateButtonWidget.resize();
			}
		},
		
		_setNoOfMonthsAttr: function(numberOfMonths){
			//console.log('Display Months->',numberOfMonths);
			var num =  parseInt(numberOfMonths);
			this.noOfMonths = num;
		},
		
		_setPopulateLogicAttr: function(populateLogic){
			//console.log('_setPopulateLogicAttr'); 
			this.populateLogic = populateLogic;
			if(this.textBoxWidget == null){
				this.updateUI();
			}
		},
		
		_setInvalidMessageAttr: function(invalidMessage){
			//console.log('_setInvalidMessageAttr'); 
			this.invalidMessage = invalidMessage;
		},
		
		updateUI: function(){
			//console.log('Update UI');
			var _this = this;
			
			while (this.cpfStatementWdgtContent.hasChildNodes()) {
				this.cpfStatementWdgtContent.removeChild(this.cpfStatementWdgtContent.firstChild);
			}
			
			this.textBoxWidget && this.textBoxWidget.destroyRecursive && this.textBoxWidget.destroyRecursive();
			this.populateButtonWidget && this.populateButtonWidget.destroyRecursive && this.populateButtonWidget.destroyRecursive();
			if(this.textBoxWidgetConnect !== null)
				this.disconnect(this.textBoxWidgetConnect);
			
			this.textBoxWidget = null;
			this.textBoxWidgetConnect = null;
			this.populateButtonWidget = null;
			if(typeof this.readOnly === 'undefined') {
				this.readOnly = false;
			}
			
			this.textBoxWidget = new TextBox({
				labelAlignment: "horizontal",
				label: "",
				hint: this.hint || '',
				hintPosition: this.hintPosition || "inside",
				tooltipPosition: ["above"],
				readOnly: this.readOnly,
				ewficonNode:this.ewficonNode,
				message:this.invalidMessage || '' 
			});
			if(this.codePattern)
				this.textBoxWidget.set('pattern', this.codePattern);
				
			this.cpfStatementWdgtTextBox.appendChild(this.textBoxWidget.domNode);
			
			this.textBoxWidget.startup();
			this.textBoxWidgetConnect = this.connect(this.textBoxWidget, "onChange", this.validateTextBoxWidget);
			
			this.searchButtonWidget = new Button({
		        label: "Populate Date",
		        disabled: this.readOnly,
		        onClick: function(){
		       		if(_this.textBoxWidget != null && _this.textBoxWidget.get('value') != ""){
						_this.setYear();
						if(this.cpfStatmentValue == null)
							_this._buildJsonFormatter();
							
						_this.tableRenderSuccess=false;
			        	_this._displayCPFStatementTable("");
					}else{
						_this.textBoxWidget.set("error","Invalid data");
						_this.textBoxWidget.set("state","Error");
					}
		        }
		    });
			this.cpfStatementWdgtButton.appendChild(this.searchButtonWidget.domNode);
			this.searchButtonWidget.startup();
			
		},
		validateTextBoxWidget: function(){
			if(this.textBoxWidget.state == "Error" || this.readOnly){
				this.searchButtonWidget.set('disabled', true);
			}else{
				if(this.validateDate() && !this.readOnly){
					this.searchButtonWidget.set('disabled', false);
				}else{
					this.searchButtonWidget.set('disabled', true);
				}
			}
		},
		validateDate: function(){
		
			var textBoxValue = this.textBoxWidget.get('value');
			var month = textBoxValue.substring(0,2);
			var tempmonth = "";
			tempmonth = parseInt(month)-1;
			var year = textBoxValue.substring(2,4);
			var twentyCentury = "20"+year;
			var newDate  = new Date(twentyCentury, tempmonth);
			var currentDate = new Date();
			if(newDate>currentDate){
				return false;
			}else{					
				return true;
			}
		},
	
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			this.textBoxWidget && this.textBoxWidget.set && this.textBoxWidget.set('readOnly', this.readOnly);
			this.searchButtonWidget && this.searchButtonWidget.set && this.searchButtonWidget.set('disabled', this.readOnly);
			
			if(this.numberTextBoxSet1 instanceof Array && this.numberTextBoxSet1.length >=1) {
				array.forEach(this.numberTextBoxSet1, function(textBox) {
					textBox.set('readOnly', readOnly);
				});
			}
			if(this.checkBoxSet1 instanceof Array && this.checkBoxSet1.length >=1) {
				array.forEach(this.checkBoxSet1, function(checkBox) {
					checkBox.set('readOnly', readOnly);
				});
			}
		},
		
		_setValueAttr: function(value){
			var isValid = true;
			if((this.textBoxWidget == null) || value === null ){
				if((this.textBoxWidget !== null) && value == null && !(this.textBoxWidget.isValid()))
				this.textBoxWidget.set("value", null);
			} else{
				isValid = isValid && (this.textBoxWidget.state !== "Error");
				if (isValid === false){
					return;
				}
				if(value){
					this.textBoxWidget.set("value", value);
					if(value!=""){
						
						if(this.property && this.property.view && this.participantsConfig && this.participantsConfig != null){
							this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
								var propertyWithoutProvider = property.get('binding').split('.');
								//if(property.get('binding') === this.participantsConfig){
								if(propertyWithoutProvider[1] == this.participantsConfig){
									//console.log("_setValueAttr - propertySymbolicName ->"+property.get('binding'));
									var propertyController = property.controller;
									var cpfvalue = propertyController && propertyController.get('value');
									if(cpfvalue !=null && cpfvalue !="")
									{
										//console.log("Value is present and displaying the table",cpfvalue);
										
											cpfvalue = dojo.fromJson(cpfvalue);
											
										this.cpfStatmentValue = cpfvalue;
										this._displayCPFStatementTable(cpfvalue);
									}
								}
							})}); 
						}
						
					}
				}
				
				
			}
		},
		
		_getValueAttr: function(){
			if(this.textBoxWidget == null)
				return this.inherited(arguments);
			if(this.textBoxWidget.state !== "Error"){
			
				if(this.property && this.property.view && this.participantsConfig && this.participantsConfig != null){
					this.property.view.forEachProperty({callback: lang.hitch(this, function(property, i){
					    var propertyWithoutProvider = property.get('binding').split('.');
						//if(property.get('binding') === this.participantsConfig){
						if(propertyWithoutProvider[1] == this.participantsConfig){
							//console.log("_getValueAttr - propertySymbolicName ->"+property.get('binding'));
							var propertyController = property.controller;
							if(!this.makerIdsPropControl){
								this.makerIdsPropControl = propertyController;
							}
							if(this.cpfStatmentValue && this.cpfStatmentValue!=null && this.cpfStatmentValue.CPFStatement && this.cpfStatmentValue.CPFStatement!=null){
								propertyController && propertyController.set && propertyController.set('value', json.stringify(this.cpfStatmentValue));
								if(propertyController && propertyController.model && propertyController.model.updated)
									propertyController.model.updated= true;
								//console.log(propertyController.get('value'));
							}
						}
					})}); 
				}
				
				return this.textBoxWidget.get("value");
				/*var value = this.textBoxWidget.get("value");
				if(value===""){
					return "";
				}else if(this.cpfStatmentValue!=null){
				  return  json.stringify(this.cpfStatmentValue); 
				}else{
					return value;
				} */
			}
			else
				return "";
		},
		_setCodePatternAttr: function(pattern){
			this.codePattern = pattern;
		},
		_setParticipantsConfigAttr: function(participantsConfig){
			this.participantsConfig = participantsConfig;
		},
		
		_displayCPFStatementTable : function(value){
		
			//console.log('Entered into _displayCPFStatementTable');
			var _this=this;
			
			if(!this.tableRenderSuccess){
			
				while (this.cpfStatementWdgtContent.hasChildNodes()) {
					this.cpfStatementWdgtContent.removeChild(this.cpfStatementWdgtContent.firstChild);
				}
				
				if(value==="")
				{
					value = this.cpfStatmentValue;
				}
				var newDate = this._getNewDate();
				
				var table = dojo.create('table', {'class': 'gridtable', 'style': "width: 60%; height: auto;"});
				var tr1 = dojo.create('tr');
				var tableHeaderValues = _this.populateLogic['headerValues'];
				functional.forIn(functional.keys(tableHeaderValues), function(property){
						var propertyName = tableHeaderValues[property];
						var th1 = dojo.create('th', {innerHTML: propertyName});
						tr1.appendChild(th1);
				});
				table.appendChild(tr1);
				this.numberTextBoxSet1 = [];
				this.checkBoxSet1 = [];
				for(var i=0; i<_this.noOfMonths; i++){
				
					var tr2 = dojo.create('tr', {style: 'height: 5%; width: 100%; border:1px solid #D9D9D9;background-color:#DDF2F9;font-size:11px;'});
					var td1 = dojo.create('td', {innerHTML: _this.months[newDate.getMonth()], style: 'width: 25%; vertical-align: middle; text-align: justify; border-left-color: transparent; '});
					var td2 = dojo.create('td', {innerHTML: newDate.getFullYear(), style: 'width: 25%; vertical-align: middle; text-align: justify; border-left-color: transparent; '});
					var td3 = dojo.create('td', {style: 'width: 25%; vertical-align: middle; text-align: justify; border-left-color: transparent; '});
					var td4 = dojo.create('td', {style: 'width: 25%; vertical-align: middle; text-align: justify; border-left-color: transparent; '});
					
					
					var textBox = new NumberTextBox({style: "display: block;", readOnly: this.readOnly,hintPosition: this.hintPosition || "inside",
				    tooltipPosition: ["above"], ewficonNode:this.ewficonNode});
					this.connect(textBox, "onChange", this.updateJsonNumberTextData);
					textBox.set("value", value.CPFStatement[i].ContribAmount);
			////Below code commented by sravanthi for July-QR Request-48261-5th point removed the BonusIndicator from the table:::::
					//var checkBox = new CheckBox({style: "display: block;", readOnly: this.readOnly});
					//this.connect(checkBox, "onChange", this.updateJsonCheckData);
					//checkBox.set("checked", value.CPFStatement[i].ContribBonus === 'Y' || false);
					
					_this.numberTextBoxSet1.push(textBox);
			//commented by sravanthi
					//_this.checkBoxSet1.push(checkBox);
					
					td3.appendChild(textBox.domNode);
			//commented by sravanthi
					//td4.appendChild(checkBox.domNode);
					tr2.appendChild(td1);
					tr2.appendChild(td2);
					tr2.appendChild(td3);
			//commented by sravanthi
					//tr2.appendChild(td4);
			////End Changes by sravanthi for July-QR Request-48261-5th point removed the BonusIndicator from the table:::::
					
					table.appendChild(tr2);
					newDate.setMonth(newDate.getMonth()+1);
				}
				this.cpfStatementWdgtContent.appendChild(table);
				
				this.tableRenderSuccess = true;
			}
			
			if(!_this.pgwidget) {
				query(".ewfActivityPanel").forEach(function(node, index) {
					_this.pgwidget = registry.byId(node.id);
				});
			}
			_this.pgwidget && _this.pgwidget.activityList && _this.pgwidget.activityList.activityListGrid && _this.pgwidget.activityList.activityListGrid.resize();
			
		
		},
		
		updateJsonCheckData: function(value){
			//console.log("updateJsonCheckData value - > ",value);
			
			dojo.forEach(this.checkBoxSet1, lang.hitch(this, function(checkBox, index){
				value = checkBox.checked === true ? 'Y' : 'N';
				//console.log("value->",value);
				if(typeof this.cpfStatmentValue.CPFStatement[index].ContribBonus != "undefined")
					this.cpfStatmentValue.CPFStatement[index].ContribBonus=value;
			}));
		},
		
		updateJsonNumberTextData: function(value){
			//console.log("updateJsonNumberTextData value - >",value);
			dojo.forEach(this.numberTextBoxSet1, lang.hitch(this, function(numberBox, index){
				value = isNaN(numberBox.getValue()) ? "" : numberBox.value;
				
				if(typeof this.cpfStatmentValue.CPFStatement[index].ContribAmount != "undefined")
					this.cpfStatmentValue.CPFStatement[index].ContribAmount=value;
			}));
			console.log('this.cpfStatmentValue value:',this.cpfStatmentValue);
			this.makerIdsPropControl && this.makerIdsPropControl.set && this.makerIdsPropControl.set('value', json.stringify(this.cpfStatmentValue));
		},

		
		_getNewDate : function(){
			
			this.setYear();
			var textBoxValue = this.textBoxDate;
			var month = textBoxValue.substring(0,2);
			month = parseInt(month);
			var year = textBoxValue.substring(2,6);
			var date = new Date(year+','+month);
			var nd = new Date(date);
			nd.setMonth((nd.getMonth() - this.noOfMonths)+1);
			var newDate = new Date(nd);
			
			return newDate;
		},
		
		setYear : function(){
		
			var textBoxValue = this.textBoxWidget.get('value');
			var month = textBoxValue.substring(0,2);
			var tempmonth = "";
			tempmonth = parseInt(month)-1;
			var year = textBoxValue.substring(2,4);
			var twentyCentury = "20"+year;
			var ninteenCentury = "19"+year;
			var newDate  = new Date(twentyCentury, tempmonth);
			var currentDate = new Date();
			if(newDate>currentDate){
				this.textBoxDate = month+ninteenCentury;
				return false;
			}else{
				this.textBoxDate = month+twentyCentury;
				return true;
			}

		},
		
		_buildJsonFormatter: function(){
		
			//console.log("Entered into _buildJsonFormatter");
			var _this = this;
			if(this.cpfStatmentValue != null){
				this.cpfStatmentValue = null;
				
			}
			var newDate = _this._getNewDate();
			var jsonFormatter={
				CPFStatement: ""
			};
			var tableHeaderValues = _this.populateLogic['headerValues'];
			var cpfStatmentArr = [];
			for(var i=0; i<_this.noOfMonths; i++){
				var items={};	
				functional.forIn(functional.keys(tableHeaderValues), function(property){
					items[property]="";
				});
				items["ContribMonth"] = _this.months[newDate.getMonth()];
				items["ContribYear"] = newDate.getFullYear();
				items["ContribBonus"] = false;
				cpfStatmentArr.push(items);
				newDate.setMonth(newDate.getMonth()+1);
			}
			jsonFormatter.CPFStatement = cpfStatmentArr;
			this.cpfStatmentValue = jsonFormatter;
			//console.log("static json formatter - >", this.cpfStatmentValue);
		},
		
		
		
		destroy: function(){
			this.textBoxWidget && this.textBoxWidget.destroyRecursive && this.textBoxWidget.destroyRecursive();
			this.searchButtonWidget && this.searchButtonWidget.destroyRecursive && this.searchButtonWidget.destroyRecursive();
			
			this.textBoxWidget = null;
			this.searchButtonWidget = null;
			this.numberTextBoxSet1=[];
			this.checkBoxSet1=[];
			this.inherited(arguments);
			this.cpfStatmentValue =null;
			this.textBoxDate = null;
			this.tableRenderSuccess=false;
			this.textBoxWidgetConnect = null;
			
		},
       isValid: function(isFocusd) {
			var numberBox;
			if(this.numberTextBoxSet1 instanceof Array)
			{
			   for(var i=0; i<this.numberTextBoxSet1.length; i++){
				numberBox = this.numberTextBoxSet1[i];
				if(typeof numberBox != 'undefined') {
				if(!numberBox.isValid()) {
					//console.log('invalid value found for dijit:', numberBox);
						return numberBox.isValid();
					}
				}
			   }
			}
			//console.log('All dijits are valid returning true');
			return true;
		}				
		
	});
});
