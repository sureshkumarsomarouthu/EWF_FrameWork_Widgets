define([ "dojo/_base/declare", 
         "dojo/_base/lang",
         "dojo/parser",
     	"dojo/dom-class",
     	"dojo/dom-style",
     	//"idx/form/TextBox",
     	"v11/ewf/idx/form/TextBox",
       // "pvr/widget/editors/TextBoxEditor",
       "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
	"dojo/text!./templates/LinesWidget.html", 
	"ecm/LoggerMixin"
	], function(declare, lang, parser, domClass, domStyle, TextBox, TextBoxEditor, 
			template, LoggerMixin){
	return declare("v11.ewf.widget.dataentry.LinesWidget", [TextBoxEditor], {
		//Used while forming the label for each line
		nameLabel: "Name",
		
		//Define max length for the text of each line
		maxLengthLine: 10,
		
		//Count of line
		lineCount: 2,
		
		//Define the string seperator to combine the values while posting
		valueSeparator: '|||',
		//commented by suresh as part of 5.2.1 upgrade JIRA SIT issue PEWFSGUPGS-167
		//width: "100%",

		templateString: template,				
		widgetsInTemplate: true,
		
		constructor: function(){
			this.lineDijits = [];
		},
		
		postCreate: function(){
			this.inherited(arguments);						
		},		
		
		resize: function(){
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			if(this.lineDijits.length > 0){
				dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDijit){
					lineDijit.resize();
				}));
			}
		},
						
		_setLineCountAttr: function(lineCount) {			
			this.lineCount = lineCount;
			if(this.lineDijits.length === 0 || this.lineDijits.length != lineCount){
				this.updateLinesUI();
			}
		},
		
		_setNameLabelAttr: function(nameLabel) {
			this.nameLabel = nameLabel;
			
			if(this.lineDijits.length > 0){
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					lineDijit.set("label", this.nameLabel + " " + (i+1));
				}
			}
		},
		
		_setMaxLengthLineAttr : function(maxLengthLine) {
			this.maxLengthLine = maxLengthLine;
			
			if(this.lineDijits.length > 0){
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					lineDijit.set("maxLength", this.maxLengthLine);
				}
			}
		},
		
		_setLinePatternAttr : function(linePattern) {
			this.linePattern = linePattern;
			
			if(this.lineDijits.length > 0){
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					lineDijit.set("pattern", this.linePattern);
				}
			}
		},
		
		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
			
			if(this.lineDijits.length > 0){
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					lineDijit.set("invalidMessage", this.invalidMessage);
				}
			}
		},

		//Added by Purna - for UPPER conversion for DE during E2E development
		_setEditorArgsAttr: function(editorArgs) {
			this.editorArgs = editorArgs;
			
			if(this.lineDijits.length > 0){
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					lineDijit.set("requiredCase", (this.editorArgs.requiredCase ? this.editorArgs.requiredCase : "normal"));
					lineDijit.set("uppercase", (this.editorArgs.uppercase ? this.editorArgs.uppercase : false));
				}
			}
		},
		//End
		
		updateLinesUI: function(){
			if(this.lineDijits.length > 1){
				dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDijit, i){
					this.disconnect(this.lineDijitsConnect[i]);
					lineDijit.destroyRecursive();
				}));
				this.lineDijits = [];
			}
			for (var i = 0; i < this.lineCount; i ++) {       
				var lineDijit = new TextBox({
					labelAlignment: "horizontal",
					label: this.nameLabel + " " + (i+1),
					hint: this.hint || '',
					hintPosition: this.hintPosition || "inside",
					tooltipPosition: ["above"],
					ewficonNode:this.ewficonNode,
					readOnly: this.readOnly,					
					style: "width:100%; display:block;",
					
					//Added by Purna - for UPPER conversion for DE during E2E development
					requiredCase: (this.editorArgs && this.editorArgs.requiredCase) ? this.editorArgs.requiredCase : "normal",
					uppercase: (this.editorArgs && this.editorArgs.uppercase) ? this.editorArgs.uppercase : false
					//End
					
				});
				
				if(this.linePattern){
					lineDijit.set('pattern', this.linePattern);
				}
				if(this.invalidMessage){
					lineDijit.set('invalidMessage', this.invalidMessage);
				}
				
				this.lineDijits.push(lineDijit);
				
				this.linesContainer.appendChild(lineDijit.domNode);
				
				lineDijit.startup();				
				
				this.lineDijitsConnect = [];
				dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDijit){
					var connect = this.connect(lineDijit, "onChange", "onChange");
					this.lineDijitsConnect.push(connect);
				}));
			}
			
			this.set("value", this.value);
		},
		
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			
			if(this.lineDijits.length > 0){
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					lineDijit.set("readOnly", this.readOnly);
				}
			}
		},
		
		_setValueAttr: function(value){
			if(this.lineDijits.length == 0 || value === null){
				this.inherited(arguments);
				if(this.lineDijits.length > 0 && value === null){
					dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDigit, i){
						lineDigit.set("value", null);
					}));
				}
			}else{
				// Make sure that each line dijit is valid
				var isValid = true;
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					isValid = isValid && (lineDijit.state !== "Error");
				}
				if (isValid === false)
					return;
					
				// Set value for each line dijit
				var valueArray = value.split(this.valueSeparator);
				dojo.forEach(valueArray, lang.hitch(this, function(value, i){
					this.lineDijits[i].set("value", value);
				}));
			}
		},
		
		_getValueAttr: function(){
			if(this.lineDijits.length == 0)
				return this.inherited(arguments);
			var mergedValue = "", lineDijit, value;
			for (var i = 0; i < this.lineDijits.length; i ++) {
				lineDijit = this.lineDijits[i];
				if (lineDijit.state === "Error") {
					//this.set("state", "Error");
					//return "";
					return;
				}
				value = lineDijit.get("value");
				if(value && value !== ''){
					if( i == 0){
						mergedValue +=  value;
					}else{
						mergedValue +=  this.valueSeparator + value;
					}
				}
			}
			return mergedValue;
		},
		
		destroy: function(){
			if(this.lineDijits.length > 0){
				dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDijit, i){
					this.disconnect(this.lineDijitsConnect[i]);
					lineDijit.destroyRecursive();
				}));
				this.lineDijits = [];
			}
			this.inherited(arguments);
		},
		
		isValid: function (isFocusd) 
		{
			if(this && this.get("value"))
			{
				var valid = this.inherited(arguments); 					
				if (!valid)
					return false;
				var lineDijit;
				for (var i = 0; i < this.lineDijits.length; i ++) 
				{
					lineDijit = this.lineDijits[i];
					if (lineDijit.state === "Error") 
					{
						return false;
					}
				}
				return true;
			}
			else
			{
			
			  return true;
			}
		},

		// Set focus at the first line when the editor is focused
		focus: function () {
			if (!this.focused && this.lineDijits.length > 0) {
				this.lineDijits[0].focus();
			}
			this.inherited(arguments);
		}
		
	});
});
