define([ "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/parser",
         "dojo/query",
         "dojo/dom-class",
         "dojo/dom-style",
         "dojo/dom-construct",
         "idx/form/TextBox",
        // "pvr/widget/editors/TextBoxEditor",
        "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
         "ecm/LoggerMixin"
       ], function(declare, lang, array, parser, query, domClass, domStyle, domConstruct, TextBox, TextBoxEditor, LoggerMixin){
	return declare("v11.ewf.widget.dataentry.ContactNumberWidget", [TextBoxEditor], {
		
		valueSeparator: '-',
		
		width: "100%",
		
		constructor: function(){
		},
		
		postCreate: function(){
			this.inherited(arguments);
			console.log('Test');
		},		
		
		_setValueAttr: function(value){
			if(value && ((value+'').length > 0) && (value.indexOf('-')>-1)){
				value = value.replace(new RegExp('-', 'g'), '');
				this.value = value;
				this.inherited(arguments);
			}else
				this.inherited(arguments);
		},
		
		_getValueAttr: function(){
			var valueToReturn = this.inherited(arguments);
			if(valueToReturn && ((valueToReturn+'').length > 0) && (valueToReturn.indexOf(this.valueSeparator) < 0)){
				var finalValue = valueToReturn.substr(0, 3) + this.valueSeparator + valueToReturn.substr(3, 3) + this.valueSeparator + valueToReturn.substr(6);
				return finalValue;
			}else 
				return this.inherited(arguments);
		},
		
		destroy: function(){
			this.inherited(arguments);
		},
		
		isValid: function(isFocusd) {
			return this.inherited(arguments);;
		},

		focus: function(){
			this.inherited(arguments);
		}
	});
});
