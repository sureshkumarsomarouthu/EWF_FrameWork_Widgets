define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"idx/html",
	"dojo/dom-class",
	"dojo/dom-construct",
	"dojo/when",
	"pvr/widget/editors/formatters/Formatter",
	"dojo/i18n!pvr/nls/common"
], function(declare, lang, html, domClass, domConstruct, when, Formatter, resources) {
	
	/**
	 * EditorAssistedFormatter uses the assistance of the Property object's
	 * editor to obtain the formatted content. The formatted content is
	 * obtained by retrieving the editor's "displayedValue" attribute value
	 * and is therefore consistent with the rendering of the content in the
	 * editor widget.
	 * 
	 * EditorAssistedFormatter object can be used for any editor class that
	 * supports the "displayedValue" attribute.
	 */
	return declare("v11.ewf.widget.dataentry.SugestionListBoxFormatter", Formatter, {
		
		postCreate: function() {
			this.inherited(arguments);
			var editorClass = require(this.property.editorConfig.editor);
			this.editorWidget = new editorClass(this.property._computeEditorParams(), domConstruct.create("div")); // Some editors require a srcRefNode.
			this.connect(this.editorWidget, "_setValueAttr", "showContent");
			this.formatValue();
		},
		
		destroy: function() {
			this.editorWidget.destroyRecursive();
			this.inherited(arguments);
		},
		
		showContent: function(){			
			this.formattedValue = this.editorWidget && this.editorWidget.get("displayedValue") || this.value;
			this.contentNode.innerHTML = html.escapeHTML(this.formattedValue || resources.common.noValue);
			domClass.toggle(this.contentNode, this.editorClass + "Empty", !this.formattedValue);
			domClass.toggle(this.contentNode, this.editorClass + "Number", typeof(this.value) === "number");
		},
		
		formatValue: function() {
			this.editorWidget && this.computeFormattedValue();
		},
		
		computeFormattedValue: function() {
			this.editorWidget.set("normalizedValue", this.value);
			this.editorWidget.validate();
		}
		
	});
	
});

