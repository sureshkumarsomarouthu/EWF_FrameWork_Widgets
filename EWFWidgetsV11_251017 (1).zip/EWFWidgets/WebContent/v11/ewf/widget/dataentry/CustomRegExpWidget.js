define([ "dojo/_base/declare", 
	//"pvr/widget/editors/TextBoxEditor",
	"v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
	"ecm/LoggerMixin",
	"dojox/lang/functional"

	], function(declare, TextBoxEditor,  LoggerMixin, functional){
	return declare("v11.ewf.widget.dataentry.CustomRegExpWidget", [TextBoxEditor,  LoggerMixin], {
	
		instantValidate: false,
		
		validate: function(/*Boolean*/ isFocused){
		
			this.inherited(arguments);
			if(this.state==""){
				var _this = this;
				var value = this.get("value");
				if(this.populateLogic!= null && value != ""){
					var methods = this.populateLogic['methods'];
					functional.forIn(functional.keys(methods), function(property){

						var valueState = "";
						var validateNumber=methods[property];
						if(property === "multiplesOfNumber")
							valueState = _this._getmultiplesOfNumber(parseInt(value), parseInt(validateNumber));

						if(valueState === "Error"){
						    _this.set("message","Key in the Preset Credit Limit in multiples of S$500.");
							_this.set("state","Error");
							return;
							//_this.set("error", "Value entered is not valid");
							//_this.set("message",_this.populateLogic['invalidMessage']);
							// return false;
						}else{
						     return true;
						}
					});

				}
			}
			
		},
		postCreate : function(){
		    this.inherited(arguments);
			console.log('entered into post create start');
			//dojo.connect(this.textbox, "onkeyup",  lang.hitch(this, this._onKeyUp));
			//this.connect(this.textbox, "onchange", lang.hitch(this, this._onKeyUp));
			console.log('entered into post create stop');
		},
		_onKeyUp: function(){
		
			this.inherited(arguments);
			var _this = this;
			var value = this.get("value");
			if(this.populateLogic!= null && value != ""){
				var methods = this.populateLogic['methods'];
				functional.forIn(functional.keys(methods), function(property){

					var valueState = "";
					var validateNumber=methods[property];
					if(property === "multiplesOfNumber")
						valueState = _this._getmultiplesOfNumber(parseInt(value), parseInt(validateNumber));

					if(valueState === "Error"){
						this.set("error", "Value entered is not valid");
					}
				});

			}
		},
		
		_getmultiplesOfNumber: function(value, validateNumber){
			var state = "";
			if(value==0)
				return "Error";
				
			return state = (value %  validateNumber) == 0  ? "" : "Error";
		},
		
		_setCodePatternAttr: function(pattern){
			this.constraints = pattern;
		},
		_setPopulateLogicAttr: function(populateLogic){
			console.log('_setPopulateLogicAttr'); 
			this.populateLogic = populateLogic;
			
		},
		
		_onInput : function(e){
			this.inherited(arguments);
			console.log(' _onInput ', e);
		},
		onkeyup : function(e){
			this.inherited(arguments);
			console.log('onkeyup', e);
		},
		onBlur : function(){
			console.log('blur');
		
		},
		onKeyUp : function(){
			console.log('onKeyUp');
		},
		onkeydown: function(){
			console.log('onkeydown');
		}
		
	});
});

