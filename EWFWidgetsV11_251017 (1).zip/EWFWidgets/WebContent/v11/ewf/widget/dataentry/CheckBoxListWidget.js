define([ "dojo/_base/declare", 
         "dojo/_base/lang",
         "dojo/_base/array",
      	"dojo/dom-class",
      	"icm/util/Util",
     	"idx/form/CheckBoxList",
		"dojo/dom-attr",
	"ecm/LoggerMixin",
	//"pvr/widget/editors/mixins/_EditorMixin",
	"v11/ewf/model/properties/pvr/widget/editors/mixins/_EditorMixin",
	"pvr/widget/editors/mixins/_WidthMixin"
	], function(declare, lang, array, domClass, icmUtil, CheckBoxList, domAttr, LoggerMixin, _EditorMixin, _WidthMixin){
	return declare("v11.ewf.widget.dataentry.CheckBoxListWidget", [CheckBoxList, LoggerMixin,
	                                 	                      _EditorMixin,  _WidthMixin], {
		groupAlignment: "vertical",
		
		postCreate: function(){
			this.inherited(arguments);
			
			this._initializeEditorMixin && this._initializeEditorMixin();
			this._initializeWidthMixin && this._initializeWidthMixin();
			
			domClass.add(this.domNode, "ewfEditor ewfCheckBoxListEditor");
		},
		
		//Inherited compare _FormWidgetMixin.js, add compare logic when multiple is false
		compare: function( val1, val2){			
			if(!icmUtil.areEqual(val1, val2)){
				return 1;
			}else{
				return this.inherited(arguments);
			}
		},
		
		_setMultipleAttr: function(value){
			this.multiple = value;
		},
		
		_setNormalizedValueAttr: function(value){
			if( !icmUtil.areEqual(value, this.value) ){
				this.set("value", value);				
			}
		},
				
		_setErrorAttr: function(error){
		},

		focus: function(){
			var children = this.getChildren();
			var childFocused = false;
			childFocused = dojo.some(children, function(child){
				return child.focused;
			});
			if(!childFocused && children.length > 0){
				children[0].focus();
			}
		},
		_updateSelection:function(){
			console.log("Entered into _updateSelection");
			this._set("value", this._getValueFromOpts());
            var val = this.value;
            if (!lang.isArray(val)) {
                val = [val];
            }
            if (val && val[0]) {
                array.forEach(this._getChildren(), function (child) {
                    var isSelected = array.some(val, function (v) {
                        return child.option && (v === child.option.value);
                    });
                    domClass.toggle(child.domNode, this.baseClass.replace(/\s+|$/g, "SelectedOption "), isSelected);
                }, this);
            }
            domAttr.set(this.valueNode, "value", this.value);
            array.forEach(this._getChildren(), function (item) {
                item && item._updateBox && item._updateBox();
            });
		}
	});
});
