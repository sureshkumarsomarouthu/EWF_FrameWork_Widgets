define(["dojo/_base/declare",
		"dojo/_base/lang",
		"dojo/dom-style",
		"dojo/request",
		"dojo/_base/array",
		"dojo/_base/Deferred",
		'dojox/lang/functional',
		//"pvr/widget/editors/TextBoxEditor",
		"v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
		"dojo/text!./templates/PostalCodeLookupWidget.html",
		"dijit/_TemplatedMixin",
		"icm/base/_BaseWidget",
		"dijit/layout/ContentPane",
		"dijit/TitlePane",
		"dijit/form/Button",
		"dijit/form/TextBox",
		"dijit/form/CheckBox",
		"dojo/on",
		"dojox/widget/Standby",
		"dojo/request"
	], function(declare, lang, domStyle, ajaxRequest, array, Deferred, functional, TextBoxEditor, template, _TemplatedMixin, 
			_BaseWidget, ContentPane, TitlePane, Button, TextBox, CheckBox, on, Standby, request){
	
	return declare("v11.ewf.widget.dataentry.PostalCodeLookupWidget", [_BaseWidget, _TemplatedMixin, TextBoxEditor], {
		
		templateString: template,				
		
		widgetsInTemplate: true,
		
		isLoadingPostalCode: false,
		
		localAddressWidgets: [],
		
		foreignAddressWidgets: [],
		
		constructor: function(){
			
		},
		
		createStandBy: function(){
			var targetNode = this.postalCodeLookup.id;
			this.standByWidget = new Standby({target: targetNode});
			document.body.appendChild(this.standByWidget.domNode);
			this.standByWidget.startup();
		},
		
		getLocalAddressWidgetsWhileProcessing: function(){
			this.localAddressWidgets = [];
			this.foreignAddressWidgets = [];
			var returnArray = [];
			returnArray.push(this.careOfNameLocal);
			returnArray.push(this.unitNoLocal1);
			returnArray.push(this.unitNoLocal2);
			returnArray.push(this.blkNoLocal);
			returnArray.push(this.streetNameLocal);
			returnArray.push(this.bldgNameLocal);
			returnArray.push(this.poBoxNoLocal);
			return returnArray;
		},
		
		gatherLocalAndForeignAddressWidgets: function(){
			this.localAddressWidgets = [];
			this.foreignAddressWidgets = [];
			this.localAddressWidgets.push(this.postalCodeLocal);
			this.localAddressWidgets.push(this.careOfNameLocal);
			this.localAddressWidgets.push(this.unitNoLocal1);
			this.localAddressWidgets.push(this.unitNoLocal2);
			this.localAddressWidgets.push(this.blkNoLocal);
			this.localAddressWidgets.push(this.streetNameLocal);
			this.localAddressWidgets.push(this.bldgNameLocal);
			this.localAddressWidgets.push(this.poBoxNoLocal);
			this.localAddressWidgets.push(this.cityLocal);
			this.localAddressWidgets.push(this.countryLocal);
			
			this.foreignAddressWidgets.push(this.postalCodeForeign);
			this.foreignAddressWidgets.push(this.careOfNameForeign);
			this.foreignAddressWidgets.push(this.addressLine1Foreign);
			this.foreignAddressWidgets.push(this.addressLine2Foreign);
			this.foreignAddressWidgets.push(this.addressLine3Foreign);
			this.foreignAddressWidgets.push(this.addressLine4Foreign);
			this.foreignAddressWidgets.push(this.cityForeign);
			this.foreignAddressWidgets.push(this.countryForeign);
			
		},
		
		postCreate: function(){
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			this.gatherLocalAndForeignAddressWidgets();
			this.registerConnects();
			this.createStandBy();
			this.resetUI();
		},		
		
		resize: function(){
			this.inherited(arguments);
			this.postalCodeLookup.resize();
			domStyle.set(this.stateNode, "border", "none");
			/*array.forEach(this.localAddressWidgets, lang.hitch(this, function(widget){
				widget.resize();
			}));
			array.forEach(this.foreignAddressWidgets, lang.hitch(this, function(widget){
				widget.resize();
			}));*/
		},
						
		_setPostalCodeLengthAttr: function(postalCodeLength) {			
			this.resetUI();
		},
		
		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
		},

		resetUI: function(){
			if(!this.addressTypeLocal.get("checked")){
				this.addressTypeLocal.set("checked", true);
				this.prefillCityAndCountry();
			}
			/*if(this.lineDijits.length > 1){
				dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDijit, i){
					this.disconnect(this.lineDijitsConnect[i]);
					lineDijit.destroyRecursive();
				}));
				this.lineDijits = [];
			}
			for (var i = 0; i < this.lineCount; i ++) {       
				var lineDijit = new TextBox({
					labelAlignment: "horizontal",
					label: this.nameLabel + " " + (i+1),
					hint: this.hint || '',
					hintPosition: this.hintPosition || "inside",
					readOnly: this.readOnly,					
					style: "width:100%; display:block;"
				});
				
				if(this.linePattern){
					lineDijit.set('pattern', this.linePattern);
				}
				if(this.invalidMessage){
					lineDijit.set('invalidMessage', this.invalidMessage);
				}
				
				this.lineDijits.push(lineDijit);
				
				this.linesContainer.appendChild(lineDijit.domNode);
				
				lineDijit.startup();				
				
				this.lineDijitsConnect = [];
				dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDijit){
					var connect = this.connect(lineDijit, "onChange", "onChange");
					this.lineDijitsConnect.push(connect);
				}));
			}*/
			
			this.set("value", this.value);
		},
		
		resetAllTextFields: function(){
			array.forEach(this.localAddressWidgets, function(widget){
				try{
					if(widget && widget.reset)
						widget.reset();
				}catch(e){}
			});
			array.forEach(this.foreignAddressWidgets, function(widget){
				try{
					if(widget && widget.reset)
						widget.reset();
				}catch(e){}
			});
		},
		
		prefillCityAndCountry: function(){
			this.cityLocal.set('value', 'Singapore');
			this.countryLocal.set('value', 'Singapore');
		},
		
		//This method is called only the first time the widget is instantiated. 
		registerConnects: function(){
			on(this.addressTypeLocal, 'change', lang.hitch(this, function(isChecked){
				this.resetAllTextFields();
				if(isChecked){
					if(this.addressTypeForeign.get("checked"))
						this.addressTypeForeign.set("checked", false);
					this.localTable.style.display="";
					this.foreignTable.style.display="none";
					this.prefillCityAndCountry();
				}else{
					if(!this.addressTypeForeign.get("checked"))
						this.addressTypeForeign.set("checked", true);
					this.localTable.style.display="none";
					this.foreignTable.style.display="";
				}
			}));
			
			on(this.addressTypeForeign, 'change', lang.hitch(this, function(isChecked){
				this.resetAllTextFields();
				if(isChecked){
					this.localTable.style.display="none";
					this.foreignTable.style.display="";
					if(this.addressTypeLocal.get("checked"))
						this.addressTypeLocal.set("checked", false);
				}else{
					this.localTable.style.display="";
					this.foreignTable.style.display="none";
					if(!this.addressTypeLocal.get("checked"))
						this.addressTypeLocal.set("checked", true);
					this.prefillCityAndCountry();
				}
			}));
			
			on(this.postalCodeValidateBtn, 'click', lang.hitch(this, function(){
				this.postalCodeValidateResponse.innerHTML='';
				request.get("/EWFWidgets/ewf/widget/dataentry/mock/SingpostData.json", {
					handleAs: 'text'
					}).then(lang.hitch(this, function(data){
					var valueFound = false;
					array.forEach(dojo.fromJson(data), lang.hitch(this, function(item){
						if(item.code === this.postalCodeLocal.get('value')){
							this.blkNoLocal.set('value', item.blkNo);
							this.streetNameLocal.set('value', item.street);
							this.bldgNameLocal.set('value', item.bldg);
							this.poBoxNoLocal.set('value', item.pobox);
							valueFound = true;
						}
					}));
					if(valueFound){
						this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #097326; font-style: italic; font-weight: bold; text-decoration: underline;">Address Details below are updated from Singpost DB</span>';
					}else{
						this.postalCodeValidateResponse.innerHTML = '<span style="font-size: 10px; color: #8E0909; font-style: italic; font-weight: bold; text-decoration: underline;">**Invalid Postal Code. Please enter details manually.</span>';
					}
					this.standByWidget.hide();
				}), lang.hitch(this, function(err){
					this.standByWidget.hide();
				}), lang.hitch(this, function(evt){
					this.standByWidget.show();
					array.forEach(this.getLocalAddressWidgetsWhileProcessing(), lang.hitch(this, function(widget){
						if(widget && widget.reset)
							widget.reset();
					}));
				}));
			}));
			this.prefillCityAndCountry();
		},
		
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
		},
		
		_setValueAttr: function(value){
			/*if(this.lineDijits.length == 0 || value === null){
				this.inherited(arguments);
				if(this.lineDijits.length > 0 && value === null){
					dojo.forEach(this.lineDijits, lang.hitch(this, function(lineDigit, i){
						lineDigit.set("value", null);
					}));
				}
			}else{
				// Make sure that each line dijit is valid
				var isValid = true;
				for (var i = 0; i < this.lineDijits.length; i ++) {
					lineDijit = this.lineDijits[i];
					isValid = isValid && (lineDijit.state !== "Error");
				}
				if (isValid === false)
					return;
					
				// Set value for each line dijit
				var valueArray = value.split(this.valueSeparator);
				dojo.forEach(valueArray, lang.hitch(this, function(value, i){
					this.lineDijits[i].set("value", value);
				}));
			}*/
			this.inherited(arguments);
		},
		
		_getValueAttr: function(){
			/*if(this.lineDijits.length == 0)
				return this.inherited(arguments);
			var mergedValue = "", lineDijit, value;
			for (var i = 0; i < this.lineDijits.length; i ++) {
				lineDijit = this.lineDijits[i];
				if (lineDijit.state === "Error") {
					//this.set("state", "Error");
					return "";
				}
				value = lineDijit.get("value");
				if(value && value !== ''){
					if( i == 0){
						mergedValue +=  value;
					}else{
						mergedValue +=  this.valueSeparator + value;
					}
				}
			}
			return mergedValue;*/
			return this.inherited(arguments);
		},
		
		destroy: function(){
			this.inherited(arguments);
			this.standByWidget.destroy();
		},
		
		isValid: function (isFocusd) {
			return this.inherited(arguments);
			/*var valid = this.inherited(arguments); 					
			if (!valid)
				return false;
			var lineDijit;
			for (var i = 0; i < this.lineDijits.length; i ++) {
				lineDijit = this.lineDijits[i];
				if (lineDijit.state === "Error") {
					return false;
				}
			}
			return true;*/
		},

		// Set focus at the first textbox when the editor is focused
		focus: function() {
			if(!this.focused){
				this.postalCodeLocal.focus();
			}
			this.inherited(arguments);
		}
	});
});