define([
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/_base/array",
        "dojox/data/QueryReadStore"
], function(declare, lang, baseArray, QueryReadStore, Memory) {
    return declare("v11.ewf.widget.dataentry.SuggestionListReadStore", [QueryReadStore], {
		searchQueryStr: null,
		initStrLength: 2,
		fetch: function(request){
			var _this = this;
			if(!(request && request.hasOwnProperty('query') && request.query.hasOwnProperty('count')))
				request.query.count = 1;
			if(request && request.hasOwnProperty('query') && request.query.hasOwnProperty('name'))
				_this.searchQueryStr = request.query.name;
			if(_this.searchQueryStr && (_this.searchQueryStr.length >= this.initStrLength))
				return _this.inherited('fetch', arguments);
			else return;
		},
		fetchItemByIdentity: function(keywordArgs){
			var _this = this;
			_this.searchQueryStr = 'fetchItemByIdentity';
			_this.inherited('fetchItemByIdentity', arguments);
		},
		_filterResponse: function(data){
			var _this = this;
			
			//Defect ID: 4343
			var startParam = -1;
			var countParam = 1;
			try{ startParam = _this._lastServerQuery.start; }catch(e){}
			try{ countParam = _this._lastServerQuery.count; }catch(e){}
			//Defect ID: 4343
			
			var dataToReturn = {identity: 'id', identifier: 'id', label: 'label', items: [], numRows: 0};
			if(_this.searchQueryStr && (_this.searchQueryStr.length >= this.initStrLength)){
				baseArray.forEach(data.items, function(item){
					if(item.name && (item.name !== null))
						dataToReturn.items.push({id: item.key, label: item.name, name: item.name});
					//else
					//	dataToReturn.items.push({id: item.key, label: item.key, name: item.key});
				});
				dataToReturn.numRows = data.numRows;
			} else {
				dataToReturn.items = [];
				dataToReturn.numRows = 0;
			}
			
			//Defect ID: 4343
			if(dataToReturn && dataToReturn.numRows > 0){
				if((startParam >= 0) && (countParam > 0)){
					if((dataToReturn.items.length > 0) && (dataToReturn.items.length <= countParam)){
						dataToReturn.numRows = startParam + dataToReturn.items.length;
					} else if(dataToReturn.items.length > 0){
						dataToReturn.numRows = startParam + countParam + 1;
					}
				}
			}
			//Defect ID: 4343
			
			return dataToReturn;
		}
	});
});