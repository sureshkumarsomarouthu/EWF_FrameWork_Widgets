define(["dojo/_base/declare", 
	"dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-construct",
    "dojo/parser",
    "dojo/on",
    "dojo/dom-class",
    "dojo/dom-style",
    "idx/form/TextBox",
   // "pvr/widget/editors/TextBoxEditor",
   "v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
    "dojo/text!./templates/AddCardsWidget.html", 
    "ecm/LoggerMixin",
    "v11/ewf/widget/dataentry/ContactNumberWidget",
    "dojox/lang/functional",
    "dijit/form/Button",
    "dojo/query",
    "dojo/Stateful",
	"dijit/registry",
	'dojo/date/locale',
    "dojo/NodeList-dom",
    "dojox/uuid/_base",
    "dojox/uuid/Uuid",
    "dojox/uuid/generateRandomUuid"
], function(declare, lang, baseArray, domConstruct, parser, dojoOn, domClass, domStyle, TextBox, TextBoxEditor, template, 
	LoggerMixin, ContactNumber, functional, Button, query, Stateful, registry, dojoLocale){
	return declare("v11.ewf.widget.dataentry.AddCardsWidget", [TextBoxEditor, Stateful], {
		
		width: "100%",

		templateString: template,
		
		widgetsInTemplate: true,
		
		localDijits: null,
		
		buttonDijits: null,
		
		buttonConnects: null,
		
		localConnects: null,
		
		existingWidgetsInUIMap: null,
		
		participantsConfig: null,
		
		allowNullOrBlankValues: null,
		
		widgetsAdded: null,
		
		isCardsUIRendered: false,
		
		defaultOpen: false,
		
		timePattern: 'T00:00:00Z',
		
		constructor: function(){
			this.localDijits = [];
			this.buttonDijits = [];
			this.buttonConnects = [];
			this.localConnects = [];
			this.existingWidgetsInUIMap = {};
			this.participantsControllersMap = {};
			this.widgetsAdded = 0;
			this.allowNullOrBlankValues = {};
			this.isCardsUIRendered = false;
		},
		
		_widgetsAddedGetter: function(){
			return this.widgetsAdded;
		},
		
		_widgetsAddedSetter: function(value){
			this.widgetsAdded = value;
		},
		
		_getWidgetsAddedAttr: function(){
			return this.widgetsAdded;
		},
		
		_setWidgetsAddedAttr: function(value){
			this.widgetsAdded = value;
		},
		
		postCreate: function(){
			this.inherited(arguments);
			this.updateWidgetUI();
			this.watch("widgetsAdded", lang.hitch(this, function(name, oldVal, newVal){
				setTimeout(lang.hitch(this, function(){
					if(newVal < this.widgetLimit){
						baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
							buttonDijit.set("disabled", this.readOnly);
						}));
					}else{
						baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
							buttonDijit.set("disabled", true);
						}));
					}
				}), 50);
			}));
		},		
		
		resize: function(){
			this.inherited(arguments);
			domStyle.set(this.stateNode, "border", "none");
			if(this.localDijits.length > 0){
				baseArray.forEach(this.localDijits, lang.hitch(this, function(localDijit){
					localDijit && localDijit.resize && localDijit.resize();
				}));
			}
			this.highlightedDivNode.innerHTML = '';
		},
		
		//Set focus at the first line when the editor is focused
		focus: function(){
			try{
				if(!this.focused && (this.buttonDijits.length > 0)){
					for(var i=0; i<this.buttonDijits.length; i++){
						if(this.buttonDijits[i] && this.buttonDijits[i].focus){
							this.buttonDijits[i].focus();
							break;
						}
					}
				}
			}catch(e){console.log('Error occurred while focus ', e);}
			this.inherited(arguments);
		},

		_setParticipantsConfigAttr: function(participantsConfig){
			this.participantsConfig = participantsConfig;
		},
		
		_setAllowNullOrBlankValuesAttr: function(allowNullOrBlankValues){
			this.allowNullOrBlankValues = allowNullOrBlankValues;
		},
		
		_setButtonLabelAttr: function(buttonLabel){
			this.buttonLabel = buttonLabel;
		},
		
		_setWidgetLimitAttr: function(widgetLimit){
			this.widgetLimit = widgetLimit;
		},

		_setInvalidMessageAttr: function(invalidMessage){
			this.invalidMessage = invalidMessage;
		},
		
		_setNoOfColsAttr: function(noOfCols){
			this.noOfCols = noOfCols;
		},
		
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			baseArray.forEach(this.localDijits, function(localDijit){
				localDijit && localDijit.set && localDijit.set("readOnly", readOnly);
			});
			baseArray.forEach(this.buttonDijits, function(button){
				button && button.set && button.set("disabled", readOnly);
			});
			if(readOnly === true){
				query(".idxTooltipDialogCloseIcon", this.columnsContainer).style("display", "none");
			}else{
				query(".idxTooltipDialogCloseIcon", this.columnsContainer).style("display", "");
			}
		},
		
		_setDefaultOpenAttr: function(defaultOpen) {
			this.defaultOpen = defaultOpen;
		},
		
		_setStoreJSONDataAttr: function(storeJSONData) {
			this.storeJSONData = storeJSONData;
			this.renderCardsUI();
		},
		
		addCard: function(cardDetailsJson, focusFirstDigit, cardIndex){
		   
			var _this = this;
			if(this.widgetsAdded >= this.widgetLimit){
				baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
					buttonDijit.set("disabled", true);
				}));
				return;
			}
			var specialHandlingMap = this.allowNullOrBlankValues;
			cardDetailsJson = cardDetailsJson || {};
			var elementsToDelete = [];
			var divElement = dojo.create('div', {'style': "height: auto; display: inline-block; border: 1px solid #ddd; padding: 5px; margin: 5px; position: relative; border-radius: 10px;"});
			var spanElement = domConstruct.toDom('<div class="idxTooltipDialogCloseIcon" role="button" tabindex="-1" aria-label="Close"><div class="idxTooltipDialogCloseText">x</div></div>');
			divElement.appendChild(spanElement);
			divElement.appendChild(dojo.create('br', {}));
			var colCount = 0;
			domStyle.set(spanElement, "top", "-3px");
			domStyle.set(spanElement, "right", "-3px");
			var randomUUID = dojox.uuid.generateRandomUuid();
			this.existingWidgetsInUIMap[randomUUID] = true;
			var firstDigit;
			var table = domConstruct.create('table', {innerHTML: ''}, divElement);
			var tr = domConstruct.create('tr', {innerHTML: ''}, table);
			baseArray.forEach(this.participantsConfig, lang.hitch(this, function(widgetConfig, index) {
				var widgetClass = require(widgetConfig['widgetClass']);
				var widgetType = widgetConfig['type'];
				if(colCount >= this.noOfCols) {
					tr = domConstruct.create('tr', {innerHTML: ''}, table);
					colCount = 0;
				}
				
				//if widget type is group associate all members to the group
				if(widgetType == "widgetGroup" && widgetConfig['members']) {
					table = domConstruct.create('table', {innerHTML: ''});
					tr = domConstruct.create('tr', {innerHTML: ''}, table);
					colCount = 0;
					baseArray.forEach(widgetConfig['members'], lang.hitch(this, function(membersConfig){
						//create all member dijits here
						widgetClass = require(membersConfig['widgetClass']);
						widgetType = membersConfig['type'];
						if(colCount >= this.noOfCols) {
							tr = domConstruct.create('tr', {innerHTML: '', style: 'width: 100%;'}, table);
							colCount = 0;
						}
						domConstruct.create('td', {innerHTML: membersConfig['label'], style: 'width: 130px;'}, tr);
						var editorWidget = this.createWidgetDijit(widgetClass, randomUUID, membersConfig, cardDetailsJson);
						var td = domConstruct.create('td', {innerHTML: ''}, tr);
						td.appendChild(editorWidget.domNode);
						elementsToDelete.push(editorWidget);
						colCount++;
						if(index == 0)
							firstDigit = editorWidget;
					}));
					widgetClass = require(widgetConfig['widgetClass']);
					var groupContainer = new widgetClass({
						title: widgetConfig['label'],
						content: table,
						collapsible: widgetConfig['collapsible']
					});
					groupContainer.startup();
					if(groupContainer.focusNode) {
						domStyle.set(groupContainer.focusNode, {width: "auto", height: "10px"});
					}
					divElement.appendChild(groupContainer.domNode);
					table = domConstruct.create('table', {innerHTML: '', style: "width:100%;"}, divElement);
					tr = domConstruct.create('tr', {innerHTML: '', style: 'width: 100%;'}, table);
				//create individual digits and append to table
				} else {
					var td1 = domConstruct.create('td', {innerHTML: ''}, tr);
					var label = domConstruct.create('label', {innerHTML: widgetConfig['label']}, td1);
					var editorWidget = this.createWidgetDijit(widgetClass, randomUUID, widgetConfig, cardDetailsJson);
					var td = domConstruct.create('td', {innerHTML: ''}, tr);
					td.appendChild(editorWidget.domNode);
					elementsToDelete.push(editorWidget);
					colCount++;
					if(index == 0)
						firstDigit = editorWidget;
					
					if(this.property && this.property.collectionController && widgetConfig['propController'] && typeof cardIndex != 'undefined'){
						var propController = this.property.collectionController.getPropertyController(widgetConfig['propController']);
						var label = '';
						
						if(propController && propController.model && propController.model.failIndexes && propController.model.failureTypes) {
							var failIndexes = propController.model.failIndexes;
							var failureTypes = propController.model.failureTypes;
							
							if(failIndexes instanceof Array && failureTypes instanceof Array && baseArray.indexOf(failIndexes, cardIndex) >= 0
								&& failIndexes.length == failureTypes.length) {
							    var failIndex = baseArray.indexOf(failIndexes, cardIndex);
							    label = failureTypes[failIndex];
							}
						}
						if(propController && propController.model && propController.model.updatedIndexes) {
							var updatedIndexes = propController.model.updatedIndexes;
							if(updatedIndexes instanceof Array && updatedIndexes.indexOf(cardIndex) >= 0) {
								label = "updated";
							}
						}
						
						if(label != '') {
							//Add the failureType label
							dojo.addClass(td1, "ewfHighlighted");
							failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = label;
							td1.appendChild(failureLabel);
						}
					}					
				}
			}));
			
			//Connect close event
			dojoOn(spanElement, 'click', lang.hitch(this, function(uuid){
				if(this.readOnly === false){
					baseArray.forEach(elementsToDelete, lang.hitch(this, function(editor){
						if(this.localDijits.length > 0){
							baseArray.forEach(this.localDijits, lang.hitch(this, function(localDijit, index){
								if(editor && localDijit && (editor.id === localDijit.id))
									delete this.localDijits[index];
							}));
						}
						editor && editor.destroyRecursive && editor.destroyRecursive();
					}));
					domConstruct.empty(divElement);
					domConstruct.destroy(divElement);
					this.set("widgetsAdded", this.get("widgetsAdded") - 1);
					this.localDijits = baseArray.filter(this.localDijits, function(localDijit, index){
						return typeof localDijit != 'undefined' && localDijit != null && localDijit != 'null';
					});
					
					//Added by Purna PETE-359 - When all the elements are deleted set the value to null
					if(this.localDijits && this.localDijits.length == 0) {
						this.value = null;
						baseArray.forEach(this.participantsConfig, lang.hitch(this, function(widgetConfig){
							if(this.property && this.property.collectionController && widgetConfig['propController']){
								var propController = this.property.collectionController.getPropertyController(widgetConfig['propController']);
								if(propController && propController != null) {
									propController.set('value', null);
									propController.set('dirty', true);
								}
							}
						}));
					}
					//End
					
				}
				if(this.widgetsAdded >= this.widgetLimit){
					baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
						buttonDijit.set("disabled", true);
					}));
					return;
				}else{
					baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
						buttonDijit.set("disabled", this.readOnly);
					}));
				}
			}, randomUUID));
			
			this.columnsContainer.appendChild(divElement);
			this.set("widgetsAdded", this.get("widgetsAdded") + 1);
			setTimeout(lang.hitch(this, function(){
				this.property.view.resize();
				var _this = this;
				//Added by Purna during E2E dev - query the activityPanel node and retrieve the ActivityPanel obj.
				//Using the object resize the grid to fix the issue with scrollbars during option change 
				if(!this.pgwidget) {
					query(".ewfActivityPanel").forEach(function(node, index) {
						_this.pgwidget = registry.byId(node.id);
					});
				}
				this.pgwidget && this.pgwidget.activityList && this.pgwidget.activityList.activityListGrid && this.pgwidget.activityList.activityListGrid.resize();
				//End
			}), 50);
			
			//For special handling @ UCOE DE starts here
			if(specialHandlingMap){
				if(this.widgetsAdded && (this.widgetsAdded % 4 === 0)){
					this.columnsContainer.appendChild(domConstruct.create('br'));
				}
			}	
			//For special handling @ UCOE DE ends here
			if(this.widgetsAdded >= this.widgetLimit){
				baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
					buttonDijit.set("disabled", true);
				}));
				return;
			}else{
				baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
					buttonDijit.set("disabled", this.readOnly);
				}));
			}
			
			if(this.widgetsAdded >= this.widgetLimit){
				baseArray.forEach(this.buttonDijits, lang.hitch(this, function(buttonDijit){
					buttonDijit.set("disabled", true);
				}));
				return;
			}
			firstDigit && focusFirstDigit && firstDigit.focus && firstDigit.focus();
		},
		
		createWidgetDijit: function(widgetClass, randomUUID, widgetConfig, cardDetailsJson) {
			var editorWidget;
			if(widgetConfig['widgetClass'] == "idx/form/CheckBox") {
				editorWidget = new widgetClass({
					readOnly: this.readOnly,
					jsonKey: widgetConfig['jsonKey'] || null,
					checked: ((widgetConfig['jsonKey'] && cardDetailsJson[widgetConfig['jsonKey']] == 'Y')  || 
							  (widgetConfig['propController'] && cardDetailsJson[widgetConfig['propController']] == 'Y'))
				});
			} else if(widgetConfig['widgetClass'] == "idx/form/CheckBoxList") {
				editorWidget = new widgetClass({
					readOnly: this.readOnly,
					options: widgetConfig['options'] || null,
					multiple: widgetConfig['multiple'] || false,
					groupAlignment: widgetConfig['alignment'] || "horizontal",
					jsonKey: widgetConfig['jsonKey'] || null
				});
				var value = (widgetConfig['jsonKey'] && cardDetailsJson[widgetConfig['jsonKey']]) ? cardDetailsJson[widgetConfig['jsonKey']] : "";
				value = (value == "" && widgetConfig['propController'] && cardDetailsJson[widgetConfig['propController']]) ? cardDetailsJson[widgetConfig['propController']] : "";
				editorWidget.set("value", value);
			} else if(widgetConfig['widgetClass'] == "idx/form/DateTextBox" || widgetConfig['widgetClass'] == "dijit/form/DateTextBox") {
				editorWidget = new widgetClass({
					readOnly: this.readOnly,
					jsonKey: widgetConfig['jsonKey'] || null,
					showPickerIcon: true,
					constraints: {datePattern: widgetConfig['datePattern'] || "ddMMyyyy", formatLength: "short"}
				});
				var value = (widgetConfig['jsonKey'] && cardDetailsJson[widgetConfig['jsonKey']]) ? cardDetailsJson[widgetConfig['jsonKey']] : "";
				value = (value == "" && widgetConfig['propController'] && cardDetailsJson[widgetConfig['propController']]) ? cardDetailsJson[widgetConfig['propController']] : "";
				if(value != "")
					editorWidget.set("value", value);
			} else {
				editorWidget = new widgetClass({
					width: widgetConfig['fieldWidth'] || '150px',
					hint: this.hint || '',
					hintPosition: this.hintPosition || "inside",
					tooltipPosition: ["above"],
					pattern: widgetConfig['regExp'] || null,
					regExps: widgetConfig['regExps'] || null,
					readOnly: this.readOnly,
					invalidMessage: widgetConfig['invalidMessage'] ||"Invalid Data Provided",
					style: "display:block;",
					ref: widgetConfig['ref'] || null,
					jsonKey: widgetConfig['jsonKey'] || null,
					required: widgetConfig['required'] || false
				}, domConstruct.create('div'));
				if(widgetConfig['jsonKey'] && cardDetailsJson[widgetConfig['jsonKey']]) {
					editorWidget.set("value", cardDetailsJson[widgetConfig['jsonKey']]);
				} else if(widgetConfig['propController'] && cardDetailsJson[widgetConfig['propController']]) {
					editorWidget.set("value", cardDetailsJson[widgetConfig['propController']]);
				}
			}
			
			editorWidget['propertySymbolicNameForMappingBack'] = widgetConfig['propController'];
			editorWidget['uuidCustom'] = randomUUID;
			if(editorWidget.stateNode){
				editorWidget.stateNode.style.width='350px';
				//Comment By Naveen KK: reduced  the width of the check box as per of upgrade.
				if(widgetConfig['widgetClass'] == "idx/form/CheckBox") 
				{
					editorWidget.stateNode.style.width='14px';
				}
			}
				
			this.localDijits.push(editorWidget);
			editorWidget.startup();
			editorWidget && editorWidget.resize && editorWidget.resize();
			
			//Added by Suresh - for UPPER conversion for DE during PLA development
			if(this.editorArgs && this.editorArgs.requiredCase) {
				editorWidget['requiredCase'] = this.editorArgs.requiredCase;
			}
			if(this.editorArgs && this.editorArgs.uppercase) {
				editorWidget['uppercase'] = this.editorArgs.uppercase;
			}
			//End
			
			//dojoOn(editorWidget, "change", lang.hitch(this, "updateChangeVal", widgetConfig['jsonKey'], randomUUID, editorWidget));		
			return editorWidget;
		},
		
		updateChangeVal: function() {
		
		},
		
		updateWidgetUI: function(){
			//Cleanup first
			baseArray.forEach(this.localDijits, function(localDijit){
				localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
			});
			//added by suresh for SIT issue PEWFSGUPGS-215 displaying lable issue
			domStyle.set(this.property._labelWrapperNode, "display", "none");
			this.localDijits = [];
			this.set("widgetsAdded", 0);
			baseArray.forEach(this.localConnects, function(localDijitConnect){
				localDijitConnect && localDijitConnect.remove && localDijitConnect.remove();
			});
			this.localConnects = [];
			
			var button = new Button({'label': this.buttonLabel || "Add", 'disabled': this.readOnly}, this.addButtonNode);
			this.buttonDijits.push(button);
			button.startup();
			var connect = button.on('click', lang.hitch(this, this.addCard, {}, true));
			this.buttonConnects.push(connect);
		},
		
		renderCardsUI: function() {
			if(!this.isCardsUIRendered && typeof this.storeJSONData != 'undefined' && typeof this.value != 'undefined') {
				if(this.value instanceof Array && this.value.length >= 1) {
					if(this.storeJSONData) {
						baseArray.forEach(this.value, lang.hitch(this, function(cardDetails, index) {
							var cardDetailsJson = dojo.fromJson(cardDetails);
							console.log('cardDetailsJson:', cardDetailsJson);
							this.addCard(cardDetailsJson, false, index);
						}));
					} else {
						var participantsValuesMap = {};
						baseArray.forEach(this.participantsConfig, lang.hitch(this, function(widgetConfig){
							if(this.property && this.property.collectionController && widgetConfig['propController']){
								var propSymbolicName = widgetConfig['propController'];
								var propController = this.property.collectionController.getPropertyController(propSymbolicName);
								if(propController && propController != null) {
									participantsValuesMap[propSymbolicName] = propController.get("value");
								} else {
									participantsValuesMap[propSymbolicName] = '';
								}
							}
						}));
						var cardInfo = {};
						baseArray.forEach(this.value, lang.hitch(this, function(val, index) {
							cardInfo = {};
							functional.forIn(functional.keys(participantsValuesMap), lang.hitch(this, function(key) {
								var propValue = participantsValuesMap[key];
								if(propValue && propValue != '' && propValue instanceof Array && propValue.length >= index) {
									cardInfo[key] = (typeof propValue[index] != 'undefined' && propValue[index] != null && 
														propValue[index] != 'null' && propValue[index] != "\u001D\u001D") ? propValue[index] : '';
								} else {
									cardInfo[key] = '';
								}
							}));
							this.addCard(cardInfo, false, index);
						}));
					}
				} else if(this.defaultOpen && this.widgetsAdded <= 0) {
					this.addCard();
				}
				this.isCardsUIRendered = true;
			}
		},
		
		_setValueAttr: function(value){
			console.log(this.isCardsUIRendered, ' inside _setValueAttr:::: ', value);
			this.value = value;
			if(value === null || (value instanceof Array && value.length == 0) || (value instanceof Array && value.length == 1 && value[0] == "")) {
				this.value = [];
			} else {
				this.value = value;
			}
			
			if(!this.storeJSONData) {
				this.storeJSONData = this.property.controller && this.property.controller.model && this.property.controller.model.storeJSONData;
			}
			if(this.value) {
			this.renderCardsUI();
			}
			//Propagate the changed value to controller
			//this.inherited(arguments);
		},
		
		//Added by Suresh - for UPPER conversion for DE during E2E development
		_setEditorArgsAttr: function(editorArgs) {
			this.editorArgs = editorArgs;
			if(this.localDijits.length > 0){
				for (var i = 0; i < this.localDijits.length; i ++) {
					localDijits = this.localDijits[i];
					localDijits.set("requiredCase", (this.editorArgs.requiredCase ? this.editorArgs.requiredCase : "normal"));
					localDijits.set("uppercase", (this.editorArgs.uppercase ? this.editorArgs.uppercase : false));
				}
			}
		},
		
		_getValueAttr: function(){
			console.log('inside _getValueAttr');
			var specialHandlingMap = this.allowNullOrBlankValues;
			var returnValue = this.inherited(arguments);
			
			if((this.localDijits.length == 0) && (this.value !== null)){
			//if(this.localDijits.length == 0){
				return this.value;
			}else if(this.localDijits.length == 0){
				return [];
			}
			
			var cardsInfo = [];
			var cardDetails = {};
			var tempCount = 0;
			var isValid = true;
			var fieldCount = this.localDijits.length/this.widgetsAdded;
			baseArray.forEach(this.localDijits, lang.hitch(this, function(localDijit, index) {
				if(tempCount >= fieldCount) {
					console.log('one card details: ', cardDetails);
					tempCount = 0;
					cardsInfo.push(dojo.toJson(cardDetails));
					cardDetails = {};
				}
				
				if(localDijit && localDijit.isValid()) {
					var val = localDijit.get('value');
					var dijitClass = localDijit.declaredClass;
					//Put the value of Number TextBox in the JSON only if the value is a number
					if(dijitClass.indexOf('NumberTextBox') > -1 && localDijit.jsonKey != null) {
						if(!isNaN(val)) {
							cardDetails[localDijit.jsonKey] = val;
						}
					//Put the value of CheckBox in the JSON only if the checkbox is selected - On
					} else if(dijitClass.indexOf('CheckBox') > -1 && dijitClass.indexOf('CheckBoxList') == -1 && localDijit.jsonKey != null) {
						if(val) {
							cardDetails[localDijit.jsonKey] = (val == "on") ? 'Y' : 'N';
						}
					//Put the value of other fields only if it is not empty -- Add in more if conditions based on future req
					} else if(typeof val != 'undefined' && val != null && val != 'null' && val.length > 0 && localDijit.jsonKey != null) {
						cardDetails[localDijit.jsonKey] =  val;
					}
				} else {
					isValid = false;
					console.log('index: ' + index + ' invalid value found for dijit: ' + localDijit.get('value'), localDijit);
				}
				tempCount++;
			}));
			
			if(!isValid) {
				return [];
			}
			
			if(functional.keys(cardDetails).length > 0) {
				console.log('one card details: ', cardDetails);
				cardsInfo.push(dojo.toJson(cardDetails));
			}
			
			console.log('cardsInfo:', cardsInfo);
			
			var valuesMapGathered = {}, localDijit;
			for(var i=0; i<this.localDijits.length; i++){
				localDijit = this.localDijits[i];
				if(typeof localDijit !== typeof undefined && localDijit['propertySymbolicNameForMappingBack']){
					if(!(valuesMapGathered.hasOwnProperty(localDijit['uuidCustom'])))
						valuesMapGathered[localDijit['uuidCustom']] = {};
					
					var val = localDijit.get('value');
					var dijitClass = localDijit.declaredClass;
					//Put the value of CheckBox as Y/N
					if(dijitClass.indexOf('CheckBox') > -1 && dijitClass.indexOf('CheckBoxList') == -1) {
						val = (val == "on") ? 'Y' : 'N';
					//Put value of datetextbox here
					} else if(dijitClass.indexOf('DateTextBox') > -1) {
						var propSymbolicName = localDijit['propertySymbolicNameForMappingBack'];
						var propController = this.property.collectionController.getPropertyController(propSymbolicName);
						var dataType = (propController && propController.model && propController.model.dataType) ? propController.model.dataType : '';
						
						if(dataType == "xs:string" && val && val != null && typeof val != 'undefined') {
							val = dojoLocale.format(val, {datePattern: 'yyyy-MM-dd', selector: 'date'});
							val = val + this.timePattern;
						}
					}
					valuesMapGathered[localDijit['uuidCustom']][localDijit['propertySymbolicNameForMappingBack']] = val || null;
				}
			}
			console.log('valuesMapGathered:', valuesMapGathered);
			
			//Get all the participants' Property Controllers'
			this.participantsControllersMap = {};
			var participantsMapWithValues = {};
			baseArray.forEach(this.participantsConfig, lang.hitch(this, function(widgetConfig){
				if(this.property && this.property.collectionController && widgetConfig['propController']){
					var propSymbolicName = widgetConfig['propController'];
					var propController = this.property.collectionController.getPropertyController(propSymbolicName);
					if(propController && propController != null) {
						this.participantsControllersMap[propSymbolicName] = propController;
						participantsMapWithValues[propSymbolicName] = [];
						functional.forIn(functional.keys(valuesMapGathered), lang.hitch(this, function(uuid){
							if(specialHandlingMap && specialHandlingMap.hasOwnProperty(propSymbolicName) && (specialHandlingMap[propSymbolicName] === true)){
								if(valuesMapGathered[uuid][propSymbolicName] && ((valuesMapGathered[uuid][propSymbolicName]+'').length>0)){
									participantsMapWithValues[propSymbolicName].push(valuesMapGathered[uuid][propSymbolicName]);
								}
							} else {
								participantsMapWithValues[propSymbolicName].push(valuesMapGathered[uuid][propSymbolicName]);
							}
						}));
						console.log('setting value for the prop:' + propSymbolicName + ' value:' + participantsMapWithValues[propSymbolicName]);
						propController.set('value', participantsMapWithValues[propSymbolicName])
					} else {
						console.log('propController is null. Please make sure the property:' +  propSymbolicName + ' is exposed in the view');
					}
				}
			}));
			
			//If the storeJSONData attr is true return JSON data. otherwise return the data captured for that prop in participantsMapWithValues
			if(this.storeJSONData)
				return cardsInfo;
			else 
				return participantsMapWithValues[this.property.get('binding')];
		},
		
		_setLabelAttr: function(label) {
			//this.compLabelNode.innerHTML = label;
			//domClass.toggle(this.labelWrap, "dijitHidden", /^\s*$/.test(label));
			this._set("label", label);
		},

		destroy: function(){
			//Cleanup first
			baseArray.forEach(this.localDijits, function(localDijit){
				localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
			});
			this.localDijits = [];
			
			baseArray.forEach(this.buttonDijits, function(localDijit){
				localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
			});
			this.buttonDijits = [];
			
			domConstruct.empty(this.columnsContainer);
			
			baseArray.forEach(this.localConnects, function(localDijitConnect){
				localDijitConnect && localDijitConnect.remove && localDijitConnect.remove();
			});
			this.localConnects = [];
			this.set("widgetsAdded", 0);
			this.isCardsUIRendered = false;
			this.participantsControllersMap = {};
			this.inherited(arguments);
		},
		
		isValid: function(isFocusd) {
			var localDijit;
			for(var i=0; i<this.localDijits.length; i++){
				localDijit = this.localDijits[i];
				if(typeof localDijit != 'undefined') {
					if(!localDijit.isValid()) {
						console.log('invalid value found for dijit:', localDijit);
						return localDijit.isValid();
					}
				}
			}
			console.log('All dijits are valid returning true');
			return true;
		}		
	});
});
