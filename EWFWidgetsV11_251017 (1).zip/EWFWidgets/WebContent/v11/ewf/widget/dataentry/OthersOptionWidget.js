define(["dojo/_base/declare", 
	"dojo/query",
	"ecm/LoggerMixin",
	//"pvr/widget/editors/TextBoxEditor",
	"v11/ewf/model/properties/pvr/widget/editors/TextBoxEditor",
	"dojo/dom-construct",
	"dojo/on",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/text!./templates/OthersOptionWidget.html"
], function(declare, query, LoggerMixin, TextBoxEditor, domConstruct, on, lang, Array, template){
	return declare("v11.ewf.widget.dataentry.OthersOptionWidget", [TextBoxEditor], {
		
		templateString: template,
		
		widgetsInTemplate: true,
		
		isUIRendered: false,
		
		constructor: function(){
			this.localDijits = [];
		},
		
		postCreate: function(){
			this.inherited(arguments);
		},
		
		_setConfigurationAttr: function(configuration){
			this.configuration = configuration;
			if(!this.isUIRendered) {
				this.renderUI();
			}
		},
		
		_setOtherFieldConfigAttr: function(otherFieldConfig) {
			this.otherFieldConfig = otherFieldConfig;
			if(!this.isUIRendered) {
				this.renderUI();
			}
		},
		
		_setEnableValueAttr: function(enableValue) {
			this.enableValue = enableValue;
			if(!this.isUIRendered) {
				this.renderUI();
			}
		},
		
		_setValueAttr: function(value){
			this.value = value;
			
			if(this.localDijits.length > 0){
				for(var i = 0; i < this.localDijits.length; i ++) {
					var localDijit = this.localDijits[i];
					if(typeof this.value != 'undefined' && this.value != null && this.value != ''){
						localDijit.set("value", this.value);
					}
					
				}
			}
		},
		
		
		_setReadOnlyAttr: function(readOnly){
			this.readOnly = readOnly;
			
			if(this.localDijits.length > 0){
				for (var i = 0; i < this.localDijits.length; i ++) {
					var localDijit = this.localDijits[i];
					localDijit.set("readOnly", this.readOnly);
				}
			}
		},
		
		_setRequiredAttr: function(required){
			this.required = required;
			
			if(this.localDijits.length > 0){
				for(var i = 0; i < this.localDijits.length; i ++) {
					var localDijit = this.localDijits[i];
					localDijit.set("required", this.required);
				}
			}
		},
		
		_getValueAttr: function() {
			if(this.localDijits.length == 0)
				return this.inherited(arguments);
			//Length is always 1
			for(var i = 0; i < this.localDijits.length; i ++) {
				var localDijit = this.localDijits[i];
				if(localDijit && localDijit.isValid() && localDijit.get("value")) {
					return localDijit.get("value");
				}
			}
			return "";
		},
		
		renderUI: function(){
			if(!this.isUIRendered && this.configuration && this.otherFieldConfig && this.enableValue) {
				if(this.configuration['widgetClass']) {
					var config = this.configuration;
					var widgetClass = require(config['widgetClass']);
					if(typeof this.value === 'undefined' || this.value === null || this.value === '') {
						this.value = this.configuration['defaultValue'];
					}
					var editorDijit = new widgetClass({
						width: config['fieldWidth'] || '150px',
						hint: this.hint || '',
						hintPosition: this.hintPosition || "inside",
						tooltipPosition: ["above"],
						pattern: config['regExp'] || null,
						regExps: config['regExps'] || null,
						readOnly: this.readOnly,
						invalidMessage: config['invalidMessage'] ||"Invalid Data Provided",
						style: "display:block;",
						ref: config['ref'] || null,
						required: this.required || false
					}, domConstruct.create('div'));
					editorDijit.startup();
					this.localDijits.push(editorDijit);
					this.othersContainer.appendChild(editorDijit.domNode);
					if(!this.otherPropController) {
						var otherProp = this.otherFieldConfig['propController'];
						if(this.property.get("binding") != otherProp) {
							this.otherPropController = this.property.collectionController.getPropertyController(otherProp);
							this.otherPropController.set("readOnly", true);
						}
					}
					on(editorDijit, "keyup", lang.hitch(this, "checkAndEnableOtherField"));
					on(editorDijit, "change", lang.hitch(this, "checkAndEnableOtherField"));
					editorDijit.set("value", ((typeof this.value != 'undefined' && this.value != null) ? this.value : ''));
				}
				this.isUIRendered = true;
			}
		},

		isValid: function (isFocusd) {
			if(this.localDijits.length == 0)					
				return true;
			var localDijit;
			for (var i = 0; i < this.localDijits.length; i ++) {
				localDijit = this.localDijits[i];
				if (localDijit.state === "Error") {
					return false;
				}
			}
			return true;
		},
		
		destroy: function(){
			try {
				this.isUIRendered = false;
				if(this.localDijits.length > 0) {
					for (var i = 0; i < this.localDijits.length; i ++) {
						var localDijit = this.localDijits[i];
						localDijit && localDijit.destroyRecursive && localDijit.destroyRecursive();
						delete this.localDijits[i];
					}
				}
			} catch(e){console.log('exception occurred in destroy:', e);}
			this.localDijits = [];
			this.inherited(arguments);
		},
		
		checkAndEnableOtherField: function(value) {
			if(!this.otherPropController) {
				var otherProp = this.otherFieldConfig['propController'];
				if(this.property.get("binding") != otherProp) {
					this.otherPropController = this.property.collectionController.getPropertyController(otherProp);
				}
			}
			
			if(value && value == this.enableValue && this.otherPropController && this.otherPropController != null) {
				this.otherPropController.set("readOnly", false);
			} else if(this.otherPropController && this.otherPropController != null) {
				this.otherPropController.set("readOnly", true);
				this.otherPropController.set("value", null);
			}
		},
		
		// Set focus at the first line when the editor is focused
		focus: function () {
			if (!this.focused && this.localDijits.length > 0) {
				this.localDijits[0].focus();
			}
			this.inherited(arguments);
		}
	});
});
