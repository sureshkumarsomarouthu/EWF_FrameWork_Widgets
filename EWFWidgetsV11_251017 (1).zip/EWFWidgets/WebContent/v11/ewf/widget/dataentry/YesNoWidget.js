define([ "dojo/_base/declare", 
      	"pvr/widget/editors/CheckBoxEditor",
	"dojo/text!./templates/YesNoWidget.html", 
	"ecm/LoggerMixin",
	"dojo/query", 
	"idx/util"
	], function(declare, CheckBoxEditor, template, LoggerMixin, query, iUtil){
	return declare("v11.ewf.widget.dataentry.YesNoWidget", [CheckBoxEditor, LoggerMixin], {
		
		templateString: template,				
		widgetsInTemplate: true,
		
		postCreate: function(){
			this.inherited(arguments);
		},
		
		_setLabelAlignmentAttr: function(labelAlignment){
			this.labelAlignment = labelAlignment;
		},
		
		_setLabelWidthAttr: function(width){
			if(!width){ return; }
			var widthInPx = iUtil.normalizedLength(width);
			query(".idxLabel", this.domNode).style("width", widthInPx + "px");
		},
				
		_setRequiredAttr: function(required) {
			this._set("required", required); // Force false.
		}
	
	});
});
