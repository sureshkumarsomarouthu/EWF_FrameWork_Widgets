define(["dojo/_base/declare",
        //new imports are added by suresh as part of 5.2.1 upgrade
        "dojo/_base/lang",
	    "dojo/_base/array",
	    "dojo/_base/kernel",
	    "dojo/dom-geometry",
	    "dojo/dom-style", 
	    "dojo/string",
	    "dojo/request",
	    "dojo/aspect",
	    "icm/util/Util",
	    "icm/base/BasePageWidget",
		"icm/base/BaseActionContext",
		"icm/model/Message",
		"ecm/widget/dialog/ErrorDialog",
		"pvr/widget/View",
		"dojo/_base/sniff",
		"icm/model/properties/controller/ControllerManager",
		"icm/pgwidget/properties/Properties",
		"icm/widget/properties/registry/Configuration",		
		"pvr/widget/registry/BasicRegistryConfiguration",
		"pvr/widget/registry/Registry",
		"pvr/widget/_Property",
		"v11/ewf/model/properties/ViewConfig",
		"v11/ewf/model/properties/ControllerConfig",
		"dojo/text!./templates/Fields.html"
		]
, function(declare, 
	lang, 
	array, 
	kernel, 
	domGeometry,
	domStyle,
	string, 
	request, 
	aspect,
	util,
	BasePageWidget, 
	BaseActionContext, 
	Message, 
	ErrorDialog,
	View,
	sniff,
	ControllerManager, 
	Properties, 
	icmConfig, 
	standardConfig, 
	Registry, 
	_Property,
	ewfViewConfig, 
	ewfControllerConfig,
	template){
	return declare("v11.ewf.widget.fields.Fields", [Properties], {
		
		templateString: template,
        widgetsInTemplate: true,
		viewMarkup: null,
		viewDefinitionId: null,

	 	constructor: function() {
	 		this.viewMarkup = null;
			this.viewDefinitionId = null;
			this.inherited(arguments);
			console.log("this in constructor : ",this);
			
		},
		
	 	setContext: function(context) {
	 		this.context = context;
		},
		
		/**
		 * Set view markup (HTML template). 
		 * If viewMarkup is not set, a default view would be opened.
		 */
		setViewMarkup: function(viewMarkup) {
			this.viewMarkup = viewMarkup;
		},
		
		/**
		 * Gets the markup to be used for rendering the view.
		 * setMarkup() can be used to set the view markup before this call.
		 * @return The markup.
		 */
		getMarkup: function() {
			if (this.viewMarkup)
				return this.viewMarkup;
			return this.inherited(arguments);
		},
		
		/**
		 * Set view definition id. 
		 * If view definition id is not set, a configured or default view would be opened.
		 */
		setViewDefinitionId: function(viewDefinitionId) {
			this.viewDefinitionId = viewDefinitionId;
		},

		/**
		 * Gets the view definition id for the view to be rendered.
		 * setViewDefinitionId() can be used to set the view definition id before this call.
		 * If the view definition id is not set, a configured or default definition id would be returned.
		 * @return The view definition id.
		 */
		getViewDefinitionId: function() {
			if (this.viewDefinitionId)
				return this.viewDefinitionId;
			return this.inherited(arguments);
		},
							
		handleICM_BeforeCancelEvent: function(context, complete, abort) {
			if (this.context && dojo.isFunction(this.context.handleICM_BeforeCancelEvent)) {
				this.context.handleICM_BeforeCancelEvent(context, complete, abort);
			} else {
				this.inherited(arguments);
			}
		},
		
		handleICM_ValidationEvent: function(context, complete, abort) {
			if (this.context && dojo.isFunction(this.context.handleICM_ValidationEvent)) {
				this.context.handleICM_ValidationEvent(context, complete, abort);
			} else {
				this.inherited(arguments);
			}
		},
		
		bindController: function(editable) {
			var integration = ControllerManager.getIntegration();
			integration.mergeConfiguration(ewfControllerConfig);
			return ControllerManager.bind(editable);
		},
		
		getRegistry: function() {
			var registry = new Registry(console);
			registry.mergeConfiguration(standardConfig);
			registry.mergeConfiguration(icmConfig);
			registry.mergeConfiguration(ewfViewConfig);
			return registry;
		},
		
		focusFirstChild: function() {
		   console.log("call focusFirstChild");
			//var view = this._view;//commented by suresh as part of 5.2.1 upgrade
			var view = this.view;//added by suresh as part of 5.2.1 upgrade
			if (view.properties && view.properties.length > 0) {
				this.focusProperty(view.properties[0]);
			}			
		},
				
		focusProperty: function(property){
		 console.log("call focusProperty");
			try{
				property.getParent().showChild(property);
				if (property.parentContainerType !== "propertyTable") {
					var editor = property.editorWidget;
					if (editor) {
						editor.focus();
						if(sniff('ie') < 9){ // Support IE8
							if (editor.editorClass === "pvrTextBoxEditor" || property.controller.get("type") === "suggestionList") {
								dijit.selectInputText(editor.textbox, 0, 0);
							}
						}
					}
				}
			}catch(e){
				console.error('Error while focusing property --> ', e);
			}
		},
		
		_handleFocus: function(invalidPropertyControllers, invalidProperties) {
			if (invalidProperties.length) {
				this.focusProperty(invalidProperties[0]);
			}
			else {
				this._view.someProperty({
					callback: lang.hitch(this, function(property) {
						this.focusProperty(property);
						return true;
					}),
					filter: function(property) {
						return array.some(invalidPropertyControllers, function(propertyController) {
							return property.get("binding") === propertyController.get("id");
						});
					}
				});
			}
		},
		
		overridePropertyObject: function() {
		
		console.log("===== inside overridePropertyObject method ======");
		lang.extend(_Property, {
		
		_getEditorConfig:function () {
		   
		    if(this.innerEditor != ""){
		      this.innerEditor="";
		    }
            var registry = this.view.registry;
            if (this.editor && registry.isValidEditor(this, this.editor)) {
                return lang.clone(registry.getEditorConfig(this.editor));
            } else {
                return lang.clone(this.innerEditor ? registry.getDefaultMultiEditorConfig() : registry.getDefaultEditorConfig(this));
            }
        }
		});
		},
		//openview method is added by suresh as part of 5.2.1 upgrade
		openView: function(editable, options, callback) {
			// Adjust the arguments to support legacy API.
			console.log("inside openView function : ");
			this.overridePropertyObject();
			if (arguments.length > 1) {
				if (lang.isFunction(options)) {
					callback = options;
					options = {
						readOnly: true
					};
					kernel.deprecated("_Properties.openView()", "Support for these arguments is now deprecated. See the JSDocs for the supported arguments.");
				} else if (typeof options === "boolean") {
					options = {
						readOnly: true,
						applyDefaultValues: options
					};
					kernel.deprecated("_Properties.openView()", "Support for these arguments is now deprecated. See the JSDocs for the supported arguments.");
				}
			}
			options = options || {};
			
			console.log("options : ",options);
			
			// We don't need to open the editable if its already open.
			if (!this.editable || this.editable !== editable) {
				// Close the existing view if necessary.
				this.closeView();
				
				// Cache the model and bind the controller.
				this.editable = editable;
				
				// Prepare the controller.
				this._prepareController(editable, lang.hitch(this, function() {
					// Configure the controller update handler.
					this._updateHandler = aspect.after(this.controller, "onChange", lang.hitch(this, function(changes) {
						this.adjustDirtyState();
						this._broadcastFieldUpdatedEvents(changes);
					}), true);
					
					// Prepare the view definition.
					this._prepareViewDefinition(lang.hitch(this, function(markup, resources) {
						// Render the view from the provided view definition. Otherwise
						// render a system generated view.
						if (markup) {
							this.view = new View(lang.mixin({
								lazyLoad: true,
								markup: markup,
								resources: resources
							}, options));
						}
						else {
							this.view = new View(lang.mixin({
								lazyLoad: true,
								propertyIds: this.getPropertyIds(),
								filter: this.getFilter(),
								comparator: this.getComparator()
							}, options));
						}
						console.log("this in openView of fields.js===== ",this);
						this.viewNode.appendChild(this.view.domNode);
						this.view.startup();
						this.view.bind(this.controller, this.getRegistry(), null, lang.hitch(this, function() {
							// Hide or show the "No properties" node.
							if (!this.view.properties || (this.view.properties && this.view.properties.length <= 0)) {
							    console.log("====no properties display node====");
								this.noPropsNode.innerHTML = util.getResourceBundle("properties").noProperties;
								domStyle.set(this.noPropsNode, "display", "");
								domStyle.set(this.view.domNode, "display", "none");
							}
							else {
							    console.log("======properties are available=====");
								domStyle.set(this.noPropsNode, "display", "none");
								domStyle.set(this.view.domNode, "display", "");
							}
							
							// Add the handlers.
							this._viewHandlers = [];
							this._viewHandlers.push(this.view.watch("state", lang.hitch(this, function(attr, oldValue, newValue) {
								this.adjustDirtyState();
							})));
							this.view.forEachProperty({
								callback: lang.hitch(this, function(property) {
									this._viewHandlers.push(aspect.after(property, "onFocus", lang.hitch(this, function() {
										this._broadcastFieldFocusedEvent(property);
									})));
									this._viewHandlers.push(aspect.after(property, "onBlur", lang.hitch(this, function() {
										this._broadcastFieldBlurredEvent(property);
									})));
									this._viewHandlers.push(aspect.after(property, "onChange", lang.hitch(this, function(value, error) {
										this._broadcastPropertyUpdatedEvent(property, value, error);
									}), true));
								})
							});
							this.view.forEachWidget({
								callback: lang.hitch(this, function(widget) {
									widget.onCellUpdated && this._viewHandlers.push(aspect.after(widget, "onCellUpdated", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellUpdatedEvent(widget, property, row, value, error);
									}), true));
									widget.onCellChange && this._viewHandlers.push(aspect.after(widget, "onCellChange", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellChangedEvent(widget, property, row, value, error);
									}), true));
									widget.onCellAdded && this._viewHandlers.push(aspect.after(widget, "onCellAdded", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellAddedEvent(widget, property, row, value, error);
									}), true));
									widget.onCellInserted && this._viewHandlers.push(aspect.after(widget, "onCellInserted", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellInsertedEvent(widget, property, row, value, error);
									}), true));
									widget.onCellMoved && this._viewHandlers.push(aspect.after(widget, "onCellMoved", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellMovedEvent(widget, property, row, value, error);
									}), true));
									widget.onCellRemoved && this._viewHandlers.push(aspect.after(widget, "onCellRemoved", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellRemovedEvent(widget, property, row, value, error);
									}), true));
									widget.onCellClicked && this._viewHandlers.push(aspect.after(widget, "onCellClicked", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellClickedEvent(widget, property, row, value, error);
									}), true));
									widget.onCellDoubleClicked && this._viewHandlers.push(aspect.after(widget, "onCellDoubleClicked", lang.hitch(this, function(property, row, value, error) {
										this._broadcastCellDoubleClickedEvent(widget, property, row, value, error);
									}), true));
									widget.onRowUpdated && this._viewHandlers.push(aspect.after(widget, "onRowUpdated", lang.hitch(this, function(row) {
										this._broadcastRowUpdatedEvent(widget, row);
									}), true));
									widget.onRowChange && this._viewHandlers.push(aspect.after(widget, "onRowChange", lang.hitch(this, function(row) {
										this._broadcastRowChangedEvent(widget, row);
									}), true));
									widget.onRowAdded && this._viewHandlers.push(aspect.after(widget, "onRowAdded", lang.hitch(this, function(row) {
										this._broadcastRowAddedEvent(widget, row);
									}), true));
									widget.onRowInserted && this._viewHandlers.push(aspect.after(widget, "onRowInserted", lang.hitch(this, function(row) {
										this._broadcastRowInsertedEvent(widget, row);
									}), true));
									widget.onRowMoved && this._viewHandlers.push(aspect.after(widget, "onRowMoved", lang.hitch(this, function(row) {
										this._broadcastRowMovedEvent(widget, row);
									}), true));
									widget.onRowRemoved && this._viewHandlers.push(aspect.after(widget, "onRowRemoved", lang.hitch(this, function(row) {
										this._broadcastRowRemovedEvent(widget, row);
									}), true));
									widget.onRowClicked && this._viewHandlers.push(aspect.after(widget, "onRowClicked", lang.hitch(this, function(rows) {
										this._broadcastRowClickedEvent(widget, rows);
									}), true));
									widget.onRowDoubleClicked && this._viewHandlers.push(aspect.after(widget, "onRowDoubleClicked", lang.hitch(this, function(rows) {
										this._broadcastRowDoubleClickedEvent(widget, rows);
									}), true));
									widget.onRowSelected && this._viewHandlers.push(aspect.after(widget, "onRowSelected", lang.hitch(this, function(rows) {
										this._broadcastRowSelectedEvent(widget, rows);
									}), true));
								})
							});
							
							// Force resize call to change view to smaller height to account for widget title at the top.
							if (this.widgetProperties && this.widgetProperties.showWidgetTitle) {
								this.resize();
							}
							
							// Give the view a chance to fire onChange events before calling the callback.
							// Perhaps this timer belongs in the PropertyCollectionController's _processNextChangeSet method.
							callback && setTimeout(callback, 200);
						}));
					}), lang.hitch(this, function(error) {
						this.noPropsNode.innerHTML = string.substitute(this.resourceBundle.properties_viewDefinitionLoadError, [error]);
						domStyle.set(this.noPropsNode, "display", "block");
						var message = Message.createErrorMessage("properties_viewDefinitionLoadError", [error]);
						var dialog = new ErrorDialog();
						dialog.showMessage(message); // TODO Does this method block the thread?
						callback && callback();
					}));
				}));
			}
			else {
				callback && callback();
			}
		}
		
	});
});
