/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2013
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
	"dojo/_base/declare",
    "icm/pgwidget/caseinfo/dijit/documents/CaseInfoDocumentsContentPane",
	"dojo/_base/array",
	"dojo/_base/lang",
	"dojo/aspect",
	"dojo/dom-construct"		
], function(declare, CaseInfoDocumentsContentPane, array, lang, aspect, domConstruct) {
    
	return declare("v11.ewf.pgwidget.customcaseinfo.dijit.CustomDocumentsContentPane", CaseInfoDocumentsContentPane, {

		postCreate: function() {
			this.inherited(arguments);
			this.connect(this.ecmContentList, "onBeforeSetResultSet", "_onBeforeSetResultSet");
		},
		   
		_onBeforeSetResultSet: function(resultSet) {
			console.log("****** _onBeforeSetResultSet", resultSet);
			var pgwdgt = this.context;
	        if(typeof pgwdgt.widgetProperties.filterSupportingDocs == 'undefined' || pgwdgt.widgetProperties.filterSupportingDocs != "Yes"){
	        	return;
	        }
	        
			var tempItems = [];
			if(resultSet && resultSet.items && resultSet.items.length >0){
				array.forEach(resultSet.items, function(item){
					if(item && item.template && item.template == 'SupportingDocument'){
						console.log('Skip SupportingDocument in the list');
					}else{
						tempItems.push(item);
					}
				});
				resultSet.items = tempItems;
			}			
		},
		
		resize: function() {
			this.inherited(arguments);
		}
	});
});
