/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2013
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define(["dojo/_base/declare",
        "dojo/text!./templates/CustomSummaryContentPane.html",
        "dojo/_base/array",
        "dojo/_base/lang",
        "dojo/aspect",
        "dojo/dom-construct",
        //commented the below path and changed the path as mentioned in 5.2.1
       // "icm/pgwidget/caseinfo/dijit/CaseInfoComponent",
        "icm/pgwidget/caseinfo/CaseInfoComponent",
        "icm/model/properties/controller/ControllerManager",
    	"pvr/widget/View",
		"pvr/widget/registry/Registry",
		"pvr/widget/registry/BasicRegistryConfiguration",
		"icm/widget/properties/registry/Configuration",
		"dojo/date/stamp"		
], function(declare, template, array, lang, aspect, domConstruct, CaseInfoComponent, 
	ControllerManager, View, Registry, basicRegistryConfig, icmRegistryConfig, stamp) {
    
	return declare("v11.ewf.pgwidget.customcaseinfo.dijit.CustomSummaryContentPane", CaseInfoComponent, {

		templateString: template,

		postCreate: function() {
			this.componentName= this.componentName || "summary";
			this.inherited(arguments);
		},
		   
		handleSendCaseInfo: function(context, iEvent) {
			
			var payload = iEvent.payload;
			
			if (!payload) {
				console.log("****** Received an incomplete payload");            
			}
			else {
				var editable = payload ? payload.caseEditable : null;
				this.render(editable);
			}
		},

		render: function(model) {
			if (!this.isInFocus() || !model || !model.payload) {
				return;
			}
			var caseEditable = model.payload.caseEditable;
			this.inherited(arguments);

			if (caseEditable) {
				    this._openView(caseEditable);
			}
			else {
					this._closeView();
			}
			this.resize();
		},

		_openView: function(editable) {
			// We don't need to open the editable if its already open.
			// Close the existing view if necessary.
			this._closeView();
			this._propertyUpdateHandler=[];
			// Cache the model and bind the controller. 
			this._editable = editable;
			var summaryView = this._editable.getCaseType().getSummaryView();
			var summaryViewProps=[];
			if(summaryView){
				summaryViewProps = summaryView.fields;
			}
			var summaryViewPropNames= new Array();

			if(summaryViewProps && summaryViewProps.length>0){ //Defined summary view properties
			//Get summary view properties
		    array.forEach(summaryViewProps, function(prop, i) {
		    	summaryViewPropNames.push(prop.name);
			});
			}else{//If there is no property defined on summary view, show default system properties
			    //well known properties
				var wellKnownProperties = icmglobal.wellKnownProperties.caseSummaryWellKnownProperties;
				for(var i=0; i<wellKnownProperties.length; i++){
					summaryViewPropNames.push(wellKnownProperties[i].symbolicName);
				}
			}
			var that = this;
			var tableMarkUp = '<table class="idxPropertyGridTable">';
			 array.forEach(summaryViewPropNames, function(sname, i) {
			 	var prop = editable.propertiesCollection[sname];
		    	if(sname=="CIFHousekeptinBWC" && (prop.value && prop.value!=null && prop.value=='Y')){
		    	console.log("Into If"+sname);
                tableMarkUp += "<tr><th class=\"idxPropertyRowLabel idxPropertyRowLabelFirst idxPropertyRowLabelEven\" style=\"background-color: yellow;\">" + prop.name + "</th><td class=\"idxPropertyRowValue idxPropertyRowValueFirst idxPropertyRowValueEven\" style=\"background-color: yellow;\">" + that.getDisplayValue(prop) + "</td></tr>";            
                }else{
                //console.log("Into Else"+sname);
                tableMarkUp += "<tr><th class=\"idxPropertyRowLabel idxPropertyRowLabelFirst idxPropertyRowLabelEven\">" + prop.name + "</th><td class=\"idxPropertyRowValue idxPropertyRowValueFirst idxPropertyRowValueEven\">" + that.getDisplayValue(prop) + "</td></tr>";
                }
			});
			tableMarkUp += "</table>";
			this.caseSummaryFormNode.innerHTML = tableMarkUp;
		},

		getDisplayValue : function(prop){
			var displayValue = "";
			if(prop.cardinality == "LIST"){
	    		if(prop.value.length > 0){
					array.forEach(prop.value, function(itemValue, i){
						if(prop.dataType == "xs:timestamp"){
							itemValue = icm.util.Util.getLocaleDate(itemValue, "date")
							+", "+icm.util.Util.getLocaleDate(itemValue, "time");
						}
						
						//Added by Purna for Enhancement - Display the choice desc instead of choice value
						var itemDisplayVal = itemValue;
						
						if(prop && prop.choiceList && prop.choiceList.choices) {
							for(j = 0; j < prop.choiceList.choices.length; j++) {
								if(prop.choiceList.choices[j].value == itemValue) {
									itemDisplayVal = prop.choiceList.choices[j].displayName;
								}
							}
						}
						
						/* Comment the previous logic and introduce new logic
						if(i ==0){
							displayValue = itemValue;
						} else {
							displayValue += ", "+itemValue
						}*/
						
						if(i ==0){
							displayValue = itemDisplayVal;
						} else {
							displayValue += ", " + itemDisplayVal
						}
						//End change
						
		    		});
	    		} else{
	    			displayValue = '<div class="dijitInputContainer dijitInline pvrStaticTextEditorEmpty  ReadOnly dijitReadOnly">No items to display</div>';
	    		}
		    } else {
				if(prop.dataType == "xs:timestamp"){ 
					if(prop.value != null && prop.value != ""){
						displayValue = icm.util.Util.getLocaleDate(prop.value, "date")
								+", "+icm.util.Util.getLocaleDate(prop.value, "time");
					} else {
						displayValue = '<div class="dijitInputContainer dijitInline pvrStaticTextEditorEmpty  ReadOnly dijitReadOnly">No value</div>';
					}
				} else {
					if(prop && prop.choiceList && prop.choiceList.choices) {
						for(j = 0; j < prop.choiceList.choices.length; j++) {
							if(prop.choiceList.choices[j].value == prop.value) {
								displayValue = prop.choiceList.choices[j].displayName;
							}
						}
					} else if(prop.value != null && prop.value != ""){
						displayValue = prop.value;
					} else {
						displayValue =  '<div class="dijitInputContainer dijitInline pvrStaticTextEditorEmpty  ReadOnly dijitReadOnly">No value</div>';
					}
				}
			}
			
			return displayValue;
		},

		_closeView: function() {
			if (this._editable) {
				// Delete the model.
				delete this._editable;
			}
		},
		
		_close: function(){
			this._closeView();
		},
		
		resize: function() {
			if (!this.isInFocus()) {
				return;
			}
			if(!this.autoHeight){
				if(this.context){
					var height = this.context.domNode.clientHeight - 100;					
					var preHeight= dojo.getContentBox(this.caseSummaryFormNode).h;					
					if(height != preHeight && height > 0){						
						dojo.style(this.caseSummaryFormNode, "height", height + "px");
					}
				}
			}
		},
		
	    destroyRecursive: function(){
	    	this._closeView();
	    	this.inherited(arguments);
	    },
	    
		_eoc_: null
	});
});
