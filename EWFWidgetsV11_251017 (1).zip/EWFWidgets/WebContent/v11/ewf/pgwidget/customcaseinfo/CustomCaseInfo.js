define([
	"dojo/_base/declare", 
	"dojo/_base/lang",
	"dojo/aspect",
	"dojo/_base/array",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",	
	"icm/pgwidget/caseinfo/CaseInfo",
	"icm/model/Solution",
	"icm/model/Case",
	"icm/model/CaseEditable",
	"v11/ewf/pgwidget/customcaseinfo/dijit/CustomSummaryContentPane",
	"v11/ewf/pgwidget/customcaseinfo/dijit/CustomDocumentsContentPane" //v11 Documents tab customized
], function(declare, lang, aspect, array, BasePageWidget, BaseActionContext, CaseInfo, Solution, Case,CaseEditable, CustomSummaryContentPane, CustomDocumentsContentPane){
	return declare("v11.ewf.pgwidget.customcaseinfo.CustomCaseInfo",
			[CaseInfo], {    
    	
    	startup: function() {
			
			console.log("Entered into startup method in CustomCaseInfo!!!!!");
			
			//this.inherited(arguments);
			
			//Code Integrated By Gopi as Part of ICM 521 Upgrade
			 this.autoHeight = this.domNode.style.height === "auto" ? true : false;
			
			if(!this.widgetProperties.tabDefinition){
	        	this.widgetProperties.tabDefinition = [{"id":"CSummary","visibility":true},
	        	                                       {"id":"Documents", "visibility":true},
	        	                                       {"id": "Activities", "visibility":true},
	        	                                       {"id":"History", "visibility":true}
	        	                                       ];
	        }
	        //End hardcode
	        
	        //Added by Purna for L&S on 08/02/2017 - Check if the setting for documents filter is available on widget
	        var filterDocuments = false;
	        if(this.widgetProperties.filterSupportingDocs && this.widgetProperties.filterSupportingDocs == "Yes"){
	        	filterDocuments = true;
	        	console.debug('Filter docs setting is enabled on the widget. Hence dont display Supporting Documents');
	        }
	        //End change by Purna
	        
			dojo.forEach(this.widgetProperties.tabDefinition,function(tabDefinition) {
				if(tabDefinition.visibility){
					var id= tabDefinition.id;
					var definitionId= id=="Activities"? "Tasks": id; //Convert "Activities" to "Tasks"
					if(id == "CustomSummary"){
						// create the custom summary dijit to show case summary
						var customSummary = new CustomSummaryContentPane({
							title: this.resourceBundle["summaryName"],
							description:"Custom Case Summary widget",
							definitionId: "CustomSummary", 
							resourceBundle: this.resourceBundle, 
							context: this
						});
						this._caseinfoTabs.push(customSummary);
					
					//Added by Purna for L&S on 08/02/2017 - Create custom Documents tab if the filter is true 
					}else if(filterDocuments && id == "Documents"){
						var lComponentName = id.toLowerCase();
						var documentsTab = new CustomDocumentsContentPane({
							title: this.resourceBundle[lComponentName+"Name"],
							componentName: lComponentName,
							resourceBundle: this.resourceBundle,
							context: this,
							definitionId: "Documents",							
							description:"Custom Case Documents widget"
						});
						this._caseinfoTabs.push(documentsTab);
					//End change by Purna
					
					}else{
						var lComponentName = id.toLowerCase();
						var className = "icm.pgwidget.caseinfo.dijit."+lComponentName+".CaseInfo"+id+"ContentPane";
						var classDef = dojo.getObject(className);
						var classObj = new classDef({
							title: this.resourceBundle[lComponentName+"Name"],
							componentName: lComponentName,
							resourceBundle: this.resourceBundle,
							context: this,
							definitionId: definitionId
						});
						this._caseinfoTabs.push(classObj);
					}
				}
			},this);
			
			// Add custom tabs
			if (this._customTabs && this._customTabs.length > 0) {
				this._caseinfoTabs = this._caseinfoTabs.concat(this._customTabs);
			}
			this.tabContainer.startup();
			array.forEach(this._caseinfoTabs, function(component) {
				this.tabContainer.addChild(component);
			}, this);

			this.tabContainer.resize();
			this._connectEvents();
			//End Of the Changes By Gopi As Part of ICM521
			
			console.log("Exit from startup method in CustomCaseInfo");
		
		},
		
		resize: function() {
			this.inherited(arguments);
		},
    	
        destroy: function() {
            var widgets = dijit.findWidgets(this.domNode);   		
            dojo.forEach(widgets, function(w) {            	
                w.destroyRecursive(true);
            });
            
            this.inherited("destroy", arguments);
        },

    	_eoc_: null
    });   
}); 