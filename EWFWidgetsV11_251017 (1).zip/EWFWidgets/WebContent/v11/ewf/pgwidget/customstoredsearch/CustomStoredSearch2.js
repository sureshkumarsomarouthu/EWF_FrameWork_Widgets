define([ "icm/pgwidget/casesearch/CaseSearchContentPane",
         "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/dom-class",
         "dojo/dom-construct",
         "dojo/dom-geometry",
         "dojo/dom-style",
         "dojo/keys",
         "dojo/string",
         "dojo/query",
         "dojo/data/ItemFileReadStore",
         "v11/ewf/pgwidget/customstoredsearch/CustomCaseSearchContentPaneEventListener",
         "ecm/widget/SinglePropertyEditorFactory",
         "icm/base/BasePageWidget",
         "dojo/date/stamp",
         "dojo/date",
		 "dojox/data/dom",
         "ecm/widget/FilteringSelect",
		 "ecm/model/AttributeDefinition"
	], 
	function(CaseSearchContentPane, declare, lang, domClass, domConstruct, domGeometry, domStyle, keys, string, query, ItemFileReadStore, 
			CustomCaseSearchContentPaneEventListener, SinglePropertyEditorFactory, BasePageWidget, stamp, date, dom, FilteringSelect, AttributeDefinition){

    return declare("v11.ewf.pgwidget.customstoredsearch.CustomStoredSearch", [CaseSearchContentPane, BasePageWidget], {
    	
    	postCreate: function(){
			this.inherited(arguments);

			//Create the event listener and the events
			this.searchContentPaneEventListener = new CustomCaseSearchContentPaneEventListener(this);

			this.connect(this, "onClickSearchButton", function(){
				this.searchContentPaneEventListener.onClickSearchButton();
			});
			this.connect(this, "onAdvancedButtonClick", function(){
				this.searchContentPaneEventListener.onAdvancedButtonClick();
			});
			this.initialize(this.getSolution());
			
			var _this = this;
			//domConstruct.empty(this.contentNode);
			//setTimeout(function(){_this.searchContentPaneEventListener.showAdvancedSearch(_this.contentNode)}, 2000);
		},
		
		/**
		 * Handler for icm.ClearContent event.
		 */
		handleClearContent: function(){
			this.logEntry("handleClearContent");
	        this.clearInputValue();
		},
		
		_eoc_: null						
	});
});
