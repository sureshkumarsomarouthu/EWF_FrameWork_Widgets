define([ "dojo/_base/declare", 
         "dojo/_base/lang",
         "dojo/_base/array",
         "dijit/registry",
         "dojo/on",
         "dojo/dom-form",
         "dojo/dom-construct",
         "dijit/form/Button",
         "icm/pgwidget/casesearch/SearchContentPaneEventListener",
         "icm/util/SearchPayload",
         "idx/widget/Dialog",
         "icm/pgwidget/casesearch/dijit/SearchDialog"
	], 
	function(declare, lang, baseArray, registry, on, domForm, domConstruct, idxButton, SearchContentPaneEventListener, SearchPayload, Dialog, SearchDialogPane){

    return declare("v11.ewf.pgwidget.customstoredsearch.CustomCaseSearchContentPaneEventListener", [SearchContentPaneEventListener], {
    	
    	constructor: function(context){
    		this.context = context;
			this.solution = context.getSolution(); 
			this.role = context.getRole();
			this.resourceBundle = context.resourceBundle;
			this._searchPayload = new SearchPayload();
		},
    	
		showAdvancedSearch: function(domNode){
			if(!this.searchDialog){	
				var wellknownProperties = this._getWellknownProperties();
				var searchButton = new idxButton({
					label: this.resourceBundle.searchButtonLabel
				});
				
				var isShowUserSpecified = true;
				if(this.context.widgetProperties && this.context.widgetProperties.advancedSearchUserSpecifiedSelector == "hideUserSpecified") {
					isShowUserSpecified = false;					
				}
				var pane= new SearchDialogPane({
					solution: this.solution,
					role: this.role,
					objectStoreName: this.solution.getTargetOS().id,
					wellknownProperties: wellknownProperties,
					searchViewPropDefs: this.context.getSearchViewPropDefs(),
					allSearchablePropDefs: this.context.getAllSearchablePropDefs(),
					isShowAllProperties: this.context.widgetProperties.isShowAllProperties,
					isShowUserSpecified:  isShowUserSpecified,
					searchCallback: lang.hitch(this,"executeSearch"),
					searchButton: searchButton
				});
				searchButton.onClick = dojo.hitch(pane,pane.onSearch);

				this.searchDialog = new Dialog({
					title: this.resourceBundle.advancedSearch,
					content: pane,
					baseClass: "searchDialogDialogPaneContent",
					buttons: [searchButton],
					closeButtonLabel: icm.util.Util.getResourceBundle("common").Close			
				}, "searchDialog");
				this.searchDialog.connect(pane, "onRezie", "_size");
			}
			this.searchDialog._firstFocusItem = this.searchDialog.titleNode;
			this.searchDialog.titleNode.title = this.resourceBundle.advancedSearchDialog;
			dojo.removeClass(this.searchDialog.closeButton.domNode, "idxSecondaryButton ");
			//this.searchDialog.show();
			domConstruct.place(this.searchDialog.domNode, domNode, 'after');
		},
		
		_eoc_: null						
	});
});
