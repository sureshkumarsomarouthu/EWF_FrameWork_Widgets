define([ "dojo/_base/declare", 
         "dojo/_base/lang",
         "dojo/_base/array",
         "dijit/registry",
         "dojo/on",
         "dojo/dom-form",
         "dojo/dom-construct",
         "dijit/form/Button",
         "dijit/form/Form",
         "dijit/form/TextBox",
         "dojox/lang/functional",
         "icm/base/BasePageWidget",
         "icm/base/BaseActionContext",
         "icm/pgwidget/contentlist/ContentList",
         "dojo/text!./dijit/templates/CustomStoredSearchTemplate.html",
         "ecm/widget/dialog/ErrorDialog",
         "icm/util/Util"
	], 
	function(declare, lang, baseArray, registry, on, domForm, domConstruct, Button, Form, TextBox, functional, BasePageWidget, BaseActionContext, ContentListWidget, template, ErrorDialog){

    return declare("v11.ewf.pgwidget.customstoredsearch.CustomStoredSearch", [ContentListWidget], {
    	
    	templateString: template,
    	
    	isSearchCriteriaFetched: false,
    	
    	fieldsConfig: {'DocumentType': 'dijit/form/TextBox'},
    	
    	constructor: function(context){
    		this.resourceBundle = icm.util.Util.getResourceBundle("ContentList");
			
			this.searchType = null;
			this.ssVsID = null;
			this.ssVersion = null;
			this.ssObjStoreName = null;
			this.contentNodeVisible = false;

			this.externalColumns = null;
			this.values = null;

			if (context)
				this.ssObjStoreName = context.solution.getTargetOS().id; 
		},
    	
		postCreate: function(){
			this.inherited(arguments);
			
			domConstruct.empty(this.searchCriteriaNode);
			//Get the configurations from widget settings
			this._getConfigurations();
			
			//Populate the SS required params for retrieving the Search Template
			this.populateSSQueryOptions();
			
			//Get the SS Template & Build the UI based on Search Criteria
			this.getStoredSearchTemplate(lang.hitch(this, this.buildUIFromSearchCriteria));
			
		},
		
		buildUIFromSearchCriteria: function(searchCriteria){
			var _this = this;
			this.isSearchCriteriaFetched = true;
			//Construct a dynamic table with 3 columns from the Search Criteria
			//searchCriteriaNode
			var fieldsToCreate = [];
			baseArray.forEach(searchCriteria, function(criterion){
				if(!criterion.readOnly)
					fieldsToCreate.push({'id': criterion.id, 'dataType': criterion.dataType, 'label': criterion.label});
			});
			
			var form = new Form({'style': 'width: 100%;'});
			var table = domConstruct.create('table', {'style': 'width: 99%;'});
			var thead = domConstruct.create('thead');
			var theadTr = domConstruct.create('tr');
			var tableTr = domConstruct.create('tr');
			var td;
			var fieldDijit;
			baseArray.forEach(fieldsToCreate, function(field, index){
				theadTr.appendChild(domConstruct.create('td', {'innerHTML': field.label, 'style': 'width: 33%; text-decoration: underline; font-weight: bold;'}));
				fieldDijit = new TextBox({'name': field.id, 'style': 'width: 80%;'});
				var fieldDijitTd = domConstruct.create('td', {'style': 'width: 33%; text-decoration: underline; font-weight: bold;'});
				fieldDijitTd.appendChild(fieldDijit.domNode);
				fieldDijit.startup();
				tableTr.appendChild(fieldDijitTd);
				if(((index+1) % 3) === 0){
					table.appendChild(theadTr);
					table.appendChild(tableTr);
					form.domNode.appendChild(table);
					
					table = domConstruct.create('table', {'style': 'width: 99%;'});
					thead = domConstruct.create('thead');
					theadTr = domConstruct.create('tr');
					tableTr = domConstruct.create('tr');
				}
			});
			if((fieldsToCreate.length % 3) !== 0){
				table.appendChild(theadTr);
				table.appendChild(tableTr);
				form.domNode.appendChild(table);
			}
			
			var submitButton = new Button({'label': 'Submit'});
			var resetButton = new Button({'label': 'Reset'});
			
			on(submitButton, 'click', lang.hitch(_this, _this.processSearch, form.id));
			on(resetButton, 'click', lang.hitch(_this, _this.resetSearch, form.id));
			
			form.domNode.appendChild(submitButton.domNode);
			form.domNode.appendChild(resetButton.domNode);
			
			this.searchCriteriaNode.appendChild(form.domNode);
			form.startup();
			submitButton.startup();
			this.showContentNode();
		},
		
		processSearch: function(form){
			this.showContentNode();
			this.contentNodeVisible = true;
			this.ecmContentList.style.height = (this.contentNode.clientHeight - 150) + ' px';
			if(registry.byId(form).validate()){
				var formJson = domForm.toObject(form);
				var anyValueEntered = false;
				functional.forIn(formJson, function(value){
					value += '';
					if(value.length > 0)
						anyValueEntered = true;
				});
				//if form is valid and any value entered this.handleICM_ReceiveSearchValuesEvent(payload);
				//else this.handleICM_ClearContentEvent();
				if(anyValueEntered){
					var payload = [], payloadElement={};
					var keys = functional.keys(formJson);
					baseArray.forEach(keys, function(key){
						payloadElement = {};
						payloadElement.id = key;
						payloadElement.value = formJson[key];
						payload.push(payloadElement);
					});
					this.searchType = 0;
					this.handleICM_ReceiveSearchValuesEvent(payload);
				}else{
					this.handleICM_ClearContentEvent();
				}
			}
		},
		
		resetSearch: function(form){
			registry.byId(form).reset();
			this.handleICM_ClearContentEvent();
			this.onPublishEvent("icm.ClearViewerContent", null);
		},
		
		getStoredSearchTemplate: function(callback){
			if (this._isReadyToQuery() && !this.isSearchCriteriaFetched) {
				this.repository = ecm.model.desktop.getRepository(this.objectStoreId);
				this.repository.retrieveSearchTemplate(null, 
						this.versionSeries, 
						this.versionStatus, 
						lang.hitch (this, this.receivedSearchTemplate, callback, null /*searchParams*/),
						lang.hitch(this, function(){
							var message = icm.model.Message.createErrorMessage("unableToGetStoredSearchError",[this.versionSeries]);
							var dialog = new ErrorDialog();
							dialog.showMessage(message);
							this.logError("StoredSearchHandler_query", message);
						})
				);
			}
		},
		
		receivedSearchTemplate: function (callback, propList, sTemplate) {
			sTemplate.retrieveSearchCriteria(lang.hitch(this, function(searchCriteria) {
				callback(searchCriteria);
			}));
		},
		
		_isReadyToQuery: function () {
			if (this.objectStoreId && this.versionSeries && this.versionStatus) 
				return true;
			else
				return false;
		},
		
		_getConfigurations: function(){
			var widgetAttributes = this.getWidgetAttributes();
			if (widgetAttributes) {
				this.searchType = widgetAttributes.getItemValue("searchType");
				if(!this.searchType) {
					// new options in 5.2
					var searchOption = widgetAttributes.getItemValue("contentListSearchOption");
					if(searchOption === "contentListStoredSearchGenerateView") {
						this.searchType = 2;
						this.ssVersion = widgetAttributes.getItemValue("storedSearchGenerateViewVersionSelector");
						if(this.ssVersion && (this.ssVersion === "currentGenerateView"))
							this.ssVsID = widgetAttributes.getItemValue("currentVersionIdGenerateView");
						else if(this.ssVersion && (this.ssVersion === "releasedGenerateView"))
							this.ssVsID = widgetAttributes.getItemValue("releasedVersionIdGenerateView");
					} else if(searchOption === "contentListStoredSearch"){
						this.searchType = 0;
						this.ssVersion = widgetAttributes.getItemValue("storedSearchVersionSelector");
						if(this.ssVersion && (this.ssVersion === "current"))
							this.ssVsID = widgetAttributes.getItemValue("currentVersionId");
						else if(this.ssVersion && (this.ssVersion === "released"))
							this.ssVsID = widgetAttributes.getItemValue("releasedVersionId");
					} else if(!searchOption || (searchOption === "contentListDocumentSearch"))
						this.searchType = 1;
				}
			}
		},
		
		populateSSQueryOptions: function(){
			this.objectStoreId = this.ssObjStoreName;
			this.versionSeries = this.ssVsID;
			this.versionStatus = "current";
		},
		
		renderSearchResults: function(results){
			this.ecmContentList.setResultSet(results);
		},
		
		_eoc_: null						
	});
});
