define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"dojo/dom-style",
    "dojo/text!./templates/FormDataEntryContentPane.html", 
	"icm/base/_BaseWidget",
	"v11/ewf/util/Util", 
    "v11/ewf/widget/fields/Fields"
	], function(declare, lang, domStyle, template, _BaseWidget, Util, Fields){
	return declare("v11.ewf.pgwidget.formdataentry.dijit.FormDataEntryContentPane", [_BaseWidget], {
		templateString: template,
		widgetsInTemplate: true,
		fieldsWidgetList: [],
		viewsOpened: 0,
			
		constructor: function(){
			this.fieldsWidgetList = [];
			this.viewsOpened = 0;
		},

		postCreate:	function(){
			this.inherited(arguments);
			this.showContentNode();	
			
			while (this.formRootNode.hasChildNodes()) {
				this.formRootNode.removeChild(this.formRootNode.firstChild);
			}
			
			//Commented by Purna - as part of generalization of Constants based on case type from current sol type.
			/*this.formViews = Util.getConstant("EWF_Form_Views", this.solution.prefix);	
					
			this.updateButtonState();*/
			//End
		},		
				
		/**
		 * Display the next view defined for Form Data Entry widget.
		 * 
		 */		 		
		showNextView: function() {
			console.log("call showNextView");
			//Added by Purna -- Sending the WorkitemEditable in order to get the CaseType from the Work item and to get the constants based on case type
			if(!this.formViews) {
				this.formViews = Util.getConstant("EWF_Form_Views", this.solution.prefix, this.workItemEditable);
				console.log("this.formViews ",this.formViews);
				//Added by Purna for COA Jan QR -- Display different views based on the configured field value in constants
				var filterField = Util.getConstant("EWF_Form_Views_Filter", this.solution.prefix, this.workItemEditable);
				console.log("filterField line 47 :",filterField);
				if(filterField) {
				    console.log("filterField ",filterField);
					if(this.workItemEditable.propertiesCollection && this.workItemEditable.propertiesCollection[filterField]) {
						var fieldValue = this.workItemEditable.propertiesCollection[filterField].value;
						var fieldCardinality = this.workItemEditable.propertiesCollection[filterField].cardinality;
						//For now getting the 1st element in the index without any logic for list fields
						if(fieldCardinality && fieldCardinality == "LIST" && fieldValue instanceof Array && fieldValue.length >= 1) {
							fieldValue = fieldValue[0];
						}
						//Check if the views is JSONObj with key value pairs or JSONArray without any filters
						if(this.formViews[fieldValue] instanceof Array) {
							this.formViews = this.formViews[fieldValue];
							console.log('Loading dynamic views based on ' + filterField + ' value: ' + fieldValue + ' formViews: ', this.formViews);
						}
					} else {
						console.log(filterField + ' is not available on the workItem properties collection. Hence ignore the value');
					}
				}
				//End change by Purna 
				this.updateButtonState();
			}
			//End
			
			if(this.viewsOpened >= this.formViews.length)
				return;
			
			// Get next view template
			var view = this.formViews[this.viewsOpened];
			
			// Create the Properties widgets for the view
			var fieldsWidget = new Fields();
			if (view.isStatic === true) {// The view has been defined in Case Builder
				fieldsWidget.setViewDefinitionId(view.viewDefinitionId);
			}
			this.fieldsWidgetList.push(fieldsWidget);
			/**commented by suresh method name is changed from _configureCoordination to configureCoordination in 5.2.1
			  as part of 5.2.1 upgrade the below method name is changed*/
			//fieldsWidget._configureCoordination(this.workItemEditable, this.coordination);			
			
			fieldsWidget.configureCoordination(this.workItemEditable, this.coordination);
				
			// Show the properties view
			fieldsWidget.closeView();
			//fieldsWidget.openView(this.workItemEditable, lang.hitch(this, this.onOpenView, fieldsWidget.viewDefinitionId));
			//options is added by suresh as part of 5.2.1 upgrade
			var options = { 
		 			disabled: false,
		 			applyDefaultValues: true
		 		};
				
			fieldsWidget.openView(this.workItemEditable, options,lang.hitch(this, this.onOpenView, fieldsWidget.viewDefinitionId));	
			this.formRootNode.appendChild(fieldsWidget.domNode);
		},
		
		/**
		 * Fired when user clicks the Show More link.
		 */		 		
		onShowMore: function() {
			this.showNextView();
		},
		
		updateButtonState: function() {
		    console.log("call updateButtonState");
		    console.log("this.viewsOpened : ",this.viewsOpened);
		    console.log("this.formViews.length :",this.formViews.length);
			this.showMoreButton.attr("disabled", this.viewsOpened >= this.formViews.length);				
		},
		
		onOpenView: function(viewDefinitionId) {
		    console.log("in onOpenView###",viewDefinitionId);
		    console.log("this.viewsOpened in onOpenView",this.viewsOpened);
			var fieldsWidget = this.fieldsWidgetList[this.viewsOpened];
			//fieldsWidget._view.set("readOnly", false);//commented by suresh as part of 5.2.1 upgrade
			fieldsWidget && fieldsWidget.view.set("readOnly", false);// added by suresh as part of 5.2.1 upgrade
			fieldsWidget.focusFirstChild();					
			this.viewsOpened++;
			this.updateButtonState();
			console.info("onOpenView -- opened view: " + this.viewsOpened + ", definition id: " + viewDefinitionId, new Date());
		},

		resetViews: function() {
			var fieldsWidget;
			//added by suresh as part of 5.2.1 upgrade when complate case next view is not rendering at Form data entry
			this.formViews=null;
			for (var i = 0; i < this.fieldsWidgetList.length; i ++) {	
				fieldsWidget = this.fieldsWidgetList[i];
				fieldsWidget.closeView();
				fieldsWidget.destroyRecursive();
				delete fieldsWidget;
			}
			this.fieldsWidgetList = [];
			this.viewsOpened = 0;
			while (this.formRootNode.hasChildNodes()) {
				this.formRootNode.removeChild(this.formRootNode.firstChild);
			}
		},
		
		destroyRecursive: function() {
			this.resetViews();
			this.inherited(arguments);
		}
	});
});
