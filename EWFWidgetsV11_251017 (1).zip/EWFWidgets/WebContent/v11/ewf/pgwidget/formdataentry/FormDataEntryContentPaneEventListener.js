define(["dojo/_base/declare", 
	"v11/ewf/util/Util", 
	"ecm/LoggerMixin"], 
	function(declare, Util, LoggerMixin){
    return declare("v11.ewf.pgwidget.formdataentry.FormDataEntryContentPaneEventListener", [LoggerMixin], {
	
		contentPane: null,
		
		constructor: function(contentPane){
			this.contentPane = contentPane;
		},
		
		initContentPane: function()	{
			this.contentPane.showContentNode();	
		},
		
		onHandleSendWorkItem: function(workItemEditable){
			this.contentPane.resetViews();
			// Mixin the additional definitions
			var solution = this.contentPane.solution;
			var property, fieldSymName;			
			for(var propertyName in workItemEditable.propertiesCollection){
				property = workItemEditable.propertiesCollection[propertyName];
				fieldSymName = Util.getShortName(solution, propertyName);
				workItemEditable.propertiesCollection[propertyName] = dojo.mixin(
					workItemEditable.propertiesCollection[propertyName], 
					
					//Added by Purna -- Sending the WorkitemEditable in order to get the CaseType from the Work item and to get the constants based on case type
					//Util.getConstant("EWF_FieldAttributes", solution.prefix)[fieldSymName]);	
					Util.getConstant("EWF_FieldAttributes", solution.prefix, workItemEditable)[fieldSymName]);
					//End
			}									
			
			// Display the first Form view to enhance performance	
			this.contentPane.showNextView();	
		}
	
	});
});
