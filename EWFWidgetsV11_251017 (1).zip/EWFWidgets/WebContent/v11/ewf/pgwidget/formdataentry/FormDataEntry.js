define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",
	"icm/base/Constants",
    "v11/ewf/pgwidget/formdataentry/dijit/FormDataEntryContentPane",
   	"v11/ewf/pgwidget/formdataentry/FormDataEntryContentPaneEventListener",
	"v11/ewf/util/Util"
	], function(declare, lang, BasePageWidget, BaseActionContext, icmConstants, contentPaneWidget, eventHandler,Util){

    return declare("v11.ewf.pgwidget.formdataentry.FormDataEntry", [contentPaneWidget, BasePageWidget, BaseActionContext], {
 
		contentPaneEventListener: null,

		postCreate: function(){
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane();
		},

		handleICM_SendWorkItemEvent: function(payload) {
			this.logEntry("handleICM_SendWorkItemEvent");
			var workItemEditable = payload ? payload.workItemEditable : null;
			if(!workItemEditable) {
				this.logError("handleICM_SendWorkItemEvent -- payload: ", payload);
				return;
			} 

			this.workItemEditable = workItemEditable;
			this.coordination = payload.coordination;
			this.coordination.participate(icmConstants.CoordTopic.BEFORECOMPLETE, lang.hitch(this, this.handleICM_BeforeCompleteEvent));
			this.coordination.participate(icmConstants.CoordTopic.BEFORESAVE, lang.hitch(this, this.handleICM_BeforeSaveEvent));
			
			// Get the work item object
			var workItem = workItemEditable.getWorkItem();

			// Check if the work item attributes have been retrieved
			if (!workItem.getCaseTaskId()) {
				// retrieves the work item attributes
				workItem.retrieveCachedAttributes(dojo.hitch(this, function(workItem){
					// retrieves the case attributes to show case title in Comments dialog
					var caseModel = workItem.getCase();
					caseModel.retrieveCachedAttributes(dojo.hitch(this, function(caseModel){
						this.contentPaneEventListener.onHandleSendWorkItem(workItemEditable);
					}));	
				}));
			}
			else {
				var caseModel = workItem.getCase();
				caseModel.retrieveCachedAttributes(dojo.hitch(this, function(caseModel){
					this.contentPaneEventListener.onHandleSendWorkItem(workItemEditable);
				}));	
			}	
			
			this.logExit("handleICM_SendWorkItemEvent");
		},
		
		/**
		*   Handler before completing the work item.
		*/
		handleICM_BeforeCompleteEvent: function(context, complete, abort) {
			this.logEntry("handleICM_BeforeCompleteEvent");
			var property;
			var marker = "\u001D\u001D";
			for (var id in this.workItemEditable.propertiesCollection) {
				property = this.workItemEditable.propertiesCollection[id];
				if (property.cardinality === "LIST" && property.value) {
					// Convert empty string in multiple value properties into special characters so that the value can be saved to CE on Oracle DB.
					var newValue = [];
					for (var i = 0; i < property.value.length; i ++) {
						if (property.value[i] === "" || property.value[i] === null) {
							newValue.push(marker);
						} else {
							newValue.push(property.value[i]);
						}
					}
					property.value = newValue;
				}
			}
			//Change for COA amker checker validations
			var roleName = ecm.model.desktop.currentRole.name;
			var userId = ecm.model.desktop.userId;
			var caseTypeObj = this.workItemEditable.getCaseType();
			var caseTypeName= caseTypeObj.id;
			var property =null;
			if(caseTypeName == Util.getConstant("EWF_CASE_TYPE").CHANGE_OF_ADDRESS){
				if(roleName==Util.getConstant("ROLE_NAMES").FORM_DE_OPERATOR){
					if(this.workItemEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").DE_USER_FIELD)){
						property = this.workItemEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").DE_USER_FIELD];
							var propValue = property.getValue();
						var originalValue = lang.clone(propValue);
						propValue.push(userId);
						property.setValue(propValue);	
						property.originalValue=originalValue;
					}
				}
			}	
						
			complete();
			this.logExit("handleICM_BeforeCompleteEvent");
		},
		
		/**
		*   Handler before saving the work item.
		*/
		handleICM_BeforeSaveEvent: function(context, next, abort) {
			this.logEntry("handleICM_BeforeSaveEvent");
			var property;
			var marker = "\u001D\u001D";
			//Added by Purna -- Handling empty string for multi valued fields
			for (var id in this.workItemEditable.propertiesCollection) {
				property = this.workItemEditable.propertiesCollection[id];
				if (property.cardinality === "LIST" && property.value) {
					 if((property.value.length==1) && (!property.value[0])) {
						// Convert empty string in multiple value properties into special characters so that the value can be saved to CE on Oracle DB.
						var newValue = [];
						property.value = newValue;
					} else if(property.value.length > 1) {
						var newValue = [];
						for (var i = 0; i < property.value.length; i ++) {
							if (property.value[i] === "" || property.value[i] === null) {
								newValue.push(marker);
							} else {
								newValue.push(property.value[i]);
							}
						}
						property.value = newValue;
					}
				}
			}
			//End
			next();
			this.logExit("handleICM_BeforeSaveEvent");
		}
		
	});
});
