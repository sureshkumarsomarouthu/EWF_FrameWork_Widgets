define([ "dojo/_base/declare", 
    "dojo/text!./templates/DocumentSearchContentPane.html", 
	"icm/base/_BaseWidget",
	"dojo/_base/lang",
	"dijit/form/FilteringSelect",
	"dijit/form/TextBox",
	"dojo/store/Memory",
	"icm/pgwidget/contentlist/dijit/ContentListContentPane",
	"dojo/_base/array",
	"dijit/form/DateTextBox",
	"dijit/form/Form",
	"dijit/form/TextBox",
	"dijit/form/Button"
	], function(declare, template, _BaseWidget, lang, FilteringSelect, TextBox, Memory, ContentListContentPane, baseArray){
	return declare("v11.ewf.pgwidget.documentsearch.dijit.DocumentSearchContentPane", [_BaseWidget], {
		
		templateString: template,
		
		widgetsInTemplate: true,
			
		constructor: function(){
			
		},

		postCreate:	function(){
			this.inherited(arguments);
		},
		
		buildFilteringSelects: function(solution){
			var _this = this;
			
			this.solution = solution;
			
			this.DocumentTypesStore = new Memory({
		        data: [
		            {name:"--Select All--", id:"0"},
		            { 'name': 'Earmark Placement and Removal','id': '1000'},
					{ 'name': 'Hold Code Placement and Removal','id': '1001'},
					{ 'name': 'Hold Code Bulk Placement and Update Same','id': '1002'},
					{ 'name': 'Hold Code Bulk Placement and Update Different','id': '1003'},
					{ 'name': 'Other Supporting Document','id': '1004'},
					{ 'name': 'Unstructured Document','id': '1005'},
					{ 'name': 'Internal Memo','id': '1006'},
					{ 'name': 'Credit Card Combo Form (May Version)','id': '1007'},
					{ 'name': 'Credit Card Combo Form (Aug Version)','id': '1008'},
					{ 'name': 'Credit Card Standalone Form','id': '1009'},
					{ 'name': 'Income-Others Document','id': '1010'},
					{ 'name': 'Identification-Others Document','id': '1011'},
					{ 'name': 'Change Of Address - Company','id': '1012'},
					{ 'name': 'Change Of Address - Personal','id': '1013'},
					{ 'name': 'Identification-NRIC','id': '1014'},
					{ 'name': 'Identification-Passport','id': '1015'},
					{ 'name': 'Identification-Employment Pass','id': '1016'},
					{ 'name': 'Income-CPF Statement','id': '1017'},
					{ 'name': 'Income-Payslip','id': '1018'},
					{ 'name': 'Income-Notice of Assessment','id': '1019'},
					{ 'name': 'Income-IR8A','id': '1020'},
					{ 'name': 'Identification-Birth Cert.','id': '1021'},
					{ 'name': 'Customer instruction','id': '1022'}
		        ]
		    });
			
			
			/*this.TransactionTypesStore = new Memory({
		        data: [
		            {name:"--Select All--", id:"0"},
		            { 'name': 'Earmark Maintenance','id': 'EAMT'},
					{ 'name': 'Hold Code Maintenance','id': 'HCMT'},
					{ 'name': 'Application - Credit Card Combo (old)','id': 'ACCO'},
					{ 'name': 'Application - Credit Card Combo (new)','id': 'ACCC'},
					{ 'name': 'Application - Credit Card Standalone','id': 'ACCA'},
					{ 'name': 'Application - Debit Card Combo','id': 'ADCC'},
					{ 'name': 'Application - CashPlus Combo','id': 'ACPC'},
					{ 'name': 'Change Of Address - Company','id': 'COAC'},
					{ 'name': 'Change Of Address - Personal','id': 'COAP'},
					{ 'name': 'Unclassified Transaction Type','id': 'UNCL'},
					{'name':'3rd Party Authorization Form','id':'3PAF'},
					{'name':'Change of Customer Static Data/Statement','id':'ASDM'},
					{'name':'Account Maintenance - Archival','id':'AMAR'},
					{'name':'Account Opening Documents - Archival','id':'AOPA'},
					{'name':'Accounts & Service Resolution','id':'ANSR'},
					{'name':'ATM Activation','id':'ATMV'},
					{'name':'ATM Application','id':'ATMA'},
					{'name':'ATM Updates','id':'ATMU'},
					{'name':'Audit Confirmation','id':'AUDF'},
					{'name':'Bad Account Information','id':'BAIN'},
					{'name':'BIB Activation','id':'BIBV'},
					{'name':'BIB Application','id':'BIBA'},
					{'name':'BIB Updates','id':'BIBU'},
					{'name':'Bonds (Letter of Authority)','id':'BOLA'},
					{'name':'Template-Bonds (Letter of Authority)','id':'TBLA'},
					{'name':'BusinessPLUS Account Application','id':'BPAA'},
					{'name':'BusinessPLUS Account Courier Services','id':'BPAC'},
					{'name':'SGS Buy','id':'SGSB'},
					{'name':'CashPlus Funds Transfer','id':'CPFT'},
					{'name':'Limit Adjustmt (CR)','id':'LADJ'},
					{'name':'Reinstmt (CR)','id':'RECR'},
					{'name':'Covered Calls - Buy/TO','id':'CCBT'},
					{'name':'Change of Address','id':'CHOA'},
					{'name':'Change of Name/ID','id':'CHNI'},
					{'name':'Change of Cust Demo','id':'COCD'},
					{'name':'Closure of Account','id':'CLAC'},
					{'name':'Cashier Order Demand Draft Application','id':'CDDA'},
					{'name':'Cashier Order Demand Draft Cancellation','id':'CDDC'},
					{'name':'Cashier Order Demand Draft Refund','id':'CDDR'},
					{'name':'COE Bidding Application','id':'COEA'},
					{'name':'COE Bidding Updates','id':'COEU'},
					{'name':'Combined Statement Service','id':'CSTS'},
					{'name':'Commercial Card Appl (Corp)','id':'CMCC'},
					{'name':'Commercial Card Appl (Per)','id':'CMCP'},
					{'name':'CPF Letter Of Indemnity','id':'CPFL'},
					{'name':'CashPlus Appl','id':'CPAP'},
					{'name':'Limit Adjustmt (CashPlus)','id':'LACP'},
					{'name':'Reinstmt (CashPlus)','id':'RECP'},
					{'name':'Credit Card Appl','id':'CCAP'},
					{'name':'Supp Appl (CR)','id':'SACR'},
					{'name':'Debit Card Appl','id':'DCAP'},
					{'name':'DDA Updates','id':'DDAU'},
					{'name':'DDA Application (Taxi Driver)','id':'DDAA'},
					{'name':'Debt Security Account Opening Form','id':'DSAO'},
					{'name':'Template-Debt Security AC Opening Form','id':'TAOF'},
					{'name':'e-Alerts Application','id':'EALT'},
					{'name':'Ear Marking','id':'EAMK'},
					{'name':'Equity Linked Notes Agreement','id':'EMNA'},
					{'name':'Template-Equity Linked Notes Agreement','id':'TLNA'},
					{'name':'Equity Linked Structures','id':'EQLS'},
					{'name':'Equity Linked Structures - Buy/TO','id':'ELSB'},
					{'name':'Template-Equity Linked Structures','id':'TELS'},
					{'name':'Fixed Deposit Placement','id':'FDPT'},
					{'name':'Fixed Deposit Renewal','id':'FDRL'},
					{'name':'Fixed Deposit Withdrawal','id':'FDWL'},
					{'name':'Fund Transfer SGD','id':'FTSG'},
					{'name':'Handling of Suspense Online Transactions','id':'HSOT'},
					{'name':'HP Redemption','id':'HPRM'},
					{'name':'High Yield Account Savings Plan','id':'HYSP'},
					{'name':'High Yield Account Linking/Delinking','id':'HYLD'},
					{'name':'High Yield Account Label Maintenance','id':'HYLM'},
					{'name':'High Yield A/c Auto Top-Up/Transfer','id':'HYTT'},
					{'name':'Indemnities','id':'INDM'},
					{'name':'Infrastructure','id':'INFR'},
					{'name':'Insurance Application','id':'INAN'},
					{'name':'KYC Checklist (Fulfillment)','id':'KYCC'},
					{'name':'KYC Maintenance (Fulfillment)','id':'KYCM'},
					{'name':'LC Amendment','id':'LCAT'},
					{'name':'LC Application','id':'LCAP'},
					{'name':'LC Others','id':'LCOT'},
					{'name':'Letter of Reference','id':'LTOR'},
					{'name':'Legal Identification','id':'LEID'},
					{'name':'Linking of Account Relationship','id':'LOAR'},
					{'name':'Memorandum & Articles','id':'MEAR'},
					{'name':'Foreign Bank Master List','id':'FBML'},
					{'name':'MaxiYield Agreement','id':'MYAG'},
					{'name':'Template-MaxiYield Agreement','id':'TMYA'},
					{'name':'Master Board Resolution','id':'MBRN'},
					{'name':'BPM-Management Approval Paper','id':'BMAP'},
					{'name':'MaxiYield First Time Customer','id':'MYFC'},
					{'name':'MWP Renewal for MaxiYield','id':'MYRN'},
					{'name':'Other Banking Txn Alert/Subscribe','id':'OBTA'},
					{'name':'Package Application Form','id':'PKAF'},
					{'name':'Phone Banking Activation','id':'PBAN'},
					{'name':'Phone Banking Application','id':'PBAP'},
					{'name':'Phone Banking Updates','id':'PBUP'},
					{'name':'PG Amendment','id':'PGAM'},
					{'name':'PG Application','id':'PGAP'},
					{'name':'PIB Activation','id':'PIBN'},
					{'name':'PIB Application','id':'PIBA'},
					{'name':'PIB Application (Internet)','id':'PIAI'},
					{'name':'PIB Updates','id':'PIBU'},
					{'name':'PLC, PCard & Trvl AC Appl','id':'PPTA'},
					{'name':'Limit Adjustmt (PLC, PCard & Trvl AC)','id':'LATR'},
					{'name':'Reinstmt (PLC, PCard & Trvl AC)','id':'RTTR'},
					{'name':'Supp Appl (PLC)','id':'SUAP'},
					{'name':'Payment Received for Charge Off Accounts','id':'PRCA'},
					{'name':'Resolution','id':'RESO'},
					{'name':'Retail Note Application','id':'RNAF'},
					{'name':'Retail Note Cancellation','id':'RNCF'},
					{'name':'Retail Note Redemption','id':'RNRF'},
					{'name':'Structured Deposit Application','id':'SDAP'},
					{'name':'SGS Sell','id':'SGSL'},
					{'name':'SG Application','id':'SGAP'},
					{'name':'Standing Order Application','id':'SGOP'},
					{'name':'Standing Order Updates','id':'SGOU'},
					{'name':'SRS CPF Fixed Deposit Placement','id':'CPFP'},
					{'name':'Structured Deposits Placement','id':'SDPT'},
					{'name':'Structured Dep Early Termination Corp','id':'SDTC'},
					{'name':'Structured Dep Early Termination Indv','id':'SDTI'},
					{'name':'Dep T&C Ack Form','id':'DTAF'},
					{'name':'BPM-T&C Governing Accounts and Services','id':'TCAC'},
					{'name':'SGS Tender','id':'SGTR'},
					{'name':'Treasury Products Transaction Memos','id':'TPTM'},
					{'name':'TR Application','id':'TRAP'},
					{'name':'TT Amend/Cancel/Tracer','id':'TTAT'},
					{'name':'TT New','id':'TTNW'},
					{'name':'Telegraphic Transfer (Others)','id':'TTOT'},
					{'name':'Update of Signature','id':'UPOS'},
					{'name':'Unit Trust Application','id':'UNTA'},
					{'name':'Investment Application Form','id':'INAP'},
					{'name':'Investment Cancellation Form','id':'INCN'}
		        ]
		    });*/
			
			this.TransactionTypesChoiceListItems = [{name:"--Select All--", id:"0"}];
			
			this.DocumentTypesChoiceListItems = [{name:"--Select All--", id:"0"}];
			
			solution.retrieveAttributeDefinitions(lang.hitch(this, function(propDefs){
				console.log('Property Definitions retrieved --> ', propDefs);
				var docTypeFieldFound = false;
				baseArray.forEach(propDefs, lang.hitch(this, function(property){
					if((property.id === 'EWS_TransactionType') && (property.cardinality === 'LIST') && (typeof property.choiceList !== typeof undefined)){
						baseArray.forEach(property.choiceList.choices, lang.hitch(this, function(choiceListObject){
							this.TransactionTypesChoiceListItems.push({"name": choiceListObject.displayName, "id": choiceListObject.value});
						}));
					}
					
					if((property.id === 'DocumentType') && (property.cardinality === 'LIST') && (typeof property.choiceList !== typeof undefined)){
						docTypeFieldFound = true;
						baseArray.forEach(property.choiceList.choices, lang.hitch(this, function(choiceListObject){
							this.DocumentTypesChoiceListItems.push({"name": choiceListObject.displayName, "id": choiceListObject.value});
						}));
					}
				}));
				
				this.TransactionTypesStore = new Memory({
					data: this.TransactionTypesChoiceListItems
				});
				
				this.DocumentTypesStore = new Memory({
					data: this.DocumentTypesChoiceListItems
				});
				
				var filteringSelect2 = new FilteringSelect({
					name: "TransactionTypes",
					value: "0",
					store: this.TransactionTypesStore,
					searchAttr: "name"
				}, this.TransactionTypesBox);
				filteringSelect2.startup();
				
				if(docTypeFieldFound){
					var filteringSelect1 = new FilteringSelect({
			            name: "DocumentType",
			            value: "0",
			            store: this.DocumentTypesStore,
			            searchAttr: "name"
			        }, this.DocumentTypeBox);
					filteringSelect1.startup();
				}else{
					var textBox = new TextBox({
			            name: "DocumentType"
			        }, this.DocumentTypeBox);
					textBox.startup();
				}
			}));
			
			
			//Extend the Content Pane Class to render the results as per our custom format
			lang.extend(ContentListContentPane, {
				renderSearchResults: function(results){
					baseArray.forEach(results.items, function(item){
						//For setting Document Types
						if(item && item['attributes'] && item['attributes']['DocumentType'] && (typeof item['attributes']['DocumentType'] !== typeof undefined)){
							var valueToSearch = item['attributes']['DocumentType'];
							var storeObject = _this.DocumentTypesStore.get(valueToSearch);
							if(storeObject && (typeof storeObject !== typeof undefined))
								item['attributes']['DocumentType'] = storeObject.name;
						}
						
						
						//For setting Transaction Types
						if(item && item['attributes'] && item['attributes']['TransactionTypes'] && (typeof item['attributes']['TransactionTypes'] !== typeof undefined)){
							var modifiedTransactionCodes = [];
							baseArray.forEach(item['attributes']['TransactionTypes'], function(code){
								var storeObject = _this.TransactionTypesStore.get(code);
								if(storeObject && (typeof storeObject !== typeof undefined))
									modifiedTransactionCodes.push(storeObject.name);
								else
									modifiedTransactionCodes.push(code);
							});
							item['attributes']['TransactionTypes'] = modifiedTransactionCodes;
						}
					});
					this.ecmContentList.setResultSet(results);
				}
			});
		},
		
		_eoc_: null	
	});
});
