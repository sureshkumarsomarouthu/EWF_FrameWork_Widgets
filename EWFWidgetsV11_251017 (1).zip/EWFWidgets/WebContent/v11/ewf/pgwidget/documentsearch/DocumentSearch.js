define([ "dojo/_base/declare", 
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",		
	"v11/ewf/pgwidget/documentsearch/DocumentSearchContentPaneEventListener",
	"v11/ewf/pgwidget/documentsearch/dijit/DocumentSearchContentPane"], function(declare, BasePageWidget, 
		BaseActionContext, eventHandler, ContentPaneWidget){

    return declare("v11.ewf.pgwidget.documentsearch.DocumentSearch", [ContentPaneWidget, BasePageWidget, BaseActionContext], {
 
		contentPaneEventListener: null,

		postCreate: function(){
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane(this.getSolution());
		},
		
		_eoc_: null						
	});
});
