define(["dojo/_base/declare", 
	"dojo/_base/lang",
	"v11/ewf/util/Util",
	"dojo/_base/lang",
	"dojo/on",
	"dojo/dom-form",
	"dojo/_base/array",
	"dojox/lang/functional",
	"ecm/LoggerMixin"], 
	function(declare, lang, Util, lang, on, domForm, dojoArray, functional, LoggerMixin){
    return declare("v11.ewf.pgwidget.documentsearch.DocumentSearchContentPaneEventListener", [LoggerMixin], {
	
		contentPane: null,
		
		LOWEST_DATE_VALUE: "1900-01-01",
		
		LARGEST_DATE_VALUE: "9999-12-31",
		
		constructor: function(contentPane){
			this.contentPane = contentPane;
		},
		
		initContentPane: function(solution){
			this.contentPane.showContentNode();
			this.contentPane.buildFilteringSelects(solution);
			this.initListeners();
			this.onResetButtonClick();
		},
		
		initListeners: function(){
			on(this.contentPane.searchButton, 'click', lang.hitch(this, 'onSearchButtonClick'));
			on(this.contentPane.resetButton, 'click', lang.hitch(this, 'onResetButtonClick'));
		},
		
		onSearchButtonClick: function(){
			this.contentPane.onPublishEvent("icm.ClearContentListContent", null);
			this.contentPane.onPublishEvent("icm.ClearContentListContent", null);
			var _this = this;
			var payload = [
			               {"id": "LegalId", "value": ""}, 
			               {"id": "CustomerName1", "value": ""}, 
			               {"id": "CustomerName2", "value": ""}, 
			               {"id": "AccountNumber", "value": ""}, 
			               {"id": "BatchId", "value": ""}, 
			               {"id": "TransactionTypes", "value": ""}, 
			               {"id": "DocumentType", "value": ""}, 
			               {"id": "DateCreated", "value": ""},
			               {"id": "DateCheckedIn", "value": ""}
			              ];
			var fieldsDefinedInForm = ["LegalId", "CustomerName", "AccountNumber", "BatchId", "TransactionTypes", "DocumentType", "DocCreationDateFrom", "DocCreationDateTo"];
			if(this.contentPane.docSearchCriteriaForm.validate()){
				var formJson = domForm.toObject(this.contentPane.docSearchCriteriaForm.id);
				var anyValueEntered = false;
				functional.forIn(formJson, function(value){
					value += '';
					if(value.length > 0)
						anyValueEntered = true;
				});
				console.log('Data being verified --> ' + anyValueEntered, formJson);
				var payload = [];
				var payloadElement;
				if(anyValueEntered){
					var keys = functional.keys(formJson);
					dojoArray.forEach(keys, function(key){
						payloadElement = {};
						switch(key){
							case 'LegalId':
								payloadElement.id = key;
								payloadElement.value = formJson[key];
								payload.push(payloadElement);
								break;
							case 'AccountNumber':
								payloadElement.id = key;
								payloadElement.value = formJson[key];
								payload.push(payloadElement);
								break;
							case 'BatchId':
								payloadElement.id = key;
								payloadElement.value = formJson[key];
								payload.push(payloadElement);
								break;
							case 'TransactionTypes':
								payloadElement.id = key;
								if((formJson[key]+'') !== '0')
									payloadElement.value = formJson[key];
								else
									payloadElement.value = '';
								//payloadElement.value = formJson[key];
								payload.push(payloadElement);
								break;
							case 'DocumentType':
								payloadElement.id = key;
								if((formJson[key]+'') !== '0')
									payloadElement.value = formJson[key];
								else
									payloadElement.value = '';
								//payloadElement.value = formJson[key];
								payload.push(payloadElement);
								break;
							case 'CustomerName':
								payloadElement = {};
								payloadElement.id = 'CustomerName1';
								payloadElement.value = formJson['CustomerName'];
								payload.push(payloadElement);
								
								payloadElement = {};
								payloadElement.id = 'CustomerName2';
								payloadElement.value = formJson['CustomerName'];
								payload.push(payloadElement);
								break;
							case 'DocCreationDateFrom':
								payloadElement.id = 'DateCreated';
								if((formJson[key]+'').length > 0)
									payloadElement.value = formJson[key];
								else
									payloadElement.value = _this.LOWEST_DATE_VALUE;
								payload.push(payloadElement);
								break;
							case 'DocCreationDateTo':
								payloadElement.id = 'DateCheckedIn';
								if((formJson[key]+'').length > 0)
									payloadElement.value = formJson[key];
								else
									payloadElement.value = _this.LARGEST_DATE_VALUE;
								payload.push(payloadElement);
								break;
							default:
								break;
						}
					});
				}else{
					payload = [];
					payloadElement = {};
					payloadElement.id = 'DateCreated';
					payloadElement.value = _this.LOWEST_DATE_VALUE;
					payload.push(payloadElement);
					
					payloadElement = {};
					payloadElement.id = 'DateCreated';
					payloadElement.value = _this.LARGEST_DATE_VALUE;
					payload.push(payloadElement);
				}
				console.log('Data being sent as payload --> ', payload);
			}
			this.contentPane.onPublishEvent("icm.SendStoredSearchPayload", payload);
		},
		
		onResetButtonClick: function(){
			var _this = this;
			console.log('onResetButtonClick() --> ');
			this.contentPane.docSearchCriteriaForm.reset();
			this.contentPane.onPublishEvent("icm.ClearContentListContent", null);
		},
		
		_eoc_: null
	
	});
});
