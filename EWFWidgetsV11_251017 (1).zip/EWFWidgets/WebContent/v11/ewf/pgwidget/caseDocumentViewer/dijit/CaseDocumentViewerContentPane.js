define([ "dojo/_base/declare", 
    "dojo/text!./templates/CaseDocumentViewer.html", 
	"icm/base/_BaseWidget",
	"dojo/cookie",
	"dojo/json",
	"dojo/_base/lang",
	"dojo/dom-construct",
	"dojo/_base/connect",
	"dojo/_base/array",
	"v11/ewf/dialog/viewerdialog/CaseViewerDialog",
	"v11/ewf/dialog/virtualviewerdialog/VirtualCaseViewerDialog",
	"v11/ewf/util/Util"
	], function(declare, template, _BaseWidget, cookie, json, lang, domConstruct, connect, array, CaseViewerDialog, VirtualCaseViewerDialog,Util){
	return declare("v11.ewf.pgwidget.caseDocumentViewer.dijit.CaseDocumentViewerContentPane", [_BaseWidget], {
		templateString: template,
		_token : null,
		_payload : null,
		viewerRolename: null,
		primaryDocClass: '',
		
		constructor: function(){
			
		},
		postCreate:	function(){
			this.inherited(arguments);
			
			//Added by Purna for PBDocArchival changes - get the Primary document class name
			this.primaryDocClass = Util.getConstant("PRIMARY_DOCUMENT_CLASS");
			//End change
			
			this.viewerRolename= ecm.model.desktop.currentRole.name;
		},
		showDialog: function(payload, token){
			// need to write constants
			console.log("Entered into showDialog ",payload);
			var _this = this;
			_this._token = token;
			_this._payload = payload;
			if(payload.Case.retrieveCaseFolder)
			{
				payload.Case.retrieveCaseFolder(lang.hitch(this, '_displayDocuments'));
			}else
			{
				payload.Case.caseObject.caseFolder.retrieveFolderContents(false,lang.hitch(this, function(resultSet) {
						this._updateDocumentsList(resultSet);
			    	}), null, null, true);
			}
		},
		_displayDocuments: function(caseFolder)
		{
			console.log('caseFolder-->', caseFolder);
			caseFolder.retrieveFolderContents(false,lang.hitch(this, function(resultSet) {
						this._updateDocumentsList(resultSet);
			    	}), null, null, true);
			
		},
		_updateDocumentsList : function(resultSet){

			var _this = this;
			console.log('resultSet',resultSet);
			
			var folderContent = resultSet.items;
			
			var redactionMimeTypes = new Array("application/pdf", "image/bmp", "image/gif", "image/jp2", "image/jpeg", "image/jpg", "image/pjpeg", "image/png", "image/tiff", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
			var tempStore = {'identifier': 'docId', 'items': []};
			//var items = new Array();
			console.log('folderContent.length - >', folderContent.length);
			var itemLength = folderContent.length;
			if(folderContent.length != 0)
			{
				var count = 0;
				dojo.forEach(folderContent, function(item, index){
					console.log('item - > ',item);
					console.log('index - > ',index);
					
					// if performance is slow we need to move this call in to the plugin code to get No of Pages count for a each document.
					item.retrieveAttributes(lang.hitch(_this,function(attr){
						if(array.indexOf(redactionMimeTypes, item.mimetype) != -1)
						{
							var _noofPages = '';
							if(attr.attributes.NoOfPages != null && attr.attributes.NoOfPages != ''){
								_noofPages = attr.attributes.NoOfPages;
							}else{
								_noofPages ='NA';
							}
							var list = {
								docId : item.id,
								vsId : item.vsId,
								Document : item.name,
								mimetype : item.mimetype,
								addedBy : attr.attributes.LastModifier,
								PageCount : _noofPages
							};
							tempStore.items.push(list);
							
						}
						count = count + 1;
						console.log(count,' = ', itemLength);
						if(count == itemLength)
						{
							console.log('tempStore',tempStore);
							
							//Added by Purna - Always display the Primary document 1st in the grid. So sort the existing docList grid
							tempStore.items = _this.sortDocumentsList(tempStore.items);
							//End change by Purna
							
							_this.showPrintDialog(tempStore);
						}
						
					}));
							
				});	
			}else
			{
				alert('No Attachment to View and Print');
			}
		},
		
		showPrintDialog: function(tempStore){
			
			console.log("Entered into showPrintDialog ");
			var _this = this;
			var payload = _this._payload;
			var text = 'Print Document Viewer';
			var title = null;
			var dialog = null;
			var virtualDialog = null;
			var buttonsCollection = {};
			var viewViewerDialog = {};
			var caseReferenceNumber = '';
			var caseObject = '';
			if(payload.WorkItem){
				caseReferenceNumber = payload.WorkItem.caseObject.attributes.EWS_CaseReferenceNumber;
				caseObject = payload.WorkItem.caseObject
			}else{
				caseReferenceNumber =  payload.Case.caseObject.attributes.EWS_CaseReferenceNumber;
				caseObject = payload.Case.caseObject
			}
			var repositoryId = payload.Case.repository.id;
			viewViewerDialog.buttonLabel = "Submit";
			viewViewerDialog.disabled = true;
			viewViewerDialog.onExecute = lang.hitch(this, function() {
				console.log('button Clicked');
			});				
			buttonsCollection.view = viewViewerDialog;
			
			var _objectDataForDialog = {
				tempStore: tempStore,
				token: this._token,
				caseObject : caseObject,
				repositoryId : repositoryId,
				objectStoreName: this.solution.targetObjectStore.id,
				caseReferenceNumber: caseReferenceNumber
			};
			
			
			if(this.viewerRolename != "Branch Enquiry Operator"){
			
			dialog = new CaseViewerDialog({
				title: "Case Print : "+caseReferenceNumber, 
				text: text,
				objectDataForDialog : _objectDataForDialog,
				buttonsCollection: buttonsCollection,
				payload:payload,
				tempStore: tempStore,
				onCancel: lang.hitch(this, function() {
					dialog.hide();
				})
			});
			dialog.show();
			
			}
			else{
			
			virtualDialog = new VirtualCaseViewerDialog({
				title: "Case Print : "+caseReferenceNumber, 
				text: text,
				objectDataForDialog : _objectDataForDialog,
				buttonsCollection: buttonsCollection,
				payload:payload,
				tempStore: tempStore,
				onCancel: lang.hitch(this, function() {
					virtualDialog.hide();
				})
			});
			
			virtualDialog.show();
			
			
			}
			
			
			
		},
		
		//Added by Purna - Always display the Primary document 1st in the grid. So sort the existing docList grid
		sortDocumentsList: function(items) {
			if(items && items.length && items.length > 1) {
				for(var i=0; i<items.length; i++) {
					if(items[i] && items[i].docId && items[i].docId.indexOf(this.primaryDocClass) >= 0) {
						if(i == 0) {
							break;
						} else {
							console.log('Swapping Primary doc found at index: ' + i + ' to 0th index');
							var tempItem = items[i];
							items[i] = items[0];
							items[0] = tempItem;
							console.log('items after sorting:', items);
							break;
						}
					}
				}
			}
			return items;
		}
		//End change
	});
});
