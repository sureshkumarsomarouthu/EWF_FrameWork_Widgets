define(["dojo/_base/declare", 
	"dojo/_base/lang",
	"ecm/LoggerMixin"], 
	function(declare, lang,  LoggerMixin){
    return declare("v11.ewf.pgwidget.caseDocumentViewer.CaseDocumentViewerContentPaneEventListener", [LoggerMixin], {
	
		contentPane: null,
		
		constructor: function(contentPane){
			this.contentPane = contentPane;
		},
		
		initContentPane: function()	{
			this.contentPane.showContentNode();	
		},
		showDialogToViewDocuments: function(payload, token){
			this.contentPane.showDialog(payload, token);
		}
			
		 
	});
});
