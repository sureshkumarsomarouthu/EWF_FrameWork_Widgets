define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",
	"ecm/model/Request",
	"v11/ewf/pgwidget/caseDocumentViewer/CaseDocumentViewerContentPaneEventListener",
	"v11/ewf/pgwidget/caseDocumentViewer/dijit/CaseDocumentViewerContentPane",
	"dojo/query"
], function(declare, lang, BasePageWidget, BaseActionContext, Request, eventHandler, contentPaneWidget, query){

    return declare("v11.ewf.pgwidget.caseDocumentViewer.CaseDocumentViewer", [contentPaneWidget, BasePageWidget, BaseActionContext, Request], {
 
		postCreate: function(){
			
			if(dojo.getObject("HavePrintAccess")==undefined || dojo.getObject("CurrentUser")==undefined || this.getSolution().getTargetOS().userId != dojo.getObject("CurrentUser")){
				this.ummCall();
			}
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane();
		},
		
		handleViewDocuments: function(payload){
			var token = Request._security_token;
			this.contentPaneEventListener.showDialogToViewDocuments(payload, token);
		},
		
		ummCall: function(){
			var printRoleCheck = "Print Operator";
			dojo.setObject("HavePrintAccess","NoAccess");
			var roleCheckfunction = dojo.hitch(this, function(response) {
				console.dir(["umm response", response]);
				for(var i = 0; i < response.length; i++){
					if (response[i]==printRoleCheck){
						dojo.setObject("HavePrintAccess","HaveAccess");
						console.log("Have Print Access:ENABLE IT");	
						dojo.query("span[data-dojo-attach-point='containerNode']",this.page.domNode).forEach(function(node) {
							if(node.innerHTML == "Case Print"){
								node=node.parentNode;
								dijit.byId(node.id).setAttribute("disabled",false);
							}
						});
					}
				}
			});
			
			var userId = this.getSolution().getTargetOS().userId;
			dojo.setObject("CurrentUser", userId);
			var makeUMMCall = dojo.hitch(this,function(){
				var params = {};
				params.subUmmPath = encodeURIComponent("/uamusers/userroles?username="+userId);
				//Modified by Purna BEGIN change - EWFWidgetsPlugin v1.0 is deprecated use EWFWidgetsPluginv11 instead   
				ecm.model.Request.invokePluginService( 
					//"EWFWidgetsPlugin", //Commented by Purna
					"EWFWidgetsPluginv11", 
					"EWFUMMService",
					{
						requestParams: params,
						backgroundRequest:true,
						requestFailedCallback: function(errData, errMsg) {
							dojo.setObject("HavePrintAccess","Fail");							   
						},
						requestCompleteCallback: dojo.hitch(this,function(response){
							roleCheckfunction(response);
						})
				});
				//End change
			});
			makeUMMCall();
		}
		
	});
});
