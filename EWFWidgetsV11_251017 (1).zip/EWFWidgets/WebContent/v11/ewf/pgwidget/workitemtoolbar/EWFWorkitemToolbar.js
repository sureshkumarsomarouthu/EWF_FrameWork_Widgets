define([
    "dojo/_base/declare", 
	"dojo/_base/lang",
	"v11/ewf/pgwidget/workitemtoolbar/EWFWorkitemToolbarContentPane",
	"icm/pgwidget/workitemtoolbar/WorkitemToolbar"
], function(declare, lang, ContentPaneWidget, WorkitemToolbar){

    /**
     * @name v11.ewf.pgwidget.workitemtoolbar.EWFWorkitemToolbar
     * @class Class represents WorkitemToolbar widget
     */
    return declare("v11.ewf.pgwidget.workitemtoolbar.EWFWorkitemToolbar", [ContentPaneWidget, WorkitemToolbar], {
      /** @lends v11.ewf.pgwidget.workitemtoolbar.EWFWorkitemToolbar.prototype */
		toolbarAttachPoint: null,
		
  		constructor: function(){
			this.inherited(arguments);
        },
        
		//Modified the OOTB method hence overridden
        updateViewPaneByModel: function(model) {    
			var optionSettingModel = model.optionSetting;
        }
    });
});

