/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2014
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([ "dojo/_base/declare", 
	"dojo/text!./templates/WorkitemToolbarContentPane.html",
	"icm/pgwidget/workitemtoolbar/dijit/WorkitemToolbarContentPane",
	"dojo/dom-geometry",
	"dojo/dom-style",
	"v11/ewf/util/Util"
	], function(declare, template, ToolbarContentPane, domGeom, domStyle, Util){

    return declare("v11.ewf.pgwidget.workitemtoolbar.EWFWorkitemToolbarContentPane", [ToolbarContentPane], {

		//Point to our own template instead of the OOTB Toolbar template
        templateString: template,
        widgetsInTemplate: true,
        model: null,   
        modelType: null,
    	workItem: null,
    	_viewMode: false,
	    taskEditable: null,
		
		//Modified the OOTB method hence overridden
		updateHeaderInformation:function() {
			
			//Added by Purna for L&S - Display the case Ref Number based on widget setting
			var caseRefNumber = '';
			if(this.widgetProperties.showCaseRefNumber && this.workItem.propertiesCollection[Util.getConstant("CASE_REF_NUMBER_PROP")]){
				caseRefNumber = this.workItem.propertiesCollection[Util.getConstant("CASE_REF_NUMBER_PROP")].value;
			}
			//End change by Purna for L&S
			
			this.instruction = this.workItem.getInstruction() ||  this.resourceBundle["noInstructionsToDisplay"];
			this.stepNameText.innerHTML = idx.escapeHTML(this.workItem.getStepName()) || "";
			var subjectText = "";
			if(this.taskEditable !== null){
				this.stepNameText.innerHTML = idx.escapeHTML(this.taskEditable.getTaskName()) || "";
				var taskTypeObj = this.taskEditable.getTaskType();
				if ((taskTypeObj !== undefined) && (taskTypeObj !== null))
				{
					subjectText = idx.escapeHTML(taskTypeObj.name);
				}
			}else{
				
				//Modified by Purna for L&S - Append Case Ref Number if it's not blank  
				//this.stepNameText.innerHTML = idx.escapeHTML(this.workItem.getStepName()) || ""; //comment exiting line
				if(caseRefNumber){
					this.stepNameText.innerHTML = idx.escapeHTML(this.workItem.getStepName() + " | " + caseRefNumber) || caseRefNumber;
				}else{
					this.stepNameText.innerHTML = idx.escapeHTML(this.workItem.getStepName()) || "";
				}
				//End change by Purna for L&S
				
				subjectText = idx.escapeHTML(this.workItem.getSubject());
			}
			var deadline;
			if (this.workItem.getDeadline !== undefined)
			{
				deadline = this.workItem.getDeadline() || "";
			}else{
				deadline = "";
			}

			var overdueStatus;

			if (this.workItem.getOverdueStatus !== undefined)
			{
				overdueStatus = this.workItem.getOverdueStatus() || "";
			}else{
			   overdueStatus = "";
			}
			
			if(!deadline || deadline.length == 0) {
				if(overdueStatus == 2){
					this.deadline.innerHTML = '<span style="color:#898A8C;">'+this.resourceBundle["deadline"] + ":</span> " + this.resourceBundle["overdue"];
				}else{
					dojo.style(this.ddLineSep, "display", "none");
					this.deadline.innerHTML = "";
				}
			} else {
				var timeValue = icm.util.Util.getLocaleDate(deadline); 
				if (document.body.dir != "rtl") {
					this.formatDeadline = timeValue.replace(/\s/g, "&nbsp;");
				} else {
					this.formatDeadline =  timeValue; 
				}
				dojo.style(this.ddLineSep, "display", "inline-block");
				this.deadline.innerHTML = '<span style="color:#898A8C;">'+this.resourceBundle["deadline"] + ":</span> " + this.formatDeadline;
			}
			//Added by tara on 17.11.2016 -� removing extra space in work item tool bar� UI standardization 
			//Begin change
			var stepDetailsWidth = 0; 
			var stepNameSpan = domGeom.position(this.stepNameText,true);
			var ddLineSepDiv = domGeom.position(this.ddLineSep,true);
			var deadlineSpan = domGeom.position(this.deadline,true);
			var wfNameSepIdDiv = domGeom.position(this.wfNameSep,true);
			stepDetailsWidth = stepNameSpan.w + ddLineSepDiv.w + deadlineSpan.w + wfNameSepIdDiv.w + 15;
			var wrapTopToolbarNode = this.wrapTopToolbar.domNode;
			wrapTopToolbarNode.style.marginLeft = stepDetailsWidth+"px";
			wrapTopToolbarNode.style.marginTop = "-20px";
			//Button Alignment on Workitem tool bar
			var menuDiv = this.topToolbar.domNode.firstChild;
			var menuToolbarWdgt = dijit.byId(menuDiv.id);
			if(menuToolbarWdgt.toolbarColumn_left) {
				menuToolbarWdgt.toolbarColumn_left.style.width="30%";          
			}
			if(menuToolbarWdgt.toolbarColumn_right) {
				menuToolbarWdgt.toolbarColumn_right.style.width="70%";
			}			
			//added by tara-- end change			
		},
       
		destroy: function(){
    	   this.model = null;   
           this.modelType = null;
       	   this.workItem = null;
       	   this._viewMode = false;
   	       this.taskEditable = null;
   	       
   	       this.inherited(arguments);
		}
    });
});
