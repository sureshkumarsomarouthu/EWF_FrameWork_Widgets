/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2013
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
	"dojo/_base/declare",
    "icm/base/BasePageWidget",
	"icm/pgwidget/viewer/Viewer"
], function(declare, BasePageWidget, ICMViewer) {
	
	
	return declare("v11.ewf.pgwidget.auditviewer.AuditViewer", [ICMViewer], {
		
	
	});         
});
