define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"icm/pgwidget/viewer/Viewer",
	'ecm/widget/viewer/FilenetViewer',
	//'icm/pgwidget/viewer/dijit/NavigatorViewer',
	'ecm/widget/viewer/ContentViewer',
	"v11/ewf/model/ViewerItem",
	'dojo/_base/array', 
	'icm/util/Util',
	'icm/base/Constants',
	'dojo/date/locale',
	'dojo/mouse',
	'dojo/on',
	'dojo/dom-geometry',
	'dojo/dom-style',
	"dojox/lang/functional",
	"v11/ewf/util/Util",
	"ecm/model/Request",
	"dojo/request",
	'v11/ewf/icmoverrides/_EWFContentListDecoratorMixin',
	'v11/ewf/dialog/callbackchecklistdialog/CallbackCheckListDialog'
	], function(declare, lang, Viewer, FilenetViewer, ContentViewer, CustomViewerItem, baseArray, ICMUtil, Constants, dojoLocale, mouse, on, domGeom, domStyle, functional, Util, Request, request){

    return declare("v11.ewf.pgwidget.documentviewer.DocumentViewer", [Viewer], {
    	
    	resourceBundle: null,
		//navigatorViewer: null,
		action: "open",
		currentCaseGUID: "",
		currentWorkItemId: "",
		constants: Constants,
		isViewer: true,
		heightDescriptionNodeExternal: null,
    	
    	constructor: function() {
	 		
			if(dojo.getObject("HavePrintAccess")==undefined || dojo.getObject("CurrentUser")==undefined || ecm.model.desktop.userId != dojo.getObject("CurrentUser")){
				this.ummCall();
			}
			this.resourceBundle = icm.util.Util.getResourceBundle("viewer");
		},
    	
		ummCall: function(){
			var printRoleCheck = "Print Operator";
			//commented by Tara on 22/12/2016 for Case Print button enable/disable
			//dojo.setObject("HavePrintAccess","NoAccess");
			var roleCheckfunction = dojo.hitch(this, function(response) {
				console.dir(["umm response", response]);
				for(var i = 0; i < response.length; i++){
					if (response[i]==printRoleCheck){
						dojo.setObject("HavePrintAccess","HaveAccess");
						console.log("Have Print Access:ENABLE IT");	
						dojo.query("span[data-dojo-attach-point='containerNode']",this.page.domNode).forEach(function(node) {
							if(node.innerHTML =="Case Print"){
								node=node.parentNode;
								dijit.byId(node.id).setAttribute("disabled",false);
							}
						
						});
					}
				}
			});
			
			var userId = ecm.model.desktop.userId;
			dojo.setObject("CurrentUser", userId);
			var makeUMMCall = dojo.hitch(this,function(){
				var params = {};
				params.subUmmPath = encodeURIComponent("/uamusers/userroles?username="+userId);
				//Modified by Purna BEGIN change - EWFWidgetsPlugin v1.0 is deprecated use EWFWidgetsPluginv11 instead
				ecm.model.Request.invokePluginService( 
					//"EWFWidgetsPlugin", //Commented by Purna
					"EWFWidgetsPluginv11", 
					"EWFUMMService",
					{
						requestParams: params,
						backgroundRequest: true,
						requestFailedCallback: function(errData, errMsg) {
							dojo.setObject("HavePrintAccess","Fail");							   
						},
						requestCompleteCallback: dojo.hitch(this,function(response){
							roleCheckfunction(response);
						})
				});
				//End Change
			});
			makeUMMCall();
		},
		//added by suresh for select case event method is changed as part of 5.2.1 upgrade jira issue PEWFSGUPGS-133
		handleICM_SelectCaseEvent: function(payload) {	
				this.handleICM_SendCaseInfoEvent(payload);
			},	
		handleICM_SendCaseInfoEvent: function(payload){
			//console.log('ewf.pgwidget.documentviewer.DocumentViewer.handleICM_SendCaseInfoEvent() 1');
			if(!payload || !payload.caseEditable){
			    return;
			}
			//Call the parent methods
			//this._cacheCurrentCaseGUID(payload);
			
			//Custom Control from here
			var _this = this;
			
			//Clear the Viewer Content on receiving Payload.
			_this.handleICM_ClearContentEvent();
			
			if(payload.caseEditable){
				payload.caseEditable.getCase().retrieveCachedAttributes(lang.hitch(this, function(payload, caseObject){
					var docId = '', docFound=false;
					this.caseObject = caseObject;
					if(caseObject && caseObject._fullAttrsRetrieved){
						docId += "EWSDocument," + payload.caseEditable.getCase().attributes.ClassDescription.ObjectStoreIdentity + ",";
					}
					
					var docIdPropValue = caseObject.attributes["EWF_CTRLDocIdentifier"];
					
					if (!docIdPropValue || (typeof docIdPropValue === typeof undefined) || (docIdPropValue.indexOf(":") < 0)){
						docFound = false; 
					} else if((typeof docIdPropValue !== typeof undefined) && (docIdPropValue.indexOf(":") > 0)){ 
						docFound = true;
					}
					
					if(docFound){
						docId += docIdPropValue.substr(0, docIdPropValue.indexOf(":"));
						this._coordinate(payload);
						var template = docId.substr(0, docId.indexOf(","));
						var documentItem = new ecm.model.ContentItem({ 
		    				"repository": payload.caseEditable.getCaseType().getSolution().getTargetOS(),
		    				"id": docId,
		    				"template": template});
		    			//this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
		    			documentItem.retrieveAttributes(lang.hitch(this, function() {
							this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
						}), true, true);
					} else{
						//Fallback option to identify the primary doc by navigating through all the docs in Case Folder
						if(payload && payload.caseEditable){
							var caseItem = payload.caseEditable.getCase();
							if(caseItem && (caseItem !== null)){
								caseItem.retrieveCaseFolder(lang.hitch(this, this.openInitCaseFolder, payload));
							}
						}
					}
				}, payload));
			}
		},
		
		openInitCaseFolder: function(payload, initCaseFolder){
			//console.log('ewf.pgwidget.documentviewer.DocumentViewer.openInitCaseFolder() 1');
			var _this = this;
			initCaseFolder.retrieveFolderContents(false, function(results){
				if(results && results.items && results.items.length > 0){
					var matchFound = false;
					baseArray.forEach(results.items, function(item){
						if(item.template === 'EWSDocument' && !matchFound){
							matchFound = true;
							_this._coordinate(payload);
							_this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
						}
						if(matchFound)
						return;
					});
					if(!matchFound){
						baseArray.forEach(results.items, function(item){
							if(item.template === 'SupportingDocument' && !matchFound){
							    matchFound = true;
								_this._coordinate(payload);
								_this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
							}
							if(matchFound)
							return;
						});
					}
					if(!matchFound){
						baseArray.forEach(results.items, function(item){
							if(item.template === 'MigratedBIWS' && !matchFound){
							    matchFound = true;
								_this._coordinate(payload);
								_this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
							}
							if(matchFound)
							return;
						});
					}
				}
			});
		},
		
		handleICM_SendWorkItemEvent: function(payload){
			if(!payload || !payload.workItemEditable){
			    return;
			}
			//Allow the default Methods to execute here
			//this._cacheCurrentWorkItemId(payload);
			this._cache_currentWorkItemId(payload);
			//In case this is getNext
			//this.createViewer();
			
			//Clear the Viewer Content on receiving Payload.
			this.handleICM_ClearContentEvent();
			
			payload.workItemEditable.getCase().retrieveCachedAttributes(lang.hitch(this, function(payload, caseObject){
				var docId = '', docFound=false;
				this.caseObject = caseObject;
				if(caseObject && caseObject._fullAttrsRetrieved){
					docId += "EWSDocument," + payload.workItemEditable.getCase().attributes.ClassDescription.ObjectStoreIdentity + ",";
				}
				
				var docIdPropValue = caseObject.attributes["EWF_CTRLDocIdentifier"];
				
				if (!docIdPropValue || (typeof docIdPropValue === typeof undefined) || (docIdPropValue.indexOf(":") < 0)){
					docFound = false; 
				} else if((typeof docIdPropValue !== typeof undefined) && (docIdPropValue.indexOf(":") > 0)){ 
					docFound = true;
				}
				
				if(docFound){
					docId += docIdPropValue.substr(0, docIdPropValue.indexOf(":"));
					this._coordinate(payload);
					var template = docId.substr(0, docId.indexOf(","));
	    			var documentItem = new ecm.model.ContentItem({ 
	    				"repository": payload.workItemEditable.getCaseType().getSolution().getTargetOS(),
	    				"id": docId,
	    				"template": template});
	    			//this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
	    			documentItem.retrieveAttributes(lang.hitch(this, function() {
						this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
					}), true, true);
				} else{
					//Fallback option to identify the primary doc by navigating through all the docs in Case Folder
					if(payload && payload.workItemEditable){
						var caseItem = payload.workItemEditable.getCase();
						if(caseItem && (caseItem !== null)){
							caseItem.retrieveCaseFolder(lang.hitch(this, this.openInitCaseFolder, payload));
						}
					}
				}
			}, payload));
		},
		
		afterCaseCommentAdded: function(comments){
			//do Nothing (if Success)
		},
		
		handleICM_OpenDocumentEvent: function(payload){
			//Override the default behavior methods
			var _this = this;
			if(dojo.getObject("HavePrintAccess")=="HaveAccess"){
				console.log("Have Print Access :ENABLE IT");
			}else{
				console.log("No Print Access:DISABLE IT");	
				dojo.query("span[data-dojo-attach-point='containerNode']",this.page.domNode).forEach(function(node) {
					if(node.innerHTML =="Case Print"){
						node=node.parentNode;
						dijit.byId(node.id).setAttribute("disabled",true);
					}
				});					
			}

			//Added by Purna for OTT V11 Upgrade Begin change - remove the split toolbars for space for OTT
			if(this.solution.prefix == "EWF") {
				lang.extend(ContentViewer, {
					showLayouts: false,
					_ifEnablePI: false
				});
			} else {
				lang.extend(ContentViewer, {
					showLayouts: true,
					_ifEnablePI: true
				});
			}
			//End change
			
			//Extend the Navigator Method's resize method to work properly if the height is auto
		/*	lang.extend(NavigatorViewer, {
				resize: function(){
					if (this.contentViewer && this.openedItems) {
		                var height = this.icmViewer.domNode.style["height"];
		                var heightContentNode = null;
		                if (this.heightContentNode) {
		                    heightContentNode = parseInt(this.heightContentNode);
		                } else {
		                    var preferredHeight = this.icmViewer.getWidgetAttributes().getItemValue("PreferredHeight");
		                    
		                    if(preferredHeight === "auto"){
		                    	try{
		                    		
		                    		//Commented by Purna for OTT V11 Upgrade Begin change - Use the max height possible instead of 98% of the height
		                    		//preferredHeight = this.icmViewer.domNode.parentNode.clientHeight * 0.98;
		                    		preferredHeight = this.icmViewer.domNode.parentNode.clientHeight;
		                    		//End change
		                    		
		                    	}catch(e){
		                    		preferredHeight = domGeom.getContentBox(this.icmViewer.domNode).w;
		                    	}
		                    }
		                    if (heightContentNode == null) {
		                        heightContentNode = parseInt(preferredHeight);
		                    }else if ((height === "auto") || (preferredHeight === "auto")){
		                        heightContentNode = parseInt(preferredHeight);
		                    }else if (height.indexOf("px") > -1) {
		                        heightContentNode = parseInt(height);
		                    }else if (height.indexOf("%") > -1) {
		                        heightContentNode = height;
		                    }
		                    
		                }
		                if (heightContentNode != null) {
		                    if (typeof heightContentNode == "string" && heightContentNode.indexOf("%") > -1) {
		                        domStyle.set(this.contentNode, "height", "100%");
		                        dojo.hitch(this, this._resize)("100%");
		                    } else {
		                        domStyle.set(this.contentNode, "height", heightContentNode + "px");
		                        
		                        //Commented by Purna for OTT V11 Upgrade Begin change - Use the max height possible for viewer
		                        //domStyle.set(this.icmViewer.domNode, "height", heightContentNode + "px");
		                        //dojo.hitch(this, this._resize)(heightContentNode + "px");
		                        domStyle.set(this.icmViewer.domNode, "height", (heightContentNode - 5) + "px");
		                        dojo.hitch(this, this._resize)((heightContentNode - 5) + "px");
		                        //End change
		                    }
		                }
		            }
				}
			}); */
			
			lang.extend(FilenetViewer, {
				/* Override _onFnViewerEvent() to capture the Print Event*/
				_onFnViewerEvent: function(n){
					//console.log('FilenetViewer._onFnViewerEvent() 1');
					if(n == 27){
						this.logDebug("_onFnViewerEvent", "FileNet Viewer printing completed.");
						//Generate the Case Comment manually
						var currentTime = dojoLocale.format(new Date(), {datePattern: 'dd/MM/yyyy', selector: 'date'});
						
						/* + ' (GMT' + dojoLocale.format(new Date(), {datePattern: 'Z', selector: 'date'}) + ')';*/ 
						/*Uncomment this if Timezone to be appended to the comment date*/
						
						var commentText = "Action: Print - Document: " + this._item.name + " Action Time: " + currentTime + " - UserID: " + _this.solution.getTargetOS().userId;
						
						
						//Modified by Purna for defect id 6068 - Introducing new service for adding comments and calling the new service instead of the existing OOTB service
						//_this.caseObject.addCaseComment(icm.base.Constants.prototype.CommentContext.CASE, commentText, lang.hitch(_this, 'afterCaseCommentAdded'));
						
						//var reqUrl = "/v11/ewf/rest/commentservice/case?caseId=" + _this.caseObject.id + "&commentText=" + commentText;
						var postData = {"caseId": _this.caseObject.id, "commentText": commentText};
						var reqUrl = "/v11/ewf/rest/commentservice/case";
						request.post(reqUrl, {
							handleAs: 'json',
							data: postData
						}).then(lang.hitch(this, function(response){
							//do nothing
						}), lang.hitch(this, function(err){
							console.log(err);
						}));
						//End change by Purna
					}
					
					
					//Default Content from FilenetViewer.js for this method
					var methodName = "_sendFnViewerSignal";
					this.logEntry(methodName);
					this.lastEvent = n;
					this.logDebug(methodName, "Received FileNet Viewer event: " + n);

					switch (n) {
					case 5:
						this.logDebug(methodName, "FileNet Viewer opened the document");
						this._annotTooltips = {};
						this.onDocumentLoaded();
						//Add Case Parameters to the Page Header while print here 
						var applet = this._getFnViewerApplet();
						if(applet){
							var currentTime = dojoLocale.format(new Date(), {datePattern: 'dd/MM/yyyy', selector: 'date'});
							var textToPrintToHeader = "$page #$of## ";
							if(_this && _this.caseObject && _this.caseObject._fullAttrsRetrieved){
								if(_this.caseObject.caseTitle)
									textToPrintToHeader += "Case:" + _this.caseObject.caseTitle + " ";
								if(_this.caseObject.attributes && _this.caseObject.attributes['EWS_CaseStatus'])
									textToPrintToHeader += _this.caseObject.attributes['EWS_CaseStatus'] + " ";
								textToPrintToHeader += "User: " + _this.solution.getTargetOS().userId + " on " + currentTime + ", ";
								if(this._item.name)
									textToPrintToHeader += this._item.name + ".";
							}
							if(this._item && this._item.attributes && this._item.attributes.DocumentType && (this._item.attributes.DocumentType !== '1079'))
								applet.setPrintHeader(textToPrintToHeader);
							else
								applet.setPrintHeader("");
							
							//Added by Purna for L&S on 09/02/2017 - doc is PrimaryDoc & Enable Redactions is Yes add redactions on the doc 	
							if(this._item.template == 'EWSDocument' && _this.widgetProperties.enableRedactions && _this.widgetProperties.enableRedactions == 'Yes'){
								_this.applyRedactions(applet);
							}
							//End change by Purna
						}
						break;
					case 57:
						this.logDebug(methodName, "FileNet Viewer printing started.");
						this._fnViewerPrinting = true;
						break;
					case 26:
					case 27:
						this.logDebug(methodName, "FileNet Viewer printing completed.");
						this._fnViewerPrinting = false;
						break;
					case 61: // document failed to load.
						this.logDebug(methodName, "FileNet Viewer failed to load the document");
						this.onDocumentLoaded();
						this._showErrorDialog("viewer_document_load_failed_error");
						break;
					case 21: // focus out of the Applet
						this.logDebug(methodName, "Focus out of the applet");
						this.onViewerFocusOut();
						break;
					case 24:
						this.logDebug(methodName, "Saving FileNet Viewer annotations completed.");
						if (this.saveCompleted != null) {
						    this._annotTooltips = {};
							this.logDebug(methodName, "Calling saveCallback");
							this.saveCompleted();
							this.saveCompleted = null;
							this.onDirty(false);
						}
						// Don't break - fall through to case 33...
					case 33:
						this.logDebug(methodName, "Calling onDirty(false)");
						this._annotTooltips = {}; //added by Suresh (MITS) for MY Upgrade
						this.onDirty(false);
						break;
					case 32:
						this.logDebug(methodName, "Calling onDirty(true)");
						this._annotTooltips = {};
						this.onDirty(true);
						//added by Suresh (MITS) for MY Upgrade
						break;
					case 74:
						this._loadTooltip(n, text, data, callbackId);
						//end added by Suresh (MITS) for MY Upgrade
						break;
					default: // assume it is a save completed.
						break;
					}

					this.logExit(methodName);
				},
				
				/* Override showItem() to redirect the viewer to EWF Custom Viewer*/
				showItem: function() {
					//console.log('FilenetViewer.showItem() 1');
					var methodName = "showItem";
					this.logEntry(methodName);
					
					var origSrc = this._src;
					if(origSrc.indexOf('/navigator/viewers/filenetViewer.jsp') > -1){
						this._src = origSrc.replace('/navigator/viewers/filenetViewer.jsp', '/EWFWidgetsv11/v11/ewf/viewer/filenetViewer.html');
						this._src = this._src + '&useEWFViewer=true';
					}
					if(dojo.getObject("HavePrintAccess")!="HaveAccess"){
						_this.widgetProperties.Permission='Read';
					}
					if(_this.widgetProperties && _this.widgetProperties.Permission){
						if(!((this._src+'').indexOf('&widgetPermission=') > -1))
							this._src = this._src + '&widgetPermission=' + _this.widgetProperties.Permission;
					}
					if(_this.solution && _this.solution.prefix)
					{
						if(!((this._src+'').indexOf('&annotatePermission=') > -1)){
							var annotaionEnable  = _this.checkAnnotaionEnable();
							this._src = this._src + '&annotatePermission=' + annotaionEnable;
							
						}
					}
					
					//Added by Purna for L&S on 09/02/2017 - Enable/Disable Show/Hide annotations button based on widget setting
					var showHideAnnotations = true;
					if(_this.widgetProperties && _this.widgetProperties.enableHideAnnotations && _this.widgetProperties.enableHideAnnotations == "No"){
						showHideAnnotations = false;
					}
					if(!((this._src+'').indexOf('&showHideAnnotations=') > -1))
						this._src = this._src + '&showHideAnnotations=' + showHideAnnotations;
					//End change by Purna
					
					if (this._loadedSrc != this._src) {
						this._isLoading = true;
						var launched = false;
	
						if (this._itemLaunched) { // Applet should already exist.
							var applet = this._getFnViewerApplet();
							if (applet) {
								applet.setPrintButtons(false);
								this.logDebug(methodName, "FnViewerApplet found");
								var launcher = this._getFnViewerLauncher();
								if (launcher != null && launcher.openDocument) {
									var thisItem = this._item;
									if (thisItem.attributes.ContentElementsPresent || thisItem.repository.type != "p8") {
										this._recycleFnViewer(launcher, thisItem, this.viewerDef.getDocUrl(thisItem), this._pageNumber);
									} else {
										thisItem.retrieveAttributes(lang.hitch(this, function(retrievedItem) {
											this._recycleFnViewer(launcher, thisItem, this.viewerDef.getDocUrl(thisItem), this._pageNumber);
										}), false);
									}
									this._loadedSrc = this._src;
									launched = true;
								}
							} else {
								this._itemLaunched = false;
							}
						}
	
						if (!launched) {
							this.logDebug(methodName, "Reloading the iframe");
							this._loadSource(this._src);
						}
					}
	
					this.logExit(methodName);
				},
				
				/* Override _loadSource() to use the CustomViewerItem which does the redirection*/
				_loadSource: function(url) {
					//console.log('FilenetViewer._loadSource() 1');
					var methodName = "_loadSource";
					this.logEntry(methodName);
					this._isLoading = true;
					this._initializeIframe();
					var frameDoc = this._viewerIframe.contentWindow.document;
					CustomViewerItem.loadSecure(this._viewerIframe.contentWindow, url);
					this._loadedSrc = url;
					this.logExit(methodName);
				}
			});
			
			//this.createViewer();
			this.build();
			var action;
			if(payload && payload.action) {
				action = payload.action;
			} else { action = this.action; }
			if(payload && payload.contentItem)
				//this.navigatorViewer && this.navigatorViewer.show && this.navigatorViewer.show(payload.contentItem, action, lang.hitch(this, function() { this.showContentNode(); this.resize(); }));
				this.show(payload.contentItem, action);
			else 
				return;
		},
		
		//Method added by Purna for applying redactions on the document
		applyRedactions: function(applet){
			var redactionsInfoField = Util.getConstant("REDACTIONS_CASE_FIELD");
			if(this.caseObject.attributes && this.caseObject.attributes[redactionsInfoField]) {
				var redactionsInfo = this.caseObject.attributes[redactionsInfoField];
				if(redactionsInfo && redactionsInfo.length > 0) {
					console.log('Applying the redactions on the Image', redactionsInfo);
					try{
						var imageWidth = applet.getImageWidth();
						var imageHeight = applet.getImageHeight();
						var xResolution = applet.getXResolution();
						var yResolution = applet.getYResolution();
						console.log('Width: ',imageWidth,' Height: ',imageHeight,' XRes: ',xResolution,' YRes: ',yResolution);
						
						baseArray.forEach(redactionsInfo, function(redactData){
							var redactDataJson = dojo.fromJson(redactData);
							var coordinates = redactDataJson.coordinates;
							var coordinatesArr = coordinates.split(",");
							var x = coordinatesArr[0]/xResolution;
							var y = coordinatesArr[1]/yResolution;
							var width = (coordinatesArr[2] - coordinatesArr[0])/xResolution;
							var height = (coordinatesArr[3] - coordinatesArr[1])/yResolution;
							var pageNo = redactDataJson.pageno;
							var name = redactDataJson.name;
							console.log('x: ',x,' y: ',y,' width: ',width,' height: ',height,' page: ',pageNo,' name: ',name);
							applet.addAnnotation("[REDACT]<P>PAGE="+pageNo+"<P>EDIT=0<P>X="+x+"<P>Y="+y+"<P>WIDTH="+width+"<P>HEIGHT="+height+"<P>LABEL="+name+"<P>");
						});
					}catch(e){
						console.error('Exception occurred while doing Redactions. Destroy viewer', e);
						this.destroyContentViewer();
						var msgDialog = new BaseDialog({
							contentString: "<b>" + resources.Actions.redactionFailedMsg + "<br><br>Error Information:</b> " + e.stack,
							cancelButtonLabel: 'Close',
							title: 'Error'
						});
						msgDialog.show();
					}
				}else{
					console.debug('REDACTIONS_CASE_FIELD is Empty on case ', redactionsInfo);
				}
			}else{
				console.debug('REDACTIONS_CASE_FIELD is missing on case type', redactionsInfoField);
			}
		},
		
		//added by rahul to check annotation should enable or disable
		checkAnnotaionEnable : function(){
			console.log('Entered into checkAnnotaionEnable');
			var _this = this;
			var annotateCheck = false;
			var curSolutionPrefix = _this.solution.prefix;
			var solutonPrefixes = Util.getConstant("EWF_ANNOTATION_ENABLE");
			if(solutonPrefixes && solutonPrefixes != undefined && solutonPrefixes != null && solutonPrefixes != ""){
				functional.forIn(functional.keys(solutonPrefixes), function(prefixes){
					if(curSolutionPrefix != null && curSolutionPrefix!= "" && prefixes != undefined  && prefixes != null && curSolutionPrefix === prefixes){
						
						//Added by Purna for L&S - Enable annotation toolbar for SNV if trans type is from list in constants
						//annotateCheck = solutonPrefixes[prefixes]; //Comment existing logic and write new
						if(solutonPrefixes[prefixes] == "true" || solutonPrefixes[prefixes] == "false"){
							annotateCheck = solutonPrefixes[prefixes];
						}else{
							var jsonKeysValObj = solutonPrefixes[prefixes];
							functional.forIn(functional.keys(jsonKeysValObj), function(jsonKey){
								if(_this.caseObject.attributes && _this.caseObject.attributes[jsonKey]){
									var fieldVal = _this.caseObject.attributes[jsonKey];
									var valuesArr = jsonKeysValObj[jsonKey];
									if(valuesArr && fieldVal && baseArray.indexOf(valuesArr, fieldVal) != -1 && _this.widgetProperties.enableHideAnnotations &&
										_this.widgetProperties.enableHideAnnotations == "Yes"){
										annotateCheck = "true";
									}
								}
							});
						}
						//End change by Purna for L&S
					}
				});
			}
			return annotateCheck;
		},
		//end
		handleICM_ClearContentEvent: function() {
			//console.log('DocumentViewer.handleICM_ClearContentEvent() 1');
			//this.currentCaseGUID = "";
			//this.currentWorkItemId = "";
			//this.reset();
			    this.logEntry("handleICM_ClearContentEvent");
				this._currentCaseGUID = "";
				this._currentWorkItemId = "";
				this.destroyContentViewer();
				this.hideContentNode();
				this.logExit("handleICM_ClearContentEvent");
		},
		
		_cacheCurrentCaseGUID: function(payload) {
			//console.log('DocumentViewer._cacheCurrentCaseGUID() 1');
			if (payload == null) {
				this.currentCaseGUID = "";
			}
			else {
				if(!payload.caseEditable) {
					return;
				}
				var currentCaseGUID = payload.caseEditable.getCase().id;
				if (this.currentCaseGUID.length > 0 && this.currentCaseGUID != currentCaseGUID) {
					this.reset();
				}
				this.currentCaseGUID = currentCaseGUID;
			}
		},
		//added by suresh as part of 5.2.1 upgrade
		_cache_currentWorkItemId: function(payload) {
				this.logEntry("_cache_currentWorkItemId");
				if (payload == null) {
					this._currentWorkItemId = "";
				}
				else {
					var currentWorkItemId = payload.workItemEditable.id;
					if (this._currentWorkItemId.length > 0 && this._currentWorkItemId != currentWorkItemId) {
						this.destroyContentViewer();
						this.hideContentNode();
					}
					this._currentWorkItemId = currentWorkItemId;
				}
				this.logExit("_cache_currentWorkItemId");
			},

		_cacheCurrentWorkItemId: function(payload) {
			//console.log('DocumentViewer._cacheCurrentWorkItemId() 1');
			if (payload == null) {
				this.currentWorkItemId = "";
			}
			else {
				var currentWorkItemId = payload.workItemEditable.id;
				if (this.currentWorkItemId.length > 0 && this.currentWorkItemId != currentWorkItemId) {
					this.reset();
				}
				this.currentWorkItemId = currentWorkItemId;
			}
		},

		_coordinate: function(payload) {
			//console.log('DocumentViewer._coordinate() 1');
			if (payload != null && payload.coordination) {
				payload.coordination.participate(this.constants.CoordTopic.BEFORECANCEL, lang.hitch(this, this._beforeCancelCallback));
				payload.coordination.participate(this.constants.CoordTopic.CANCEL, lang.hitch(this, this._cancelCallback));
			}
		},

		_beforeCancelCallback: function(context, complete, abort) {
			this.logEntry("_beforeCancelCallback");
				if (this.isDirty()) {
					abort({"message": this._resourceBundle.viewer_unsavedData});
				}
				else {
					complete();
				}
				this.logExit("_beforeCancelCallback");
		},

		_cancelCallback: function(context, complete, abort) {
			//console.log('DocumentViewer._cancelCallback() 1');
			complete();
		},
		
		reset: function() {
			//console.log('DocumentViewer.reset() 1');
			//this.navigatorViewer && this.navigatorViewer.reset && this.navigatorViewer.reset();
			this.destroyContentViewer();
			this.hideContentNode();
		},
		
		resize: function(){
			//console.log('DocumentViewer.resize() 1');
			//this.navigatorViewer && this.navigatorViewer.resize && this.navigatorViewer.resize();
			this.logEntry("resize");
			    	console.log("call resize method");
			    	if (this.contentViewer && this._openedItems) {
			    		var height = this.domNode.style["height"];
			    		var heightNode = this._getNodeHeight(height);
			    		
		    			if (heightNode != null) {
				    		if (typeof heightNode == "string"&& heightNode.indexOf("%") > -1) {
				    			domStyle.set(this.contentNode, "height", "100%");
				    			domStyle.set(this.contentViewer.domNode, "height", "100%");
				    		}
				    		else {
				    			domStyle.set(this.contentNode, "height", heightNode + "px");
				    			domStyle.set(this.domNode, "height", heightNode + "px");
								domStyle.set(this.contentViewer.domNode, "height", heightNode + "px");	
				    		}
				    		this.contentViewer.startup();
							this.contentViewer.layout();	
		    			} 		
			    	}
			    	this.logExit("resize");
		},
		
		_getNodeHeight: function(height) {
			    	this.logEntry("_getNodeHeight");
			    	console.log("call _getNodeHeight");
			    	var heightNode;
		    		if (this._heightExternalNode) {
	    				// Custom component. Custom component such as dialog must pass an object to constructor like {height: "400px"} and then call build(node) passing it container node.
	    	    		heightNode = parseInt(this._heightExternalNode);
		    		}
		    		else {
	    				// ICM Page widget 
		    			var preferredHeight = parseInt(this.getWidgetAttributes().getItemValue("PreferredHeight"));
		    			
	    	    		if (preferredHeight === "auto") {
	    	    		     console.log("===if preferredHeight is auto ===");
	    	    			//heightNode = parseInt(preferredHeight);
	    	    				try{
		                    		 preferredHeight = this.domNode.parentNode.clientHeight * 0.98;
		                    		
		                    	}catch(e){
		                    		preferredHeight = domGeom.getContentBox(this.domNode).w;
		                    	}
	    	    		}else{
	    	    		       try{
	    	    		            preferredHeight = this.domNode.parentNode.clientHeight * 0.98;
	    	    		           }catch(e){
		                    		      preferredHeight = domGeom.getContentBox(this.domNode).w;
		                    	           }
	    	    		}
	    	    		if (height.indexOf("px") > -1) {
	    	    			heightNode = parseInt(height);
	    	    		}
	    	    		if (height.indexOf("%") > -1) {
	    	    			heightNode = height;
	    	    		}
	    	    		if (heightNode == null) {
	    	    			heightNode = parseInt(preferredHeight);
	    	    		}
	    	    		if((height === "auto") || (preferredHeight === "auto")){
		                        heightNode = parseInt(preferredHeight);
		                    }
		    		}
		    		this.logExit("_getNodeHeight");
		    		return heightNode;
			    },	
		
		isDirty: function(){
			//console.log('DocumentViewer.isDirty() 1');
		/*	var viewerStatus;
			if(this.navigatorViewer && this.navigatorViewer.contentViewer && this.navigatorViewer.contentViewer.getViewersStatus)
				viewerStatus = this.navigatorViewer.contentViewer.getViewersStatus();
			return viewerStatus && viewerStatus.mainStatus && (viewerStatus.mainStatus.length > 0); */
		},
		
		cleanUp: function(){
			//console.log('DocumentViewer.cleanUp() 1');
			//this.navigatorViewer && this.navigatorViewer.destroy && this.navigatorViewer.destroy();
			//delete this.navigatorViewer;
			
			//this.currentCaseGUID = "";
			//this.currentWorkItemId = "";
			
			this.destroyContentViewer();
			this.hideContentNode();
		},
		
		_eoc_:null
	});
});