define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"dojo/dom-class",
	"v11/ewf/base/Constants",
    "dojo/text!./templates/CustomCaseDataWidget.html", 	
	"icm/base/_BaseWidget",
	"icm/base/Constants",
	"icm/model/PropertyEditable",
	"v11/ewf/widget/fields/Fields",
	"v11/ewf/util/Util",
	"dojo/aspect",
	"icm/model/properties/controller/ControllerManager"
	], function(declare, lang, domClass, Constants, template, _BaseWidget, icmConstants, PropertyEditable, Fields, Util, aspect, ControllerManager){
	return declare("v11.ewf.pgwidget.customcasedata.dijit.CustomWidgetContentPane", [_BaseWidget], {
		
		templateString: template,
		widgetsInTemplate: true,	
		properties: null,
		workItemEditable: null,
		coordination: null,
		caseType: null,

		constructor: function(){
			this.fieldsWidget = new Fields();
		},

		postCreate:	function(){
			this.inherited(arguments);			
		},
		 
	    initializeFieldsProperties: function() {
			var workItem = this.workItemEditable.getWorkItem();
			this.caseType = this.workItemEditable.getCaseType().id;
			this.stepName = workItem.getStepName();
			this.solutionPrefix = this.workItemEditable.getCaseType().solution.prefix;
			var caseTypeConstants, fieldSymName, propertyName, attrDef, value, modesValue;	
			
			//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
			//caseTypeConstants = Util.getConstant(this.caseType, this.solutionPrefix);
			caseTypeConstants = Util.getConstant(this.caseType, this.solutionPrefix, this.workItemEditable);
			//End
			
			// Create PropertyEditable objects
			workItem._initializePropertiesCollectionFromAttributes();
			
			// Update the WorkItemEditable object with the added properties
			var otherParams = {};
			otherParams.modifiable = true;
			otherParams.parentContext = this.workItemEditable._propertiesParentContext;	
			//otherParams.provider = "F_CaseActivity";
			otherParams.provider = "F_CaseFolder";		
			this.fields = caseTypeConstants[this.stepName]['fields'];
			this.modes = caseTypeConstants[this.stepName]['modes'];
			for (var i = 0; i < this.fields.length; i ++) {	
				fieldSymName = this.fields[i];
				propertyName = fieldSymName
				modesValue = this.modes[i];
				this.solution.attributeDefinitionsById[propertyName]['readOnly'] = modesValue;
				attrDef = this.solution.attributeDefinitionsById[propertyName];	
				otherParams.value = workItem.attributes[propertyName];
				 //Modified By Gopi As part of ICM 5.2.1 Upgrade			
				var property = PropertyEditable._createProperty(propertyName, attrDef.name, attrDef, otherParams,this.workItemEditable.repository);
				this.workItemEditable.propertiesCollection[property.id] = property;
				
				// Mixin the additional definitions
				//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
				//this.workItemEditable.propertiesCollection[propertyName] = dojo.mixin(this.workItemEditable.propertiesCollection[propertyName], Util.getConstant("EWF_FieldAttributes",this.solutionPrefix)[fieldSymName]);
				this.workItemEditable.propertiesCollection[propertyName] = dojo.mixin(this.workItemEditable.propertiesCollection[propertyName], 
					Util.getConstant("EWF_FieldAttributes",this.solutionPrefix, this.workItemEditable)[fieldSymName]);
				//End	
			}

			// this is to update the custom data if the "SP List Accounts" widget loads first
			//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
			//if(this.stepName == Util.getConstant("SP_CONSTANTS",this.solutionPrefix)[this.caseType]["STEP_NAME"])
			if(Util.getConstant("SP_CONSTANTS",this.solutionPrefix, this.workItemEditable)!= undefined && this.stepName == Util.getConstant("SP_CONSTANTS",this.solutionPrefix, this.workItemEditable)[this.caseType]["STEP_NAME"])
			//End
			{
				otherParams = {};
				otherParams.modifiable = true;
				otherParams.provider = "F_CaseFolder";	
				otherParams.parentContext = this.workItemEditable._propertiesParentContext;
				//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.					
				//fieldSymName = Util.getConstant("SP_CONSTANTS",this.solutionPrefix)[this.caseType]["FIELD_TO_RENDER"];
				fieldSymName = Util.getConstant("SP_CONSTANTS",this.solutionPrefix, this.workItemEditable)[this.caseType]["FIELD_TO_RENDER"];
				//End
				propertyName = Util.getSymbolicName(this.solution, fieldSymName);
				attrDef = workItem.attributeDefinitions[propertyName];
				otherParams.value = workItem.attributes[propertyName];	
				//updated by suresh as part of 5.2.1 upgrade
				var property = PropertyEditable._createProperty(propertyName, attrDef.name, attrDef, otherParams,this.workItemEditable.repository);
				this.workItemEditable.propertiesCollection[property.id] = property;

				// Mixin the additional definitions
				//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
				//this.workItemEditable.propertiesCollection[propertyName] = dojo.mixin(this.workItemEditable.propertiesCollection[propertyName], Util.getConstant("EWF_FieldAttributes",this.solutionPrefix)[fieldSymName]);
				this.workItemEditable.propertiesCollection[propertyName] = dojo.mixin(this.workItemEditable.propertiesCollection[propertyName], 
					Util.getConstant("EWF_FieldAttributes",this.solutionPrefix, this.workItemEditable)[fieldSymName]);
				//End	
			}
		},	 
	
		// Show the fields using dynamically created view
		showFields: function(){
			var columnCount = this.columnCount ? this.columnCount : this.widgetProperties.columnCount;
			if (this.stepName === "Manual Processing" || this.stepName === "Manual Processing - Pend")
			var labelAlignment = "vertical";
			else
			var labelAlignment = this.widgetProperties.labelAlignment;
			
			this.logInfo("showFields", "labelAlignment: ", this.widgetProperties.labelAlignment + ", columnCount: " + this.widgetProperties.columnCount);	
			var viewDefinition = "<div data-dojo-type=\"pvr\/widget\/Layout\"><div data-dojo-type=\"pvr\/widget\/MultiColumnContainer\">";		
			var viewColumns = [];
			var column, fieldDiv, fieldSymName, propertyName;
			var columnWidth = 100/columnCount;
			for (var i = 0; i < columnCount; i ++) {
				column = "<div data-dojo-type=\"pvr\/widget\/Layout\""
				+ " data-dojo-props=\"labelAlignment:'"
				+ labelAlignment
				+ "'\,style:{width:'" + columnWidth + "%'}\">";				
				viewColumns.push(column);
				for (var j = 0; j < this.fields.length; j ++) {
					// Get the property symbolic name for the field
					fieldSymName = this.fields[j];
					var fieldDef = this.properties[fieldSymName];
					fieldDiv = this.getPropertyLayout(fieldDef);						
						if (j % columnCount === i){
							viewColumns[i] += fieldDiv;						
						}
						
				}
					viewDefinition += viewColumns[i] + "<\/div>";		
			}
			viewDefinition += "<\/div><\/div>";
			// Create the properties dijits
			this.fieldsWidget.setViewMarkup(viewDefinition);
			this.fieldsWidget.setContext(this);
			
			// Create the properties view in edit mode
			this.fieldsWidget.closeView();
			this.fieldsWidget.openView(this.workItemEditable, lang.hitch(this, this.onOpenView));
		},
		
		/**
		 * Return the layout for a property
		 */
		getPropertyLayout: function(property) {
			// Set field dijit class name
			var	fieldDijitClass = "\"pvr\/widget\/Property\"";

			// Property symbolic name
			var propertyName = property.id;
			
			// Set layout style as per property type
			var fieldDiv = "<div data-dojo-type=" + fieldDijitClass + " data-dojo-props=\"binding:'" + propertyName + "'";

			// Set editor if required
			if (property.hasOwnProperty('editor')) 
				fieldDiv += ",editor:'" + property.editor + "'";
			
			// Set parameters that are passed to the editor
			var field = property.id;
			
			//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
			//var fieldDef = Util.getConstant("EWF_FieldAttributes",this.solutionPrefix)[field] || {};
			var fieldDef = Util.getConstant("EWF_FieldAttributes",this.solutionPrefix, this.workItemEditable)[field] || {};
			//End
			
			if (property.propertyExtensionType) { // if custom editor is to be used
				fieldDef = lang.mixin({
					propertyId: property.id,
					displayMode: 'readonly',
					readOnly: true,
					settability: 'readonly'
				}, fieldDef);	
			}

			if (property.propertyExtensionType == "DecisionWidget") {
				fieldDef = lang.mixin({
					caseType: this.caseType
				}, fieldDef);
			}
			var editorParams = dojo.toJson(fieldDef).replace(/\"/g, "'");
			
			// Add the editor parameters to the view template.
			fieldDiv += ",editorParams:" + editorParams;

			fieldDiv += "\"><\/div>";
			return fieldDiv;
		},
	
		/**
		 * Called after the properties are rendered
		 */
		onOpenView: function() {
		    //commented the below code as part of 5.2.1 upgrade changes
			//this.fieldsWidget._view.set("readOnly", false);
			this.fieldsWidget.view.set("readOnly", false);
			//commented the below code as part of 5.2.1 upgrade changes
			//this.fieldsWidget._configureCoordination(this.workItemEditable, this.coordination);
			this.fieldsWidget.configureCoordination(this.workItemEditable, this.coordination);
			this.decisionPanel.appendChild(this.fieldsWidget.domNode);	
			this.createUpdateHandler();
						
		},
		
		createUpdateHandler: function() {
			if (this._updateHandler)
				this._updateHandler.remove();
			//commented the below code as part of 5.2.1 upgrade changes
			//this._updateHandler = aspect.after(this.fieldsWidget._controller, "onUpdate", lang.hitch(this, function(changes) {
			this._updateHandler = aspect.after(this.fieldsWidget.controller, "onUpdate", lang.hitch(this, function(changes) {
				console.log("onUpdate - changes");
				console.dir(changes);
				
			}), true);
		},

	/**
	 * @private destroys this widget
	 */
	destroy: function() {
		//Do any custom clean up here
		this.inherited(arguments);
	}
	
});
});
