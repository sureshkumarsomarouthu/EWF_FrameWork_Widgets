define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",		
	"v11/ewf/pgwidget/customcasedata/CustomWidgetContentPaneEventListener",
	"v11/ewf/pgwidget/customcasedata/dijit/CustomWidgetContentPane"], 
	function(declare, lang, BasePageWidget, BaseActionContext, eventHandler, contentPaneWidget){

    return declare("v11.ewf.pgwidget.customcasedata.CustomCaseDataWidget", [contentPaneWidget, BasePageWidget, BaseActionContext], {
 
		contentPaneEventListener: null,

		postCreate: function(){
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane();
		},
		//added by suresh as part of 5.2.1 upgrade for jira issue PEWFSGUPGS-125
		resize: function() {
		    if(this.fieldsWidget.view){
			 this.fieldsWidget.view.resize();
			}
		},
  
		handleICM_SendWorkItemEvent: function(payload) {
			this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);
			// clear & set action context
			this.cleanActionContext("WorkItemPage");
			this.cleanActionContext("Coordination");
			this.cleanActionContext("UIState");
			this.setActionContext("WorkItemPage", payload.workItemEditable);
			this.setActionContext("Coordination", payload.coordination);
			if(payload.UIState !== undefined){
				this.setActionContext("UIState", payload.UIState);
			}else{
				this.setActionContext("UIState", null);
			}
			
			   //Added by rahul to send payload to the Associated document widget because controller bind is failling in Custom Case Document
            /*
            	Need to create wiring from custom case data widget to the Associate Document widget to receive payload widget
            */
            
            this.onBroadcastEvent("icm.associateDocument.SendWorkItem", payload);
		},	
		

	});
});
