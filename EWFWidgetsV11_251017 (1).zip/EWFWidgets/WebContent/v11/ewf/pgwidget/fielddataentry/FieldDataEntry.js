define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",
	"v11/ewf/util/Util", 	
	"v11/ewf/pgwidget/fielddataentry/FieldDataEntryContentPaneEventListener",
	"v11/ewf/pgwidget/fielddataentry/dijit/FieldDataEntryContentPane"], function(declare, lang, BasePageWidget, 
		BaseActionContext, Util, eventHandler, contentPaneWidget){

    return declare("v11.ewf.pgwidget.fielddataentry.FieldDataEntry", [contentPaneWidget, BasePageWidget, BaseActionContext], {
 
		contentPaneEventListener: null,
		plaCaseType: 'COPC_PermanentLineAdjustment',
		
		postCreate: function(){
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane();
		},
		
		handleICM_SendWorkItemEvent: function(payload){
			this.logEntry("handleICM_SendWorkItemEvent#########");
			
			//Added by Purna to capture the start Date time of the WI Load
			this.startDateTime = new Date();
			console.log("Start Timer Captured is :"+this.startDateTime);
			//End By Purna
			
			if(!payload || !payload.workItemEditable) {
				this.logError("handleICM_SendWorkItemEvent -- payload: ", payload);
				return;
			} 
			
			if(this.keyPressHandler){
				// prevent completing the work item before the view is rendered
				dojo.disconnect(this.keyPressHandler);
			}		
			
			// Set action context
			this.setActionContext("WorkItemPage", payload.workItemEditable);
			this.setActionContext("Coordination", payload.coordination);
			if(payload.UIState !== undefined){
				this.setActionContext("UIState", payload.UIState);
			}else{
				this.setActionContext("UIState", null);
			}

			// Get the work item object
			var workItem = payload.workItemEditable.getWorkItem();
			// Check if the work item attributes have been retrieved
			if (!workItem.getCaseTaskId()) {
				// retrieves the work item attributes
				workItem.retrieveCachedAttributes(dojo.hitch(this, function(workItem){
					
					//Modified by Purna - Check whether the case attributes are available or not and then call render
					//this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);
					this.checkAndRenderCase(workItem, payload);
					//End Change
					
				}));
			}
			else {
				
				//Modified by Purna - Check whether the case attributes are available or not and then call render
				//this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);
				this.checkAndRenderCase(workItem, payload);
				//End Change
			}
			this.logExit("handleICM_SendWorkItemEvent");
		},
				
		/**
		 * The function replaces the handler of the Properties widget to discard the changes without notifying the user. 
		 * This coordination topic handler does pre-processing before cancel editing a work item.
		 */
		handleICM_BeforeCancelEvent: function(context, complete, abort) {
			console.log("handleICM_BeforeCancelEvent*****this.fieldsWidget*******",this.fieldsWidget);
			this.fieldsWidget._commit(lang.hitch(this, function() {
				//if (this.fieldsWidget._controller.isModified(this.fieldsWidget._widgetLoadTime)) {	
				if (this.fieldsWidget.controller.isModified(this.fieldsWidget._widgetLoadTime)) {					
					// Restore FieldValue to the original value
					if(this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE]
						&& (this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE].value !== this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE].originalValue)) {
						this.updateDataField(Util.getConstant("EWF_PropertyName").FIELD_VALUE, this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE].originalValue);
					}
					// Do not prompt to discard the changes
					/*
					abort({
						message: this.fieldsWidget.resourceBundle.unsavedError
					});
					*/		
				}
				// Set reason message
				this.updateDataField(Util.getConstant("EWF_PropertyName").REASON_MESSAGE, Util.getConstant("EWF_DEReasonMessage").CLOSE);
				
				complete();
			}));	
		},
		
		handleICM_ValidationEvent: function(context, complete, abort) {	
		    console.log("this.fieldsWidget is@@@ ",this.fieldsWidget);		
			// Remove focus to force onBlur() in case complete is triggered by short-cut key while user is editing a field	
			// support: IE9
			try {
				// If the <body> is blurred, IE will switch windows
				if ( document.activeElement && document.activeElement.nodeName.toLowerCase() !== "body" ) {
					console.log("handleICM_ValidationEvent - remove focus before validation");
					document.activeElement.blur();
				}
			} catch ( error ) {console.log("Error occurred: " + error);}
						
			this.fieldsWidget._commit(lang.hitch(this, function() {				
				//var controllerErrors = this.fieldsWidget._controller.validate();
				//var viewErrors = this.fieldsWidget._view.validate();
				var controllerErrors = this.fieldsWidget.controller.validate();
				var viewErrors = this.fieldsWidget.view.validate();
				
				// Ignore the residual controller error on FieldValue
				if (controllerErrors.length === 1 && controllerErrors[0].id === Util.getConstant("EWF_PropertyName").FIELD_VALUE
					&& viewErrors.length === 0) {
					complete();
				} else if (controllerErrors.length > 0 || viewErrors.length > 0) {
					abort({"message": this.fieldsWidget.resourceBundle.validationError});
					this.fieldsWidget._handleFocus(controllerErrors, viewErrors);
				}
				else {
					complete();
				}
			}));
		},
		
		checkAndRenderCase: function(workItem, payload) {
			if(this.plaCaseType == workItem._caseTypeName) {
				var caseAttributes = dojo.getObject(workItem._caseTypeName);
				if(caseAttributes && caseAttributes != null && caseAttributes != 'null') {
					this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);
				} else {
					var caseItem = workItem.getCase();
					caseItem.retrieveCachedAttributes(dojo.hitch(this,function(caseObj){
						var caseAttributes = caseObj.attributeDefinitions;
						console.log('Retrieved and Setting the case attr globally', caseAttributes);
						dojo.setObject(workItem._caseTypeName, caseAttributes);
						this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);
					}));
				}
			} else {
				this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);
			}
		}
	});
});
