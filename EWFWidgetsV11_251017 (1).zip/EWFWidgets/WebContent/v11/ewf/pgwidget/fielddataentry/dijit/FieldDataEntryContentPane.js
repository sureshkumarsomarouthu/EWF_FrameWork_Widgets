define([ "dojo/_base/declare", 
	"dojo/_base/array",
	"dojo/_base/lang",
	'dojo/query',
	"dojo/aspect",
	"dojo/dom-class",
	"dojo/keys",
	"dojo/dom-geometry",
	"dojo/dom-style",
	"icm/action/Action",
	"icm/model/PropertyEditable",
	"v11/ewf/util/Util", 
	"v11/ewf/widget/fields/Fields",
    "dojo/text!./templates/FieldDataEntryContentPane.html", 	
	"icm/base/_BaseWidget",
	"v11/ewf/action/workitem/EWFCommonDispatchWorkItem",
	"v11/ewf/action/workitem/_EWFWorkItemHandlerMixin"
	], function(declare, array, lang, dojoQuery, aspect, domClass, keys, domGeom, domStyle, Action,
		PropertyEditable, Util, Fields, template, _BaseWidget
		){
	return declare("v11.ewf.pgwidget.fielddataentry.dijit.FieldDataEntryContentPane", [_BaseWidget], {
		templateString: template,
		widgetsInTemplate: true,
			
		properties: null,
		workItemEditable: null,
		fieldsToRender: [],
		timeDifference: null,

		constructor: function(){
			this.fieldsWidget = new Fields();
			this.resourceBundle = Util.getResourceBundle("DataEntry");
		},

		postCreate:	function(){
			this.inherited(arguments);
		},	
		
		/**
		 * Display field/section instructions.
		 */
		showInstruction: function(){
			console.log("showInstruction", "fieldsToRender: " + this.fieldsToRender + ", workItemType: " + this.workItemType);
			
			var instructionsText = '';
			var instructionsHTML = '';
			
			// Create the instruction content for fields if Field DE
			if (this.workItemType === Util.getConstant("EWF_WorkItemType").FIELD) {
				for (var i = 0; i < this.fieldsToRender.length; i ++) {
					if(dojo.trim(this.fieldsToRender[i]).length > 0)
					{
						// Get the property symbolic name for the field
						var fieldSymName = Util.getShortName(this.solution, this.fieldsToRender[i]);
						var propertyName = Util.getSymbolicName(this.solution, this.fieldsToRender[i]);
						
						var fieldDef = this.properties[propertyName];
						if (fieldDef.instruction && fieldDef.instruction.length > 0)
							instructionsText = fieldDef.instruction;
						else
							instructionsText = this.resourceBundle.instructionDefault;
						instructionsHTML += "<b>" + fieldDef.name + ": </b><i>" + instructionsText + "</i>";
						if (i < this.fieldsToRender.length -1) // Not the last field to display
							instructionsHTML += ", ";
					}
				}
			} 
			// Create the instruction content for Section/Special Section DE
			else  {
				
				// Get the section name from the data fields
				var propertyName = this.workItemType === Util.getConstant("EWF_WorkItemType").SECTION ? Util.getConstant("EWF_PropertyName").SECTION_NAME : Util.getConstant("EWF_PropertyName").SPECIAL_SECTION_NAME ;				
				var sectionNameValue = this.properties[propertyName] ? this.properties[propertyName].getValue() : "";
				
				// Set the section label and instruction text
				var sectionLabel = "SECTION";	
				instructionsText = this.resourceBundle.instructionDefault;				
				if (sectionNameValue && sectionNameValue.length > 0) {
					// Get the section symbolic name
					var sectionPropertyName = Util.getSymbolicName(this.solution, sectionNameValue);
					this.currentSection = sectionPropertyName; //Added by Suresh for 5.2.1
					
					if (this.properties[sectionPropertyName]) { // The section corresponds to a field
						sectionLabel = this.properties[sectionPropertyName].name;
						instructionsText = this.properties[sectionPropertyName].instruction;	
					} else { // The section is a group of field
						// Get the section definition
						sectionNameValue = Util.getShortName(this.solution, sectionNameValue);
						
						//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
						//var sectionAttributes = Util.getConstant("EWF_SectionAttributes", this.solution.prefix)[sectionNameValue];
						var sectionAttributes = Util.getConstant("EWF_SectionAttributes", this.solution.prefix, this.workItemEditable)[sectionNameValue];
						//End
						
						if (sectionAttributes) {
							sectionLabel = sectionAttributes.displayName;
							instructionsText = sectionAttributes.instruction;
						}
					}
					
					//Special Handling for COA AMT_CorpContactDetails Section starts here
					if(sectionPropertyName === 'AMT_CorpContactDetails'){
						console.log('Special handling for AMT_CorpContactDetails section');
						var thisPageWidget = this;
						for(var widget in thisPageWidget.page){
							if(widget){
								if(thisPageWidget.page.hasOwnProperty(widget)){
									var actualWidget = thisPageWidget.page[widget];
									if(actualWidget && actualWidget.widgetDefId && (actualWidget.widgetDefId.indexOf('ImageCroppingv11') > -1)){
										var actualWidgetToModify = actualWidget;
										console.log('Special handling for AMT_CorpContactDetails section --> ImageCroppingv11', actualWidgetToModify);
										actualWidgetToModify.domNode.style.overflow = 'auto';
										actualWidgetToModify.imageDiv.style.overflow = 'auto';
										dojoQuery('img', actualWidgetToModify.imageDiv).forEach(function(imageNode){
											imageNode.onload = function(){
												console.log('Special handling for AMT_CorpContactDetails section --> ImageCroppingv11 --> Image onload', imageNode);
												var imgHeight = imageNode.height;
												var imgWidth = imageNode.width;
												var fullWindowCoords = domGeom.getContentBox(document.body);
												
												var finalCoordToSet = {h: 0, w: 0};
												finalCoordToSet.w = fullWindowCoords.w * 0.98;
												finalCoordToSet.h = fullWindowCoords.h * 0.40;
												
												if((imgWidth * finalCoordToSet.h) >= (imgHeight * finalCoordToSet.w)){
													if(imgWidth > finalCoordToSet.w){
														domStyle.set(imageNode, "width", "100%");
													}
												}else{
													if(imgHeight > finalCoordToSet.h){
														var newWidth = Math.floor(finalCoordToSet.h / imgHeight * imgWidth);
														domStyle.set(imageNode, "width", newWidth+"px");
													}
												}
												
												if(imgHeight < finalCoordToSet.h){
													finalCoordToSet.h = imgHeight + 10;
												}
												
												finalCoordToSet.h = finalCoordToSet.h + 10;
												
												if(imgWidth <= fullWindowCoords.w){
													finalCoordToSet.w = fullWindowCoords.w;
												}
												
												domGeom.setContentSize(actualWidgetToModify.imageDiv, finalCoordToSet);
												imageNode.style.width = '99%';
												actualWidgetToModify.domNode.style.overflow = 'auto';
												actualWidgetToModify.imageDiv.style.overflow = 'auto';
											}
										});
									}
								}
							}
						}
					}
					//Special Handling for COA AMT_CorpContactDetails Section ends here
					
				}
				
				instructionsHTML = "<b>" + sectionLabel	+": </b><i>" + instructionsText + "</i>";	
			}
			
			// Display instruction text
			this.instructionContent.innerHTML = instructionsHTML;
		},
		
		// Return the view markup (template) for Section DE
		getSectionViewMarkup: function(){
			var columnCount = this.columnCount ? this.columnCount : this.widgetProperties.columnCount;
			this.logInfo("getSectionViewMarkup", "labelAlignment: ", this.widgetProperties.labelAlignment + ", columnCount: " + columnCount);	
			var viewMarkup = "<div data-dojo-type=\"pvr\/widget\/Layout\">";
			var rowDiv= "<div data-dojo-type=\"pvr\/widget\/MultiColumnContainer\">";			
			var columnDiv, fieldDiv, fieldSymName;
			//var columnWidth = (100/columnCount) + '%';
			// To align with columns in image, fix the column width to pixels
			var columnWidth = "500px";
			for (var i = 0; i < this.fieldsToRender.length; ) {
				// Set view template for a row which is a MultiColumnContainer
				viewMarkup += rowDiv;			
				
				if(columnCount <= 1){
					columnWidth = "100%";
				}
				// Set view template for each column which contains one property
				for (var j = 0; j < columnCount && i < this.fieldsToRender.length; j++) {
					// Set the column layout
					columnDiv = "<div data-dojo-type=\"pvr\/widget\/Layout\""
						+ " data-dojo-props=\"labelAlignment:'"
						+ this.widgetProperties.labelAlignment
						+ "'";
					columnDiv += ",style:{width:'" + columnWidth + "'},labelWidth:'250px'";					
					columnDiv += "\">";
						
					// Get the property symbolic name for the field
					fieldSymName = this.fieldsToRender[i];
					if(dojo.trim(fieldSymName).length > 0)
					{
						propertyName = Util.getSymbolicName(this.solution, fieldSymName);
							
						// Get the property definiton
						var fieldDef = this.properties[propertyName];
						
						// Get the property layout
						fieldDiv = this.getPropertyLayout(fieldDef);
						
						// Add the column to the view
						columnDiv += fieldDiv + "</div>";		
						viewMarkup += columnDiv;					
						i++;
					}else
					{
						//For Handling special section in OTT Section DE
						viewMarkup += "<div></div>";					
						i ++;
					}
				}					
				viewMarkup += "<\/div>";				
			}
			viewMarkup += "<\/div>";
			return viewMarkup;			
		},
		
		getSpecialSectionViewMarkup: function() {
			var viewMarkup = "<div data-dojo-type=\"pvr/widget/PropertyTable\">";			
			var fieldDiv, fieldSymName;
			for (var i = 0; i < this.fieldsToRender.length; i ++) {							
				// Get the property symbolic name for the field
				fieldSymName = this.fieldsToRender[i];
				if(fieldSymName==="")
					continue;
				propertyName = Util.getSymbolicName(this.solution, fieldSymName);
					
				// Get the property definiton
				var fieldDef = this.properties[propertyName];
				fieldDiv = this.getPropertyLayout(fieldDef);

				// Add the field to the view template
				viewMarkup += fieldDiv;	
			}
			
			viewMarkup += "<\/div>";
			return viewMarkup;
		},
		
		// Return the view markup (template)
		getViewMarkup: function(){
			if (this.workItemType !== Util.getConstant("EWF_WorkItemType").SPECIAL_SECTION) {
				return this.getSectionViewMarkup();
			}
			return this.getSpecialSectionViewMarkup();			
		},
		
		// Show the fields using dynamically created view
		showFields: function(){
			// Get the view template
			var viewMarkup = this.getViewMarkup();
			console.log("showFields -- viewMarkup: " + viewMarkup);		
			
			// Create the properties dijits
			this.fieldsWidget.setViewMarkup(viewMarkup);
			this.fieldsWidget.setContext(this);
			
			// Create the properties view in edit mode
			this.fieldsWidget.closeView();
			
			var options = { 
		 			disabled: false,
		 			applyDefaultValues: true
		 		};
			
			this.fieldsWidget.openView(this.workItemEditable, options, lang.hitch(this, this.onOpenView));
		},
		
		/**
		 * Return the layout for a property
		 */
		getPropertyLayout: function(property) {
			// Set field dijit class name
			var	fieldDijitClass = "\"pvr\/widget\/Property\"";

			// Property symbolic name
			var propertyName = property.id;
			
			// Set layout style as per property type
			
			var fieldDiv = "<div data-dojo-type=" + fieldDijitClass
				+ " data-dojo-props=\"binding:'" + propertyName + "'";

			// Set editor if configured
			if (property.hasOwnProperty('editor')) 
				fieldDiv += ",editor:'" + property.editor + "'";
			
			// Set editorParams if configured in Constants
			var field = Util.getShortName(this.solution, propertyName);
			
			//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
			//var fieldAttributes = Util.getConstant("EWF_FieldAttributes", this.solution.prefix)[field];
			var fieldAttributes = Util.getConstant("EWF_FieldAttributes", this.solution.prefix, this.workItemEditable)[field];
			//End
			
			if (fieldAttributes.hasOwnProperty('editorParams')){
				var fieldDef = fieldAttributes.editorParams || {};	
				var editorParams = dojo.toJson(fieldDef).replace(/\"/g, "'");
				fieldDiv += ",editorParams:" + editorParams;
			}
			
			/* Commented out as the parameters are now passed in via the model
			// Set parameters that are passed to the editor			
			var field = Util.getShortName(this.solution, propertyName);
			var fieldAttributes = Util.getConstant("EWF_FieldAttributes", this.solution.prefix)[field];
			var fieldDef = fieldAttributes || {};			
			var editorParams = dojo.toJson(fieldDef).replace(/\"/g, "'");			
			
			// Add the editor parameters to the view template.
			fieldDiv += ",editorParams:" + editorParams;
			*/

			fieldDiv += "\"><\/div>";
			return fieldDiv;
		},
			
		/**
		 * Initialize the fields properties using the solution attributes and the additional field attributes in constants files
		 */
        initializeFieldsProperties: function() {
			var workItem = this.workItemEditable.getWorkItem();
			var fieldSymName, propertyName, attrDef, value;
			console.log("this scope in initializeFieldsProperties : ",this);
			for (var i = 0; i < this.fieldsToRender.length; i ++) {		
				// Get the property symbolic name for the field
				if(dojo.trim(this.fieldsToRender[i]).length > 0)
					{
					fieldSymName = Util.getShortName(this.solution, this.fieldsToRender[i]);
					propertyName = Util.getSymbolicName(this.solution, fieldSymName);
					console.log("fieldSymName: " + fieldSymName);

					// Construct field definitions
					
					// Mixin the solution attributes definition if the property is invisible to the work item
					if (workItem.attributes.hasOwnProperty(propertyName) 
						&& workItem.attributeDefinitions.hasOwnProperty(propertyName))
						continue;
					
					//Modified by Purna - Retrieve the attribute def from Case instead of sol if available			
					//attrDef = this.solution.attributeDefinitionsById[propertyName];
					var caseAttributes = dojo.getObject(workItem._caseTypeName);
					if(caseAttributes && caseAttributes != null && caseAttributes != 'null') {
						attrDef = caseAttributes[propertyName];
					} else {
						attrDef = this.solution.attributeDefinitionsById[propertyName];
					}
					//End Change
						
					if (!attrDef) {
						console.error("Property \"" + propertyName + "\" is not defined in the solution.");
						//this.logError("initializeFieldsProperties", "Property \"" + propertyName + "\" is not defined in the solution.");
					}
					workItem.attributeDefinitions[propertyName] = attrDef;
					value = attrDef.defaultValue;
					if (!value) { 
						if (attrDef.cardinality === "LIST") {
							value = [];
						}
						else if (attrDef.dataType === Util.getConstant("DataType").STRING) {
							value = "";
						}
					}
					workItem.attributes[propertyName] = value;
				}
			}
			
			// Create PropertyEditable objects
			workItem._initializePropertiesCollectionFromAttributes();
			
			// Update the WorkItemEditable object with the added properties
			var otherParams = {};
			otherParams.modifiable = true;
			otherParams.parentContext = this.workItemEditable._propertiesParentContext;	
			otherParams.provider = "F_CaseFolder";		
			for (var i = 0; i < this.fieldsToRender.length; i ++) {	
				if(dojo.trim(this.fieldsToRender[i]).length > 0)
				{
					// Get the property symbolic name for the field
					fieldSymName = Util.getShortName(this.solution, this.fieldsToRender[i]);
					propertyName = Util.getSymbolicName(this.solution, fieldSymName);
					if (!this.workItemEditable.propertiesCollection.hasOwnProperty(propertyName)) {
						attrDef = workItem.attributeDefinitions[propertyName];
						var attrName = attrDef.name;
						otherParams.value = workItem.attributes[propertyName];		
						console.log("this.worlitemEditable.repository ::::: ",this.workItemEditable.repository);
						//Modified By Gopi As part of ICM 5.2.1 Upgrade
						var property = PropertyEditable._createProperty(propertyName, attrName, attrDef, otherParams,this.workItemEditable.repository);
						console.log("property @@@@### : ",property);
						console.log("this.workItemEditable : ",this.workItemEditable);
						this.workItemEditable.propertiesCollection[property.id] = property;
						
						// Do not post this property when saving the step since it does not exist in the workflow
						this.workItemEditable.propertiesCollection[property.id]._getPayloadObject = function () {
							return null;
						}
					}
					
					// Mixin the additional definitions
					this.workItemEditable.propertiesCollection[propertyName] = dojo.mixin(
						this.workItemEditable.propertiesCollection[propertyName], 
						
						//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
						//Util.getConstant("EWF_FieldAttributes", this.solution.prefix)[fieldSymName]);	
						Util.getConstant("EWF_FieldAttributes", this.solution.prefix, this.workItemEditable)[fieldSymName]);
						//End
					}			
				}
			console.log('this.worlitemEditable->',this.workItemEditable)
		},
		
		/**
		 * Create an update handler to set the FieldValue property whenever a field value changes.
		 */
		createUpdateHandler: function() {
			if (this._updateHandler)
				this._updateHandler.remove();
			//this._updateHandler = aspect.after(this.fieldsWidget._controller, "onUpdate", lang.hitch(this, function(changes) {
			this._updateHandler = aspect.after(this.fieldsWidget.controller, "onChange", lang.hitch(this, function(changes) {
				console.log("onUpdate - changes");
				console.dir(changes);
				// Check if the change occurs to FieldValue only
				var count = 0;
				var isFieldValue = false;
				for(var item in changes){
					count++;
					isFieldValue = (item === Util.getConstant("EWF_PropertyName").FIELD_VALUE);
				}
				// FieldValue is changed by refreshFieldValue(), so no need to set it again				
				if (count === 1 && isFieldValue === true)
					return;
				
				this.refreshFieldValue();
				// Get the FieldValue property controller
				//var fieldValueController = this.fieldsWidget._controller.getPropertyController(Util.getConstant("EWF_PropertyName").FIELD_VALUE);
				var fieldValueController = this.fieldsWidget.controller.getPropertyController(Util.getConstant("EWF_PropertyName").FIELD_VALUE);
				var modified = fieldValueController.isModified();
				this.setDirtyState(modified);
				
				this.fieldsWidget.adjustDirtyState();
			}), true);
		},
		
		/**
		 * Called after the properties are rendered
		 */
		onOpenView: function() {
			//this.fieldsWidget._view.set("readOnly", false);//commented by suresh as part of 5.2.1 upgrade
			this.fieldsWidget.view.set("readOnly", false);
			/**commented by suresh method name is changed from _configureCoordination to configureCoordination in 5.2.1
			  as part of 5.2.1 upgrade the below method name is changed*/
			
			//this.fieldsWidget._configureCoordination(this.workItemEditable, this.coordination);
			
			this.fieldsWidget.configureCoordination(this.workItemEditable, this.coordination);
			
			this.createUpdateHandler();
			
			//Get step name
			var stepNameLocal = this.workItemEditable.getWorkItem().stepName;
			console.log("Step Name: " + stepNameLocal);			
			if((stepNameLocal !== Util.getConstant("EWF_DEStepName").DE1_NUMERIC) 
				&& (stepNameLocal !== Util.getConstant("EWF_DEStepName").DE1_ALPHANUMERIC) 
				&& (stepNameLocal !== Util.getConstant("EWF_DEStepName").DE1_PROCESS)) {
				// Initialize data fields
				this.updateDataField(Util.getConstant("EWF_PropertyName").REASON_MESSAGE, "");	
			}
			// Set the FieldValue to a list of default values
			this.refreshFieldValue();			
			
			// Display the properties
			while (this.fieldsForm.hasChildNodes()) {
				this.fieldsForm.removeChild(this.fieldsForm.firstChild);
			}
			this.fieldsForm.appendChild(this.fieldsWidget.domNode);			
			//this.fieldsWidget._view.resize();
			this.fieldsWidget.view.resize();
			if (this.workItemType === Util.getConstant("EWF_WorkItemType").SPECIAL_SECTION) {
				// Focus at the property table toolbar
				//this.fieldsWidget._view.domNode.firstChild.childNodes[1].focus();
				this.fieldsWidget.view.domNode.firstChild.childNodes[1].focus();
			} else {
				// Forcus at the first property in view
				//Special condition for sections which take time to load,set tiemout for focus
				if(this.currentSection == "EWF_BeneficiaryAddress" || this.currentSection == "EWF_BeneficiaryName"){
					setTimeout(lang.hitch(this, function(){
						this.fieldsWidget.focusFirstChild();
					}), 500);
				}else{
					this.fieldsWidget.focusFirstChild();
				}
			}
			
			// Add key handler
			this.registerKeyListeners();
		},
		
		/**
		 * Refresh FieldValue, DataType, FieldInfo and other data fields
		 */
		refreshFieldValue: function() {
			console.log("refreshFieldValue");
			
			// Get field values list, datatype list
			var fieldValuesList = [];
			var dataTypesList = [];
			var fieldInfoList = [];
			var fieldSymName, propertyName, propertyValue, propertyType, dataType, cardinality;
			var fieldValueType = this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE].dataType;
			for (var i = 0; i < this.fieldsToRender.length; i ++) {
				if(dojo.trim(this.fieldsToRender[i]).length > 0)
				{
					// Get the property symbolic name for the field
					fieldSymName = Util.getShortName(this.solution, this.fieldsToRender[i]);
					propertyName = Util.getSymbolicName(this.solution, fieldSymName);
					
					// Get the input value
					propertyValue = this.properties[propertyName].value;
					if (fieldValueType === Util.getConstant("DataType").STRING) {
						if (propertyValue !== null && propertyValue !== undefined) {
							if (this.properties[propertyName].dataType === Util.getConstant("DataType").DATETIME) {
								// convert date to ISO string						
								propertyValue = this.properties[propertyName]._convertSingleValueToPayload(propertyValue);
							} else if (typeof propertyValue === "object") {
							
							// Added by Sagar for COA Issue fix - if value in the element of an array contains COMMA (,) it is treated as one more
							// index in Array. Hence changing the Delimiter and using join() instead of toString()
								// handles array values
								if(propertyValue instanceof Array){
									propertyValue = propertyValue.join(Util.getConstant("ARRAY_SEPERATOR"));
									console.log('*****propertyName: ', propertyName, ' value is ARRAY. Adding the new Array Delimiter |||. propertyValue', propertyValue);
								// handles other object type values
								} else {
									propertyValue = propertyValue.toString();
								}
							//End Change
							
							} else if (typeof propertyValue !== "string") {
								// handles number and other non-string values
								propertyValue = propertyValue + '';
							} 
						} else {
							// convert null to empty string
							propertyValue = propertyValue || '';
						}

						// Save the FieldValue only when the workitem is completed by clicking "Complete" or pressing Enter 
						var reason = this.properties[Util.getConstant("EWF_PropertyName").REASON_MESSAGE].value;
						if (!reason || reason === "")
							fieldValuesList.push(propertyValue);
						else
							fieldValuesList.push('');
					}
					
					// Get the datatype
					dataType = this.properties[propertyName].dataType;
					cardinality = this.properties[propertyName].cardinality;
		
					if (dataType === Util.getConstant("DataType").STRING) {
						
						//Modified by Purna - For multi section the data type should be always string []
						//if (cardinality === "LIST")
						if (cardinality === "LIST" || (this.isMultiSection && this.isMultiSection == 'Y'))
						//End change
						
							propertyType = Util.getConstant("EWF_DataType").STRING_ARRAY;
						else
							propertyType = Util.getConstant("EWF_DataType").STRING;
							
					//Modified by Purna - For multi section datetime data type is mapped to string [] in the backend
					} else if (dataType === Util.getConstant("DataType").DATETIME) { 
						
						if (this.isMultiSection && this.isMultiSection == 'Y') {
							console.log('inside PLA Multi Section .. setting DATETIME datatype to STRINGARRY');
							propertyType = Util.getConstant("EWF_DataType").STRING_ARRAY;
						} else {
							propertyType = Util.getConstant("EWF_DataType").DATE_TIME;
						}
					}
					else if (dataType === Util.getConstant("DataType").BOOLEAN) 
						propertyType = Util.getConstant("EWF_DataType").BOOLEAN;	
					else if (dataType.indexOf("xs:") === 0) 
						propertyType = dataType.substring(3);	// remove "xs:" from the data type
					else
						propertyType = dataType;
					dataTypesList.push(propertyType);
					
					// Add display name to fieldInfoList
					fieldInfoList.push(this.properties[propertyName].name);
				}
			};
			
			// Update the FieldValue list
			this.updateDataField(Util.getConstant("EWF_PropertyName").FIELD_VALUE, fieldValuesList);
			
			//Get step name
			var stepNameLocal = this.workItemEditable.getWorkItem().stepName;
			if((stepNameLocal === Util.getConstant("EWF_DEStepName").DE2_NUMERIC) 
				|| (stepNameLocal === Util.getConstant("EWF_DEStepName").DE2_ALPHANUMERIC) 
				|| (stepNameLocal === Util.getConstant("EWF_DEStepName").DE2_PROCESS)) {
				// Update the DataType list
				if (this.workItemType === Util.getConstant("EWF_WorkItemType").FIELD) { // Field DE
					this.updateDataField(Util.getConstant("EWF_PropertyName").DATA_TYPE, dataTypesList);
				} else if (this.workItemType === Util.getConstant("EWF_WorkItemType").SECTION) { // Section DE
					this.updateDataField(Util.getConstant("EWF_PropertyName").SECTION_DATA_TYPE, dataTypesList);
				} else { // Special Section DE
					this.updateDataField(Util.getConstant("EWF_PropertyName").SPECIAL_SECTION_DATA_TYPE, dataTypesList);
				}

				// Update the FieldInfo list
				this.updateDataField(Util.getConstant("EWF_PropertyName").FIELD_INFO, fieldInfoList);
			}
			
			// Set other data fields
			
			//modified by rahul for field comparison and field comparison is removed from workflow
			if ((stepNameLocal === Util.getConstant("EWF_DEStepName").DE2_PROCESS) 
				|| (stepNameLocal === Util.getConstant("EWF_DEStepName").DE2_ALPHANUMERIC) 
					|| (stepNameLocal === Util.getConstant("EWF_DEStepName").DE2_NUMERIC)) {
				var de1FieldsList = this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE_DE1].value;
				var de2FieldsList = fieldValuesList;
				
				var de1ReasonMsg = this.properties[Util.getConstant("EWF_PropertyName").REASON_MESSAGE_DE1].value;
				var de2ReasonMsg = this.properties[Util.getConstant("EWF_PropertyName").REASON_MESSAGE].value;
				
				var DE1andDE2ValuesMatched =  dojo.every(de1FieldsList, function(value, index){
					//Modified by Purna for DE comparision rule change
					var de2Value = (typeof de2FieldsList[index] == 'undefined') ? de2FieldsList[index] : de2FieldsList[index].replace(/ /g, '');
					var de1Value = (typeof value == 'undefined') ? value : value.replace(/ /g, '');
					console.log(de2FieldsList[index], ':', value, ' After ', de2Value, ':', de1Value);
					return ((de2Value+'') === (de1Value+''));
					//End
				});
				
				var DE1andDE2ReasonMatched = (de1ReasonMsg == de2ReasonMsg);
				
				// Set DEMatchResult
				this.updateDataField(Util.getConstant("EWF_PropertyName").DE_MATCH_RESULT, DE1andDE2ValuesMatched);
				
				// Set DEReasonMatch
				this.updateDataField(Util.getConstant("EWF_PropertyName").DE_REASON_MATCH, DE1andDE2ReasonMatched);		
				
			} else if((stepNameLocal === Util.getConstant("EWF_DEStepName").DE3_PROCESS)
				|| (stepNameLocal === Util.getConstant("EWF_DEStepName").DE3_ALPHANUMERIC) 
					|| (stepNameLocal === Util.getConstant("EWF_DEStepName").DE3_NUMERIC)) {
				var de1FieldsList = this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE_DE1].value;
				var de2FieldsList = this.properties[Util.getConstant("EWF_PropertyName").FIELD_VALUE_DE2].value;
				var de3FieldsList = fieldValuesList;
				
				var de1ReasonMsg = this.properties[Util.getConstant("EWF_PropertyName").REASON_MESSAGE_DE1].value;
				var de2ReasonMsg = this.properties[Util.getConstant("EWF_PropertyName").REASON_MESSAGE_DE2].value;
				var de3ReasonMsg = this.properties[Util.getConstant("EWF_PropertyName").REASON_MESSAGE].value;
				
				var DE1andDE3ValuesMatched =  dojo.every(de3FieldsList, function(value, index){
					//Modified by Purna for DE comparision rule change
					var de1Value = (typeof de1FieldsList[index] == 'undefined') ? de1FieldsList[index] : de1FieldsList[index].replace(/ /g, '');
					var de3Value = (typeof value == 'undefined') ? value : value.replace(/ /g, '');
					console.log(de1FieldsList[index], ':', value, ' After ', de1Value, ':', de3Value);
					return ((de1Value+'') === (de3Value+''));
					//End
					//return (de1FieldsList[index]+'') === (value+'');
				});					
				var DE2andDE3ValuesMatched =  dojo.every(de3FieldsList, function(value, index){
					//Modified by Purna for DE comparision rule change
					var de2Value = (typeof de2FieldsList[index] == 'undefined') ? de2FieldsList[index] : de2FieldsList[index].replace(/ /g, '');
					var de3Value = (typeof value == 'undefined') ? value : value.replace(/ /g, '');
					console.log(de2FieldsList[index], ':', value, ' After ', de2Value, ':', de3Value);
					return ((de2Value+'') === (de3Value+''));
					//End
					//return (de2FieldsList[index]+'') === (value+'');
				});
				var DE3ValuesMatched;
				
				if (DE1andDE3ValuesMatched) {
					DE3ValuesMatched = true;
					DE3ReasonMatched = (de1ReasonMsg === de3ReasonMsg);
				} else if (DE2andDE3ValuesMatched) {
					DE3ValuesMatched = true;
					DE3ReasonMatched = (de2ReasonMsg === de3ReasonMsg);
				} else {
					DE3ValuesMatched = false;
					DE3ReasonMatched = (de1ReasonMsg === de3ReasonMsg) || (de2ReasonMsg === de3ReasonMsg);
				}

				// Set DE3Match
				this.updateDataField(Util.getConstant("EWF_PropertyName").DE3_MATCH, DE3ValuesMatched);
				
				// Set DE3Reason
				this.updateDataField(Util.getConstant("EWF_PropertyName").DE3_REASON, DE3ReasonMatched);				
			}
		},
		
		registerKeyListeners: function() {
			if(this.keyPressHandler){
				dojo.disconnect(this.keyPressHandler);
			}
			this.completeAction = Action.create(this, {
				actionModelClass: 'v11.ewf.action.workitem.EWFCommonDispatchWorkItem',
				propertiesValue: { 
					item: {
						GetNext: false,
						id:	"",	
						label: "Complete",	
						title: "Complete"
					}
				}
			});		
			this.keyPressHandler = dojo.connect(document, "onkeydown", lang.hitch(this, function(event){
			
				// Do not handle the key if a dialog is popped up
				var node = document.activeElement;
				while(node){
					if(domClass.contains(node, "dijitDialog")){
						return; // just let it go to leave for the popped up dialog to handle the key event
					} else if(node.nodeName.toLowerCase() === "textarea" && event.keyCode === keys.ENTER) {
						return; // allow ENTER in text area
					} else if(domClass.contains(node, "dijitContentPane")) {
						break; // handle it
					}
					node = node.parentNode;
				}
				
				switch(event.keyCode){
					case keys.ENTER:
						console.log('Pressed Key: Enter');
						dojo.stopEvent(event);						
						// Complete the work item
						this.completeWorkitem("");
						break;
					default:
						if((event.altKey === true) || (event.altKey == 'true')){
							console.log('Pressed Key: ALT + ' + event.keyCode);
							//Check for the key Code and respond accordingly
							switch(event.keyCode){
								case 48: // ALT + 0
									dojo.stopEvent(event);																		
									// Exit to Home Screen
									this.closeWorkItemPage(Util.getConstant("EWF_DEReasonMessage").CLOSE);
									break;
								case 49: // ALT + 1
									dojo.stopEvent(event);
									this.completeWorkitem(Util.getConstant("EWF_DEReasonMessage").UNCLEAR_IMAGE);
									break;
								case 51: // ALT + 3
									dojo.stopEvent(event);
									this.completeWorkitem(Util.getConstant("EWF_DEReasonMessage").ALTERED_IMAGE);
									break;
								case 96: // ALT + KP_0
									dojo.stopEvent(event);																		
									// Exit to Home Screen
									this.closeWorkItemPage(Util.getConstant("EWF_DEReasonMessage").CLOSE);
									break;
								case 97: // ALT + KP_1
									dojo.stopEvent(event);
									this.completeWorkitem(Util.getConstant("EWF_DEReasonMessage").UNCLEAR_IMAGE);
									break;
								case 99: // ALT + KP_3
									dojo.stopEvent(event);									
									this.completeWorkitem(Util.getConstant("EWF_DEReasonMessage").ALTERED_IMAGE);
									break;
								default:
									break;
							}
						}
						break;
				}
			}));					
		},
		
		destroyRecursive: function(){
			if(this.keyPressHandler){
				this.logInfo('destroyRecursive', 'Removing the key press Handler');
				dojo.disconnect(this.keyPressHandler);
			}		
	    	this.fieldsWidget.destroyRecursive();
	    	this.inherited(arguments);
	    },
		
		// Complete the work item and get next workitem if need to
		completeWorkitem: function(msg) {
		
			//Added By Gopi to capture the time difference between start and close time of the WI

			this.timeDifference = this.startDateTime.getTime()-new Date().getTime();
			
			console.log("TimeDifference Spent by the user in Milli Seconds :"+this.timeDifference);
			
			console.log("After Converting into seconds "+(this.timeDifference/1000));

			this.updateDataField("DETimeDifference", Math.round(this.timeDifference/1000));

			//End By Gopi
			
			// Avoid duplicate actions to complete a work item
			if (!this.completeAction.isEnabled()) {
				console.log("completeWorkitem -- Complete action is not enabled");
				return;
			}
			console.log('completeWorkitem');
			if (msg) {
				// Set reason message
				this.updateDataField(Util.getConstant("EWF_PropertyName").REASON_MESSAGE, msg);
			}

			// Execute ICM action DispatchWorkItemAndClosePage to complete the workitem and get next workitem if need to
			this.completeAction.execute();
		},
		
		// Close the work item and get next workitem if need to
		closeAndGetNextWorkItem: function(msg) {
			this.logInfo('closeAndGetNextWorkItem');
			if (msg) {
				// Set reason message
				this.updateDataField(Util.getConstant("EWF_PropertyName").REASON_MESSAGE, msg);
			}
			// Execute EWF action CloseAndGetNextWorkItem to close the workitem and get next workitem if need to
			Action.perform(this.id, 'v11.ewf.action.workitem.CloseAndGetNextWorkItem');
		},
		
		// Close the work item and go to home screem
		closeWorkItemPage: function(msg) {
			this.logInfo('closeWorkItemPage');
			if (msg) {
				// Set reason message
				this.updateDataField(Util.getConstant("EWF_PropertyName").REASON_MESSAGE, msg);
			}
			// Execute ICM action CloseWorkItemPage to close the workitem and go to home screem
			Action.perform(this.id, 'icm.action.workitem.CloseWorkItemPage');
		},
		
		// Update a data field value using the property controller
		updateDataField: function(fieldName, value) {
			console.log('MODIFIED updateDataField -- ' + fieldName + ' -->', value);
			// Get the property controller
			//var propertyController = this.fieldsWidget._controller.getPropertyController(fieldName);	
			var propertyController = this.fieldsWidget.controller.getPropertyController(fieldName);			
			if (!propertyController)
				return;
			var iSspecValue = true;
			if (propertyController.get("type") ==="datetime" || propertyController.get("type") ==="float")
				iSspecValue = false;								
			var converter = propertyController.converter;
			if (propertyController.get("cardinality") === "single") {
				propertyController.set("value", converter.parse(value, iSspecValue));
			}else {
				propertyController.set("value", array.map(value, function(item) {
				  return converter.parse(item, iSspecValue);
				}, this.fieldsWidget));
			}
		}
		
	});
});
