define(["dojo/_base/declare", 
	"dojo/_base/lang",
	"v11/ewf/util/Util", 
	"ecm/LoggerMixin"], 
	function(declare, lang, Util, LoggerMixin){
    return declare("v11.ewf.pgwidget.fielddataentry.FieldDataEntryContentPaneEventListener", [LoggerMixin], {
	
		contentPane: null,
		
		constructor: function(contentPane){
			this.contentPane = contentPane;
		},
		
		initContentPane: function()	{
			this.contentPane.showContentNode();	
		},

		openWorkItem: function(workItemEditable, coordination)	{		
			// Check if this is a field work item
			var properties = workItemEditable.propertiesCollection;
			var workItemType = Util.getWorkItemType(properties);
			
			//Modified by Purna - Extra condition for Multi Section
			if (properties[Util.getConstant("EWF_PropertyName").MULTI_SECTION_COORDINATES]) {
				this.contentPane.isMultiSection = 'Y';
				console.log('workItemType is Multi Section');
			} else {
				this.contentPane.isMultiSection = 'N';
			}
			//End
			 
			// Get the column count	and fields to be rendered		
			var symName;				
			if (workItemType === Util.getConstant("EWF_WorkItemType").FIELD) { // Field DE
				symName = Util.getConstant("EWF_PropertyName").FIELD_NAME;
				this.contentPane.columnCount = null;
			} else if (workItemType === Util.getConstant("EWF_WorkItemType").SECTION) {  // Section DE
				symName = Util.getConstant("EWF_PropertyName").SECTION_FIELD_NAMES;
				var property = properties[Util.getConstant("EWF_PropertyName").SECTION_COLUMN_TYPE];
				this.contentPane.columnCount = property ? property.value : null;
			} else {// Special Section DE	
				symName = Util.getConstant("EWF_PropertyName").SPECIAL_SECTION_FIELD_NAMES;
				this.contentPane.columnCount = null;
			}
						
			var fieldsToRender = properties[symName] ? properties[symName].getValue() : [];				

			// Save objects
			this.contentPane.workItemEditable = workItemEditable;
			this.contentPane.properties = properties;
			this.contentPane.coordination = coordination;
			this.contentPane.workItemType = workItemType;
			this.contentPane.fieldsToRender = fieldsToRender;					
			
			if (fieldsToRender.length === 1 && fieldsToRender[0] === "") // ignore the system default value
				return;

			// Display the fields and instructions
			this.render();
		},
		
		/**
		 * Display the fields and instructions
		 */
		render: function()	{	
			this.contentPane.initializeFieldsProperties();
			this.contentPane.showInstruction();
			this.contentPane.showFields();
		}
		 
	});
});
