define([
"dojo/_base/declare", 
"dojo/_base/lang",
"icm/pgwidget/viewer/Viewer",
'ecm/widget/viewer/FilenetViewer',
'dojo/_base/array', 
'icm/util/Util',
'icm/base/Constants',
'dojo/date/locale',
'dojo/mouse',
'dojo/on',
'dojo/dom-geometry',
'dojo/dom-style'
], function(declare, lang, Viewer, FilenetViewer, baseArray, ICMUtil, Constants, dojoLocale, mouse, on, domGeom, domStyle){

    return declare("v11.ewf.pgwidget.virtualdocumentviewer.VirtualDocumentViewer", [Viewer], {
    	
    	resourceBundle: null,
		action: "open",
		currentCaseGUID: "",
		currentWorkItemId: "",
		constants: Constants,
		isViewer: true,
		heightDescriptionNodeExternal: null,
    	
    	constructor: function() {
    		
    		if(dojo.getObject("HavePrintAccess")==undefined || dojo.getObject("CurrentUser")==undefined || ecm.model.desktop.userId != dojo.getObject("CurrentUser")){
				this.ummCall();
			}
			
	 		this.resourceBundle = icm.util.Util.getResourceBundle("viewer");
		},
		ummCall: function(){
			var printRoleCheck = "Print Operator";
			dojo.setObject("HavePrintAccess","NoAccess");
			var roleCheckfunction = dojo.hitch(this, function(response) {
				console.dir(["umm response", response]);
				for(var i = 0; i < response.length; i++){
					if (response[i]==printRoleCheck){
						dojo.setObject("HavePrintAccess","HaveAccess");
						console.log("Have Print Access:ENABLE IT");	
						dojo.query("span[data-dojo-attach-point='containerNode']",this.page.domNode).forEach(function(node) {
							if(node.innerHTML =="Case Print"){
								node=node.parentNode;
								dijit.byId(node.id).setAttribute("disabled",false);
							}
						
						});
					}
				}
			});
			
			var userId = ecm.model.desktop.userId;
			dojo.setObject("CurrentUser", userId);
			var makeUMMCall = dojo.hitch(this,function(){
				var params = {};
				params.subUmmPath = encodeURIComponent("/uamusers/userroles?username="+userId);
				//Modified by Purna BEGIN change - EWFWidgetsPlugin v1.0 is deprecated use EWFWidgetsPluginv11 instead
				ecm.model.Request.invokePluginService( 
					//"EWFWidgetsPlugin", //Commented by Purna
					"EWFWidgetsPluginv11", 
					"EWFUMMService",
					{
						requestParams: params,
						backgroundRequest: true,
						requestFailedCallback: function(errData, errMsg) {
							dojo.setObject("HavePrintAccess","Fail");							   
						},
						requestCompleteCallback: dojo.hitch(this,function(response){
							roleCheckfunction(response);
						})
				});
				//End Change
			});
			makeUMMCall();
		},
		postCreate: function(){
			
			this.inherited(arguments);
			
			console.log("call postCreate");
		},
    	
		handleICM_SendCaseInfoEvent: function(payload){
			
			console.log("call send caseInfoEvent11");

             console.log("payload in send caseinfo event: ",payload);

			//console.log('ewf.pgwidget.documentviewer.DocumentViewer.handleICM_SendCaseInfoEvent() 1');
			if(!payload || !payload.caseEditable){
			    return;
			}

			//Call the parent methods
			//this._cacheCurrentCaseGUID(payload);
			
			//Custom Control from here
			var _this = this;
			
			//Clear the Viewer Content on receiving Payload.
			_this.handleICM_ClearContentEvent();
			console.log("1111111111111111111111111");
					
			if(payload.caseEditable){
			    console.log("enter into payload.caseEditable");
				payload.caseEditable.getCase().retrieveCachedAttributes(lang.hitch(this, function(payload, caseObject){
					var docId = '', docFound=false;
					this.caseObject = caseObject;
					if(caseObject && caseObject._fullAttrsRetrieved){
						docId += "EWSDocument," + payload.caseEditable.getCase().attributes.ClassDescription.ObjectStoreIdentity + ",";
					}
					
					var docIdPropValue = caseObject.attributes["EWF_CTRLDocIdentifier"];
					
					console.log("docIdPropValue is :",docIdPropValue);
					
					if (!docIdPropValue || (typeof docIdPropValue === typeof undefined) || (docIdPropValue.indexOf(":") < 0)){
						docFound = false; 
					} else if((typeof docIdPropValue !== typeof undefined) && (docIdPropValue.indexOf(":") > 0)){ 
						docFound = true;
					}
					
					console.log("docFound is :",docFound);
					
					if(docFound){
						
						docId += docIdPropValue.substr(0, docIdPropValue.indexOf(":"));
						
						console.log("docId is :",docId);
						
						console.log("repository is :",payload.caseEditable.getCaseType().getSolution().getTargetOS());
						
						this._coordinate(payload);
						var template = docId.substr(0, docId.indexOf(","));
						var documentItem = new ecm.model.ContentItem({ 
		    				"repository": payload.caseEditable.getCaseType().getSolution().getTargetOS(),
		    				"id": docId,
	    				    "template": template});
		    			//this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
		    			console.log("documentItem in SendCaseInfoEvent: ",documentItem);
		    			documentItem.retrieveAttributes(lang.hitch(this, function() {
							this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
						}), true, true);
					} else{
						//Fallback option to identify the primary doc by navigating through all the docs in Case Folder
						if(payload && payload.caseEditable){
							var caseItem = payload.caseEditable.getCase();
							if(caseItem && (caseItem !== null)){
								caseItem.retrieveCaseFolder(lang.hitch(this, this.openInitCaseFolder, payload));
							}
						}
					}
				}, payload));
			}
		
			
		},
		
		openInitCaseFolder: function(payload, initCaseFolder){
			
			console.log("call openInitCaseFolder");
			//_this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
			
			
			//console.log('ewf.pgwidget.documentviewer.DocumentViewer.openInitCaseFolder() 1');
			var _this = this;
			initCaseFolder.retrieveFolderContents(false, function(results){
				if(results && results.items && results.items.length > 0){
					var matchFound = false;
					baseArray.forEach(results.items, function(item){
						if(item.template === 'Document' && !matchFound){
							matchFound = true;
							_this._coordinate(payload);
							
							item.retrieveAttributes(lang.hitch(this, function() {
								this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
							}), true, true);
							//_this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
						}
						if(matchFound)
						return;
					});
					if(!matchFound){
						baseArray.forEach(results.items, function(item){
							if(item.template === 'SupportingDocument' && !matchFound){
							    matchFound = true;
								_this._coordinate(payload);
								//_this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
								item.retrieveAttributes(lang.hitch(this, function() {
									this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
								}), true, true);
							}
							if(matchFound)
							return;
						});
					}
					if(!matchFound){
						baseArray.forEach(results.items, function(item){
							if(item.template === 'MigratedBIWS' && !matchFound){
							    matchFound = true;
								_this._coordinate(payload);
								//_this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
								item.retrieveAttributes(lang.hitch(this, function() {
									this.handleICM_OpenDocumentEvent({'contentItem': item, 'action': 'open'});
								}), true, true);
							}
							if(matchFound)
							return;
						});
					}
				}
			});
		},
		
		handleICM_SendWorkItemEvent: function(payload){
			console.log("call handleICM_SendWorkItemEvent");
			if(!payload || !payload.workItemEditable){
			    return;
			}
			//Allow the default Methods to execute here
			//this._cacheCurrentWorkItemId(payload);
			
			//In case this is getNext
			//this.createViewer();
			
			//Clear the Viewer Content on receiving Payload.
			this.handleICM_ClearContentEvent();
			
			payload.workItemEditable.getCase().retrieveCachedAttributes(lang.hitch(this, function(payload, caseObject){
				var docId = '', docFound=false;
				this.caseObject = caseObject;
				if(caseObject && caseObject._fullAttrsRetrieved){
					docId += "EWSDocument," + payload.workItemEditable.getCase().attributes.ClassDescription.ObjectStoreIdentity + ",";
				}
				
				var docIdPropValue = caseObject.attributes["EWF_CTRLDocIdentifier"];
				
				if (!docIdPropValue || (typeof docIdPropValue === typeof undefined) || (docIdPropValue.indexOf(":") < 0))
					docFound = false; 
				else if((typeof docIdPropValue !== typeof undefined) && (docIdPropValue.indexOf(":") > 0))
					docFound = true;
				
				if(docFound){
					docId += docIdPropValue.substr(0, docIdPropValue.indexOf(":"));
					this._coordinate(payload);
					var template = docId.substr(0, docId.indexOf(","));
	    			var documentItem = new ecm.model.ContentItem({ 
	    				"repository": payload.workItemEditable.getCaseType().getSolution().getTargetOS(),
	    				"id": docId,
	    				"template": template});
	    			//this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
	    			console.log("documentItem is : ",documentItem);
	    			documentItem.retrieveAttributes(lang.hitch(this, function() {
						this.handleICM_OpenDocumentEvent({'contentItem': documentItem, 'action': 'open'});
					}), true, true);
				} else{
					//Fallback option to identify the primary doc by navigating through all the docs in Case Folder
					if(payload && payload.workItemEditable){
						var caseItem = payload.workItemEditable.getCase();
						if(caseItem && (caseItem !== null)){
							caseItem.retrieveCaseFolder(lang.hitch(this, this.openInitCaseFolder, payload));
						}
					}
				}
			}, payload));
		},
		// added by suresh for load document viewer widget in copc all workdatails page need to override resize mehod
		resize: function() {
			    	this.logEntry("resize");
			    	console.log("call resize method");
			    	if (this.contentViewer && this._openedItems) {
			    		var height = this.domNode.style["height"];
			    		var heightNode = this._getNodeHeight(height);
			    		
		    			if (heightNode != null) {
				    		if (typeof heightNode == "string"&& heightNode.indexOf("%") > -1) {
				    			domStyle.set(this.contentNode, "height", "100%");
				    			domStyle.set(this.contentViewer.domNode, "height", "100%");
				    		}
				    		else {
				    			domStyle.set(this.contentNode, "height", heightNode + "px");
				    			domStyle.set(this.domNode, "height", heightNode + "px");
								domStyle.set(this.contentViewer.domNode, "height", heightNode + "px");	
				    		}
				    		this.contentViewer.startup();
							this.contentViewer.layout();	
		    			} 		
			    	}
			    	this.logExit("resize");
			    },
			    
		_getNodeHeight: function(height) {
			    	this.logEntry("_getNodeHeight");
			    	console.log("call _getNodeHeight");
			    	var heightNode;
		    		if (this._heightExternalNode) {
	    				// Custom component. Custom component such as dialog must pass an object to constructor like {height: "400px"} and then call build(node) passing it container node.
	    	    		heightNode = parseInt(this._heightExternalNode);
		    		}
		    		else {
	    				// ICM Page widget 
		    			var preferredHeight = parseInt(this.getWidgetAttributes().getItemValue("PreferredHeight"));
		    			
	    	    		if (preferredHeight === "auto") {
	    	    		     console.log("===if preferredHeight is auto ===");
	    	    			//heightNode = parseInt(preferredHeight);
	    	    				try{
		                    		 preferredHeight = this.domNode.parentNode.clientHeight * 0.98;
		                    		
		                    	}catch(e){
		                    		preferredHeight = domGeom.getContentBox(this.domNode).w;
		                    	}
	    	    		}else{
	    	    		       try{
	    	    		            preferredHeight = this.domNode.parentNode.clientHeight * 0.98;
	    	    		           }catch(e){
		                    		      preferredHeight = domGeom.getContentBox(this.domNode).w;
		                    	           }
	    	    		}
	    	    		if (height.indexOf("px") > -1) {
	    	    			heightNode = parseInt(height);
	    	    		}
	    	    		if (height.indexOf("%") > -1) {
	    	    			heightNode = height;
	    	    		}
	    	    		if (heightNode == null) {
	    	    			heightNode = parseInt(preferredHeight);
	    	    		}
	    	    		if((height === "auto") || (preferredHeight === "auto")){
		                        heightNode = parseInt(preferredHeight);
		                    }
		    		}
		    		this.logExit("_getNodeHeight");
		    		return heightNode;
			    },	  
			    
		handleICM_ClearContentEvent: function() {
			this.currentCaseGUID = "";
			this.currentWorkItemId = "";
			this.reset();
		},
		
		reset: function() {
				console.log("call reset :",this);
				this.destroyContentViewer();
				this.hideContentNode();
			},  		
		
		handleICM_OpenDocumentEvent: function(payload){
			console.log("======call handleICM_OpenDocumentEvent=====");
			var _this = this;
			//Override the default behavior methods
			var _this = this;
			this.build();
			var action;
			if(payload && payload.action) {
				action = payload.action;
			} else { action = this.action; }
			if(payload && payload.contentItem)
				//this.navigatorViewer && this.navigatorViewer.show && this.navigatorViewer.show(payload.contentItem, action, lang.hitch(this, function() { this.showContentNode(); this.resize(); }));
				this.show(payload.contentItem, payload.action ? payload.action : this._action);
			else 
				return;
		},
		checkAnnotaionEnable : function(){
			console.log('Entered into checkAnnotaionEnable');
			var _this = this;
			var annotateCheck = false;
			var curSolutionPrefix = _this.solution.prefix;
			var solutonPrefixes = Util.getConstant("EWF_ANNOTATION_ENABLE");
			if(solutonPrefixes && solutonPrefixes != undefined && solutonPrefixes != null && solutonPrefixes != ""){
				functional.forIn(functional.keys(solutonPrefixes), function(prefixes){
					if(curSolutionPrefix != null && curSolutionPrefix!= "" && prefixes != undefined  && prefixes != null && curSolutionPrefix === prefixes){
						annotateCheck = solutonPrefixes[prefixes];
					}
				});
			}	
			return annotateCheck;
		}
	});
});
