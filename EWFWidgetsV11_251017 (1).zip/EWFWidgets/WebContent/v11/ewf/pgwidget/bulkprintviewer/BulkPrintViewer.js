define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",
	"ecm/model/Request",
	"v11/ewf/pgwidget/bulkprintviewer/BulkPrintViewerEventListener",
	"v11/ewf/pgwidget/bulkprintviewer/dijit/BulkPrintViewerContentPane"
], 
function(declare, lang, BasePageWidget, BaseActionContext, Request, eventHandler, contentPaneWidget){

    return declare("v11.ewf.pgwidget.bulkprintviewer.BulkPrintViewer", [contentPaneWidget, BasePageWidget, BaseActionContext, Request], {
 
		contentPaneEventListener: null,
		caseType: null,
		viwerHTML : '/EWFWidgetsv11/v11/ewf/viewer/bulkPrintViewer.html',
		getDocumentUrl : '/navigator/p8/getDocument.do',
		folderId:'',
		
		postCreate: function(){
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane();
		},
		
		handlePrintSelectWorkItems: function(payload){
			var token = Request._security_token;
			this.contentPaneEventListener.showDocument(payload, token);
		},
		
		handleICM_ClearContentEvent: function() {
			this.currentCaseGUID = "";
			this.currentWorkItemId = "";
			
		},
		
		handleICM_SendWorkItemEvent: function(payload){			
			var callback = lang.hitch(this, function(workitem){
				this.folderId = workitem.getCaseFolderId();
			});
			
			if(payload.workItemEditable){
			   payload.workItemEditable.retrieveCachedAttributes(lang.hitch(this,callback));
			}
			
			var token = Request._security_token;
			var contentItemdocid = this.folderId;
			var repositoryid = payload.workItemEditable.repository['id'];
			var documentURL = this.viwerHTML+'?url='+this.getDocumentUrl;
			var docid='';
			var template_name = '';
			var vsId = '';
			var objectStoreName = '';
			var doc_title = '';
			
			//making ajax call to get folder data from contentItems
			var contentItemUrl = "/navigator/p8/getContentItems.do";
			var contentItem_content = {desktop:'icm', docid: contentItemdocid, objectStoreId: '', repositoryId: repositoryid,security_token:token,template_name:'Folder',version:''};	
			dojo.xhrPost({ url: contentItemUrl, handleAs: 'json', sync: true, failOk: true, content: contentItem_content,
				headers: { "Content-Type":"application/x-www-form-urlencoded"},
				handle: function(_contenItempayload) {
					try {
						var folderDocId =  _contenItempayload.rows[0].id;
						var folderName =   _contenItempayload.rows[0].name;
						var folderObjectStoreId =   _contenItempayload.rows[0].objectStoreId;

						//making ajax call to get document data from folder
						var _url = "/navigator/p8/openFolder.do";
						var _content = {desktop:'icm', docid: folderDocId, filter_type: '', name: folderName,objectStoreId:folderObjectStoreId,repositoryId:repositoryid,security_token:token};	
						dojo.xhrPost({ url: _url, handleAs: 'json', sync: true, failOk: true, content: _content,
							headers: { "Content-Type":"application/x-www-form-urlencoded"},
							handle: function(folderPayload) {
								try {
									dojo.forEach(folderPayload.rows, function(docs,index){
										docid = docs['id'];
										template_name = docs['template'];
										objectStoreName = docs['objectStoreName'];
										vsId = docs['vsId'];
										doc_title = docs['name'];
									});
								} catch (e){console.log("Exception occurred while getting payload", e);}
							}
						});
					} catch (e){console.log("Exception occurred while getting getContentItems payload", e);}
				}
			});
			
			
			//get case data  to update the case comments when user clicks print option on viewer
			this.folderId = this.folderId.substring(1, this.folderId.length-1);
			documentURL = documentURL+'?docid='+docid+'&template_name='+template_name+'&repositoryId='+repositoryid+'&vsId='+vsId+'&objectStoreName='+objectStoreName+'&security_token='+token+'&permission='+this.widgetProperties.Permission;
			this.contentPaneEventListener.viewDocument(documentURL,  token);
		},
		
		handleICM_OpenDocumentEvent: function(payload) {
			
		},
		
		handleICM_SendCaseInfoEvent: function(payload) {
			
		}
		
	});
});
