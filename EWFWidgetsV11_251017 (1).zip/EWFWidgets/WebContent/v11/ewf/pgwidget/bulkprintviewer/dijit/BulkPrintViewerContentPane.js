define([ "dojo/_base/declare", 
    "dojo/text!./templates/BulkPrintViewer.html", 
	"icm/base/_BaseWidget",
	"dojo/cookie",
	"dojo/json",
	"dojo/dom-construct",
	"dojo/_base/connect",
	"dojo/date/locale"
], 
function(declare, template, _BaseWidget, cookie, json, domConstruct, connect, dojoLocale){
	
	return declare("v11.ewf.pgwidget.bulkprintviewer.dijit.DocumentViewerContentPane", [_BaseWidget], {
		templateString: template,
		widgetsInTemplate: true,
		wobNumber:null,
		_viewerIframe: null,
		
		constructor: function(){
			
		},
		postCreate:	function(){
			this.inherited(arguments);
		},
		_initializeIframe: function() {
			if (this.contentNode.children.length > 0) {
				this.contentNode.removeChild(this.contentNode.children[0]);
				this._viewerIframe = null;
			}
			this._viewerIframe = domConstruct.create('iframe', {
				style: {
					margin: "0px",
					padding: "0px",
					width: "100%",
					height: "100%"
				}
			});
			this.contentNode.appendChild(this._viewerIframe);
			this._viewerIframe.docViewer = this;
			this._viewerIframe.title = "IframeDocViewer";
		},
		show: function(payload, token) {
			this._initializeIframe();
			var _payload = '';					
			var documentURL = this.viwerHTML+'?url='+this.getDocumentUrl+'&security_token='+token;
			this.wobNumber = '';
			this.wobNumber = payload.WobNumber;
			
			//Added by Purna for capturing the date time of print action
			var currentDate = dojoLocale.format(new Date(), {datePattern: 'dd/MM/yyyy'});
			payload.currentDate = currentDate;
			//End change
			
			var temp = json.stringify(payload);
			this._viewerIframe.docIdData = temp;
			console.log('temp.WobNumber ->', this.wobNumber);
			this._viewerIframe.src = documentURL;

		},
		
		_onFnViewerEvent: function(n) {
			
			var methodName = "_sendFnViewerSignal";
			this.lastEvent = n;

			switch (n) {
			
				case 27:
					alert('Print Completed : Batch Header Sheet will be generated');
					console.log('this.wobNumber in print -> ', this.wobNumber);
					this.onBroadcastEvent("icm.RePrint.sendWorkItem", this.wobNumber);
	
					this.contentNode.removeChild(this.contentNode.children[0]);
					// need to fire the event 
					break;
				case 26:
					
					console.log('print Cancel	-> ', this.wobNumber);
					this.onBroadcastEvent("icm.PrintCancel.sendWorkItem", this.wobNumber);
	
					this.contentNode.removeChild(this.contentNode.children[0]);
					// need to fire the event 
					break;
				case 61: // document failed to load.
					this.logDebug(methodName, "FileNet Viewer failed to load the document");
					break;
				case 21: // focus out of the Applet
					this.logDebug(methodName, "Focus out of the applet");
				
					break;
				case 24:
					this.logDebug(methodName, "Saving FileNet Viewer annotations completed.");
					
					// Don't break - fall through to case 33...
				case 33:
					this.logDebug(methodName, "Calling onDirty(false)");
					
					break;
				case 32:
					this.logDebug(methodName, "Calling onDirty(true)");
					
					break;
				case 22:
					console.log('Document is Ready');
					var applet = this._viewerIframe.contentWindow.document.viewONE;
					applet.printDocument();
					break;
				default: // assume it is a save completed.
					break;
			}

		},
		
		renderUI: function(documentURL, doc_title, token, folderId){
			this._initializeIframe();
			console.log('documentURL -->',documentURL);
			var payload = [{'case':{ 'docID':'Document,{A3E86877-D72D-44C2-B3D2-751F5167960E},{C3FBD696-5EBE-4D69-AEA4-4D12FDA639DD}', 'vsID': '{1231F23E-80FF-424C-9F43-3437CD8B8227}'}},{'caseRefNumber':{ 'docID':'Document,{A3E86877-D72D-44C2-B3D2-751F5167960E},{C3FBD696-5EBE-4D69-AEA4-4D12FDA639DD}', 'vsID': '{1231F23E-80FF-424C-9F43-3437CD8B8227}'}}];
			var temp = json.stringify(payload);
			console.log('temp -> ',temp);
			//cookie("docIds", temp, {expires: 30});
			//alert("The value of the cookie is: "+cookie("docIds"));
			 var checkCookieDocIds = this.getCookie("docIds");
			if(checkCookieDocIds)
			{
				this.WriteCookie("docIds");
			}
			
			this.setCookie("docIds", temp, 30);
			//dojo.attr(this._documentViewFrame, "src", documentURL);	
			console.log('_viewerIframe -->',this._viewerIframe);
			this._viewerIframe.src = documentURL;

		},
		setCookie: function(cname,cvalue,exdays) {
			// set cookies
			var d = new Date();
			d.setTime(d.getTime() + (exdays*24*60*60*1000));
			var expires = "expires=" + d.toGMTString();
			document.cookie = cname+"="+cvalue+"; "+expires+"; path=/";
			
		},
		getCookie: function (cname) {
			// get cookies
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for(var i=0; i<ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1);
				if (c.indexOf(name) != -1) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		},
		 read_cookie: function(name) {
			var result = document.cookie.match(new RegExp(name + '=([^;]+)'));
			console.log("result ->", result);
			result && (result = json.parse(result[1]));
			return result;
		},
		 WriteCookie: function(cookievalue)
		{
			// del cookies
		   var now = new Date();
		   now.setMonth( now.getMonth() + 1 ); 
		   document.cookie="docIds=" + cookievalue;
		   document.cookie = "expires=" + now.toUTCString() + ";"
		   
		}
	});
});
