define(["dojo/_base/declare", 
	"dojo/_base/lang",
	"ecm/LoggerMixin"
], 
function(declare, lang,  LoggerMixin){
    return declare("v11.ewf.pgwidget.bulkprintviewer.BulkPrintViewerEventListener", [LoggerMixin], {
	
		contentPane: null,
		
		constructor: function(contentPane){
			this.contentPane = contentPane;
		},
		
		initContentPane: function()	{
			this.contentPane.showContentNode();	
		},
		
		viewDocument: function(documentURL, doc_title, token, folderId) {
			this.contentPane.renderUI(documentURL, doc_title, token, folderId);
		},
		
		showDocument: function(payload, token) {
			this.contentPane.show(payload, token);
		}
		 
	});
});
