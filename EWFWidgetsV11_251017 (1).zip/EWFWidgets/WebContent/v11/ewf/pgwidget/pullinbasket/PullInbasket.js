define(["dojo/_base/declare", "dojo/json",
"icm/pgwidget/inbasket/Inbasket",
"v11/ewf/action/workitem/_EWFWorkItemHandlerMixin"
],

    function(declare, dojojson, Inbasket){

        return declare("v11.ewf.pgwidget.pullinbasket.PullInbasket", [Inbasket], {
        	
        	setInbasketFilters: function(noneOrVars,inbasket) {
    			if(dojo.isArray(noneOrVars)){
    				if(noneOrVars.length > 0) {
    					var filterCriteria = {};
    					filterCriteria.filters = noneOrVars;
    					var filters = dojojson.stringify(filterCriteria);
    					this.queryMap[inbasket.queueName][inbasket.name].filters = filters;
    					//Added by Purna - Set the filters on the Inbasket so that even when sorted the filter is not removed. Clearing the filter has to be done
    					inbasket.filterValues = filters;
    					//End
    				} else {
    					this.queryMap[inbasket.queueName][inbasket.name].filters = null;
    					//Added by Purna - Set the filters to null on the inbasket
    					inbasket.filterValues = null;
    					//End
    				}
    				
    			}
    		}
    	// commented by suresh on 22/11/2016 these override methods logic is available in icm 5.2.1 no need to override these methods
    		
    		/*getInbasketFilters: function(inbasket) {
    			var filters = this.queryMap[inbasket.queueName][inbasket.name].filters;
    			return filters;
    		},
    		
    		setInbasketQueryFilter: function(orVars,hideLockedByOther,inbasket) {
    			if(dojo.isArray(orVars)){
	                if(orVars.length > 0 || hideLockedByOther){
	                    var queryFilter = this.inbasketFilterUtil._parseQueryFilter(orVars,hideLockedByOther);
	                    this.queryMap[inbasket.queueName][inbasket.name].uiQueryFilter = queryFilter;
	                } else {
	                    this.queryMap[inbasket.queueName][inbasket.name].uiQueryFilter = null;
	                }
	            }
    		},
    		
    		setInbasketSubstitutionVars: function(orVars,hideLockedByOther,inbasket) {
    			var substitutionVars = orVars;
	            if(hideLockedByOther) {
	                substitutionVars.push({
	                    "name": "F_Locked",
	                    "value": [0,1],
	                    "type": "xs:integer"
	                });
	                substitutionVars.push({
	                    "name": "F_LockUser",
	                    "value": "\"{{USN:" + this.solution.getTargetOS().userId + "}}\"",
	                    "type": "xs:string"
	                });
	            }
	            if(dojo.isArray(substitutionVars)) {
	                if(substitutionVars.length > 0){
	                    this.queryMap[inbasket.queueName][inbasket.name].uisubstitutionVars = substitutionVars;
	                } else {
	                    this.queryMap[inbasket.queueName][inbasket.name].uisubstitutionVars = null;
	                }

	            }
    		},
    		
    		getInbasketQueryFilter: function(inbasket){
    			var uiQueryFilter = this.queryMap[inbasket.queueName][inbasket.name].uiQueryFilter;
    			var queryFilter = this.queryMap[inbasket.queueName][inbasket.name].queryFilter;
				var filter = null;
	            if(queryFilter){
					filter = queryFilter;
	            }
	            
	            if(uiQueryFilter){
	                filter = (filter !== null) ? (filter + " AND " + uiQueryFilter) : uiQueryFilter;
	            }
	
	            return filter;
    		},
    		
    		getInbasketSubstitutionVars: function(inbasket) {
	            var uisubstitutionVars = this.queryMap[inbasket.queueName][inbasket.name].uisubstitutionVars;
	            var substitutionVars = this.queryMap[inbasket.queueName][inbasket.name].substitutionVars;
	            var vars = [];
	            if(substitutionVars){
	                vars = vars.concat(substitutionVars);
	            }
	            if(uisubstitutionVars){
	                vars = vars.concat(uisubstitutionVars);
	            }
	            return {"substitution_vars":vars};
	
	        },
	        _setQueryMap: function(filters,filterMap){
				if(filters && dojo.isArray(filters)){
					for(var i = 0; i < filters.length; i++){
						var queueName = filters[i].queueName;
						var inbasketName = filters[i].inbasketName;
						if(this.queryMap[queueName] && this.queryMap[queueName][inbasketName]){
							if(filterMap[queueName][inbasketName].filters){
								this.queryMap[queueName][inbasketName].filters = filterMap[queueName][inbasketName].filters;
							}
							this.queryMap[queueName][inbasketName].queryFilter = filterMap[queueName][inbasketName].queryFilter;
							this.queryMap[queueName][inbasketName].substitutionVars = filterMap[queueName][inbasketName].substitutionVars;
							this.queryMap[queueName][inbasketName].hideFilterUI = filters[i].hideFilterUI;
						}
					}
				}
			}*/
        });
    });
