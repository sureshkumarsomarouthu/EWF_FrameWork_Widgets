/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2010, 2013 US
 * Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define(
    [ "dojo/_base/declare", "dojo/_base/lang", "dojo/json","dojo/aspect",
        "dojo/dom-geometry", "dojo/dom-style",
        "dijit/layout/ContentPane", "dijit/layout/TabContainer",
        "icm/base/_BaseWidget", "icm/base/BaseActionContext",
        "v11/ewf/util/Util",
        "icm/model/properties/controller/ControllerManager",
        "icm/widget/menu/Toolbar",
        "icm/widget/listView/modules/RowContextualMenu",
        "icm/widget/menu/ContextualMenu",
        "icm/widget/menu/MenuManager",
        "dojo/text!./templates/AssociateDocumentContentPane.html",
        "icm/model/properties/controller/ControllerManager",
        "ecm/model/SearchTemplate","ecm/model/SearchClass","ecm/model/SearchFolder",
		"icm/model/PropertyEditable"],
    function(declare, lang, json,aspect, domGeometry, domStyle, contentPane,
             tabContainer, _BaseWidget, baseActionContext, Util,
             controllerManager, icmToolbar, icmContextMenu,
             icmContextualMenu, menuManager, template,ControllerManager,SearchTemplate,SearchClass,SearchFolder, PropertyEditable) {

        /**
         * @private
         * @name ewf.pgwidget.associatedocument.dijit.AttachmentContentPane
         * @class Displays attachments of a work item.
         * @augments icm.base._BaseWidget, icm.base.BaseActionContext
         */
        return declare(
            "v11.ewf.pgwidget.associatedocument.dijit.AttachmentContentPane",
            [ _BaseWidget, baseActionContext ],
            {

                templateString : template,
                
                _payload : null,
				
				

                constructor : function(context) {

                    this.context = context;

                    this.addedCases = {};

                    this.crnCaseIdMap = {};

                },


                postCreate : function() {

                    this.inherited(arguments);

                    this.contentList = this.ecmContentList;

                    this.contentList.setContentListModules(this._getContentListModules());

                    this.connect(this.contentList, "onSelectItem", function(selectedItems){
                        this._onSelectItem(selectedItems);
                    });

                    this.connect(this.contentList, "_createGrid", "_createGrid");

                    this.connect(this.contentList,"onBeforeSetResultSet","onBeforeSetResultSet");

                    if (this.contentList.startup)
                        this.contentList.startup();

                },

                onBeforeSetResultSet: function(resultSet){
                  this.setGridStructure(resultSet);
                  this.addCaseIDColumn(resultSet);
                },

                addCaseIDColumn: function(resultSet){
                    var items = resultSet.items;
                    if(items){
                        for(var i = 0; i < items.length; i++){
                            var item = items[i];
							
                            item.attributeTypes["CaseId"] = "xs:string";
							item.attributes["CaseId"] = "";
							item.attributeDisplayValues["CaseId"] = "";
							this._UpdateCaseIDAndCRN(item);
                        }
                    }
                },
				
				_initcrnCaseIdMap: function(){
					var cdmValue = this._getModelValue(this.workItemEditable,"CaseDocumentsMap");
					if(cdmValue == null){
						return;
					}
					for(var i = 0; i < cdmValue.length; i++) {
						var obj = json.parse(cdmValue[i]);
						var caseId = obj.CaseID;
						var crn = obj.CRN;
						this.crnCaseIdMap[crn] = caseId;
					}
				},
				
				_UpdateCaseIDAndCRN: function(item){
					
					var cdmValue = this._getModelValue(this.workItemEditable,"CaseDocumentsMap");
					
					for(var i = 0; i < cdmValue.length; i++) {
						var obj = json.parse(cdmValue[i]);
						var docIds = obj.DocIDs;
						var caseId = obj.CaseID;
						var crn = obj.CRN;
						for(var j = 0; j < docIds.length; j++) {
							if(docIds[j] == item.vsId){
								item.attributes["CaseId"] = caseId;
								item.attributeDisplayValues["CaseId"] = crn;
							}
						}
					}
					
				},

                setGridStructure: function(resultSet){
                    var newCell = [{"field":"CaseId","name":"Associated Case","nosort":true,"sortable":false,"width":"20em"}];
                    if(resultSet && resultSet.structure && resultSet.structure.cells && dojo.isArray(resultSet.structure.cells)){
                        var cells = resultSet.structure.cells[0];
                        for(var i = 0; i < cells.length; i++) {
                            if(!cells[i].decorator) {
								if(cells[i].field == "DocumentTitle"){
									cells[i].name = "Document Title";
								}
                                newCell.push(cells[i]);
                            }
                        }
                        resultSet.structure.cells[0] = newCell;
                    }
                },


                destroyRecursive : function() {
                    this._closeView();
                    this.inherited(arguments);
                },

                _init: function(payload){
					//this._initcrnCaseIdMap();
					this._payload = payload;
                    this._displayDocuments();
                },

                _createGrid: function(){
                   // this._initTree();
                   // this._showExistedAssoDocs();
				   
                    this.fireFirstDocument();
                },

                fireFirstDocument: function(){
                    var store = this.contentList.grid.store;
                    var allDocItems = store.parentModelObject.items;
                    if(allDocItems && allDocItems.length > 0){
                        var payload = {
                            "contentItem": allDocItems[0],
                            "action": "open"
                        };
                        //commented the below code by suresh as part of 5.2.1 upgrade for jira issue PEWFSGUPGS-185
                       //this.onBroadcastEvent("icm.OpenDocument",payload);
                    }
                },

                resize : function() {
					var size = this._getContainerSize();
					//alert("call resize, w is " + size.w);
					if(this.contentList && this.contentList.grid){
						//alert("call resize, w is " + size.w);
						this.contentList.grid.resize({w: size.w-10, h: undefined}); 
					} else{
						//this.contentList.grid.resize();
					}
                },

                _getContentListModules : function() {
                    var array = [];
                    array.push({
                        moduleClass : icmContextMenu,
                        dojoAttachPoint : "documentContextMenu"
                    });
                    return array;
                },

                _onSelectItem: function(selectedItems) {
                    this.cleanActionContext("Document");
                    for ( var i = 0; i < selectedItems.length; i++) {
                        this.setActionContext("Document", selectedItems[i],true);
                    }

                },

                _clearContent : function() {
                    this._closeView();
                },

                _getSearchTemplateResults: function() {
                    // Compose the property list for query
                    var propertyList = ["DocumentTitle",
                        "BatchId",
						"CustomerName1",
                        "CustomerName2",
						"CustomerCountry"/*,
						"LegalId",
						"IDType",
						"idCountryofIssue",
                        "CIFNumber",
						"CustomerSegment",
                        "AccountNumber",
                        "AccountName1",
                        "AccountName2"*/
                    ];


                    var resultsDisplay = {
                        columns: propertyList,
                        "saved":true
                    };

                    return resultsDisplay;
                },

                _getModelValue: function(model,property){
                    var controllerCollection = ControllerManager.bind(model);
                    var propController = controllerCollection.getPropertyController(property);
                    var propValue = propController.get("value");

                    if(propValue instanceof Array){
                        if(propValue[0] != null){
                            return propValue;
                        } else{
                            return [];
                        }
                    } else{
                        return propValue;
                    }
                    return null;
                },
                _setModelValue: function(model,property,propertyValue){
                    var controllerCollection = ControllerManager.bind(model);
                    controllerCollection.beginChangeSet();
                    var propController = controllerCollection.getPropertyController(property);
                    propController.set("value", propertyValue);
                    controllerCollection.endChangeSet();

                },

                _getCDMMap: function(){
                    var items = this.contentList.getResultSet().items;
                    var map = {};
					var map2 = {};
                    if(items && items.length > 0){
                        for(var i = 0; i < items.length; i++){
                            var item = items[i];
                            var caseId = item.attributes.CaseId;
							var crn =  item.attributeDisplayValues.CaseId;
                            if(caseId && caseId != ""){
                                var vsId = item.vsId;
                                if(!map[caseId]){
                                    map[caseId] = [];
                                }
                                map[caseId].push(vsId);
								map2[caseId] = crn;
                            }
                        }
                    }
                    return {"map":map,"map2":map2};

                },

                convertMaptoCDM: function(){
					var mapAll = this._getCDMMap();
                    var map = mapAll.map;
					var map2 = mapAll.map2;
                    var array = [];
                    var obj = {};
                    for(key in map){
                        obj["CaseID"] = key;
                        obj["DocIDs"] = map[key];
						obj["CRN"] = map2[key];
                        //console.dir(obj);
                        array.push(json.stringify(obj));
                    }
                    return array;
                },

                updateCDM: function () {

                    var cdmValue = this._getModelValue(this.workItemEditable,"CaseDocumentsMap");
                    if(cdmValue == null){
                        return;
                    }
                    var newCMD = this.convertMaptoCDM();
                    this._setModelValue(this.workItemEditable,"CaseDocumentsMap",newCMD);
                },

                createCriterion: function() {
                    var criterions = new Array();
                    var criterion = new ecm.model.SearchCriterion({
                        id: "DocumentTitle",
                        name: "Document Title",
                        anded: true,
                        availableOperators: ["STARTSWITH","ENDSWITH","LIKE","NOTLIKE","EQUAL","NOTEQUAL","LESS","LESSOREQUAL","GREATER","GREATEROREQUAL","INANY","NOTIN","NULL","NOTNULL"],
                        selectedOperator:"NOTNULL",
                        defaultOperator:"NOTNULL",
                        dataType: "xs:string",
                        cardinality: "SINGLE",
                        defaultValue: []

                    });
                    criterions.push(criterion);
                    return criterions;
                },

                _displayDocuments : function() {

                    this.currentDRCase = this.workItemEditable.getCase();
                    this.currentDRCase.retrieveCaseFolder(lang.hitch(this,
                        '_showDocuments'));
                },

                getSearchTemplate: function(caseFolder){
                    var repository = this.solution.targetObjectStore;
                    var params = {};
                    params.id = "";
                    params.name = "";
                    params.repository = repository;
                    params.description = "";

                    var searchTemplate = new SearchTemplate(params);

                    var options = {objectType:"document","macros":{"fileTypes":[]}};
                    searchTemplate.objectType = options.objectType;
                    var contentClass = repository.getContentClass("Document");
                    searchTemplate.setSearchContentClass(contentClass);
                    searchTemplate.includeSubclasses = true;

                    var classes = [];

                    var caseType = this.workItemEditable.getCaseType()
                    classes.push(new SearchClass(caseType.id, caseType.id, options.objectType, true));
                    searchTemplate.setClasses(classes);


                    searchTemplate.objectStores = [{id:repository.objectStoreName, symbolicName:repository.objectStoreName, displayName:repository.objectStoreDisplayName}];
                    searchTemplate.folders = [];
                    searchTemplate.andSearch = true;
                    searchTemplate.moreOptions = options;
                    searchTemplate.textSearchType = repository.textSearchType;
                    searchTemplate.className = "Document";
                    searchTemplate.classDisplayName = "Document";


                    searchTemplate.resultsDisplay = this._getSearchTemplateResults();
                    searchTemplate.searchCriteria = this.createCriterion();

                    var tmp = caseFolder.getPath()[0];
                    var searchFlds = new Array();
                    var searchFld = new SearchFolder();
                    searchFld.objectStoreId = tmp.objectStore.symbolicName;
                    searchFld.objectStoreName = tmp.objectStore.displayName;
                    searchFld.id = tmp.id;
                    searchFld.searchSubfolders=true;
                    var reg = new RegExp("/","g");
                    var pathName = tmp.attributes.PathName.replace(reg,"\\");
                    searchFld.setPathName(pathName);
                    searchFlds.push(searchFld);
                    searchTemplate.folders = searchFlds;
                    return searchTemplate;
                },

                _showDocuments : function(caseFolder) {
                    console.debug("enter _showDocuments");
                    var searchTempldate = this.getSearchTemplate(caseFolder);
                    this.contentList.openItem(searchTempldate);
                },
                _addAssociateCase : function(payload) {
                    if (payload && payload.caseEditable) {
                        var caseId = payload.caseEditable.id;

						  var crn = this._getModelValue(payload.caseEditable,"EWS_CaseReferenceNumber");
                            if(crn == null){
                                crn = caseId;
                            }
                            caseId = "{" + caseId + "}";
                            this.curCaseId = caseId;
                            this.curCRN = crn;
							
                    }
                },

                isAddToCurCaseVisible: function(){
                    var selectedItems = this.getActionContext("Document");
                    if(this.curCaseId && selectedItems && selectedItems.length > 0){
                        return true;
                    }
                    return false;
                },

                isCleanAssociateCaseVisible: function(){
                    var selectedItems = this.getActionContext("Document");
                    for(var i = 0; i < selectedItems.length;i++){
                        var item = selectedItems[i];
                        if(item.attributes.CaseId && item.attributes.CaseId != ""){
                            return true;
                        }
                    }
                    return false;
                },

                addAssociateDocument: function() {
                    
                    //Modified by Purna - get all the documents in the DR case and update the case ref number to all instead of one doc
                    //var documents = this.getActionContext("Document");
                    if(this.contentList && this.contentList._resultSet && this.contentList._resultSet.items) {
                    	var documents = this.contentList._resultSet.items;
                    	
                    	for(var i = 0; i < documents.length; i++) {
                        	this.contentList.grid.store.setValue(documents[i].attributes,"CaseId",this.curCaseId);
							documents[i].attributeDisplayValues["CaseId"] = this.curCRN;
                        	this.contentList.grid.store.onNew(documents[i]);
                    	}
                    	this.contentList.grid.store.save();
						this.updateCDM();
					}
					//End change
                },
				openCaseInfo: function(){
					if(this._payload != null)
     					this.onBroadcastEvent("icm.SendWorkItem", this._payload);
		        },
                cleanAssociateCase: function(){
                    
                    //Modified by Purna - get all the documents in the DR case and update the case ref number to all instead of one doc
                    //var documents = this.getActionContext("Document");
                    if(this.contentList && this.contentList._resultSet && this.contentList._resultSet.items) {
                    	var documents = this.contentList._resultSet.items;
                    	
                    	for(var i = 0; i < documents.length; i++) {
                        	this.contentList.grid.store.setValue(documents[i].attributes,"CaseId","");
							documents[i].attributeDisplayValues["CaseId"] = "";
                        	this.contentList.grid.store.onNew(documents[i]);
                    	}
						this.contentList.grid.store.save();
						this.updateCDM();
                    }
                    //End change
                },
                
                //Reusing this method because it is not using any where.
                removeAssociateCase : function() {
		        	
                },

                removeAssociateDoc : function() {

                },

                _setController: function(){
                	
                	//this.bindControllers();
					
					
					setTimeout(lang.hitch(this, function(){
						console.log('test')
						this.workItemController = ControllerManager.bind(this.workItemEditable);
                        //commented the below code as part of 5.2.1 upgrade onUpdate is changed to onChange
						//this._updateHandler = aspect.after(this.workItemController, "onUpdate", 
						this._updateHandler = aspect.after(this.workItemController, "onChange", 
						  lang.hitch(this, function(updateField) {
							  console.log('Value updated ',updateField );
							  console.log('Value updated F_CaseFolder ',updateField.F_CaseFolder );
							  //commented the below code as part of 5.2.1 F_CaseFolder provider is introduced
							  if(updateField.EWFSV_ProcessingTeam)
							    //if(updateField.F_CaseFolder.EWFSV_ProcessingTeam)
								 this.setPendDocProcessingCenter(updateField.EWFSV_ProcessingTeam.value);
								 //this.setPendDocProcessingCenter(updateField.F_CaseFolder.EWFSV_ProcessingTeam.value);
						}), true);
						
						//Modified by Purna - we should capture the Initial value too 
						var processingTeamController = this.workItemController.getPropertyController("EWFSV_ProcessingTeam");
                		if(processingTeamController && processingTeamController != null) {
                			this.setPendDocProcessingCenter(processingTeamController.get("value"));
                    	}
                    	//End change
                    	
					}), 1000);
                },

                _showExistedAssoDocs: function(){
                    this._caseTree._showExistedAssoDocs();
                },

                _closeView : function() {

                    if(this.context) {
                        delete this.context;
                    }
                    
					this._updateHandler && this._updateHandler.remove();
					this._updateHandler = null;
					this.processingCenter = null;
                },


                _getContainerSize : function() {
                    var dimension = {
                        h : 100,
                        w : 200
                    };
                    var domNodeMarginBox = domGeometry
                        .getMarginBox(this.domNode);

                    if (domNodeMarginBox && domNodeMarginBox.h
                        && domNodeMarginBox.w) {
                        dimension.h = domNodeMarginBox.h > dimension.h ? domNodeMarginBox.h
                            : dimension.h,
                            dimension.w = domNodeMarginBox.w > dimension.w ? domNodeMarginBox.w
                                : dimension.w;
                    }
                    return dimension;
                },



                isModified: function () {
                    if(this.workItemController){
                        return this.workItemController.isModified();
                    }


                    return false;
                },

                resetModified: function () {
                    if(this.workItemController){
                        return this.workItemController.resetModified();
                    }

                },
                bindControllers: function(){
					var workItem = this.workItemEditable.getWorkItem();
					var caseType = this.workItemEditable.getCaseType().id;
					var solutionPrefix = this.workItemEditable.getCaseType().solution.prefix;
					var caseTypeConstants = Util.getConstant(caseType, solutionPrefix);
					var stepName = workItem.getStepName();
					var otherParams = {};
					otherParams.modifiable = true;
					otherParams.parentContext = this.workItemEditable._propertiesParentContext;	
					//otherParams.provider = "F_CaseActivity";
					otherParams.provider = "F_CaseFolder";		
					workItem._initializePropertiesCollectionFromAttributes();
					var fields = caseTypeConstants[stepName]['fields'];
					var modes = caseTypeConstants[stepName]['modes'];
					for (var i = 0; i < fields.length; i ++) {	
						fieldSymName = fields[i];
						propertyName = fieldSymName
						modesValue = modes[i];
						this.solution.attributeDefinitionsById[propertyName]['readOnly'] = modesValue;
						attrDef = this.solution.attributeDefinitionsById[propertyName];	
						otherParams.value = workItem.attributes[propertyName];			
						 //Modified By Gopi As part of ICM 5.2.1 Upgrade
						var property = PropertyEditable._createProperty(propertyName, attrDef.name, attrDef, otherParams,this.workItemEditable.repository);
						this.workItemEditable.propertiesCollection[property.id] = property;
						
						// Mixin the additional definitions
						this.workItemEditable.propertiesCollection[propertyName] = dojo.mixin(this.workItemEditable.propertiesCollection[propertyName], Util.getConstant("EWF_FieldAttributes",solutionPrefix)[fieldSymName]);	
					}
							
                	
                },
                
        				


                _eoc_ : null
            });
    });
