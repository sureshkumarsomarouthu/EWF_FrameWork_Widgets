/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2013
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
    "dojo/_base/declare",
    "icm/base/BasePageWidget",
    "v11/ewf/pgwidget/associatedocument/_AssociateDocumentCoordinationMixin",
    "v11/ewf/pgwidget/associatedocument/dijit/AssociateDocumentContentPane",
    "icm/model/CaseEditable",
    "icm/model/Case"
], function(declare, BasePageWidget, _AssociateDocumentCoordinationMixin, AssociateDocumentContentPane,CaseEditable,Case) {


    return declare("v11.ewf.pgwidget.associatedocument.AssociateDocument", [AssociateDocumentContentPane, _AssociateDocumentCoordinationMixin, BasePageWidget], {


		processingCenter : null,
		
		
		handleICM_SendWorkItemEvent: function (payload)
        {
        	this.logEntry("handleICM_SendWorkItemEvent");
        },
        
		handlePageActivatedWorkItemEvent: function (payload)
        {
        	console.log('Entered ito handlePageActivatedWorkItemEvent');
        	this.logEntry("handlePageActivatedWorkItemEvent");
        	//this.handle_ReceiveWorkItemEvent(payload);
        },
		
		/*
			Below method is called when an other widget fires an event to this widget with exact payload of workItem
		*/
        handle_ReceiveWorkItemEvent: function (payload)
        {
        	console.log('Entered ito handle_ReceiveWorkItemEvent');
        	
            if ((!payload) || (!payload.workItemEditable))
                return;
			
			
            if(payload.workItemEditable) {
                this.workItemEditable = payload.workItemEditable;
                this._configureCoordination(payload.workItemEditable, payload.coordination, this);
                this._setController();
                this._init(payload);

            }
            this.logExit("handleICM_ReceiveWorkItemEvent");
        },

        handleICM_SelectCaseEvent: function(payload){

            this._addAssociateCase(payload);
        },

      


        handleICM_ClearContentEvent: function () {

            this.logEntry("handleICM_ClearContentEvent");

            this._clearContent();

            this.logExit("handleICM_ClearContentEvent");
        },
        
        setPendDocProcessingCenter: function(value){
        
        	this.processingCenter = value;
        },
        
        getPendDocProcessingCenter : function(){
        
        	return this.processingCenter != null ? this.processingCenter : "" ;
        },
        resize: function(payload) {
					
			if(this.ecmContentList)
			{	//dojo.contentBox(this.activityList.grid.domNode, {w: this.domNode.clientWidth - 5, h: this.domNode.clientHeight - 5});
				this.ecmContentList.resize({w: this.domNode.clientWidth - 5, h: this.domNode.clientHeight - 5});
			}	
		}
        
    });
});
