/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2013
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"icm/base/Constants",
	"v11/ewf/util/Util",
	"ecm/widget/dialog/MessageDialog",
	"dojo/i18n!../../nls/common",
	"v11/ewf/dialog/activitydialog/ActivityDialog",
	"icm/model/properties/controller/ControllerManager"
], function(declare, lang, Constants, Util, MessageDialog, resources, ActivityDialog, ControllerManager) {

	var constants = Constants;

	return declare("v11.ewf.pgwidget.associatedocument._AssociateDocumentCoordinationMixin", null, {
	
		workItemEditable: null,
		
		getNLSValue : function(name){
			return resources.DRWarnings[name] || null;
		},
		_configureCoordination: function (workItemEditable, coordination, pgwidget) {
			this.workItemEditable = workItemEditable;
			coordination.participate(Util.getConstant('EWF_CoordTopic').DRROUTEHANDLE, lang.hitch(this, this.beforeCompleteWorkItem));
            coordination.participate(constants.CoordTopic.BEFORESAVE, lang.hitch(this, this.handleICM_BeforeSaveEvent));
			coordination.participate(constants.CoordTopic.AFTERSAVE, lang.hitch(this, this.handleICM_AfterSaveEvent));
			coordination.participate(constants.CoordTopic.BEFORECANCEL, lang.hitch(this, this.handleICM_BeforeCancelEvent));
		},

		handleICM_AfterSaveEvent: function (context, complete, abort) {
			this.logDebug("handleICM_AfterSaveEvent");
			this.resetModified();
			complete();
		},

		handleICM_BeforeCancelEvent: function(context, complete, abort) {
			this.logDebug("handleICM_BeforeCancelEvent");
			if (this.isModified()) {
				abort ({"message":"Do you want to close page without save?"});
			}
			else
				complete();
		},
        handleICM_BeforeSaveEvent: function(context, complete, abort){
            //this.saveCDM();
            complete();
        },
        beforeCompleteWorkItem : function(context, complete, abort){
		
        	console.log('Entered into beforeCompleteWorkItem method');
        	
        	if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").ROUTETOORPHAN){
				
				var documentAssociated = this.isCaseAssociatedToDoc();
				
				if(documentAssociated){
					this.showRouteToOrphanDialog(context, complete, abort);
				}else{
					complete();
					//abort({"message": this.getNLSValue("msg_abort")});
				}
							
        	}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").ROUTETOOC){
			
				var documentAssociated = this.isCaseAssociatedToDoc();
				
				if(documentAssociated){
				
					this.showRouteToOCDialog(context, complete, abort, this.getNLSValue("text_RTOC"));
					
				}else if (this.getPendDocProcessingCenter() == ""){
				
					this.showRouteToOCDialog(context, complete, abort, this.getNLSValue("text_PendDocProcessingCenterRTOC"));
					
				}else{
					complete();
					
				}
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").COMPLETE || context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").ACCEPT){
			
				var documentAssociated = this.isCaseAssociatedToDoc();
				
				if(!documentAssociated){
				
					this.showIncompleteDialog(context, complete, abort);
				}else{
					//WF_ParentCaseRefNo
					//complete();
					if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").COMPLETE ){
						if(this.workItemEditable) {
							var controller = ControllerManager.bind(this.workItemEditable);
								
							var pendReasonPropertyController = controller.getPropertyController("EWS_ReferenceNumber");
							if (pendReasonPropertyController) { 
								
								pendReasonPropertyController.set("value", this.getAssociatedCase());
							}
							
							var parentCaseIDPropertyController = controller.getPropertyController("WF_ParentCaseId");
							if (parentCaseIDPropertyController) { 
								
								parentCaseIDPropertyController.set("value", this.getAssociatedCaseGUID());
							}
							
							ControllerManager.unbind(this.workItemEditable);
							complete();
						}
					}else{
						if(this.workItemEditable) {
							var controller = ControllerManager.bind(this.workItemEditable);
								
							var parentCaseIDPropertyController = controller.getPropertyController("WF_ParentCaseId");
							if (parentCaseIDPropertyController) { 
								
								parentCaseIDPropertyController.set("value", this.getAssociatedCaseGUID());
							}
							ControllerManager.unbind(this.workItemEditable);
							complete();
						}
					}
					//abort({"message": this.getNLSValue("msg_abort")});
				}
				
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").REJECT){
			
				this.showRejectDialog(context, complete, abort, null);
				
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").RETURNTODR){
			
				this.showReturnToDRDialog(context, complete, abort, null);
				
			}else{
				abort({"message": this.getNLSValue("msg_abort")});
			}
			
        	console.log('Exit from beforeCompleteWorkItem method');
        },
        
        completeWorkItem: function(){
        	
        	
        },
		// check case is associated to Document
		isCaseAssociatedToDoc: function(){
		
			var documentAssociated = false;
			
			if(this.contentList.grid && this.contentList.grid.rowCount() > 0){
			
				var gridStore = this.contentList.grid.store;
				
				for(var index = 0; index < this.contentList.grid.rowCount(); index++) {
				
					var gridItem = this.contentList.grid.row(index).item();
					
					if(gridItem.attributeDisplayValues && gridItem.attributeDisplayValues.CaseId){
					
						var caseID = gridItem.attributeDisplayValues.CaseId;
						
						if(caseID !== ""){
							
							documentAssociated = true;
						}
					}
				}
			}
			
			return documentAssociated;
		},
		
		getAssociatedCase: function(){
		
			var caseRefNO = "";		
			
			if(this.contentList.grid && this.contentList.grid.rowCount() > 0){
			
				var gridStore = this.contentList.grid.store;
				
				for(var index = 0; index < this.contentList.grid.rowCount(); index++) {
				
					var gridItem = this.contentList.grid.row(index).item();
					
					if(gridItem.attributeDisplayValues && gridItem.attributeDisplayValues.CaseId){
					
						var caseID = gridItem.attributeDisplayValues.CaseId;
						
						if(caseID !== ""){
							
							caseRefNO = caseID;
						}
					}
				}
			}
			
			return caseRefNO;
		},
		
        getAssociatedCaseGUID: function(){
		
			var caseGUID = "";		
			
			if(this.contentList.grid && this.contentList.grid.rowCount() > 0){
			
				var gridStore = this.contentList.grid.store;
				
				for(var index = 0; index < this.contentList.grid.rowCount(); index++) {
				
					var gridItem = this.contentList.grid.row(index).item();
					
					if(gridItem.attributes && gridItem.attributes.CaseId){
								
						caseGUID = gridItem.attributes.CaseId;
						
					}
				}
			}
			
			return caseGUID;
		},
        showRouteToOrphanDialog : function(context, complete, abort){
        	console.log("Entered into showRouteToOrphanDialog");
			var inCompleteDialog = new MessageDialog({
					text: this.getNLSValue("text_RTO"),
					buttonLabel: this.getNLSValue("label_inComplete_RTO"),
					onCancel:lang.hitch(this, function(){
						abort({"message": this.getNLSValue("msg_abort")});
					})
				});
			inCompleteDialog.cancelButton.set("label", this.getNLSValue("label_inCompleteCancel_RTO"));
			inCompleteDialog.show();
		},
		
		showRouteToOCDialog: function(context, complete, abort, textDescription ){
			console.log("Entered into showRouteToOCDialog");
			var inCompleteDialog = new MessageDialog({
					text: textDescription, 
					buttonLabel: this.getNLSValue("label_inComplete_RTOC"),
					onCancel:lang.hitch(this, function(){
						abort({"message": this.getNLSValue("msg_abort")});
					})
				});
			inCompleteDialog.cancelButton.set("label", this.getNLSValue("label_inCompleteCancel_RTOC"));
			inCompleteDialog.show();
		},
		
		showIncompleteDialog: function(context, complete, abort ){
			console.log("Entered into showIncompleteDialog");
			var inCompleteDialog = new MessageDialog({
					text: this.getNLSValue("text_Incomplete"), 
					buttonLabel: this.getNLSValue("label_inComplete"),
					onCancel:lang.hitch(this, function(){
						abort({"message": this.getNLSValue("msg_abort")});
					})
				});
			inCompleteDialog.cancelButton.set("label", this.getNLSValue("label_inCompleteCancel"));
			inCompleteDialog.show();
		},
		
		showRejectDialog: function(context, complete, abort, resultSet){
			console.log("Entered into showRejectDialog");
			var text = this.getNLSValue("text_reject");
			var title = null;
			var dialog = null;
			var buttonsCollection = {};
				    
			var buttonObj = {};
			buttonObj.buttonLabel = this.getNLSValue("label_OK");
			buttonObj.disabled = true;
			buttonObj.onExecute = lang.hitch(this, function() {
				if(this.workItemEditable) {
					var controller = ControllerManager.bind(this.workItemEditable);
						
					var pendReasonPropertyController = controller.getPropertyController("EWFSV_RejectReason");
					if (pendReasonPropertyController) { 
						pendReasonPropertyController.set("value", dialog.reason.get("value"));
					}
								
					var parentCaseIDPropertyController = controller.getPropertyController("WF_ParentCaseId");
					if (parentCaseIDPropertyController) { 
						
						parentCaseIDPropertyController.set("value", this.getAssociatedCaseGUID());
					}
							
					ControllerManager.unbind(this.workItemEditable);
					complete();
				}
			});
										
			buttonsCollection.ok = buttonObj;
			
			dialog = new ActivityDialog({
					title: this.getNLSValue("title_reject"), // DEV: to be localized
					text: text,
					containReason: true,
					buttonsCollection: buttonsCollection,
					onCancel: lang.hitch(this, function() {
						abort({"message": this.getNLSValue("msg_abort")});
				})
			});
			dialog.show();
		},
		
		showReturnToDRDialog: function(context, complete, abort, resultSet){
			console.log("Entered into showReturnToDRDialog");
			var text = this.getNLSValue("text_RTDR");
			var title = null;
			var dialog = null;
			var buttonsCollection = {};
				    
			var buttonObj = {};
			buttonObj.buttonLabel = this.getNLSValue("label_OK");
			buttonObj.disabled = true;
			buttonObj.onExecute = lang.hitch(this, function() {
				if(this.workItemEditable) {
					var controller = ControllerManager.bind(this.workItemEditable);
						
					var pendReasonPropertyController = controller.getPropertyController("WF_ReturnDRReasons");// Need to change the controller 
					if (pendReasonPropertyController) { 
						pendReasonPropertyController.set("value", dialog.reason.get("value"));
					}
					ControllerManager.unbind(this.workItemEditable);
					complete();
				}
			});
										
			buttonsCollection.ok = buttonObj;
			
			dialog = new ActivityDialog({
					title: this.getNLSValue("title_RTDR"), // DEV: to be localized
					text: text,
					containReason: true,
					buttonsCollection: buttonsCollection,
					onCancel: lang.hitch(this, function() {
						abort({"message": this.getNLSValue("msg_abort")});
				})
			});
			dialog.show();
		}
	});

});

