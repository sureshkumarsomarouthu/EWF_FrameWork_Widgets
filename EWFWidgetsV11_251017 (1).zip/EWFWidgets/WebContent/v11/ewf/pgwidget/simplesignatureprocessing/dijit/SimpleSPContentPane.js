define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"dojo/dom-class",
	"v11/ewf/base/Constants",
    "dojo/text!./templates/SimpleSPContentPane.html", 	
	"icm/base/_BaseWidget",
	"icm/base/Constants",
	"icm/model/PropertyEditable",
	"v11/ewf/widget/fields/Fields",
	"v11/ewf/util/Util",
	"dojo/aspect"
	], function(declare, lang, domClass, Constants, template, _BaseWidget, icmConstants, PropertyEditable, Fields, Util, aspect){
	return declare("v11.ewf.pgwidget.simplesignatureprocessing.dijit.SimpleSPContentPane", [_BaseWidget], {
		
		templateString: template,
		widgetsInTemplate: true,	
		properties: null,
		workItemEditable: null,
		coordination: null,
		caseType: null,

		constructor: function(){
			this.fieldsWidget = new Fields();
		},

		postCreate:	function(){
			this.inherited(arguments);	
		},	
		
		/**
		 * Initialize the fields properties using the additional definition in Constants.js
		 */
        initializeFieldsProperties: function() {
			var workItem = this.workItemEditable.getWorkItem();
			this.caseType = this.workItemEditable.getCaseType().id;
			this.prefix = this.workItemEditable.getCaseType().solution.prefix;
			var fieldSymName, propertyName, attrDef, value;		

			// Get the property symbolic name for the field
			var spConstants = Util.getConstant("SP_CONSTANTS", this.solution.prefix, this.workItemEditable);
			fieldSymName = spConstants[this.caseType]["FIELD_TO_RENDER"];
			propertyName = Util.getSymbolicName(this.solution, fieldSymName);

			// Create PropertyEditable objects
			workItem._initializePropertiesCollectionFromAttributes();
			
			// Update the WorkItemEditable object with the added properties
			var otherParams = {};
			otherParams.modifiable = true;
			otherParams.parentContext = this.workItemEditable._propertiesParentContext;		
			//otherParams.provider = "F_CaseActivity";	
			otherParams.provider = "F_CaseFolder";		
			attrDef = workItem.attributeDefinitions[propertyName];
			otherParams.value = workItem.attributes[propertyName];	
			 //Modified By Gopi As part of ICM 5.2.1 Upgrade
			 //updated by suresh
			var property = PropertyEditable._createProperty(propertyName, attrDef.name, attrDef, otherParams,this.workItemEditable.repository);
			this.workItemEditable.propertiesCollection[property.id] = property;

			// Mixin the additional definitions
			this.workItemEditable.propertiesCollection[propertyName] = dojo.mixin(this.workItemEditable.propertiesCollection[propertyName], 
				Util.getConstant("EWF_FieldAttributes", this.solution.prefix, this.workItemEditable)[fieldSymName]);	
		},

		// Show the fields using dynamically created view
		showFields: function(){		
			//var fieldDef = this.properties[this.prefix + "_" + Constants.SP_CONSTANTS[this.caseType]["FIELD_TO_RENDER"]];
			var spConstants = Util.getConstant("SP_CONSTANTS", this.solution.prefix, this.workItemEditable);
			var fieldSymName = spConstants[this.caseType]["FIELD_TO_RENDER"];
			var fieldDef = this.properties[fieldSymName];
			fieldDiv = this.getPropertyLayout(fieldDef);
			var viewDefinition = "<div data-dojo-type=\"pvr\/widget\/Layout\">" + fieldDiv + "<\/div>";				
			
			// Create the properties dijits
			this.fieldsWidget.setViewMarkup(viewDefinition);
			this.fieldsWidget.setContext(this);

			// Create the properties view in edit mode
			this.fieldsWidget.closeView();
			this.fieldsWidget.openView(this.workItemEditable, lang.hitch(this, this.onOpenView));
		},

		/**
		 * Return the layout for a property
		 */
		getPropertyLayout: function(property) {
			// Set field dijit class name
			var	fieldDijitClass = "\"pvr\/widget\/Property\"";

			// Property symbolic name
			var propertyName = property.id;
			
			// Set layout style as per property type
			var fieldDiv = "<div data-dojo-type=" + fieldDijitClass + " data-dojo-props=\"binding:'" + propertyName + "'";

			// Set editor if required
			if (property.hasOwnProperty('editor')) 
				fieldDiv += ",editor:'" + property.editor + "'";
			
			// Set parameters that are passed to the editor
			//var field = Constants.SP_CONSTANTS[this.caseType]["FIELD_TO_RENDER"];
			var spConstants = Util.getConstant("SP_CONSTANTS", this.solution.prefix, this.workItemEditable);
			var field = spConstants[this.caseType]["FIELD_TO_RENDER"];
			
			var fieldDef = Util.getConstant("EWF_FieldAttributes", this.solution.prefix, this.workItemEditable)[field] || {};
			if (property.propertyExtensionType) { // if custom editor is to be used
				fieldDef = lang.mixin({
					propertyId: property.id
					//value: property.value
				}, fieldDef);	
			}

			if (property.propertyExtensionType == "DecisionWidget") {
				fieldDef = lang.mixin(fieldDef, {
					caseType: this.caseType,
					prefix: this.prefix,
					panel: "sp"
				});
			}
			var editorParams = dojo.toJson(fieldDef).replace(/\"/g, "'");
			
			// Add the editor parameters to the view template.
			fieldDiv += ",editorParams:" + editorParams;

			fieldDiv += "\"><\/div>";
			return fieldDiv;
		},

		/**
		 * Called after the properties are rendered
		 */
		onOpenView: function() {
		    //commented the below code by suresh as part of 5.2.1 upgrade changes
			//this.fieldsWidget._view.set("readOnly", false);
			this.fieldsWidget.view.set("readOnly", false);
			//this.fieldsWidget._configureCoordination(this.workItemEditable, this.coordination);
			this.fieldsWidget.configureCoordination(this.workItemEditable, this.coordination);
			// end changes
			this.createUpdateHandler();
			this.decisionPanel.appendChild(this.fieldsWidget.domNode);				
		},
		
		/**
		 * Create an update handler to set the FieldValue property whenever a field value changes.
		 */
		createUpdateHandler: function() {
			if (this._updateHandler)
				this._updateHandler.remove();
			//this._updateHandler = aspect.after(this.fieldsWidget._controller, "onUpdate", lang.hitch(this, function(changes) {
			this._updateHandler = aspect.after(this.fieldsWidget.controller, "onUpdate", lang.hitch(this, function(changes) {
				//var fieldName = this.prefix + "_" + Constants.SP_CONSTANTS[this.caseType]["FIELD_TO_RENDER"];
				var spConstants = Util.getConstant("SP_CONSTANTS", this.solution.prefix, this.workItemEditable);
				fieldSymName = spConstants[this.caseType]["FIELD_TO_RENDER"];
				var fieldName = fieldSymName;
				// Get the FieldValue property controller
				//var fieldValueController = this.fieldsWidget._controller.getPropertyController(fieldName);
				var fieldValueController = this.fieldsWidget.controller.getPropertyController(fieldName);
				var modified = fieldValueController.isModified();
				this.setDirtyState(modified);
				this.fieldsWidget.adjustDirtyState();
				this.workItemEditable.propertiesCollection[fieldName]['value'] = fieldValueController.get("value");
				this.workItemEditable.propertiesCollection[fieldName]['dirty'] = true;
			}), true);
		}

	});
});
