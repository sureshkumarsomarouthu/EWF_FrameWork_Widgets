define([ "dojo/_base/declare", 
	"dojo/_base/lang",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",		
	"v11/ewf/pgwidget/simplesignatureprocessing/SimpleSPContentPaneEventListener",
	"v11/ewf/pgwidget/simplesignatureprocessing/dijit/SimpleSPContentPane"], 
	function(declare, lang, BasePageWidget, BaseActionContext, eventHandler, contentPaneWidget){

    return declare("v11.ewf.pgwidget.simplesignatureprocessing.SimpleSP", [contentPaneWidget, BasePageWidget, BaseActionContext], {
 
		contentPaneEventListener: null,

		postCreate: function(){
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane();
		},
		
		createActiveXObject: function(context, complete, abort) {
			console.log('createActiveXObject() --> ');
			setTimeout(function(){try{this.ocxObject.SetCursorArea(0, 0, 0, 0); this.ocxObject.HookHotKeys(); this.ocxObject.SetTop(true);}catch(e){}}, 300);
			complete();
		},
		
		removeActiveXObject: function(context, complete, abort){
			var _this = this;
			console.log('removeActiveXObject() --> ', _this.ocxObject);
			setTimeout(function(){try{_this.ocxObject.ReleaseCursor();_this.ocxObject.UnHookHotKeys();_this.ocxObject.SetTop(false);} catch(e){}}, 1);
			if(complete && (typeof complete !== "undefined"))
				complete();
		},
		
		handleICM_SendWorkItemEvent: function(payload){
			this.logEntry("handleICM_SendWorkItemEvent");
			if(!payload || !payload.workItemEditable) {
				this.logError("handleICM_SendWorkItemEvent -- payload: ", payload);
				return;
			} 
			
			// Set action context
			this.setActionContext("WorkItemPage", payload.workItemEditable);
			this.setActionContext("Coordination", payload.coordination);
			if(payload.UIState !== undefined){
				this.setActionContext("UIState", payload.UIState);
			}else{
				this.setActionContext("UIState", null);
			}
			
			payload.coordination.participate("SPCOMPLETE", lang.hitch(this, this.participateSPComplete));
			payload.coordination.participate("BEFORECANCEL", lang.hitch(this, this.removeActiveXObject));
			payload.coordination.participate("AFTERLOADWIDGET", lang.hitch(this, this.createActiveXObject));
			

			// Get the work item object
			var workItem = payload.workItemEditable.getWorkItem();
			// Check if the work item attributes have been retrieved
			if (!workItem.getCaseTaskId()) {
				// retrieves the work item attributes
				workItem.retrieveCachedAttributes(dojo.hitch(this, function(workItem){
					this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);		
				}));
			}
			else {
				this.contentPaneEventListener.openWorkItem(payload.workItemEditable, payload.coordination);		
			}
			this.logExit("handleICM_SendWorkItemEvent");
		},

		participateSPComplete: function(context, complete, abort){
			var _this = this;
			//commented the below code as part of 5.2.1 upgrade _controller is changed to controller
			//var controllerErrors = this.fieldsWidget._controller.validate();
			var controllerErrors = this.fieldsWidget.controller.validate();
			//commented the below code as part of 5.2.1 upgrade _view is changed to view
			//var viewErrors = this.fieldsWidget._view.validate();
			var viewErrors = this.fieldsWidget.view.validate();
			// Ignore the residual controller error on FieldValue
			if (controllerErrors.length > 0 || viewErrors.length > 0) {
				var dialog = new dijit.Dialog({ title: 'Incomplete' });
				var wrapper = dojo.create('div', {style:"align:center"});
				var label = dojo.create('label', {innerHTML: 'Please complete all tasks with signature verification<br/><br/>'});
				wrapper.appendChild(label);
				var buttonDiv = dojo.create('div',{style: "float:right; display: block; margin-top: 10px; margin-right: 10px; margin-bottom: 10px;"});
				var continueButton = new dijit.form.Button({
					label : 'Continue',
					onClick : function (event) {
						dialog.destroy();
						abort({"message": "Aborted"});
					}
				}); 
				buttonDiv.appendChild(continueButton.domNode);
				wrapper.appendChild(buttonDiv);
				dialog.set("content", wrapper);
				dialog.show();
			} else {
				_this.removeActiveXObject(null, null, null);
				complete();
			}
		}
	});
});
