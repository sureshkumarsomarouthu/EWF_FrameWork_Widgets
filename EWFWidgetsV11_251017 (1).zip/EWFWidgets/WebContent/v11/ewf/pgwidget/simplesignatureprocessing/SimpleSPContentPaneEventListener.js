define(["dojo/_base/declare", 
	    "ecm/LoggerMixin"], 
	function(declare, LoggerMixin){
    return declare("v11.ewf.pgwidget.simplesignatureprocessing.SimpleSPContentPaneEventListener", [LoggerMixin], {
	
		contentPane: null,		
		constructor: function(contentPane){
			this.contentPane = contentPane;
		},
		
		initContentPane: function()	{
			this.contentPane.showContentNode();	
		},

		openWorkItem: function(workItemEditable, coordination)	{		
			// Save objects
			this.contentPane.workItemEditable = workItemEditable;
			this.contentPane.properties = workItemEditable.propertiesCollection;
			this.contentPane.coordination = coordination;
			// Display the panel
			this.render();
		},
		
		/**
		 * Display the panel
		 */
		render: function()	{	
			this.contentPane.initializeFieldsProperties();
			this.contentPane.showFields();
		}
	});
});
