define([
	"dojo/_base/declare",
	"dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-style",
	"icm/base/Constants",
	"dojo/i18n!../../nls/common",
	"v11/ewf/model/ActivityList",
    "v11/ewf/pgwidget/activitypanel/dijit/VerticalPendReasonCfg",
	"ecm/widget/dialog/MessageDialog",
	"ecm/widget/dialog/ConfirmationDialog",
	"v11/ewf/dialog/activitydialog/PendDialog",
	"v11/ewf/dialog/activitydialog/ActivityDialog",
	"v11/ewf/dialog/activitydialog/FollowUpDialog",
	"v11/ewf/dialog/activitydialog/EmailActivityDialog",
	"v11/ewf/dialog/activitydialog/ExtensionProviderDialog",
	"v11/ewf/util/Util"
],function(declare, lang, array, domStyle, constants, resources, ActivityList, VerticalPendReasonCfg, MessageDialog, ConfirmationDialog, PendDialog, ActivityDialog, FollowUpDialog, EmailActivityDialog, ExtensionProviderDialog, Util){
	
	return declare("v11.ewf.pgwidget.activitypanel._ActivityPanelCoordinationMixin", null, {
	
		getNLSValue : function(name){
			return resources.ActivityPanel[name] || null;
		},
		
		setCoordinationCfg: function(editable, coordination){
		    //this function is for the setting how to participate each topic of the coordination for each response;    			
			coordination.participate(Util.getConstant("EWF_CoordTopic").MANUALPROCESSINGROUTEHANDLE, lang.hitch(this, this.manualProcessingParticipating));
			coordination.participate(Util.getConstant("EWF_CoordTopic").REVIEWROUTEHANDLE, lang.hitch(this, this.reviewParticipating));
			coordination.participate(Util.getConstant("EWF_CoordTopic").CALLBACKROUTEHANDLE, lang.hitch(this, this.callBackParticipating));
			coordination.participate(Util.getConstant("EWF_CoordTopic").EXCEPTIONROUTEHANDLE, lang.hitch(this, this.exceptionHandlingParticipating));
			return;
		},
		
		manualProcessingParticipating: function(context, complete, abort){
			
			//Added for COA maker checker Validations
			var roleName = ecm.model.desktop.currentRole.name;
			var userId = ecm.model.desktop.userId;
			var caseTypeObj = this.workItemEditable.getCaseType();
			var caseTypeName= caseTypeObj.id;
			var property =null;
			if(caseTypeName == Util.getConstant("EWF_CASE_TYPE").CHANGE_OF_ADDRESS){
				if(roleName==Util.getConstant("ROLE_NAMES").MANUAL_PROCESSING){
					if(this.workItemEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").MP_USER_FIELD)){
						property = this.workItemEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").MP_USER_FIELD];
						var propValue = property.getValue();
						var originalValue = lang.clone(propValue);
						if(this.caseEditable && this.caseEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD)){
							var reworkField = this.caseEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD].value; 
							
							var reworkSplit = null;
							var isRework = null;
							var reworkCount = null;
							if(reworkField){
								reworkSplit=reworkField.split("-");
								isRework = reworkSplit[0];
								reworkCount = reworkSplit[1];
							}else{
								isRework="false";
							}
						
							if(isRework == "false"){
								if(propValue.indexOf(userId)==-1){
									propValue.push(userId);
									property.setValue(propValue);	
									property.originalValue=originalValue;
								}
							}else{
										var counts={};
										for(var countIndex=0;countIndex<originalValue.length;countIndex++){
											var num = originalValue[countIndex];
											counts[num]= counts[num] ? counts[num]+1:1;
										}
										if(counts[userId] ){
											if(counts[userId] < reworkCount){
												propValue.push(userId);
												property.setValue(propValue);	
												property.originalValue=originalValue;
											}
										}else{
												propValue.push(userId);
												property.setValue(propValue);	
												property.originalValue=originalValue;
										}
								}
						}
					}
				}
			
			}
			//End of changes for COA maker checker Validations
			if(context[constants.CoordContext.WKITEMRESPONSE] === "" || context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").COMPLETE || context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").RERUN){
				if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").RERUN){
					complete();
				}else{
				    var status = [];
				    //status.push(Util.getConstant("EWF_AcitivityStatus").FAILED);
					//status.push(Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM);
					
					callbackFunc = lang.hitch(this, function(context, complete, abort, resultSet){
						this.responseToManualProcessingComplete(context, complete, abort, resultSet);		
					}, context, complete, abort);
					
					var activityListModel = new ActivityList({
						repository: this.getSolution().getTargetOS(),
						parentCase: this.caseEditable
					});
					activityListModel.retrieveActivityItems(callbackFunc, status, context, complete, abort);
				}
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").PEND){
				this.showPendDialog(context, complete, abort, "MP");
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").UNPEND 
					|| context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").RESUME){
				complete();
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").EXCEPTION){
				this.showRaiseExceptionDialog(context, complete, abort);
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").REJECT){
				/*var status = [];
			    status.push(Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM);
				
				callbackFunc = lang.hitch(this, function(context, complete, abort, resultSet){
					this.showRejectDialog(context, complete, abort, resultSet);		
				}, context, complete, abort);
				
				var activityListModel = new ActivityList({
					repository: this.getSolution().getTargetOS(),
					parentCase: this.caseEditable
				});
				activityListModel.retrieveActivityItems(callbackFunc, status, context, complete, abort);*/
				this.showRejectDialog(context, complete, abort, null);
				//added by rahul for DR Changes
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").NOTIFYSCANHUB){
				var response = Util.getConstant("EWF_DISPATCH").NOTIFYSCANHUB;
				this.showEmailDialog(context, complete, abort, null, true, response);
				//end
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").SENDTOCOPC || context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").SENDTOPFS){
				complete();
				//end
			}else{
				abort({"message": this.getNLSValue("msg_abort")});
			}
		},
		
		callBackParticipating: function(context, complete, abort){
		//Added for COA maker checker Validations
			var roleName = ecm.model.desktop.currentRole.name;
			var userId = ecm.model.desktop.userId;
			var caseTypeObj = this.workItemEditable.getCaseType();
			var caseTypeName= caseTypeObj.id;
			var property =null;
			if(caseTypeName == Util.getConstant("EWF_CASE_TYPE").CHANGE_OF_ADDRESS){
				if(roleName==Util.getConstant("ROLE_NAMES").CALLBACK){
					if(this.workItemEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").CB_USER_FIELD)){
						property = this.workItemEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").CB_USER_FIELD];
						var propValue = property.getValue();
						var originalValue = lang.clone(propValue);
						propValue.push(userId);
						property.setValue(propValue);	
						property.originalValue=originalValue;
					}
				}
			
			} 
			//End of changes for COA maker checker Validations
			if(context[constants.CoordContext.WKITEMRESPONSE] === "" || context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").COMPLETE){
			    var status = [];
			    //status.push(Util.getConstant("EWF_AcitivityStatus").FAILED);
				//status.push(Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM);
				
				callbackFunc = lang.hitch(this, function(context, complete, abort, resultSet){
					this.responseToCallBackComplete(context, complete, abort, resultSet);		
				}, context, complete, abort);
				
				var activityListModel = new ActivityList({
					repository: this.getSolution().getTargetOS(),
					parentCase: this.caseEditable
				});
				activityListModel.retrieveActivityItems(callbackFunc, status, context, complete, abort);
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").PEND){
				this.showPendDialog(context, complete, abort, "CB");
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").UNPEND){
				complete();
			}else{
				abort({"message": this.getNLSValue("msg_abort")});
			}
		},
		
		reviewParticipating: function(context, complete, abort){
			//Added for COA maker checker Validations
			var roleName = ecm.model.desktop.currentRole.name;
			var userId = ecm.model.desktop.userId;
			var caseTypeObj = this.workItemEditable.getCaseType();
			var caseTypeName= caseTypeObj.id;
			var property =null;
			if(caseTypeName == Util.getConstant("EWF_CASE_TYPE").CHANGE_OF_ADDRESS){
				if(roleName==Util.getConstant("ROLE_NAMES").REVIEWER){
					if(this.caseEditable && this.caseEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD)){
							var reworkField = this.caseEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD].value; 
							
							var reworkSplit = null;
							var isRework = null;
							var reworkCount = null;
							var propValue;
							var originalValue;
							if(reworkField){
								reworkSplit=reworkField.split("-");
								isRework = reworkSplit[0];
								reworkCount = reworkSplit[1];
							}else{
								isRework="false";
							}
						property = this.workItemEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").RV_USER_FIELD];
						
						if(isRework == "false"){
							propValue = property.getValue();
							originalValue = lang.clone(propValue);
							if(propValue.indexOf(userId)==-1){
								propValue.push(userId);
								property.setValue(propValue);	
								property.originalValue=originalValue;
							}
						}else{
							var counts={};
							propValue = property.getValue();
							originalValue = lang.clone(propValue);
							if(originalValue!= null)
							{
							for(var countIndex=0;countIndex<originalValue.length;countIndex++){
								var num = originalValue[countIndex];
								counts[num]= counts[num] ? counts[num]+1:1;
							}
							}
							if(counts[userId] ){
								if(counts[userId] < reworkCount){
									propValue.push(userId);
									property.setValue(propValue);	
									property.originalValue=originalValue;
								}
							}else{
									propValue.push(userId);
									property.setValue(propValue);	
									property.originalValue=originalValue;
							}
								
						}
					}
				}
			} 
			//End of changes for COA maker checker Validations
			if(context[constants.CoordContext.WKITEMRESPONSE] === "" || context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").COMPLETE){
			    var status = [];
			    //status.push(Util.getConstant("EWF_AcitivityStatus").FAILED);
				//status.push(Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM);
				
				callbackFunc = lang.hitch(this, function(context, complete, abort, resultSet){
					this.responseToManualProcessingComplete(context, complete, abort, resultSet);		
				}, context, complete, abort);
				
				var activityListModel = new ActivityList({
					repository: this.getSolution().getTargetOS(),
					parentCase: this.caseEditable
				});
				activityListModel.retrieveActivityItems(callbackFunc, status, context, complete, abort);
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").PEND){
				this.showPendDialog(context, complete, abort, "RV");
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").UNPEND){
				complete();
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").EXCEPTION){
				this.showRaiseExceptionDialog(context, complete, abort);
			}else if(context[constants.CoordContext.WKITEMRESPONSE] === Util.getConstant("EWF_DISPATCH").REJECT){
				var status = [];
			    status.push(Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM);
				
				callbackFunc = lang.hitch(this, function(context, complete, abort, resultSet){
					this.showRejectDialog(context, complete, abort, resultSet);		
				}, context, complete, abort);
				
				var activityListModel = new ActivityList({
					repository: this.getSolution().getTargetOS(),
					parentCase: this.caseEditable
				});
				activityListModel.retrieveActivityItems(callbackFunc, status, context, complete, abort);
			}else{
				abort({"message": this.getNLSValue("msg_abort")});
			}
		},
		
		exceptionHandlingParticipating: function(context, complete, abort){
			this.showExceptionHandlingDialog(context, complete, abort);
		},
		
		responseToManualProcessingComplete: function(context, complete, abort, resultSet){
			var showDialogFunc;
			if(resultSet){
				var items = resultSet.getItems();
				var status = null;
				var myCfgStatus = this.getCfgOfStatus();
				if(array.some(items, function(item) {
					status = item.getValue("ActivityStatus");
					var position = array.indexOf(myCfgStatus, status);
					if(position >= 0 && status !== Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM){
						return true;
					}
				})){
					showDialogFunc = lang.hitch(this, function(context, complete, abort, resultSet){
						this.showInCompleteDialog(context, complete, abort, resultSet);
					});				
				}else{
					if(array.some(items, function(item) {
						status = item.getValue("ActivityStatus");
						if(status === Util.getConstant("EWF_AcitivityStatus").FAILED){
							return true;
						}
					})){
						showDialogFunc = lang.hitch(this, function(context, complete, abort, resultSet){
							this.showFailedDialog(context, complete, abort, resultSet);
						});
					}else{
						if(array.some(items, function(item) {
							status = item.getValue("ActivityStatus");
							if(status === Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM || status === Util.getConstant("EWF_AcitivityStatus").FOLLOWUPCB){
								return true;
							}
						})){
							showDialogFunc = lang.hitch(this, function(context, complete, abort, resultSet){ //show Email dialog
								this.showFollowUpDialog(context, complete, abort, resultSet);
							});
						}else{
							complete();
						}
					}
				}
				if(lang.isFunction(showDialogFunc))
					showDialogFunc(context, complete, abort, resultSet);
			}else{
				complete();
			}
		},
		
		responseToCallBackComplete: function(context, complete, abort, resultSet){
			var showDialogFunc;
			if(resultSet){
				var items = resultSet.getItems();
				var status = null;
				var myCfgStatus = this.getCfgOfStatus();
				if(array.some(items, function(item) {
					status = item.getValue("ActivityStatus");
					var position = array.indexOf(myCfgStatus, status);
					if(position >= 0){
						return true;
					}
				})){
					showDialogFunc = lang.hitch(this, function(context, complete, abort, resultSet){
						this.showInCompleteDialog(context, complete, abort, resultSet);
					});				
				}else{
					showDialogFunc = lang.hitch(this, function(context, complete, abort, resultSet){
						this.showExtensionProviderDialog(context, complete, abort);
					});
				}
				showDialogFunc(context, complete, abort, resultSet);
			}else{
				complete();
			}
		},		
		
		showRejectDialog: function(context, complete, abort, resultSet){
			var text = this.getNLSValue("text_reject");
			var title = null;
			var dialog = null;
			var buttonsCollection = {};
				    
			var emailButtonObj = {};
			emailButtonObj.buttonLabel = this.getNLSValue("label_email");
			emailButtonObj.disabled = true;
			emailButtonObj.onExecute = lang.hitch(this, function() {
										if(this._workItemController){
											var controller = this._workItemController;
												
											var pendReasonPropertyController = controller.getPropertyController("WF_RejectReason");
											if (pendReasonPropertyController) { 
												pendReasonPropertyController.set("value", dialog.reason.get("value"));
											}
											
											var RejectWithEmailPropertyController = controller.getPropertyController("WF_RejectWithEmail");
											if (RejectWithEmailPropertyController) { 
												RejectWithEmailPropertyController.set("value", true);
											}
										}
										var rejectReason = dialog.reason.get("value");
										this.showEmailDialog(context, complete, abort, resultSet, true, "", rejectReason);
									});
										
			buttonsCollection.email = emailButtonObj;
			
			var manualButtonObj = {};
			manualButtonObj.buttonLabel = this.getNLSValue("label_manual");
			manualButtonObj.disabled = true;
			manualButtonObj.onExecute = lang.hitch(this, function() {
										if(this._workItemController){
											var controller = this._workItemController;
												
											var pendReasonPropertyController = controller.getPropertyController("WF_RejectReason");
											if (pendReasonPropertyController) { 
												pendReasonPropertyController.set("value", dialog.reason.get("value"));
											}
											
											//Added by Purna for Enhancement - Capture the Reason on the case
											var rejectReasonPropertyController = controller.getPropertyController("EWFSV_RejectReason");
											if (rejectReasonPropertyController) { 
												rejectReasonPropertyController.set("value", dialog.reason.get("value"));
											}
											//End change
											
											var RejectWithEmailPropertyController = controller.getPropertyController("WF_RejectWithEmail");
											if (RejectWithEmailPropertyController) { 
												RejectWithEmailPropertyController.set("value", false);
											}
										}
										complete();
									});
										
			buttonsCollection.manual = manualButtonObj;
				
				
			dialog = new ActivityDialog({
										title: this.getNLSValue("title_reject"), // DEV: to be localized
										text: text,
										containReason:true,
										buttonsCollection: buttonsCollection,
										onCancel: lang.hitch(this, function() {
											abort({"message": this.getNLSValue("msg_abort")});
									})
			});
			dialog.show();
		},
		
		showRaiseExceptionDialog: function(context, complete, abort){
			var text = this.getNLSValue("text_raiseException");
			var title = null;
			var dialog = null;
			var buttonsCollection = {};
				    
			var raiseExceptionButtonObj = {};
			raiseExceptionButtonObj.buttonLabel = this.getNLSValue("label_raiseException");
			raiseExceptionButtonObj.disabled = true;
			raiseExceptionButtonObj.onExecute = lang.hitch(this, function() {
										if(this._workItemController){
											var controller = this._workItemController;
												
											var pendReasonPropertyController = controller.getPropertyController("WF_ExceptionReason");
											if (pendReasonPropertyController) { 
												pendReasonPropertyController.set("value", dialog.reason.get("value"));
											}
										}
										complete();
									});
										
			buttonsCollection.raiseException = raiseExceptionButtonObj;
				
				
			dialog = new ActivityDialog({
										title: this.getNLSValue("title_raiseException"), // DEV: to be localized
										text: text,
										buttonsCollection: buttonsCollection,
										onCancel: lang.hitch(this, function() {
											abort({"message": this.getNLSValue("msg_abort")});
									})
			});
			dialog.show();
		},
		
		showExceptionHandlingDialog: function(context, complete, abort){
			var text = this.getNLSValue("text_exception");
			var title = null;
			var dialog = null;
			var buttonsCollection = {};
				    
			var ExceptionHandlingButtonObj = {};
			ExceptionHandlingButtonObj.buttonLabel = this.getNLSValue("label_exception");
			ExceptionHandlingButtonObj.disabled = true;
			ExceptionHandlingButtonObj.onExecute = lang.hitch(this, function() {
										if(this._workItemController){
											var controller = this._workItemController;
												
											var pendReasonPropertyController = controller.getPropertyController("WF_ExceptionReason");
											if (pendReasonPropertyController) { 
												pendReasonPropertyController.set("value", dialog.reason.get("value"));
											}
										}
										complete();
									});
										
			buttonsCollection.ExceptionHandling = ExceptionHandlingButtonObj;
				
				
			dialog = new ActivityDialog({
										title: this.getNLSValue("title_exception"), // DEV: to be localized
										text: text,
										buttonsCollection: buttonsCollection,
										onCancel: lang.hitch(this, function() {
											abort({"message": this.getNLSValue("msg_abort")});
									})
			});
			dialog.show();
		},
		
		getVerticalPendReasonList: function(vertical){
			var reasonList = null;
			if(VerticalPendReasonCfg.hasOwnProperty(vertical)){
				reasonList = VerticalPendReasonCfg[vertical];
			}
			
			return reasonList;
		}, 
		
		showPendDialog: function(context, complete, abort, vertical){
			var dialog = null;
			var title = this.getNLSValue("title_pend");
			var buttonsCollection = {};
			var PendButtonObj = {};
			PendButtonObj.buttonLabel = this.getNLSValue("label_pend");
			PendButtonObj.disabled = true;
			PendButtonObj.onExecute = lang.hitch(this, function() {
				if(this._workItemController){
					var controller = this._workItemController;
					
					var pendReasonPropertyController = controller.getPropertyController("WF_PendReason");
					if (pendReasonPropertyController) { 
						pendReasonPropertyController.set("value", dialog._detailReason.get("value"));
					}
					
					var pendTimePropertyController = controller.getPropertyController("WF_PendTime");
					if (pendTimePropertyController) { 
						var durationValue = dialog._reminder.get("value");
						if(durationValue === -1){
							pendTimePropertyController.set("value", durationValue);
						}else if(durationValue === -2){
							pendTimePropertyController.set("value", durationValue);
							var pendFutureDatePropertyController = controller.getPropertyController("WF_PendFutureDate");
							if(pendFutureDatePropertyController){
								pendFutureDatePropertyController.set("value", dialog._futureTransactionReminder.get("value"));
							}
						}else{
							pendTimePropertyController.set("value", dialog._reminder.get("value")*3600);
						}
					}
				}
				complete();
			});
			buttonsCollection.Pend = PendButtonObj;
			var reasonList = null;
			
			reasonList = this.getVerticalPendReasonList(vertical);
			
			if(reasonList === null){
				reasonList = [{"id": 1, "value": "0.5", "label": "Unable to reach customer (Default)"},
								  {"id": 2, "value": "1", "label": "Pending Customer to Revert - 1 hour"},
								  {"id": 3, "value": "4", "label": "Pending Customer to Revert - 4 hours"},
								  {"id": 4, "value": "-1", "label": "Pending Customer to Revert - next Business Day"},
								  {"id": 5, "value": "2", "label": "Pending BU's response - 2 hours"},
								  {"id": 6, "value": "-1", "label": "Pending BU's response - next Business Day"},
								  {"id": 7, "value": "1", "label": "One Hour"},
								  {"id": 8, "value": "1", "label": "Missing Document"},
								  {"id": 9, "value": "1", "label": "Assistance Required"},
								  {"id": 10, "value": "-2", "label": "Future Transaction"}
								 ];
			}
			
			dialog = new PendDialog({
						title: title, // DEV: to be localized
						reasonList:reasonList,
						buttonsCollection: buttonsCollection,
						onCancel: lang.hitch(this, function() {
							abort({"message": this.getNLSValue("msg_abort")});
						})
					});
			dialog.show();	
			domStyle.set(dialog.domNode, 'top', '150px');
		},
		
		showExtensionProviderDialog: function(context, complete, abort){
			var dialog = null;
			var title = this.getNLSValue("title_extensionProvider");
			var text = this.getNLSValue("text_extensionProvider");
			var buttonsCollection = {};
			var OKButtonObj = {};
			OKButtonObj.buttonLabel = this.getNLSValue("label_extensionProvider");
			OKButtonObj.disabled = true;
			OKButtonObj.onExecute = lang.hitch(this, function() {
				if(this._workItemController){
					var controller = this._workItemController;
					var pendReasonPropertyController = controller.getPropertyController("WF_ExtensionInfo");
					if (pendReasonPropertyController) {
						//Modified by Purna for OTT on 25/01/2017 - OTT will not have the field Contact Person.Hence change the value
						if(this.solution.prefix == "EWF"){
							pendReasonPropertyController.set("value", "Extension number:"+dialog._ExtensionNubmer.get("value") + " Contact Number Used:"+dialog._ContactNubmerUsed.get("value"));
						}else {
							pendReasonPropertyController.set("value", "Contact Person:" + dialog._ContactPerson.get("value") + ", Extension number:" + dialog._ExtensionNubmer.get("value") + ", Contact Number Used:" + dialog._ContactNubmerUsed.get("value"));
						}
						//End change by Purna
					}
				}
				complete();
			});
			buttonsCollection.Pend = OKButtonObj;
			dialog = new ExtensionProviderDialog({
						title: title, // DEV: to be localized
						text: text,
						solutionPrefix: this.solution.prefix,//Added by Purna on 25/01/2017 - Hide Contact Person field for OTT
						buttonsCollection: buttonsCollection,
						onCancel: lang.hitch(this, function() {
							abort({"message": this.getNLSValue("msg_abort")});
						})
					});
		    //added by suresh for dialog width issue raised in JIRA PEWFSGUPGS-18
		    dialog.setSize(500,300);		
			dialog.show();	
		},
		
		showInCompleteDialog:function(context, complete, abort, resultSet){
			var configuredStatusList = this.getCfgOfStatus();
			var textToShowInDialog = "";
			if(configuredStatusList && (configuredStatusList.length > 1)){
				
				//Please complete all tasks with a status of 
				
				//Handle at MP Complete
				textToShowInDialog = configuredStatusList.toString().replace("MyTasks,AllTasks,", "");
				
				//Handle at CB Complete
				textToShowInDialog = configuredStatusList.toString().replace("MyTasks,", "");
				
				textToShowInDialog = textToShowInDialog.replace(/,/g, ', '); 
				textToShowInDialog = " with a status of <b>" + textToShowInDialog;
				textToShowInDialog = "Please complete all tasks".replace('\.', '') + textToShowInDialog + ".</b>";
			}else{
				textToShowInDialog = this.getNLSValue("text_inComplete");
			}
			
			var inCompleteDialog = new MessageDialog({
					text: textToShowInDialog,
					buttonLabel: this.getNLSValue("label_inComplete"),
					cancelButtonLabel: this.getNLSValue("label_inCompleteCancel"),
					title: this.getNLSValue("title_inComplete"),
					onCancel:lang.hitch(this, function(){
						abort({"message": this.getNLSValue("msg_abort")});
					})
				});
			inCompleteDialog.cancelButton.set("label", this.getNLSValue("label_inCompleteCancel"));
			inCompleteDialog.show();
			domStyle.set(inCompleteDialog.domNode, 'width', '450px');
		},
		
		showFailedDialog:function(context, complete, abort, resultSet){
			var failedDialog = new ConfirmationDialog({
					text: this.getNLSValue("text_failed"),
					buttonLabel: this.getNLSValue("label_failed"),
					cancelButtonLabel: this.getNLSValue("label_failedCancel"),
					cancelButtonDefault: true,
					title: this.getNLSValue("title_failed"),
					onExecute: lang.hitch(this, function(){
						complete();
					}),
					onCancel:lang.hitch(this, function(){
						abort({"message": this.getNLSValue("msg_abort")});
					})
				});
			failedDialog.show();
		},
		
		showFollowUpDialog:function(context, complete, abort, resultSet){
			var dialog = null;
			var title = this.getNLSValue("title_followUp");
			var text = this.getNLSValue("text_followUp");
			
			var buttonsCollection = {};
			var ContinueButtonObj = {};
			ContinueButtonObj.buttonLabel = this.getNLSValue("label_followUp");
			ContinueButtonObj.disabled = false;
			ContinueButtonObj.onExecute = lang.hitch(this, function(context, complete, abort, resultSet){
				if(dialog.emResultSet){
					var emItems = [];
			
					var items = resultSet.getItems();
					array.forEach(items, function(item){
						if(item && item.getValue("ActivityStatus") === Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM){
							emItems.push(item);
						}
					}, this);
					resultSet.items = emItems;				
					this.showEmailDialog(context, complete, abort, resultSet, false, "");
				}else{
					complete();
				}
			}, context, complete, abort, resultSet);
			buttonsCollection.Continue = ContinueButtonObj;
			dialog = new FollowUpDialog({
						title: title, // DEV: to be localized
						text: text,
						resultSet: resultSet,
						buttonsCollection: buttonsCollection,
						onCancel: lang.hitch(this, function() {
							abort({"message": this.getNLSValue("msg_abort")});
						})
					});
			dialog.show();
		},
		
		showEmailDialog: function(context, complete, abort, resultSet, disableReminder, response){
			var dialog = null;
			var title = this.getNLSValue("title_sendEmail");
			var isNotifyToScanHub = false;
			var buttonsCollection = {};
			var SendEmailButtonObj = {};
			
			//Added by Purna for Enhancement - Capture the Reason on the case
			var rejectReason = (arguments.length > 6 && arguments[6]) ? arguments[6] : '';
			//End change
			
			// added by rahul to check that user clicked response as "Notify to Scan Hub or not"
			if(response != null && response != "" && response === Util.getConstant("EWF_DISPATCH").NOTIFYSCANHUB){
				isNotifyToScanHub = true;
			}
			SendEmailButtonObj.buttonLabel = this.getNLSValue("label_sendEmail");
			SendEmailButtonObj.disabled = true;
			SendEmailButtonObj.onExecute = lang.hitch(this, function() {
				if(this._workItemController){
					var controller = this._workItemController;
					var emPropertyController = controller.getPropertyController("EmailContent");
					
					if (emPropertyController) {			
						var contentValue = "<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'/></head>" + dialog._emailContent.get("value") + "</html>";
						emPropertyController.set("value", contentValue);
						//emPropertyController.set("value", dialog._emailContent.get("value"));
					}
								
					var toEmailAddressPropertyController = controller.getPropertyController("EmailTo");
					if (toEmailAddressPropertyController) { 
						toEmailAddressPropertyController.set("value", dialog._toEmailAddress.get("value"));
					}
					
					var ccEmailAddressPropertyController = controller.getPropertyController("EmailCC");
					if (ccEmailAddressPropertyController) { 
						ccEmailAddressPropertyController.set("value", dialog._ccEmailAddress.get("value"));
					}
								
					var fromEmailAddressPropertyController = controller.getPropertyController("EmailFrom");
					if (fromEmailAddressPropertyController) { 
						fromEmailAddressPropertyController.set("value", dialog._fromEmailAddress.get("value"));
					}
								
					var emailSubjectPropertyController = controller.getPropertyController("EmailSubject");
					if (emailSubjectPropertyController) { 
						emailSubjectPropertyController.set("value", dialog._emailSubject.get("value"));
					}
					//modified the below changes by suresh as part of 5.2.1 upgrade UAT issue: OTT Case will not Reject at MP
					var pendTimeSubjectPropertyController = controller.getPropertyController("WF_PendTime");
					if (pendTimeSubjectPropertyController) { 
					    var reminderTime = dialog._reminder.get("value")*3600;
					    if(!isNaN(reminderTime)){
						pendTimeSubjectPropertyController.set("value", reminderTime);
						}
						else{
						pendTimeSubjectPropertyController.set("value", pendTimeSubjectPropertyController.model.originalValue);
						}
					//End change	
					}
					
					//Added by Purna for Enhancement - Capture the Reason on the case
					if(rejectReason) {
						var rejectReasonPropertyController = controller.getPropertyController("EWFSV_RejectReason");
						if (rejectReasonPropertyController) { 
							rejectReasonPropertyController.set("value", rejectReason);
						}
					}
					//End change
				}
				complete();
			});
			var enableReminder = true;
			if(disableReminder){
				enableReminder = false;
			}else{
				enableReminder = true;
			}
			//MODIFED BY RAHUL FOR NOTIFY SCAN HUB CHANGES
			buttonsCollection.SendEmail = SendEmailButtonObj;
			dialog = new EmailActivityDialog({
						repository: this.workItemEditable.getCaseType().getSolution().getTargetOS(),
						caseType: this.workItemEditable.getCaseType(),
	    				parentCase: this.workItemEditable.getCase(),
						title: title, // DEV: to be localized
						solutionPrefix: this.solution.prefix,//Added by Purna on 25/01/2017 - Hide CC & set Subject to blank for OTT
						resultSet: resultSet,
						isNotifyToScanHub: isNotifyToScanHub,
						enableReminder: enableReminder,
						buttonsCollection: buttonsCollection,
						onCancel: lang.hitch(this, function() {
							abort({"message": this.getNLSValue("msg_abort")});
						})
					});
			dialog.setActivityListResultSet(resultSet);
			dialog.show();
		}
		
	});
});