define(["dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/dom-class",
        "dojo/dom-style",
        "dojo/_base/array",
		"v11/ewf/pgwidget/activitypanel/dijit/Activity",
		"dojo/store/Memory",
		"dojo/text!./templates/DataValidationActivity.html",
		"idx/form/CheckBox"],
		function(declare, lang, domClass, domStyle, array, Activity, Memory, template){
	return declare("v11.ewf.pgwidget.activitypanel.dijit.DataValidationActivity", [Activity], {
		
		templateString: template,
		
		highlighted: true,		
		
		postMixInProperties: function(){
			this.inherited(arguments);
		},
		
		postCreate: function(){
			this.inherited(arguments);			
			this.connect(this.showAllBox, "onChange", "updateView");
			
			if(this.activityObj.getSystemMessage()){
				this.activityTitle.innerHTML += "<br><span style='font-weight:bold;'>" + this.activityObj.getSystemMessageName() + ":</span>&nbsp; "
									+ this.activityObj.getSystemMessage();
			}
			
		},
				
		afterShowView: function(){
			this.inherited(arguments);
			
			//By default, show highlighted properties, filter highlighted properties.
			this.showHighLightedView();
		},
		
		resize: function(){
			this.inherited(arguments);
			var wholeWidth = dojo.contentBox(this.domNode).w;
			var showAllWidth = dojo.marginBox(this.showAllBox.domNode).w;
			var paddingLeft = wholeWidth - showAllWidth - 10;
			if(paddingLeft > 0){
				domStyle.set(this.showAllBox.domNode.parentNode, "paddingLeft", paddingLeft + "px");
			}
			setTimeout(lang.hitch(this, function(){
				this.pageWidget && this.pageWidget.activityList && this.pageWidget.activityList.activityListGrid && this.pageWidget.activityList.activityListGrid.resize && this.pageWidget.activityList.activityListGrid.resize(); 
			}), 200);
		},
				
		updateView: function(){
			var showAllChecked = this.showAllBox.get("value");
			
			if(showAllChecked){
				this.highlighted = false;
				this.showAllView();
			}else{
				this.highlighted = true;
				this.showHighLightedView();
			}
		},
				
		showHighLightedView: function(){
			//Hide no-highlighted properties
			this._view.forEachProperty({
				callback: lang.hitch(this, function(property) {					
					if(!this.isHighlightedPro(property.controller)){
						property.controller.set("hidden", true);
						dojo.style(property.domNode, "display", "none");
					}
				})
			});
			
			// Hide any empty, unbound or hidden items.
			dojo.forEach(this._view.getChildren(), function(child) {
				child.hideEmpties();
			});
			
			setTimeout(lang.hitch(this, this.resize), 200);
		},
		
		showAllView: function(){
			//Show no-highlighted properties
			this._view.forEachProperty({
				callback: lang.hitch(this, function(property) {					
					if(!this.isHighlightedPro(property.controller)){
						property.controller.set("hidden", false);
						dojo.style(property.domNode, "display", "");
					}
				})
			});
			
			// Hide any empty, unbound or hidden items.
			dojo.forEach(this._view.getChildren(), function(child) {
				child.hideEmpties();
			});
			
			setTimeout(lang.hitch(this, this.resize), 200);
		}
		
	});
});