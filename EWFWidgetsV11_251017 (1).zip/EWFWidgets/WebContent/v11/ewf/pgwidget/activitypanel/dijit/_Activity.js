define(["dojo/_base/declare",
    	"dojo/_base/lang",
    	"dojo/request",
    	"dojo/aspect",
		"dojo/query",
    	"dojo/_base/array",
		"v11/ewf/model/properties/ControllerConfig",
		"icm/model/properties/controller/ControllerManager",
		"pvr/widget/View",
		"icm/model/Message",
		"ecm/widget/dialog/ErrorDialog",
		"v11/ewf/util/Util"
		],
		function(declare, lang, request, aspect, query, array, ewfControllerConfig, ControllerManager, View, Message, ErrorDialog, Util){
	
	return declare("v11.ewf.pgwidget.activitypanel.dijit._Activity", [], {
		
		resize: function() {
			this._editable && this._view && this._view.resize();
		},
		
		adjustDirtyState: function() {
			
			var controllerDirty = this._controller && this._controller.isModified(new Date());
			var viewError = this._view && this._view.get("state") === "Error";
			this.setDirtyState(controllerDirty || viewError);
		},
		
		setDirtyState: function(dirty) {
			this.pageWidget.onBroadcastEvent("icm.SetDirtyState", {
				"dirtyState": dirty,
				"reference": this.id
			});
		},
		
		destroy: function() {
			this._closeView();
			this.inherited(arguments);
		},		
		
		getIntegration: function(){
			var integration = ControllerManager.getIntegration();
			integration.mergeConfiguration(ewfControllerConfig);
		},
		
		/*
		 * bind this.activityEditable, this.worktItemEditable, and this.caseEditable to do sync up.
		 */
		bindController: function(){
			this.getIntegration();
			
			//this.activityEditable
			if(this.activityEditable){
				this._editable = this.activityEditable;
				this._controller = ControllerManager.bind(this._editable);
				//commented the below code by suresh as part of 5.2.1 upgrade onUpdate is changed to onChange
				//this._updateHandler = aspect.after(this._controller, "onUpdate", 
				this._updateHandler = aspect.after(this._controller, "onChange", 
					  lang.hitch(this, function(changes) {
						  	var updateValue = false;
						  	for (var id in changes) {
								if (changes[id].hasOwnProperty("value")) {
									updateValue = true;
								}
							}
						  	if(updateValue){
							  	if(this._caseController){
									this._updateProperty(this._caseController, changes);
								}
								if(this._workItemController){
									this._updateProperty(this._workItemController, changes);
								}
						  	}
						}), true);
			}
			
			//this.workItemEditable
			/*if(this.workItemEditable){
				this._workItemEditable = this.workItemEditable;
				this._workItemController = ControllerManager.bind(this._workItemEditable);
				this._workItemHandler = aspect.after(this._workItemController, "onUpdate", 
					  lang.hitch(this, function(changes) {
						  	console.debug("workItemEditable, controller, onUpdate;");
						  	this._updateProperty(this._controller, changes);
						}), true);
			}
			
			//this.caseEditable
			if(this.caseEditable){
				this._caseEditable = this.caseEditable;
				this._caseController = ControllerManager.bind(this._caseEditable);
				this._caseHandler = aspect.after(this._caseController, "onUpdate", 
					lang.hitch(this, function(changes) {
					  	console.debug("caseEditable, controller, onUpdate;");
					  	this._updateProperty(this._controller, changes);
					}), true);
			}*/
		},
		
		/*
		 * Need to init this.activityEditable, this.workItemEditable, and this.caseEditable before call this function.
		 */
		createView: function(callback){
		    //added by suresh for 5.2.1 upgrade issue: view is not rendered when open row in activity panel widget
			var viewresources=this._editable.getCaseType().getViewDefinitionResourceBundle();
			// Retrieve the view definition and render the view 
			this._controller.retrieveAttachmentValues(lang.hitch(this, function() {
				this.retrieveViewDefinition(lang.hitch(this, function(viewDefinition) {
					if (viewDefinition) {
						this._view = new View({
							readOnly: false,
							markup: viewDefinition,
							resources: viewresources
							//resources: this._editable.getCaseType().getViewDefinitionResourceBundle()
						});
					}
					else {
						this._view = new View({
							containerParams: {
								labelAlignment: "horizontal",
								labelWidth: "180px"
							},
							readOnly: false,
							filter: function(property) {
								return !property.get("systemDefined") && !property.get("inherited") && property.get("type") !== "attachment"
									&& property.get("id") != "SystemMessage";
							},
							comparator: function(property1, property2) {
								var type1 = property1.get("type");
								var type2 = property2.get("type");
								var label1 = property1.get("label") || property1.get("id") || property1.get("id");
								var label2 = property2.get("label") || property2.get("id") || property2.get("id");
								return (type1 !== type2 && type2 === "group") || (label1 > label2) ? 1 : -1;
							}
						});
					}
					
					callback && callback();
					
					// Add the handlers.
					this._viewHandlers = [];
					this._viewHandlers.push(this._view.watch("state", lang.hitch(this, function(attr, oldValue, newValue) {
						this.adjustDirtyState();
					})));
					
					return this._view;
					
				}), lang.hitch(this, function(error) {
					// TODO Find a way to render the error in the widget.
					var message = Message.createErrorMessage("viewDefinitionLoadError", [error]);
					var dialog = new ErrorDialog();
					dialog.showMessage(message); 
					
					return null;
				}));
			}));
			
		},

		syncUpUpdatedProperties: function(updatedCasePropertiesCollection){
			var controller = this._controller;
			for (var id in updatedCasePropertiesCollection) {
				var propertyController = controller.getPropertyController(id);
				if (propertyController && updatedCasePropertiesCollection[id].hasOwnProperty("value")) { // Mapping is necessary only for those properties common to both controllers.
					var propertyValue = propertyController.get("value");
					var changeValue = updatedCasePropertiesCollection[id]["value"];
					if( !icm.util.Util.areEqual(propertyValue, changeValue )){
						propertyController.set("value", changeValue);
						//this.updatePropertyLabel(propertyController);
					}
				}
			}
			this._view && this._view.forEachProperty({
				filter: function(property) {
					for (var id in updatedCasePropertiesCollection) {
						var propertyController = controller.getPropertyController(id);
						if(propertyController && property.binding === propertyController.get("id")){
							return true;
						}
					}
						return false;
				},
				callback: lang.hitch(this, function(property) {
				var controller = property.controller;
					if(property.editorWidget){
					    //commited by suresh as part of 5.2.1 upgrade changes 
					    //property.editorWidget.labelWrap is changed to property.domNode.firstChild
						//var failureNode = query(".ewfFailureType", property.editorWidget.labelWrap);
						var failureNode = query(".ewfFailureType", property.domNode.firstChild);
						if(failureNode && failureNode[0]){
							var content = failureNode[0].innerHTML;
							if( content.indexOf("Updated") < 0){
								failureNode[0].innerHTML = " Updated";
							}
						}else{
						if(controller.type != "checkBox"){
						    //commented the below code by suresh as part of upgrade added the below line as part of 5.2.1 changes 
							//dojo.addClass(property.editorWidget.labelWrap, "ewfHighlighted");
							dojo.addClass(property.domNode.firstChild, "ewfHighlighted");
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " Updated";
							//commented the below code by suresh as part of upgrade and added the below line as part of 5.2.1 changes
							//property.editorWidget.labelWrap.appendChild(failureLabel);
							property.domNode.firstChild.appendChild(failureLabel);
							}
							else{
							if(controller.id != "COPC_ListofCardOrg"){
						    if(controller.id != "COPC_ListofGiftCode"){
							var mainLabel = dojo.create("label");
						    var failureLabel = dojo.create("label");
						    dojo.addClass(failureLabel, "ewfFailureType");
						   // dojo.addClass(property.domNode.firstChild, "ewfHighlighted");
						    failureLabel.innerHTML = " Updated";
						    if(controller.model.label){
						        mainLabel.innerHTML = controller.model.label;
						    }else{
						    mainLabel.innerHTML = controller.model.name;
						    }
							mainLabel.appendChild(failureLabel);
							property.domNode.firstChild.appendChild(mainLabel);
							dojo.addClass(property.domNode.firstChild, "ewfHighlighted");
							property.editorWidget.compLabelNode.innerHTML="";
							}
							}
							else if(controller.id != "COPC_ListofGiftCode"){
							if(controller.id != "COPC_ListofCardOrg"){
							
							var mainLabel = dojo.create("label");
						    var failureLabel = dojo.create("label");
						    dojo.addClass(failureLabel, "ewfFailureType");
						   // dojo.addClass(property.domNode.firstChild, "ewfHighlighted");
						    failureLabel.innerHTML = " Updated";
							mainLabel.innerHTML = controller.model.name;
							mainLabel.appendChild(failureLabel);
							property.domNode.firstChild.appendChild(mainLabel);
							property.editorWidget.compLabelNode.innerHTML="";
							
							}
							}
							}
						}
					}					
				})
			});
		},
		        
        _updateProperty: function(controller, changes) {
			for (var id in changes) {
				var propertyController = controller.getPropertyController(id);
				if (propertyController && changes[id].hasOwnProperty("value")) { // Mapping is necessary only for those properties common to both controllers.
					var propertyValue = propertyController.get("value");
					var changeValue = changes[id]["value"];
					if( !icm.util.Util.areEqual(propertyValue, changeValue )){
						propertyController.set("value", changeValue);
						//this.updatePropertyLabel(propertyController);
					}
				}
			}
		},
		
		updatePropertyLabel: function(controller){
			if(!this._view) return;
			
			var viewPropTables = {};
			this._view.forEachProperty({
				filter: function(property) {
						return property.binding === controller.get("id");
				},
				callback: lang.hitch(this, function(property) {
					if(property.editorWidget){
						var failureNode = query(".ewfFailureType", property.editorWidget.labelWrap);
						if(failureNode && failureNode[0]){
							var content = failureNode[0].innerHTML;
							if( content.indexOf("Updated") < 0){
								failureNode[0].innerHTML = " Updated";
							}
						}else{
							dojo.addClass(property.editorWidget.labelWrap, "ewfHighlighted");
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " Updated";
							property.editorWidget.labelWrap.appendChild(failureLabel);
						}
					}
					if(property.getParent()._containerType == "propertyTable"){
						if(!viewPropTables.hasOwnProperty(property.getParent().id)){
							viewPropTables[property.getParent().id] = property.getParent();
						}
					}
				})
			});
			
			var propTable;
			for(propTable in viewPropTables){
				if(viewPropTables.hasOwnProperty(propTable)){
					var propGrid = viewPropTables[propTable]._grid;
					var propGridStructure = propGrid.structure;
					dojo.forEach(propGridStructure, lang.hitch(this, function(headerCell){
						var propGridHeader = propGrid.header;
						var colId = headerCell.id;
						var colCell = propGridHeader.getHeaderNode(colId).firstChild;
						
						var failureNode = query(".ewfFailureType", colCell);
						if(failureNode && failureNode[0]){
							var content = failureNode[0].innerHTML;
							if( content.indexOf("Updated") < 0){
								content.innerHTML = " Updated";
							}
						}else{
							dojo.addClass(colCell, "ewfHighlighted");
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " Updated";
							colCell.appendChild(failureLabel);
						}
					}));
				}
			}			
		},
		
		/**The method could be overridden once there is any other business rule except mandatory condition rule for CCA**/
        businessValidation: function(controller) {
			var invalidProperties = [];
			controller.forEachPropertyController({
				callback: function(propertyController) {
					if (propertyController.get("logicRequired")){
						var value = propertyController.get("value");
						if(value === null || ((typeof value === "string" || value instanceof String) && value.length === 0)
							|| (value === undefined)){
							invalidProperties.push(propertyController);
						}else if(lang.isArray(value)){//the logic is for multiple values can't be null if each element is mandatory
							if(array.some(value, function(item) {
								if(item === null || ((typeof item === "string" || item instanceof String) && item.length === 0)
								|| (item === undefined)){
									return true;
								}
							}) || value.length === 0){
								invalidProperties.push(propertyController);
							}
						}
					}
				}
			});
			return invalidProperties;
		},
		
		/**The method could be overridden once there is any other method to judge whether the current activity item is at updated status of not**/
        getUpdatedProperties: function(controller) {
			var updatedProperties = [];
			controller.forEachPropertyController({
				callback: function(propertyController) {
					if (propertyController.get("updated") || (propertyController.model && propertyController.model.updated)) {
						updatedProperties.push(propertyController);
					}
				}
			});
			return updatedProperties;
		},
		
		focusProperty: function(property) {
			property.getParent().showChild(property);
			if (property.parentContainerType !== "propertyTable") {
				property.editorWidget && property.editorWidget.focus();
			}
		},
				
		_handleFocus: function(invalidPropertyControllers, invalidProperties) {
			if(this._view){
				if(invalidProperties && invalidProperties.length) {
					this.focusProperty(invalidProperties[0]);
				}
				else{
					this._view.someProperty({
						callback: lang.hitch(this, function(property) {
							this.focusProperty(property);
							return true;
						}),
						filter: function(property) {
							return array.some(invalidPropertyControllers, function(propertyController) {
								return property.get("binding") === propertyController.get("id");
							});
						}
					});
				}
			}
		},
		
		_closeView: function() {

			if(this._workItemEditable){
				this._workItemHandler && this._workItemHandler.remove();
				
				// Tear down the controller.
				ControllerManager.unbind(this._workItemEditable);				
				delete this._workItemController;
				
				delete this._workItemEditable;
			}
			
			if(this._caseEditable){
				this._caseHandler && this._caseHandler.remove();
				
				// Tear down the controller.
				ControllerManager.unbind(this._caseEditable);				
				delete this._caseController;
				
				delete this._caseEditable;
			}
			
			if (this._editable) {
				// Tear done the update handler.
				this._updateHandler && this._updateHandler.remove();
				
				// Tear down the view.
				if (this._view) {
					// Remove the handlers.
					array.forEach(this._viewHandlers, function(handler) {
						handler.remove();
					});
					delete this._viewHandlers;
					
					// Tear down the view.
					this._view.unbind();
					this._view.destroyRecursive();
					delete this._view;
				}
				
				// Tear down the controller.
				ControllerManager.unbind(this._editable);
				delete this._controller;
				
				// Delete the model.
				delete this._editable;
			}			
		},
		
		retrieveViewDefinition: function(onSuccess, onError) {
			var viewDefinitionId = this.getViewDefinitionId();
			if (viewDefinitionId) {
				this.logDebug("ViewDefinitionID is:", viewDefinitionId);
				request(this._editable.getCaseType().getViewDefinitionUri(viewDefinitionId)).then(function(text) {
					onSuccess(text);
				}, function(error) {
					onError(viewDefinitionId);
				});
			}
			else {
				onSuccess(null);
			}
		},
		
		getViewDefinitionId: function() {
			var viewDefinitionIds = this.getViewDefinitionIds(); // Get the configured view definition.
			if (viewDefinitionIds) {
				for (var i = 0; i < viewDefinitionIds.length; i++) {
					if (viewDefinitionIds[i]["caseTypeId"] === this._editable.getCaseType().id) {
						return viewDefinitionIds[i]["viewDefinitionId"];
					}
				}
			}
			return null; 
		},
		
		getWidgetAttributes: function(){
			return this.pageWidget.getWidgetAttributes();
		},
		
		getViewDefinitionIds: function(){
			//return null;
			//Modified by Purna for COA Jan QR changes - Render different views for DVC based on a field value
			if(this.activityObj.activityType.indexOf('DataValidationCheck') >= 0) {
				var filterField = Util.getConstant("DVC_View_Filter", this.pageWidget.solution.prefix, this.caseEditable);
				
				if(filterField && this.caseEditable.propertiesCollection && this.caseEditable.propertiesCollection[filterField]) {
					var fieldValue = this.caseEditable.propertiesCollection[filterField].value;
					var fieldCardinality = this.caseEditable.propertiesCollection[filterField].cardinality;
					//For now getting the 1st element in the index without any logic for list fields
					if(fieldCardinality && fieldCardinality == "LIST" && fieldValue instanceof Array && fieldValue.length >= 1) {
						fieldValue = fieldValue[0];
					}
					var viewDefinitionIds = this.getWidgetAttributes().getItemValue(this.activityObj.activityType+"_"+fieldValue+"_ViewMap");
					if(null != viewDefinitionIds)
						return viewDefinitionIds;
				}
			}
			//End change by Purna
			
			return this.getWidgetAttributes().getItemValue(this.activityObj.activityType+"_ViewMap");
		}
	});
});