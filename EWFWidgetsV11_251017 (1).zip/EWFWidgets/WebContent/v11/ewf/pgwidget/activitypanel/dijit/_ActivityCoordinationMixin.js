define(["dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/_base/array",
		"icm/base/Constants",
		"v11/ewf/util/Util"],
		function(declare, lang, array, constants, Util){
	
	return declare("v11.ewf.pgwidget.activitypanle.dijit._ActivityCoordinationMixin", [], {
		_updatedCasePropertiesCollection:{},
		
		configureCoordination: function(coordination) {
			coordination.participate(Util.getConstant("EWF_CoordTopic").COMMIT, lang.hitch(this, this.handleICM_CommitEvent));
			coordination.participate(Util.getConstant("EWF_CoordTopic").VALIDATE, lang.hitch(this, this.participate_TopicOfValidation));	
			
			coordination.participate(Util.getConstant("EWF_CoordTopic").AFTERCOMPLETE, lang.hitch(this, this.participate_TopicOfAfterComplete));
			coordination.participate(Util.getConstant("EWF_CoordTopic").HIDE, lang.hitch(this, this.participate_TopicOfHide));
			coordination.participate(Util.getConstant("EWF_CoordTopic").AFTERFOLLOWUP, lang.hitch(this, this.participate_TopicOfAfterFollowUp));
		},
		
		handleICM_CommitEvent: function(context, complete, abort) {
			this._commit(complete);
		},
		
		_commit: function(callback) {
			// TODO Figure out a more reliable method to ensure that the model updates are complete.
			//Here we need to trigger an onBlur on the current Property, so that model gets updated.
			setTimeout(callback, 100);
		},
		
		participate_TopicOfValidation: function(context, complete, abort) {
			var result = {};
			
			var caseTypeObj = this.activityObj.parentCase.getCaseType();
			var caseTypeName= caseTypeObj.id;
			result.activityType = this.activityObj.getActivityType();
			result.activityId = this.activityObj.getActivityId();
			if(this.continueCoordination(context)){
				
				console.log("this.pageWidget.workItemEditable::" +this.pageWidget.workItemEditable);
				if(this.continueCoordination(context) && this.pageWidget && this.pageWidget.activityList){
					this._updatedCasePropertiesCollection = this.activityObj.getUpdatedPropertiesCollection("update", "CaseFolder");
				}
			    var isModified 	= this._controller.isModified();
				console.log("isModified:::::::::::::::::" ,isModified);
				result.isModified = isModified;
			
				
				//Added by Purna during OTT V11 Upgarde BEGIN - for setting isAnyActivityModified flag for 2D Barcode MP Indicator off check
				if(this.pageWidget.solution.prefix == "EWF" && this.pageWidget._workItemController && this.pageWidget.workItemEditable) {
					var stepName = this.pageWidget.workItemEditable.getStepName();
					var is2DCaseController = this.pageWidget._workItemController.getPropertyController("EWF_Is2DBarcode");
					console.log("stepName: ", stepName, "is2DCaseController", is2DCaseController, isModified);
					
					if((stepName == "Manual Processing" || stepName == "Manual Processing - Pend") && is2DCaseController && is2DCaseController.get("value") == "Yes") { 
						var isAnyActModifiedController = this.pageWidget._workItemController.getPropertyController("WF_IsAnyActivityFieldModified");
						if(isAnyActModifiedController && isModified) {
							isAnyActModifiedController.set("value", "Yes");
							isAnyActModifiedController.set("dirty", true);
						}
					} else {
						console.log("Case is not 2D OR Case is not at MP Operator");
					}
				}
				//End change
				
				//Add Logic to determine isModified if any of the activity Properties are in the Ctrl Updated Fields List. --> Starts here
				if(!isModified){
					var updatedCasePropertiesList = [], updatedCasePropertiesListStr= '', updatedCasePropertiesListPropController;
					if(this._controller && this._controller.getPropertyController)
						updatedCasePropertiesListPropController = this._controller.getPropertyController("EWS_ListOfUpdatedCaseProps");
					if(updatedCasePropertiesListPropController){
						updatedCasePropertiesList = updatedCasePropertiesListPropController.get('value');
						updatedCasePropertiesListStr = updatedCasePropertiesList.toString();
					}
					
					if(updatedCasePropertiesList && (typeof updatedCasePropertiesList !== typeof undefined)){
						var propertiesCollectionInActivity = this.activityObj.propertiesCollection;
						var property;
						for(property in propertiesCollectionInActivity){
							if(propertiesCollectionInActivity.hasOwnProperty(property)){
								if(updatedCasePropertiesListStr.indexOf(property) > -1){
									result.isModified = true;
									break;
								}
							}
						}
					}
				}
				//Add Logic to determine isModified if any of the activity Properties are in the Ctrl Updated Fields List. --> Ends here
				
				var controllerErrors = this._controller.validate();
				var viewErrors = this._view && this._view.validate();
				var businessErrors = this.businessValidation(this._controller);
				
				var updatedProperties = this.getUpdatedProperties(this._controller);
				if(updatedProperties && updatedProperties.length){
					
						if(caseTypeName == Util.getConstant("EWF_CASE_TYPE").CHANGE_OF_ADDRESS || caseTypeName == Util.getConstant("EWF_CASE_TYPE").SCAN_AND_POST){
							var isvalidFieldsUpdated = array.some(updatedProperties,function(propController){
								if(propController.id && (propController.id!=Util.getConstant("MAKER_CHECKER_FIELDS").MP_USER_FIELD && propController.id!=Util.getConstant("MAKER_CHECKER_FIELDS").RV_USER_FIELD && propController.id!=Util.getConstant("MAKER_CHECKER_FIELDS").CB_USER_FIELD && propController.id!=Util.getConstant("MAKER_CHECKER_FIELDS").SP_USER_FIELD)){
									return true;
								}														
							});
								if(isvalidFieldsUpdated){
									result.backEndUpdated = true;
								}else{
									result.backEndUpdated = false;
								}
						}else{
							result.backEndUpdated = true;
						}
				}else{
					result.backEndUpdated = false;
				}
				
				if(businessErrors && businessErrors.length){//business rules validation
					result.bizValid = false;
				}else{
					result.bizValid = true;
				}
				
				//Added by Purna during OAO - to handle APRuleMatrixInfo filed when empty
				var matrixInfo = this.activityObj.getRulesMatrixInformation();
				if(matrixInfo != null && matrixInfo != "" && lang.isArray(matrixInfo)) {
					
					//Added during COA Dev starts here
					var anyAPRuleFailed = array.some(this.activityObj.getRulesMatrixInformation(), function(rule){
						try {
							var ruleJsonObject = dojo.fromJson(rule);
							if((ruleJsonObject !== undefined) 
									&& ruleJsonObject.hasOwnProperty('Status') 
									&& (ruleJsonObject['Status'] === 'Fail')){
								return true;
							}
						} catch(e) {
							console.log('JSON conversion failed for rule:', rule, 'Exceptiopn', e);
						}
					});
					result.anyAPRuleFailed = anyAPRuleFailed;
					
					var anyAPRuleOverride = array.some(this.activityObj.getRulesMatrixInformation(), function(rule){
						try {
							var ruleJsonObject = dojo.fromJson(rule);
							if((ruleJsonObject !== undefined) 
									&& ruleJsonObject.hasOwnProperty('Status') 
									&& (ruleJsonObject['Status'] === 'Override')){
								return true;
							}
						} catch(e) {
							console.log('JSON conversion failed for rule:', rule, 'Exceptiopn', e);
						}
					});
					result.anyAPRuleOverride = anyAPRuleOverride;
					//Added during COA Dev ends here
					
				} else {
					result.anyAPRuleFailed = false;
					result.anyAPRuleOverride = false;
				}
				//End OAO changes
				
				if ((controllerErrors && controllerErrors.length) || (viewErrors && viewErrors.length)) {
					result.message = "The activity is not complete. Would you like to override or fail the activity?";
					result.isValid = false;
					this._handleFocus(controllerErrors, viewErrors);
					
					/*
					if(controllerErrors.length <= 0 && viewErrors.length > 0){
							array.forEach(viewErrors, function(property){

							var value = property.editorWidget.get("value");
							var error = property.controller.test("value", value);
							if (lang.isArray(error) ? array.every(error, function(item) {
								return !item;
							}) : !error) {
								console.debug("validation, property controller, no error");
								property.controller.set("value", value);
							}else{
								abort();
							}
						});
					}*/
				}
				else {
					result.isValid = true;
					if(!isModified){
						result.message = "No changes have been detected. Have you reviewed the activity?";
					}else{
						result.message = "Do you really want to make these changes?";
					}
				}
				
				if(caseTypeName == Util.getConstant("EWF_CASE_TYPE").CHANGE_OF_ADDRESS || caseTypeName == Util.getConstant("EWF_CASE_TYPE").SCAN_AND_POST){
				 lang.hitch(this,this.updateMakerCheckerFields(complete,result));
				//complete(result); 
				 }else{
					complete(result);
				}
			}else{
				complete();
			}
        },
		
		participate_TopicOfSave: function(context, complete, abort) {
			this.activityEditable.save(
								lang.hitch(this, function(response, fieldErrors) {
									this.pageWidget.onPublishEvent(
											"icm.ewfActivitySave",
											{'ActivityEditable': this.activityEditable}
									);
									complete();
								}),
								lang.hitch(this, function(response, fieldErrors) {
									// enable action if failed
									abort({"message": "It failed to save this activity:" + this.activityEditable.getActivityType()});
								})
							);
        },
		
		
		continueCoordination: function(context){
			if(this._controller&&this.viewNode){
				var activityType = this.activityObj.getActivityType();
				var activityId = this.activityObj.getActivityId();
				if(context && context[Util.getConstant("EWF_CoordContext").ACTIVITYTYPE] === activityType && context[Util.getConstant("EWF_CoordContext").ACTIVITYID] === activityId){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		},
		
		participate_TopicOfAfterComplete: function(context, complete, abort) {		
			if(lang.isFunction(this.performUpdated)){
				this.performUpdated(context);
			}
		    if(this.continueCoordination(context)){
				if(this.viewNode){
					this._controller.resetModified();
					this.adjustDirtyState();
				}
				this.gridRow.hideDetail();
			}
			complete();
        },
		
		performUpdated:function(context){
			if(this.continueCoordination(context) && this.pageWidget && this.pageWidget.activityList){
				this.pageWidget.activityList.updatedCasePropertiesCollection = this._updatedCasePropertiesCollection;
				this.pageWidget.activityList.syncUpUpdatedProperties();
			}
			
			if( this.activityObj.getActivityType() === "COPC_CreditCardCheck"
				&& this.pageWidget && this.pageWidget.activityList && this.pageWidget.activityList.syncUpDiffActivities ){
				this.pageWidget.activityList.syncUpDiffActivities();
			}
			return;
		},
		        
		participate_TopicOfHide: function(context, complete, abort) {
		    if(this.continueCoordination(context)){
				this.resetController(context);
				this.gridRow.hideDetail();
			}
			complete();
        },
		
		resetController:function(context){
			if(this.continueCoordination(context)){
				if(this.pageWidget && this.pageWidget.activityList){
					this._updatedCasePropertiesCollection = this.activityObj.getUpdatedPropertiesCollection("update", "CaseFolder");
				}
				var v;
				var propertyController;
				var updatedPropertiesCollection = this.activityObj.getUpdatedPropertiesCollection("update");
				for (v in updatedPropertiesCollection) {
					if (updatedPropertiesCollection.hasOwnProperty(v)) {
						var prop = updatedPropertiesCollection[v];
						if(this.viewNode){
							propertyController = this._controller.getPropertyController(v);
							propertyController.set("value", this.activityObj.getActivity().getValue(v));
						}
					}
				}
				if(this.viewNode){
					this._controller.resetModified();
					this.adjustDirtyState();
				}
			}
		},
		
		participate_TopicOfAfterFollowUp: function(context, complete, abort) {			
			if(lang.isFunction(this.performUpdated)){
				this.performUpdated(context);
			}
		    if(this.continueCoordination(context)){
				if(this.viewNode){
					this._controller.resetModified();
					this.adjustDirtyState();
				}
				this.gridRow.hideDetail();
			}
			complete();
        },
		//Changes added by sagar for COA july QR/* 
		updateMakerCheckerFields:function(complete,result){
			var roleName = ecm.model.desktop.currentRole.name;
			var userId = ecm.model.desktop.userId;
			var caseTypeObj = this.activityEditable.getCaseType();
			var caseTypeName= caseTypeObj.id;
			var property =null;
			if(caseTypeName == Util.getConstant("EWF_CASE_TYPE").CHANGE_OF_ADDRESS || caseTypeName == Util.getConstant("EWF_CASE_TYPE").SCAN_AND_POST){
			
			if(this.workItemEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").RV_USER_FIELD)){
						property = this.workItemEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").RV_USER_FIELD];
						if(this.caseEditable && this.caseEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD)){
							var reworkField = this.caseEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD].value; 
							
							var reworkSplit = null;
							var isRework = null;
							var reworkCount = null;
							var propValue;
							var originalValue;
							if(reworkField){
								reworkSplit=reworkField.split("-");
								isRework = reworkSplit[0];
								reworkCount = reworkSplit[1];
							}else{
								isRework="false";
							}
							if(isRework == "false"){
							propValue = property.getValue();
							originalValue = lang.clone(propValue);
								if(propValue.indexOf(userId)==-1){
									propValue.push(userId);
									property.setValue(propValue);	
									property.originalValue=originalValue;
								}
							}else{
										var counts={};
										propValue = property.getValue();
							            originalValue = lang.clone(propValue);
										if(originalValue != null)
										{
							             for(var countIndex=0;countIndex<originalValue.length;countIndex++){
								          var num = originalValue[countIndex];
								          counts[num]= counts[num] ? counts[num]+1:1;
							              }
										}
										if(counts[userId] ){
											if(counts[userId] < reworkCount){
												propValue.push(userId);
												property.setValue(propValue);	
												property.originalValue=originalValue;
											}
										}else{
												propValue.push(userId);
												property.setValue(propValue);	
												property.originalValue=originalValue;
										}
								}
						}
						this.workItemEditable.saveStep(function callback(response){
							complete(result);
						});
			}else{
				if(roleName==Util.getConstant("ROLE_NAMES").MANUAL_PROCESSING || roleName==Util.getConstant("ROLE_NAMES").SNP_MANUAL_PROCESSING){
					if(this.activityEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").MP_USER_FIELD)){
						property = this.activityEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").MP_USER_FIELD];
					}
				}else if(roleName==Util.getConstant("ROLE_NAMES").CALLBACK || roleName==Util.getConstant("ROLE_NAMES").SNP_CALLBACK){
					if(this.activityEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").CB_USER_FIELD)){
						property = this.activityEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").CB_USER_FIELD];
					}
				} 
				if(property!=null){
					var propValue = property.getValue();
					var originalValue = lang.clone(propValue);
					if(roleName==Util.getConstant("ROLE_NAMES").MANUAL_PROCESSING || roleName==Util.getConstant("ROLE_NAMES").SNP_MANUAL_PROCESSING){
						if(this.caseEditable && this.caseEditable.propertiesCollection.hasOwnProperty(Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD)){
							var reworkField = this.caseEditable.propertiesCollection[Util.getConstant("MAKER_CHECKER_FIELDS").REWORK_FIELD].value; 
							
							var reworkSplit = null;
							var isRework = null;
							var reworkCount = null;
							
							if(reworkField){
								reworkSplit=reworkField.split("-");
								isRework = reworkSplit[0];
								reworkCount = reworkSplit[1];
							}else{
								isRework="false";
							}
							if(isRework == "false"){
								if(propValue.indexOf(userId)==-1){
									propValue.push(userId);
									property.setValue(propValue);	
									property.originalValue=originalValue;
								}
							}else{
										var counts={};
										if(originalValue != null)
										{
										for(var countIndex=0;countIndex<originalValue.length;countIndex++){
											var num = originalValue[countIndex];
											counts[num]= counts[num] ? counts[num]+1:1;
										}
										}
										if(counts[userId] ){
											if(counts[userId] < reworkCount){
												propValue.push(userId);
												property.setValue(propValue);	
												property.originalValue=originalValue;
											}
										}else{
												propValue.push(userId);
												property.setValue(propValue);	
												property.originalValue=originalValue;
										}
								}
						}
					}else{	
						if(propValue.indexOf(userId)==-1){
							propValue.push(userId);
							property.setValue(propValue);	
							property.originalValue=originalValue;
						   }
						
					     }
					}
					complete(result);
				}/* else{
					//return args;
				} */
			}else{
				 
				//return args;
			}
			console.log(roleName+"---------------"+userId);
			//return args;
		}
		//End of Changes added by sagar for COA july QR
	});
});
