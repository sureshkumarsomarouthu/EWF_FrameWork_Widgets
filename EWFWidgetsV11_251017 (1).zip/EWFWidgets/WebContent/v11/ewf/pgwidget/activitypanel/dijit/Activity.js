define(["dojo/_base/declare",
    	"dojo/_base/lang",
    	"dojo/aspect",
    	"dojo/string",
    	"dojo/keys",
        "dojo/dom-class",
    	"dojo/_base/array",
    	"v11/ewf/util/Util",
        "dojo/text!./templates/Activity.html",
        "pvr/widget/_Property",
        "dojo/i18n!../../../nls/common", 
		"icm/widget/menu/Toolbar",
		"icm/widget/menu/MenuManager",
		"pvr/widget/registry/Registry",
		"pvr/widget/registry/BasicRegistryConfiguration",
		"icm/widget/properties/registry/Configuration",
		"v11/ewf/model/properties/ViewConfig",
		"icm/base/_BaseWidget",
		"icm/base/BaseActionContext",
		"v11/ewf/pgwidget/activitypanel/dijit/_Activity",
		"v11/ewf/pgwidget/activitypanel/dijit/_ActivityCoordinationMixin",
		"dojo/date/locale",
		"dijit/layout/ContentPane"]
, function(declare, lang, aspect, string, keys, domClass, array, Util, template, _Property, resources, 
		Toolbar, MenuManager, 
		Registry, standardConfig, icmConfig,
		ewfViewConfig, _BaseWidget, BaseActionContext, _Activity, _ActivityCoordinationMixin, dateLocale){
	return declare("v11.ewf.pgwidget.activitypanel.dijit.Activity", [_BaseWidget, BaseActionContext, _Activity, _ActivityCoordinationMixin], {
		
		templateString: template,
        widgetsInTemplate: true,        
        
        baseClass: "icmPageWidget ewfActivity", //simulate a page widget so that actions can be disabled/enabled separately for each digit
        
        instructionDetail: "",
        
        /*
         * args includes:
         * 		activityObj: Use to get the activity instance's attributes;
         * 		activityToolbarAttachPoint: Use it to render activity toolbar by icm.widget.menu.Toolbar; 
         * 		gridRow: The opened grid row;
         * 		pageWidget: Use pageWidget(ActivityPanel)'s functions;
         */
		constructor: function(args){	
			
		},
		
		/*
		 * Init the Activity's instruction information;
		 */
		postMixInProperties: function(){
			this.inherited(arguments);
			this.resourceBundle = resources.ActivityPanel;
			this.instructionDetail = this.activityObj.instruction || "";	
			this.widgetProperties = this.pageWidget.widgetProperties;//stimulate a page widget so that actions can be disabled/enabled separately for each digit
		},
		
		postCreate: function(){
			
			this.inherited(arguments);
			
			this.activityTitle.innerHTML = "<span style='font-weight:bold;'>" + resources.ActivityPanel.activityInsLabel  + "</span>&nbsp;"
							+ this.activityObj.instruction || "";
			
			//Modified by Purna for OTT V11 upgrade changes - Display the Sysytem Msg for OTT alone
			if(this.pageWidget.solution && this.pageWidget.solution.prefix == "EWF") {
				if(this.activityObj.getSystemMessage()){
					this.activityTitle.innerHTML += "<br><span style='font-weight:bold;'>" + this.activityObj.getSystemMessageName() + ":</span>&nbsp; "
										+ this.activityObj.getSystemMessage();
				}
			}
			//End change
			
			this.set("tabIndex", "0");

			// Init this.activityEditable
        	var activityEditable = this.pageWidget.getActionContext("ActivityEditable") && this.pageWidget.getActionContext("ActivityEditable")[0];
			activityEditable.customizeProperties(this.pageWidget.getCusPropsDef());	
			this.activityEditable = activityEditable;
			
			// Init this.workitemEditable
			var workItemEditable = this.pageWidget.getActionContext("WorkItemEditable") && this.pageWidget.getActionContext("WorkItemEditable")[0];
			this.workItemEditable = workItemEditable;
			
			// Init this.caseEditable
			var caseEditable = this.pageWidget.getActionContext("CaseEditable") && this.pageWidget.getActionContext("CaseEditable")[0];
			this.caseEditable = caseEditable;
			
			this.createOrRefreshAPRuleMatrixInfo();
		},
		
		createOrRefreshAPRuleMatrixInfo: function(){
			if(this.activityObj && this.activityObj.getRulesMatrixInformation && this.activityObj.getRulesMatrixInformation()){
				if(this && this.activityRulesMatrixTBody){
					if(this.activityRulesMatrixTBody.innerHTML)
						this.activityRulesMatrixTBody.innerHTML = '';
					var rulesMatrixInformation = this.activityObj.getRulesMatrixInformation();
					var anyRuleDataAvailable = false;
					array.forEach(rulesMatrixInformation, lang.hitch(this, function(ruleItem){
						if(ruleItem && (ruleItem.length > 0)){
							var ruleJsonObject = dojo.fromJson(ruleItem);
							if(ruleJsonObject && (typeof ruleJsonObject !== typeof undefined)){
								anyRuleDataAvailable = true;
								
								var tr = document.createElement('tr');
								var td1 = document.createElement('td');
								var td2 = document.createElement('td');
								var td3 = document.createElement('td');
								var td4 = document.createElement('td');
								
								if(ruleJsonObject['TimeStamp'] && (typeof ruleJsonObject['TimeStamp'] !== typeof undefined)){
									if(!(isNaN(new Date(ruleJsonObject['TimeStamp'])))){
										try{td3.innerHTML = dateLocale.format(new Date(ruleJsonObject['TimeStamp']), {datePattern: 'dd MMM yyyy'});}catch(e){td3.innerHTML = ruleJsonObject['TimeStamp'] || '';}
									}else{
										try{
											//2015-02-16T18:17:27.354+0800
											var timeStampStr = (ruleJsonObject['TimeStamp'] + '').split('T');
											var timeStampStrDateArr = timeStampStr[0].split('-');
											var timeStampStrTimeArr = timeStampStr[1].split(':');
											var timeStampDate = new Date(timeStampStrDateArr[0], Number(timeStampStrDateArr[1]) - 1, timeStampStrDateArr[2], timeStampStrTimeArr[0], timeStampStrTimeArr[1]);
											try{td3.innerHTML = dateLocale.format(timeStampDate, {datePattern: 'dd MMM yyyy'});}catch(e){td3.innerHTML = ruleJsonObject['TimeStamp'] || '';}
										}catch(e){
											td3.innerHTML = ruleJsonObject['TimeStamp'] || '';
										}
										
									}
								}
								
								td1.innerHTML = ruleJsonObject['RuleName'] || ruleJsonObject['System'] ||'';
								td2.innerHTML = ruleJsonObject['Status'] || '';
								//td3.innerHTML = ruleJsonObject['TimeStamp'] || '';
								td4.innerHTML = ruleJsonObject['SystemMessage'] || ruleJsonObject['HostMessage'] || '';
								tr.appendChild(td1);
								tr.appendChild(td2);
								tr.appendChild(td3);
								tr.appendChild(td4);
								
								this.activityRulesMatrixTBody.appendChild(tr);
							}
						}
					}));
				}
				if(anyRuleDataAvailable){
					if(this.activityRulesMatrixDiv && this.activityRulesMatrixDiv.style)
						this.activityRulesMatrixDiv.style.display = 'block';
				}
			}
		},
		
		/*
		 * Render the activity action toolbar when rendering Activity Detail.
		 */
		startup: function(){
			this.inherited(arguments);
			console.log("in startup method this: ",this);			
			if(this.pageWidget && this.pageWidget.coordination){
				
				var coordination = this.pageWidget.coordination;
				if(this.viewNode){
					this.showView();				

					/*coordination.participate(Util.getConstant("EWF_CoordTopic").COMMIT, lang.hitch(this, this.handleICM_CommitEvent));
					coordination.participate(Util.getConstant("EWF_CoordTopic").VALIDATE, lang.hitch(this, this.participate_TopicOfValidation));	
					*/				
				}
				
				this.configureCoordination(coordination);
				
				/*coordination.participate(Util.getConstant("EWF_CoordTopic").AFTERCOMPLETE, lang.hitch(this, this.participate_TopicOfAfterComplete));
				coordination.participate(Util.getConstant("EWF_CoordTopic").HIDE, lang.hitch(this, this.participate_TopicOfHide));
				coordination.participate(Util.getConstant("EWF_CoordTopic").AFTERFOLLOWUP, lang.hitch(this, this.participate_TopicOfAfterFollowUp));
				this._configureCoordination(null, coordination);//complete participate the topics started from the actions configured in work item toolbar
				coordination.participate(constants.CoordTopic.SAVE, lang.hitch(this, this.participate_TopicOfSave));
				*/
			}
			
			if(this.activityToolbarAttachPoint){
				
				this.actionToolbar = new Toolbar({
					"dojoAttachPoint": this.activityToolbarAttachPoint
				});
				
				this.buttonsContainer.addChild(this.actionToolbar);
				
				this.actionToolbar.startup();
			}	
		},
		
		getRegistry: function() {
			var registry = new Registry(console);
			registry.mergeConfiguration(standardConfig);
			registry.mergeConfiguration(icmConfig);
			registry.mergeConfiguration(ewfViewConfig);
			return registry;
		},
		
        showView: function(){
        console.log("this in activity.js showView method ###!!: ",this);
        	var callback = lang.hitch(this, function(){
        		
				if(this._view && this.viewNode){
					this.viewNode.addChild(this._view);
					this._view.startup();
					//TODO : chabges for icm 5.2.1 migration added by suresh bind controller method perameters are changed
					//this._view.bind(this._controller, this.getRegistry());
					//this.afterShowView();
					this.overridePropertyObject();
					this._view.bind(this._controller, this.getRegistry(),null,lang.hitch(this,this.afterShowView));
				}							
        	});
        	
			this.bindController();
			this.createView(callback);
			
        },
        
        overridePropertyObject: function() {
		
		console.log("===== inside overridePropertyObject method in Activity.js ======");
		lang.extend(_Property, {
		
		_getEditorConfig:function () {
	     
	        if(this.innerEditor != ""){
		       this.innerEditor="";
		     }
		   /* if(this.editor == "pvr/widget/editors/DateTimeTextBoxEditor"){
                 this.editor="";
                }*/
            var registry = this.view.registry;
            if (this.editor && registry.isValidEditor(this, this.editor)) {
                return lang.clone(registry.getEditorConfig(this.editor));
            } else {
                return lang.clone(this.innerEditor ? registry.getDefaultMultiEditorConfig() : registry.getDefaultEditorConfig(this));
            }
            
        }
		
		});
		},
		
		afterShowView: function(){
		
		console.log("call afterShowView method",this);
			//Disable view;
			
		//Begin change by Tara on 23.09.2016 for JAN QR- Commented and modified the existing behavior. Based on MyTasks/AllTasks retrieve particular setting if configured
			//to set the view Editable/ReadOnly
			/*if(!this.pageWidget.getCfgOfRunMode()){		
				this._view && this._view.set("readOnly", true);
			}*/
			//If the value is MyTasks get widget setting for runMode
			if(this.pageWidget.filterTask.value == "myTasks"){			
				if(!this.pageWidget.getCfgOfRunMode()){		
					this._view && this._view.set("readOnly", true);
				}
			//Else get the widget setting for  RunMode_AllActivities 
			}else{	
				if(this.pageWidget.getCfgOfRunMode_AllActivities() == "false"){
					this._view && this._view.set("readOnly", true);
				}	
			}
		//End change

			
			var viewPropTables = {};
			//Set property label failureType
			this._view.forEachProperty({
				callback: lang.hitch(this, function(property) {
					if(property.editorWidget){
						var controller = property.controller;
						if( this.isHighlightedPro(controller) ){
						    //commented by suresh as part of 5.2.1 upgrade super script issue
							//dojo.addClass(property.editorWidget.labelWrap, "ewfHighlighted");
							dojo.addClass(property.domNode.firstChild, "ewfHighlighted");
						}
						if(controller.get("required")
								|| controller.get("logicRequired")){
							//commented by suresh as part of 5.2.1 upgrade super script issue
							//dojo.addClass(property.editorWidget.labelWrap, "ewfRequied");
							dojo.addClass(property.domNode.firstChild, "ewfRequied");
						}
						if(controller.get("failureType") && !controller.get("updated")){
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " "+controller.get("failureType");
							//commented by suresh as part of 5.2.1 upgrade super script issue
							//property.editorWidget.labelWrap.appendChild(failureLabel);
							property.domNode.firstChild.appendChild(failureLabel);
						}
						if(controller.get("updated")){
						    //added by suresh for displaying super script for check boxes
						    if(controller.type == "checkBox"){
						    var mainLabel = dojo.create("label");
						    var failureLabel = dojo.create("label");
						    dojo.addClass(failureLabel, "ewfFailureType");
						    failureLabel.innerHTML = " Updated";
							//mainLabel.innerHTML = controller.model.name;
							if(controller.model.label){
						        mainLabel.innerHTML = controller.model.label;
						    }else{
						    mainLabel.innerHTML = controller.model.name;
						    }
							mainLabel.appendChild(failureLabel);
							//modified by suresh for displaying check box label twice jira issue PEWFSGUPGS-214
							property.domNode.firstChild.innerText="";
							property.domNode.firstChild.appendChild(mainLabel);
							property.editorWidget.compLabelNode.innerHTML="";
						    }
						    //added by suresh for displaying super script for add cards widget issue
						    else{
						    if(controller.id != "COPC_ListofCardOrg"){
						    if(controller.id != "COPC_ListofGiftCode"){
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " Updated";
							//commented by suresh as part of 5.2.1 upgrade super script issue
							//property.editorWidget.labelWrap.appendChild(failureLabel);
							property.domNode.firstChild.appendChild(failureLabel);
							}
							}
							else if(controller.id != "COPC_ListofGiftCode"){
							 if(controller.id != "COPC_ListofCardOrg"){
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " Updated";
							//commented by suresh as part of 5.2.1 upgrade super script issue
							//property.editorWidget.labelWrap.appendChild(failureLabel);
							property.domNode.firstChild.appendChild(failureLabel);
							}
							}
							}
						}
					}
					if(property.getParent()._containerType == "propertyTable"){
						if(!viewPropTables.hasOwnProperty(property.getParent().id)){
							viewPropTables[property.getParent().id] = property.getParent();
						}
					}
				})
			});
			
			var propTable;
			for(propTable in viewPropTables){
				if(viewPropTables.hasOwnProperty(propTable)){
					var propGrid = viewPropTables[propTable]._grid;
					var propGridStructure = propGrid.structure;
					dojo.forEach(propGridStructure, lang.hitch(this, function(headerCell){
						var propGridHeader = propGrid.header;
						var colId = headerCell.id;
						var colCell = propGridHeader.getHeaderNode(colId).firstChild;
						var controller = this._controller.getPropertyController(colId);
						
						if(this.isHighlightedPro(controller) ){
							dojo.addClass(colCell, "ewfHighlighted");
						}
						if(controller.get("required") 
								|| controller.get("logicRequired") ){
							dojo.addClass(colCell, "ewfRequied");
						}
						if(controller.get("failureType") && !controller.get("updated")){
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " " + controller.get("failureType");
							colCell.appendChild(failureLabel);
						}
						if(controller.get("updated")){
							var failureLabel = dojo.create("label");
							dojo.addClass(failureLabel, "ewfFailureType");
							failureLabel.innerHTML = " Updated";
							colCell.appendChild(failureLabel);
						}
					}));
					
				}
			}
			
			//Sync up caseEditable controller change
			/*if(this._caseController.isModified()){
				var changes = {};
				var collectChanges = function(propertyController){
					if(propertyController.isModified()){
						var change = {
								value: propertyController.get("value"),
								error: propertyController.get("error")
						}
						var propertyId = propertyController.get("id");
						changes[propertyId] = change;
					}
				}
				var options = {
					callback: collectChanges
				}
				this._caseController.forEachPropertyController(options);
				this._updateProperty(this._controller, changes);
			}*/

			setTimeout(lang.hitch(this, this.resize), 200);
			
			console.log("end of afterShowView method");
			
		},
		
		isHighlightedPro: function(propertyController){
			
			if( propertyController.get("updated")
				|| propertyController.get("failureType")){
				return true;
			}else{
				return false;
			}
		},

		/*
		 * Fix the issue of cannot focus the cursor by mouse.
		 */
		onMouseDown: function(evt){
			var sr = this.gridRow.grid.select.row;
			sr.triggerOnCell = false;
			evt.columnId = true;
		},
		
		/*
		 * Fix the issue of cannot input the SPACE key.
		 */
		onKeyDown: function(evt){			
			if(evt.keyCode == keys.SPACE){
				var sr = this.gridRow.grid.select.row;
				sr.triggerOnCell = false;
				evt.columnId = true;
				//evt.target.value = evt.target.value + " ";
			console.debug("activity, onKeyDown: "+evt.columnId);
			}
		},	

		onKeyUp: function(evt){			
			if(evt.keyCode == keys.SPACE){
				var sr = this.gridRow.grid.select.row;
				sr.triggerOnCell = false;
				evt.columnId = true;
				//evt.target.value = evt.target.value + " ";
			console.debug("activity, onKeyUp: "+evt.columnId);
			}
		},
		
		destroy: function(){			
			console.debug("activity destroy");					
			
			this.resourceBundle = null;
			this.instructionDetail = null;	
			this.widgetProperties = null;
			
			this.actionToolbar = null;
			
			this.activityEditable = null;
			
			this.workItemEditable = null;
			
			this.caseEditable = null;			

			//clean context
			this.cleanActionContext("ActivityEditable");
			this.cleanActionContext("WorkItemEditable");
			this.cleanActionContext("CaseEditable");
			this.cleanActionContext("Coordination");
			this.cleanActionContext("UIState");
						
			this.inherited(arguments);
		}
	});
});
