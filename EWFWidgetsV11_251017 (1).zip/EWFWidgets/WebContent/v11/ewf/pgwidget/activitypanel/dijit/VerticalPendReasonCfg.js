define([], function(){
	
	var VerticalPendReasonCfg = {
		"MP": [
			{
				"id": 1,
				"value": "0.5",
				"label": "Unable to reach customer (Default)"
			},
			{
				"id": 2,
				"value": "1",
				"label": "Pending Customer to Revert - 1 hour"
			},
			{
				"id": 3,
				"value": "4",
				"label": "Pending Customer to Revert - 4 hours"
			},
			{
				"id": 4,
				"value": "-1",
				"label": "Pending Customer to Revert - next Business Day"
			},
			{
				"id": 5,
				"value": "2",
				"label": "Pending BU's response - 2 hours"
			},
			{
				"id": 6,
				"value": "-1",
				"label": "Pending BU's response - next Business Day"
			},
			{
				"id": 7,
				"value": "1",
				"label": "One Hour"
			},
			{
				"id": 8,
				"value": "48",
				"label": "Missing Document"
			},
			{
				"id": 9,
				"value": "1",
				"label": "Assistance Required"
			},
			{
				"id": 10,
				"value": "-2",
				"label": "Future Transaction"
			}
		],
		"CB": [
			{
				"id": 1,
				"value": "0.5",
				"label": "Unable to reach customer (Default)"
			},
			{
				"id": 2,
				"value": "-1",
				"label": "Unable to reach customer - next Biz Day"
			},
			{
				"id": 3,
				"value": "0.25",
				"label": "Customer request to CB later - 15 min"
			},
			{
				"id": 4,
				"value": "0.50",
				"label": "Customer request to CB later - 30 min"
			},
			{
				"id": 5,
				"value": "1",
				"label": "Customer request to CB later - 60 min"
			},
			{
				"id": 6,
				"value": "2",
				"label": "Customer request to CB later - 120 min"
			},
			{
				"id": 7,
				"value": "-1",
				"label": "Customer request to CB - next Biz Day"
			},
			{
				"id": 8,
				"value": "1",
				"label": "One Hour"
			},
			{
				"id": 9,
				"value": "48",
				"label": "Missing Document"
			},
			{
				"id": 10,
				"value": "1",
				"label": "Assistance Required"
			}
		],
		"RV": [
			{
				"id": 1,
				"value": "0.5",
				"label": "Unable to reach customer (Default)"
			},
			{
				"id": 2,
				"value": "1",
				"label": "Pending Customer to Revert - 1 hour"
			},
			{
				"id": 3,
				"value": "4",
				"label": "Pending Customer to Revert - 4 hours"
			},
			{
				"id": 4,
				"value": "-1",
				"label": "Pending Customer to Revert - next Business Day"
			},
			{
				"id": 5,
				"value": "2",
				"label": "Pending BU's response - 2 hours"
			},
			{
				"id": 6,
				"value": "-1",
				"label": "Pending BU's response - next Business Day"
			},
			{
				"id": 7,
				"value": "1",
				"label": "One Hour"
			},
			{
				"id": 8,
				"value": "48",
				"label": "Missing Document"
			},
			{
				"id": 9,
				"value": "1",
				"label": "Assistance Required"
			},
			{
				"id": 10,
				"value": "-2",
				"label": "Future Transaction"
			}
		],
		"EH": [
			{
				"id": 1,
				"value": "0.5",
				"label": "Unable to reach customer (Default)"
			},
			{
				"id": 2,
				"value": "0.25",
				"label": "Customer request to CB later - 15 min"
			},
			{
				"id": 3,
				"value": "0.50",
				"label": "Customer request to CB later - 30 min"
			},
			{
				"id": 4,
				"value": "1",
				"label": "Customer request to CB later - 60 min"
			},
			{
				"id": 5,
				"value": "2",
				"label": "Customer request to CB later - 120 min"
			},
			{
				"id": 6,
				"value": "-1",
				"label": "Customer request to CB - next Biz Day"
			},
			{
				"id": 7,
				"value": "1",
				"label": "One Hour"
			},
			{
				"id": 8,
				"value": "48",
				"label": "Missing Document"
			},
			{
				"id": 9,
				"value": "1",
				"label": "Assistance Required"
			}
		]
	};
	
	return VerticalPendReasonCfg;
	
});