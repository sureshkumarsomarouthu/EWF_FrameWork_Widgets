define(["v11/ewf/pgwidget/activitypanel/dijit/DataValidationActivity",
        "v11/ewf/pgwidget/activitypanel/dijit/Activity"], 
		function(){
	
	var ActivityConfig = {
			"COPC_DataValidationCheck": "v11/ewf/pgwidget/activitypanel/dijit/DataValidationActivity",
			"Default": "v11/ewf/pgwidget/activitypanel/dijit/Activity"
	};
	
	return ActivityConfig;
	
});