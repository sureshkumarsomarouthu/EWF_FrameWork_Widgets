define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/_base/sniff",
	"dojo/_base/event",
	"dojo/_base/query",
	"dojo/keys",
	"dojo/aspect",
	"dojo/dom-class",
	"icm/base/_BaseWidget",
	"icm/base/BaseActionContext",
	"dojo/text!./templates/ActivityList.html",
	"dojo/i18n!../../../nls/common",
	"gridx/modules/RowHeader",
	"gridx/modules/Dod",
	//import added by suresh for Activity panel grid render issue
	"gridx/modules/Body",
	//End change
	"v11/ewf/pgwidget/activitypanel/dijit/_GridDodFocusMixin",
	"v11/ewf/pgwidget/activitypanel/modules/ActivityListViewDetail",
	"v11/ewf/model/ActivityList",
	"v11/ewf/model/Activity",
	"v11/ewf/model/ActivityEditable",
	"v11/ewf/pgwidget/activitypanel/dijit/ActivityFactory",
	"dojo/dom-style",
	"dojo/_base/Deferred",
	"dojo/dom-construct",
	"dijit/form/Button",
	"ecm/widget/listView/ContentList",
	"ecm/model/ResultSet"
],function(declare, lang, array, sniff, event, query, keys, aspect, domClass, _BaseWidget, BaseActionContext, template, resources, 
		RowHeader, Dod, Body, _GridDodFocusMixin, ActivityListViewDetail, ActivityListModel, ActivityModel, ActivityEditable, ActivityFactory, 
		domStyle, Deferred, domConstruct){
	
	return declare("v11.ewf.pgwidget.activitypanel.dijit.ActivityList", [_BaseWidget], {

		templateString: template,
		
        widgetsInTemplate: true,
        
        baseClass: "ewfActivityList",
        
        /*
         * activityDijits to store the opened activityDijits by gridRow.
         */
        activityDijits: null,
		
		
		/*
         * maintain the list that case properties Collection are updated by current UI as an array.
         */
		updatedCasePropertiesCollection:null,
        
        /*
         * args includes:
         * 			pageWidget: Use pageWidget(ActivityPanel)'s functions;
         */
        constructor: function(args){
        	this.activityDijits = {};
        	this.updatedCasePropertiesCollection = {};
        },
        
        postMixInProperties: function(){
        	this.resourceBundle = resources.ActivityPanel;
    		this.inherited(arguments);
        },
        
        postCreate: function(){
        	this.inherited(arguments);
        	
        	this.initContentList();
        	
        	this.connect(this.activityListGrid, "onRowClick", "onClickRow");
        	this.connect(this.activityListGrid, "onRender", "onGridRender");
			
			//Added by Purna for OTT V11 Upgrade changes begin change - based on the boolean flag enable activity expansion on row double click
			if(this.pageWidget && this.pageWidget.widgetProperties && this.pageWidget.widgetProperties.expandAll) {
				this.connect(this.activityListGrid, "onRowDblClick", "onRowDblClick");
        	}
			//End change
			//Added by suresh for Activity panel widget Grid render issue
			this.overrideRenderRows();
			//End change
        	try{this.activityListGrid.grid.vScroller.buffSize = 50;}catch(e){}
        	try{this.activityListGrid.vScrollerBuffSize = 50;}catch(e){}
        	try{delete this.activityListGrid.grid.vScroller;}catch(e){}
        },        
        
        initContentList: function(){
            //Added by suresh for Activity panel widget Grid render issue passed annimation
            //perameter useAnimation: false for detailProvider Object
        	var gridExtensionModules = [ RowHeader,
        	                            { moduleClass: Dod,
        								  detailProvider: dojo.hitch(this,
        										  this.showActivityDetail),useAnimation: true}
        								];
        	this.activityListGrid.setGridExtensionModules(gridExtensionModules);
        	
        	var contentListModules = this.getContentListModules();
        	this.activityListGrid.setContentListModules([]);
        },
        
        /*
         * Update Activity List based on configured status.
         */
        renderGrid: function(status){
           //Added by suresh for Activity panel activity is open after complete the each Activity
           //begin change
        	this.overrideDodLoad();
           // end change	
			var params = {
        		repository: this.pageWidget.caseEditable.repository,
				parentCase: this.pageWidget.caseEditable
        	};
        	var myList = new ActivityListModel(params);
			myList.retrieveActivityItems(lang.hitch(this, 
			                                        function(results){
														this.destroyActivityDijits();
														this.activityListGrid.autoHeight = true;
														this.activityListGrid.multiSelect = false;//Activity List can't support multile Select
														this.activityListGrid.setResultSet(results);
														this._A11yFix_ContentList_Gridx();//that could be removed once gridx is upgraded for bettor support on a11y;
														if(this.page && this.page.resize && lang.isFunction(this.page.resize)){
														    this.page.resize();
														}
												    }), status);
			setTimeout(lang.hitch(this, this.resize()), 50);

        },
        
        //Added by suresh for Activity panel activity is open after complete the each Activity
		overrideDodLoad: function() {
		lang.extend(Dod, {
		load:function (args, deferStartup) {
            var t = this, g = t.grid, m = g.model;
            t._rowMap = {};
            t.connect(g.body, "onAfterCell", "_onAfterCell");
            t.connect(g.body, "onAfterRow", "_onAfterRow");
            t.connect(g.bodyNode, "onclick", "_onBodyClick");
            t.connect(g.body, "onUnrender", "_onBodyUnrender");
            t.connect(g, "onCellKeyDown", "_onCellKeyDown");
            t.connect(g.body, "_onRowMouseOver", "_onRowMouseOver");
           //t.connect(m, "onSet", "_onModelSet");
            if (g.isIE) {
                t.aspect(t.grid.body, "renderRows", function (s, c, p) {
                    if (p === "top" || p === "bottom") {
                        return;
                    }
                    var i, rowInfo, _row, temp, rm = t._rowMap;
                    for (var k in rm) {
                        temp = rm[k];
                        temp.dodLoaded = false;
                        temp.dodLoadingNode = null;
                        temp.dodNode = null;
                    }
                }, t, "before");
            }
            if (t.grid.columnResizer) {
                t.connect(t.grid.columnResizer, "onResize", "_onColumnResize");
            }
            t.loaded.callback();
        }
       
        });
        },	
        //End change
        
        getContentListModules: function(){
        	var array = [];
        	var viewDetail = this.getViewDetailModule();
        	array.push(viewDetail);
        	return array;
        },
        
        getViewDetailModule: function() {
			var view = {
				moduleClass: ActivityListViewDetail
			};
			return view;
		},
        
		onClickRow: function(item, evt){
		},
		
		//Added by Purna for OTT V11 Upgrade changes BEGIN - Expand/Hide the activity detail on row double click event
		onRowDblClick: function(item, evt){
			//Ensure the event is cell double click then only expand the activity
			if(evt && evt.cellNode) {
				var rowId = item.id;
				var selectedRow = this.activityListGrid.grid.row(rowId, true);
				this.activityListGrid.grid.dod.toggle(selectedRow);
			}
        },
		//End method
		
		//Added by Purna for OTT V11 Upgrade changes BEGIN - Override the Dod show method to capture exception scenarios and retry expand & to expand next activity
		overrideDodShow: function() {
			var _self = this;
			lang.extend(Dod, {
				show: function(row){
					row = typeof row === 'object' ? row : this.grid.row(row, 1/*isid*/);
					var _row = this._row(row),
						df = new Deferred(),
						g = this.grid;

					if(_row.dodShown || _row.inAnim){
						df.errback('Row detail has already shown.');
						return df;
					}
					
					_row.dodShown = true;
					
					//Modified by Purna BEGIN - Comment the OOTB code change it to capture the exception scenario and to set retry falg
					/*if(!row.node()){
						df.callback(row);
						return df;
					}*/
					if(!row.node()) {
						console.debug('unable to expand the current row. _row: ', _row, ' row.node(): ', row.node(), 'index:', _self.currentActivityIndex);
						if(_self.isExpandAllInProgress) {
							_self.currentActivityIndex = _self.currentActivityIndex - 1;//decrement the activity index as this activity isn't expanded
							_self.retryExpand = true;
						}
						return df;
					}
					//End change
					
					var expando = this._getExpando(row);
					
					//Modified by Purna BEGIN - Comment the OOTB code and add additional condition as sometimes 'firstChild' is coming as null for exception scenarios
					//if(expando && expando.firstChild){expando.firstChild.innerHTML = '-';}
					if(expando) {
						if(expando.firstChild){
							expando.firstChild.innerHTML = '-';
						}else{
							console.debug('Expando firstChild is null expando:', expando, 'index:', _self.currentActivityIndex); 
							expando.innerHTML = '<span class="gridxDodExpandoText">-</span>';
						}
					}
					//End change
					
					var node = row.node(), w = node.scrollWidth;
					if(!_row.dodLoadingNode){
						_row.dodLoadingNode = dojo.create('div', {
							className: 'gridxDodLoadNode', 
							innerHTML: 'Loading...'
						});
					}
					if(!_row.dodNode){
						_row.dodNode = dojo.create('div', {className: 'gridxDodNode'});
					}
					domConstruct.place(_row.dodLoadingNode, node, 'last');
					domConstruct.place(_row.dodNode, node, 'last');
					
					domStyle.set(_row.dodLoadingNode, 'width', w + 'px');
					domStyle.set(_row.dodNode, 'width', w + 'px');
					domStyle.set(_row.dodNode, 'visibility', 'hidden');
					domStyle.set(_row.dodNode, 'overflow', 'hidden');
					domStyle.set(_row.dodNode, 'height', '0px');
					
					domClass.add(node, 'gridxDodShown');
					
					//Modified by Purna BEGIN - Comment the OOTB code and add additional checks to make sure the body is shown
					//if(_row.dodLoaded){
					if(_row.dodLoaded && _row.dodNode && _row.dodNode.firstChild){
						//this._detailLoadComplete(row); //Comment the OOTB call and call our own method inorder to continue expanding next activity
						_self.onDetailLoadComplete(row, df, this);
						return df;
					}else{
						domStyle.set(_row.dodLoadingNode, 'display', 'block');
						if(g.autoHeight){
							g.vLayout.reLayout();
						}
						_row.inLoading = true;
					}
					
					if(this.grid.rowHeader){
						var rowHeaderNode = query('[rowid="' + this.grid._escapeId(row.id) + '"].gridxRowHeaderRow', this.grid.rowHeader.bodyNode)[0];
						//TODO: 1 is the border for claro theme, will fix
						var h = domStyle.get(row.node(), 'height');
						domStyle.set(rowHeaderNode.firstChild, 'height', h + 'px');
						domStyle.set(rowHeaderNode, 'height', h + 'px');
					}
					
					var _df = new Deferred(),
						_this = this;
					if(this.arg('detailProvider')){
						this.detailProvider(this.grid, row.id, _row.dodNode, _df);
					}else{
						_df.callback();
					}
					//Comment the OOTB calls and call our own methods inorder to continue expanding next activity
					//_df.then(lang.hitch(this, '_detailLoadComplete', row, df), lang.hitch(this, '_detailLoadError', row, df));
					_df.then(lang.hitch(_self, 'onDetailLoadComplete', row, df, this), lang.hitch(_self, 'onDetailLoadError', row, df, this));
					return df;
				}
			});
		},
		//End method
		
		//Added by suresh for Activity panel widget Grid render issue to override render rows method
		overrideRenderRows: function() {
		lang.extend(Body, {
		renderRows:function (start, count, position, isRefresh) {
            var t = this, g = t.grid, str = "", uncachedRows = [], renderedRows = [], n = t.domNode, en = g.emptyNode, emptyInfo = t.arg("emptyInfo", g.nls.emptyInfo), finalInfo = "";
            if (t._err) {
                return;
            }
            if (count > 0) {
                if (position != "top" && position != "bottom") {
                    t.model.free();
                }
                if (position == "top") {
                    str = t._buildRows(start, count, uncachedRows, renderedRows);
                    t.renderCount += t.renderStart - start;
                    t.renderStart = start;
                    domConstruct.place(str, n, "first");
                    if (g.cellWidget && g.vScroller._updateRowHeight) {
                        var oldEnd = t.renderStart + t.renderCount, postCount = g.vScroller._updateRowHeight("post");
                        if (oldEnd - postCount < start + count) {
                            count = oldEnd - postCount - start;
                        }
                    }
                } else {
                    if (position == "bottom") {
                        str = t._buildRows(start, count, uncachedRows, renderedRows);
                        t.renderCount = start + count - t.renderStart;
                        domConstruct.place(str, n, "last");
                        //Comment the OOTB calls and add if g.vScroller is available then only we will call _updateRowHeight method
                        //if (g.cellWidget && g.vScroller._updateRowHeight) {
                        if (g.cellWidget && g.vScroller && g.vScroller._updateRowHeight) {
                            g.vScroller._updateRowHeight("pre");
                            if (t.renderStart > start) {
                                start = t.renderStart;
                                count = t.renderCount;
                            }
                        }
                    } else {
                        t.renderStart = start;
                        t.renderCount = count;
                        var scrollTop = isRefresh ? n.scrollTop : 0;
                        if (!t._skipUnrender) {
                            t.onBeforeUnrender();
                            t.onUnrender();
                        }
                        t.renderedIds = {};
                        str = t._buildRows(start, count, uncachedRows, renderedRows);
                        n.innerHTML = str;
                        n.scrollTop = scrollTop;
                        n.scrollLeft = g.hScrollerNode.scrollLeft;
                        finalInfo = str ? "" : emptyInfo;
                        if (!str) {
                            en.style.zIndex = 1;
                        }
                    }
                }
                array.forEach(renderedRows, t.onAfterRow, t);
                Deferred.when(t._buildUncachedRows(uncachedRows), function () {
                    if (!t._err) {
                        en.innerHTML = finalInfo;
                    }
                    t._hideLoadingMask();
                    t.onRender(start, count);
                });
            } else {
                if (!{top:1, bottom:1}[position]) {
                    var id = 0;
                    n.scrollTop = 0;
                    if (!t._skipUnrender) {
                        t.onBeforeUnrender();
                        t.onUnrender();
                    }
                    while (n.firstChild) {
                        id = n.firstChild.getAttribute("rowid");
                        n.removeChild(n.firstChild);
                    }
                    t.renderedIds = {};
                    en.innerHTML = emptyInfo;
                    en.style.zIndex = 1;
                    t._hideLoadingMask();
                    t.onEmpty();
                    t.model.free();
                }
            }
        }
        });
        },
		//End method
		
		//Added by Purna for OTT V11 Upgrade changes BEGIN - Call the expandAllActivities function to continue expanding next activity
		onDetailLoadComplete: function(row, df, dodObj) {
			if(dodObj) {
				dodObj._detailLoadComplete(row, df);
				console.log('_detailLoadCompleted');
				setTimeout(lang.hitch(this, this.resize), 20);
	    	    if(this.isExpandAllInProgress) {
	    	    	setTimeout(lang.hitch(this, this.expandAllActivities), 200);
				}
			} else {
				console.error('dodObj param missing');
			}
		},
		//End method
		
		//Added by Purna for OTT V11 Upgrade changes BEGIN - On error fail expand all
		onDetailLoadError: function(row, df, dodObj) {
			dodObj && dodObj._detailLoadError && dodObj._detailLoadError(row);
			this.isExpandAllInProgress = false;
			this.currentActivityIndex = 0;
			delete this.currentActivityIndex;
			this.pageWidget.expandAll.set("disabled", false);
			console.log('Expand all activities not finished as activity load failed');
		},
		//End method
		
		//Added by Purna for OTT V11 Upgrade changes BEGIN - Iteratively expand all the Activities in the grid
		expandAllActivities: function(evt) {
			if(typeof this.currentActivityIndex == 'undefined') {
				this.currentActivityIndex = 0;
				//this.evtTimeStamp = evt.timeStamp;
			} else { 
				this.currentActivityIndex = this.currentActivityIndex + 1;
			}
			
			if(this.activityListGrid._resultSet.items && this.currentActivityIndex < this.activityListGrid._resultSet.items.length) {
				this.isExpandAllInProgress = true;
				var item = this.activityListGrid._resultSet.items[this.currentActivityIndex];
				var rowId = item.id;
				var selectedRow = this.activityListGrid.grid.row(rowId, true);
				
				if(!this.activityListGrid.grid.dod.isShown(selectedRow)) {
					console.debug('Going to expand activity: ', new Date());
					this.activityListGrid.grid.dod.show(selectedRow);
				} else {
					console.debug('Row is already in expand row: ', selectedRow);
					this.expandAllActivities();
				}
			} else {
				this.isExpandAllInProgress = false;
				this.currentActivityIndex = 0;
				delete this.currentActivityIndex;
				this.pageWidget.expandAll.set("disabled", false);
				console.log('Expand all activities finished');
			}
		},
		//End method
		
		//Added by Purna for OTT V11 Upgrade changes BEGIN - Collapse all Activities
		collapseActivities: function(evt) {
			if(this.activityListGrid._resultSet.items && this.activityListGrid._resultSet.items.length > 0) {
				array.forEach(this.activityListGrid._resultSet.items, lang.hitch(this, function(item) {
					var rowId = item.id;
					var selectedRow = this.activityListGrid.grid.row(rowId, true);
					if(this.activityListGrid.grid.dod.isShown(selectedRow)) {
						this.activityListGrid.grid.dod.hide(selectedRow);
					}
				}));
			}
			this.isExpandAllInProgress = false;
			this.currentActivityIndex = 0;
			delete this.currentActivityIndex;
			this.pageWidget.expandAll.set("disabled", false);
			this.pageWidget.collapseAll.set("disabled", false);
			console.log('Collapse all activities finished');
		},
		//End method
		
        /*
         * Show Activity Detail information when click to open row
         */
        showActivityDetail: function(grid, rowId, detailNode, renderred){
        	
        	var selectedRow = grid.row(rowId, true);
        	var contentItem = selectedRow.item();
			
			ActivityModel.fromContentItem(contentItem, this.pageWidget.caseEditable, 
					lang.hitch(this, function(activityItem){
			
				var activityEditable = ActivityEditable.fromActivity(activityItem);
				
				this.pageWidget.cleanActionContext("ActivityEditable");
				this.pageWidget.setActionContext("ActivityEditable", activityEditable);
	        	
	        	var activityToolbarAttachPoint = this.pageWidget.getActivityToolbarAttachPoint();
	        	
	        	var callback = lang.hitch(this, function(activityDijit, activityEditable){
				        if(this.activityDijits[rowId]){
							this.activityDijits[rowId].destroy();
						}
	        			this.activityDijits[rowId] = activityDijit;
	    	        	
	    	        	detailNode.appendChild(activityDijit.domNode);
	    				
	    				if(activityDijit.isInstanceOf(BaseActionContext)){//TODO: we will remove this codes once we have our own property which is not an instance of BaseActionContext
	    					activityDijit.cleanActionContext("WorkItemEditable");
	    					if(this.pageWidget.getActionContext("WorkItemEditable") && this.pageWidget.getActionContext("WorkItemEditable")[0]){
	    						activityDijit.setActionContext("WorkItemEditable", this.pageWidget.getActionContext("WorkItemEditable")[0]);
	    					}
	    			
	    					activityDijit.cleanActionContext("Coordination");
	    					activityDijit.setActionContext("Coordination", this.pageWidget.getActionContext("Coordination")[0]);
	    					
	    					activityDijit.cleanActionContext("ActivityEditable");
	    					activityDijit.setActionContext("ActivityEditable", activityEditable);
	    					
	    					activityDijit.cleanActionContext("UIState");
							if(this.pageWidget.getActionContext("UIState") && this.pageWidget.getActionContext("UIState")[0]){
	    						activityDijit.setActionContext("UIState", this.pageWidget.getActionContext("UIState")[0]);
	    					}
	    				}
	    	        	
	    	        	activityDijit.startup();
						setTimeout(lang.hitch(this, this.resize), 20);
	    	        	renderred.callback();
	    	        	
	    	        	//Commented by Purna for OTT V11 Upgarde changes BEGIN - Execute the deferred functions in onDetailLoadComplete
	    	        	/*renderred.then(lang.hitch(this, function(resolvedCallback){
	    	        		console.debug('inside resolvedCallback');
	    	        		//setTimeout(lang.hitch(this, this.resize), 20);
	    	        		if(this.isExpandAllInProgress) {
	    	        			setTimeout(lang.hitch(this, this.expandAllActivities), 100);
	    	        		}
	    	        	}),
	    	        	lang.hitch(this, function(errorCallback){
	    	        	}),
	    	        	lang.hitch(this, function(progressCallback){
	    	        	}));*/
	    	        	//End change
	        	});
	        	
	        	ActivityFactory.createActivity(activityEditable, activityToolbarAttachPoint, selectedRow, this.pageWidget, callback);
	       
			}));
			
    		return renderred;
        },

        syncUpUpdatedProperties: function(){
        	if(this.updatedCasePropertiesCollection == {}){
        		return;
        	}
        	var ccCheckActivity, ccUpgradeActivity;
        	
        	var dijitId;
        	var activityDijits = this.activityDijits;
        	for (dijitId in activityDijits){
        		if(activityDijits.hasOwnProperty(dijitId)){
            		var activityDijit = activityDijits[dijitId];
            		activityDijit.syncUpUpdatedProperties(this.updatedCasePropertiesCollection);
        		}
        	}
        },
        
        // Mainly to handle the sync up of credit card check and credit card upgrade
        syncUpDiffActivities: function(){
        	
        	var ccCheckActivity, ccUpgradeActivity;
        	
        	var dijitId;
        	var activityDijits = this.activityDijits;
        	for (dijitId in activityDijits){
        		if(activityDijits.hasOwnProperty(dijitId)){
            		var activityDijit = activityDijits[dijitId];
            		if(activityDijit.activityObj.getActivityType() === "COPC_CreditCardCheck"){
            			ccCheckActivity = activityDijit;
            		}
            		if(activityDijit.activityObj.getActivityType() === "COPC_CreditCardUpgrade"){
            			ccUpgradeActivity = activityDijit;
            		}
        		}
        	}
        	
        	if( ccCheckActivity && ccUpgradeActivity){
        		var ctController = ccCheckActivity._controller.getPropertyController("COPC_ListofCardType");
        		var coController = ccCheckActivity._controller.getPropertyController("COPC_ListofCardOrg");
        		if(ctController.isModified() || coController.isModified()){
        			var gridRow = ccUpgradeActivity.gridRow;
        			ccUpgradeActivity.destroy();
        			if(gridRow.isDetailShown()){
            			gridRow.grid.dod._row(gridRow).dodShown = false;
            			gridRow.grid.dod.refresh(gridRow);
        			}else{
        				gridRow.grid.dod._row(gridRow).dodLoaded = false;
        			}
        		}
        	}        	
        },
                
        _handleICM_UpdateFieldsEvent: function(changes){
        	var activityDijits = this.activityDijits;
        	
        	var dijitId;
        	for (dijitId in activityDijits){
        		if(activityDijits.hasOwnProperty(dijitId)){
            		var activityDijit = activityDijits[dijitId];
            		if(activityDijit && activityDijit._handleICM_UpdateFieldsEvent){
            			activityDijit._handleICM_UpdateFieldsEvent(changes);
            		}
        		}
        	}
        },
		
		_A11yFix_ContentList_Gridx:function(){
			//the below fix could not be the final solution to fix the issue that editable fields can't get focus.
			this.activityListGrid.disconnect(this.activityListGrid.gridConnections[0]);
			
			//F4 pressing can make the dod get focus
			var _onKeyDown = lang.hitch(this, function(grid){
				this.connect(grid.bodyNode, 'onkeydown', function(e){
					if(e.keyCode === keys.F4){
						e.keyCode = 0;
						if(e.preventDefault){
							e.preventDefault();
						}else{
							e.returnValue = false;
						}
					}
				});
				
				/*this.connect(grid.body, 'renderRows', function(s, c, p){
					if(p !== 'top' && p !== 'bottom'){
						if(grid.dod){
							for(var i in grid.dod._rowMap){
								grid.dod._rowMap[i].dodLoaded = false;
								grid.dod._rowMap[i].dodLoadingNode = null;

							}
						}
						// grid.dod._rowMap = {};
					}
				});*/
				
				this.connect(grid.body, 'onRender', lang.hitch(this, function(){//fix the issue that vertial crollbar is not shown as expected
					setTimeout(function(){
						grid.resize();
					}, 10);
					
					//Added by Purna for OTT V11 Upgarde changes BEGIN - Check the flags Expand All & Retry and if both set retry expanding
					if(this.isExpandAllInProgress && this.retryExpand) {
						console.debug('onRender finished, retry Expand Activity.');
						this.retryExpand = false;
						delete this.retryExpand;
						setTimeout(lang.hitch(this, "expandAllActivities"), 200);
					}
					//End change
				}));
			});
														
			//Below line would be removed once applying new version of gridx which could fix the 'space' issue 
			//that 'SPACE' key can not be input into dod panel.
			this._IE8SpaceIssueFix();
														
			if(!this.activityListGrid.grid){
				setTimeout(function(){
					lang.mixin(this.activityListGrid.grid.dod, _GridDodFocusMixin);
					this.activityListGrid.grid.dod.iniFocus();
					_onKeyDown(this.activityListGrid.grid);																
					aspect.before(this.activityListGrid.grid.dod, "toggle", lang.hitch(this, function(row){
						this._onDodBeforeToggle(row);
					}));
				}, 10);
			}else{
				lang.mixin(this.activityListGrid.grid.dod, _GridDodFocusMixin);
				this.activityListGrid.grid.dod.initFocus();
				_onKeyDown(this.activityListGrid.grid);
				aspect.before(this.activityListGrid.grid.dod, "toggle", lang.hitch(this, function(row){
					this._onDodBeforeToggle(row);
				}));
			}
		},
		
		_onDodBeforeToggle: function(row){
			console.debug("activityList, _onDodBeforeToggle");
			var dodRow = row.grid.dod._row(row);
			
			if(dodRow.dodLoaded == true && dodRow.dodShown == false && dodRow.dodNode && !(dodRow.dodNode.firstChild)){			
				dodRow.dodLoaded = false;
				dodRow.dodLoadingNode = null;
			}
			return row;
		},
		
		//Below function would be removed once applying new version of gridx which could fix the 'space' issue 
		//that 'SPACE' key can not be input into dod panel.
		_IE8SpaceIssueFix:function(){
			var grid = this.activityListGrid.grid;
														
			var c = grid.select.row._cnnts.pop();
			c.remove && c.remove();
			var t = grid.select.row
			var g = grid;
			grid.select.row.connect(grid, sniff('ff') < 4 ? 'onRowKeyUp' : 'onRowKeyPress', function(e){
				if((t.arg('triggerOnCell') || !e.columnId) && e.keyCode == keys.SPACE){
					var cell = g.cell(e.rowId, e.columnId);
					if(!(cell && cell.isEditing && cell.isEditing())){
						if(sniff('ie') < 9){
							//event.stop(e);
							t._select(e.rowId, g._isCopyEvent(e));
						}
					}
				}
			});
		},
        
        onGridRender: function(){
        	if(this.activityListGrid && this.activityListGrid.grid && this.activityListGrid.grid.bodyNode){
	        	var bn = this.activityListGrid.grid.bodyNode;
				if(sniff('ie') < 9 && bn && bn.childNodes && bn.childNodes.length){
					query('> .gridxLastRow', bn).removeClass('gridxLastRow');
					domClass.add(bn.lastChild, 'gridxLastRow');
				}
				try{this.activityListGrid.grid.vScroller.buffSize = 50;}catch(e){}
	        	try{this.activityListGrid.vScrollerBuffSize = 50;}catch(e){}
	        	try{delete this.activityListGrid.grid.vScroller;}catch(e){}
			}
        },
        
        resize: function(){
        	this.inherited(arguments);
        	this.activityListGrid && this.activityListGrid.resize && this.activityListGrid.resize();
        	try{this.activityListGrid.grid.vScroller.buffSize = 50;}catch(e){}
        	try{this.activityListGrid.vScrollerBuffSize = 50;}catch(e){}
        	try{delete this.activityListGrid.grid.vScroller;}catch(e){}
        },

		destroyActivityDijits: function(){
			//Destroy old activities;
			var activityDijitId;
			for(activityDijitId in this.activityDijits){
				if(this.activityDijits.hasOwnProperty(activityDijitId)){
					var activityDijit = this.activityDijits[activityDijitId];
					activityDijit.destroy();
				}
				delete this.activityDijits[activityDijitId];
			}
			this.activityDijits = {};
		},
        
        destroy: function(){

			this.destroyActivityDijits();
			this.activityListGrid.destroy();

        	this.inherited(arguments);
        }

	});
});