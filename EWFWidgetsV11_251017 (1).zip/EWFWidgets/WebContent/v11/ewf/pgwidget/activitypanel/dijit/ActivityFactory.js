define(["require", "dojo/_base/declare"],
		function(require, declare){
	
	var ActivityFactory = declare("v11.ewf.pgwidget.activitypanel.dijit.ActivityFactory", null, {
		
	});
	
	/*
     * 	activityObj: Use to get the activity instance's attributes;
     * 	activityToolbarAttachPoint: Use it to render activity toolbar by icm.widget.menu.Toolbar; 
     * 	gridRow: The opened grid row;
     * 	pageWidget: Use pageWidget(ActivityPanel)'s functions;
     */
	ActivityFactory.createActivity = function(activityObj, activityToolbarAttachPoint, gridRow, pageWidget, callback){
		var activityParams = {
				"activityObj": activityObj,
				"activityToolbarAttachPoint": activityToolbarAttachPoint,
				"gridRow": gridRow,
				"pageWidget": pageWidget
		};
		
		var activityName = activityObj.getActivityType();
		//activityName = activityName.slice( activityObj.getCaseType().solution.prefix.length + 1);
	
		var _activityClass = pageWidget.getActivityDigitCfg(activityName);
		
		require([_activityClass], function(activityClass){			
	    	var activityDijit = new activityClass(activityParams);
	    	callback(activityDijit, activityObj);
		});	
	};
	
	return ActivityFactory;
});