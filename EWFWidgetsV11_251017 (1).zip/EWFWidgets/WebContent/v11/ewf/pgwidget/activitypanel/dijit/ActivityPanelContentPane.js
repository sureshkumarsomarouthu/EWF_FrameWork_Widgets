define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"icm/base/_BaseWidget",
    "dojo/dom-style",
	"dojo/store/Memory",
	"dojo/text!./templates/ActivityPanelContentPane.html",
	"dojo/i18n!../../../nls/common",
	"v11/ewf/pgwidget/activitypanel/dijit/ActivityList",
	"idx/form/Select"
],function(declare, lang, _BaseWidget, domStyle,Memory, template, resources){
	
	return declare("v11.ewf.pgwidget.activitypanel.dijit.ActivityPanelContentPane", [_BaseWidget], {

		templateString: template,
        widgetsInTemplate: true,
        
        baseClass: "ewfActivityPanel",
        
        postMixInProperties: function(){
        	this.resourceBundle = resources.ActivityPanel;
    		this.inherited(arguments);
        },
        
        postCreate: function(){
        	this.inherited(arguments);
        	
        	/*
        	 * Init task filter store
        	 */
            this.filterArray = this.getCfgOfFilterArray();

            var filterTaskStore = new Memory({idProperty: "value", data: this.filterArray});
            this.filterTask.labelAttr = "label";
            this.filterTask.setStore(filterTaskStore, null);

            this.hideFilter();
        
        },
        
        hideFilter: function(){
            if(this.filterArray.length <= 1) {
            	//Modified by Purna for OTT V11 Upgrade BEGIN - Based on the expandAll flag only hide the filter label & Drop down OR hide all
            	if(this.widgetProperties.expandAll) {
            		domStyle.set(this.filterTaskLabel, "display", "none");
            		domStyle.set(this.filterTask.domNode, "display", "none");
            	} else {
                	domStyle.set(this.filterTaskArea, "display", "none");
                }
                //End change
            }
        },

        getDefaultFilterValue: function(){
//            if(this.filterArray.length == 0 || this.filterArray.length == 2){
//                return "myTasks";
//            } else if(this.filterArray.length == 1) {
//                return this.filterArray[0].value;
//            }
            return this.filterArray[0].value;
        },
        
        resize: function(){
        	this.inherited(arguments);
        	this.activityList.resize();
        },
        
        /*
         * The implement is in ewf.pgwidget.acititypanel.ActivityPanel
         */
        getActivitiesByFilter: function(){
        }
	});
});