define([
	"dojo/_base/declare",
	"dojo/_base/lang",
    "dojo/Stateful",
    "dojo/_base/array",
	"v11/ewf/pgwidget/activitypanel/dijit/ActivityPanelContentPane",
    "v11/ewf/pgwidget/activitypanel/dijit/ActivityConfig",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",
	"v11/ewf/util/Util",
	"icm/model/properties/controller/ControllerManager",
	"./_ActivityPanelCoordinationMixin",
	"dojo/dom-style"
],function(declare, lang, Stateful, array, ActivitypanelContentPane, ActivityConfig, BasePageWidget, BaseActionContext, Util, ControllerManager, _ActivityPanelCoordinationMixin, domStyle){
	
	return declare("v11.ewf.pgwidget.activitypanel.ActivityPanel", [ActivitypanelContentPane, BasePageWidget, BaseActionContext, _ActivityPanelCoordinationMixin], {
		
		runMode: true,
		_workItemController: null,
		
		getCfgOfRunMode: function(){
			//also can get the value based on configuration in Case Builder. 
			//true: RW, allow to edit; false: Read only for Properties  
			
			if(this.widgetProperties && this.widgetProperties.runMode === undefined){
				this.runMode = this.widgetProperties.runMode; 
			}else{
				this.runMode = this.widgetProperties.runMode; 
			}
			
			return this.runMode;
		},
		
		//Method added by TARA on 22.09.2016 for JAN QR --- Begin Change
		getCfgOfRunMode_AllActivities: function(){
			//A New property "runMode_AllActivities" is introduced as per requirement
			// If the property does not exists or no value is assigned to it, then the existing runMode value is considered.			
						  
			if(this.widgetProperties.runMode_AllActivities && this.widgetProperties.runMode_AllActivities != "NA"){
				return this.widgetProperties.runMode_AllActivities; 
			} 
			return "" + this.widgetProperties.runMode;				
		},
		//Method added by TARA on 22.09.2016 for JAN QR --- END
	
		getActivityDigitCfg: function(activityType){
		    //this is dev-level cfg. That would be a json cfg file for which digit is for a activity type. 
			//If there is no specific digit for a activity type, the default digit would be for this type;
			var activityClass;
			if(ActivityConfig.hasOwnProperty(activityType)){
				activityClass = ActivityConfig[activityType];
			}else{
				activityClass = ActivityConfig.Default;
			}
			return activityClass;
		},		
		
        getCfgOfFilterArray: function(){
            var filterArray = [];
          if(this.widgetProperties.MyTasks){
              filterArray.push({"value": "myTasks", "label": this.resourceBundle.myTasks});
          }
          if(this.widgetProperties.AllTasks){
                filterArray.push({"value": "allTasks", "label": this.resourceBundle.allTasks});
          }
          if(filterArray.length == 0){
              filterArray.push({"value": "myTasks", "label": this.resourceBundle.myTasks});
          }

          return filterArray;

        },
		
        /**
		 * Get the configuration of status for the activities which can be handled by current step.
		 * The status would be configured in the work detail page for each step from the page designer.
		 * The function would be customized for the solution if necessary.
		 */		
        getCfgOfStatus: function(){
        	var wdgProperties = this.widgetProperties;
        	var cfgOfStatus = [];
            var status;
        	for (status in wdgProperties) {
			    if (wdgProperties.hasOwnProperty(status) && wdgProperties[status] === true && status !== "runMode") {
			    	cfgOfStatus.push(status);
			    }
			}
        	return cfgOfStatus;
        },
        
        getActivitiesByFilter: function(){
        	var filterId = this.filterTask.getValue();
            if(filterId == ""){
                filterId = this.getDefaultFilterValue();
            }
			var status = [];
            if(filterId == "myTasks"){
				status = this.getCfgOfStatus();
			}	
        	this.activityList.renderGrid(status);
        },

        getActivityToolbarAttachPoint: function(){
        	//Modified by Purna as part of COA Jan QR changes - Add new logic to determine which toolbar to show based on myTasks/AllTasks
        	var filterId = this.filterTask.getValue();
        	if(filterId == ""){
                filterId = this.getDefaultFilterValue();
            }
            if(filterId == "allTasks"){
        		if(this.widgetProperties.useMyActivitiesToolbar && this.widgetProperties.useMyActivitiesToolbar != "NA") {
        			var useMyTasksToolbar = this.widgetProperties.useMyActivitiesToolbar;
        			if(useMyTasksToolbar == "false") {
        				return "activityActionToolbar_AllActivities";
        			} 
        		}
        	}
        	//End change
        	return "activityActionToolbar";
        },
		
		//Added by Purna for OTT V11 Upgrade changes - show or hide expand all based on page widget settings
		showOrHideExpandAll: function() {
			if(this.widgetProperties.expandAll) {
				domStyle.set(this.expandAll.domNode, "display", "");
				domStyle.set(this.collapseAll.domNode, "display", "");
				this.connect(this.expandAll, "onClick", "expandAllActivities");
				this.connect(this.collapseAll, "onClick", "collapseActivities");
				this.activityList.overrideDodShow();				
			} else {
				domStyle.set(this.expandAll.domNode, "display", "none");
				domStyle.set(this.collapseAll.domNode, "display", "none");
			}
		},
		//End method
		
		//Added by Purna for OTT V11 Upgrade changes - Fire the event to ActivityList for expand all
		expandAllActivities: function(evt) {
			this.expandAll.set("disabled", true);
			this.activityList.expandAllActivities(evt);
		},
		//End method
		
		//Added by Purna for OTT V11 Upgrade changes - Fire the event to ActivityList for collapse all
		collapseActivities: function(evt) {
			this.collapseAll.set("disabled", true);
			this.activityList.collapseActivities(evt);
		},
		//End method
		
		getCusPropsDef: function(){
			//Added by Purna -- Sending the CaseEditable in order to load the CaseType specific prefix constants configured in base constants. 
			return Util.getConstant("EWF_FieldAttributes", this.solution.prefix, this.caseEditable);
			//End
		}, 
		
		renderActivityList: function(){	
        	//Added by Purna for OTT V11 Upgrade changes - Enable/Disable Expand All/Collapse All buttons
        	this.showOrHideExpandAll();
        	//End change
        	
        	if(!this.getActivityHandler){
            	this.getActivityHandler = this.connect(this.filterTask, "onChange", "getActivitiesByFilter");
        	}
        	
			var curValue = this.filterTask.getValue();
			if(curValue == this.getDefaultFilterValue()){
				this.getActivitiesByFilter();
			}else{
				//By set filter value, the activity list will update based on filter value.
				this.filterTask.set("value", this.getDefaultFilterValue());
			}
		},
        
        
        handleCaseInfoReceived: function(){
        	
        },
        
		/**
		 * Handler for the icm.SendCaseInfo event. Properties widget will display the case properties in the widget UI.
		 * 
		 * @param payload
		 * <ul>
		 * <li> caseEditable: An {@link icm.model.CaseEditable} object that represents the case that is to be displayed.
		 * <li> coordination: An {@link icm.util.Coordination } object that is used internally by the widgets in the same page.
		 * </ul>
		 * <pre>
		 *  	Example: payload = { 
		 *			"caseEditable": caseEditable,
		 *			"coordination": coordination
		 *		};
		 * </pre>
		 */		
		handleICM_SendCaseInfoEvent: function(payload) {
			var editable = payload ? payload.caseEditable : null;
			var coordination = payload ? payload.coordination : null;
			
			this.caseEditable = editable;
			this.cleanActionContext("CaseEditable");
			this.setActionContext("CaseEditable", this.caseEditable);
			
			this.coordination = coordination;
			this.cleanActionContext("Coordination");
			this.setActionContext("Coordination", this.coordination);
			
			if(this.caseEditable){
				this.caseEditable.retrieveCachedAttributes(dojo.hitch(this,function(caseObj){
					this.renderActivityList();
				}));
				
			}
		},        
        
        /**
		 * Handler for the icm.SendWorkItem event.
		 * 
		 * @param payload
		 * <ul>
		 * <li> workItemEditable: An {@link icm.model.CaseEditable} object that represents the workitem that is to be displayed.
		 * <li> coordination: An {@link icm.util.Coordination} object that is used internally by the widgets in the same page.
		 * </ul>
		 * <pre>
		 *  Example: payload = { 
		 *				"workItemEditable": workItemEditable,
		 *				"coordination": coordination
		 *			};
		 * </pre>
		 */		
		handleICM_SendWorkItemEvent: function(payload) {
			
			var callback = lang.hitch(this, function(workitem){
				var caseItem = workitem.getCase();
				if(caseItem!=null){
					caseItem.retrieveCachedAttributes(dojo.hitch(this,function(caseObj){
						this.caseEditable =caseObj.createEditable();
						this.cleanActionContext("CaseEditable");
						this.setActionContext("CaseEditable", this.caseEditable);
						
						this.renderActivityList();
					}));
				}
			});
			
			/*
			 * Set context "WorkItemEditable"
			 */
			this.workItemEditable = payload ? payload.workItemEditable : null;			
			this.cleanActionContext("WorkItemEditable");
			this.setActionContext("WorkItemEditable", this.workItemEditable);
			
			if(this.workItemEditable){
				this._workItemController = ControllerManager.bind(this.workItemEditable);
			}
			
			/*
			 * Retrieve caseEditable from WorkItemEditable
			 */
			if(this.workItemEditable){
			   this.workItemEditable.retrieveCachedAttributes(lang.hitch(this,callback));
			}
			
			/*
			 * Set context "Coordination"
			 */
			this.coordination = payload ? payload.coordination : null;
			this.cleanActionContext("Coordination");
			this.setActionContext("Coordination", this.coordination);
			
			
			this.setCoordinationCfg(this.workItemEditable, this.coordination);
			
			/*
			 * Set context "UIState"
			 */
			var uiState = payload.UIState || null;
			if(!uiState){
				uiState = new Stateful();
			}
			
			
			var readonly = uiState.get("workItemReadOnly");
			if(readonly){
				 uiState.set("ActivityReadOnly", true);
			}
			
			this.cleanActionContext("UIState");
			this.setActionContext("UIState", uiState);			
		},
        
        handleCompleteWorkItem: function(payload){
        	
        },
        
        handleSaveWorkItem: function(payload){
        	
        },
        
        handleCloseWorkItem: function(payload){
        	
        },
        
        handleICM_UpdateFieldsEvent: function(payload){
        	this.activityList._handleICM_UpdateFieldsEvent(payload.changes);
        },
        
        destroy: function(){
        	console.debug("destroy activity panel");

			//clean context
        	this.cleanActionContext("ActivityEditable");
			this.cleanActionContext("WorkItemEditable");
			this.cleanActionContext("CaseEditable");
			this.cleanActionContext("Coordination");
			this.cleanActionContext("UIState");

        	this.inherited(arguments);
        }
		
	});
});