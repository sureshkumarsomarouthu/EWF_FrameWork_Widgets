define(["dojo/_base/declare",
        "ecm/widget/listView/modules/ViewDetail"],
		function(declare, ViewDetail){
	return declare("icm.cca.iwidgets.MP.ActivityPanelWidget.modules.ActivityListViewDetail", [ViewDetail], {
		
		
	});
});