/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2014
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([ "dojo/_base/declare", 
	"dojo/text!./templates/CaseToolbarContentPane.html", 
	"icm/pgwidget/casetoolbar/dijit/CaseToolbarContentPane",
	"dojo/dom-geometry",
	"idx/html",
	"dojo/dom-construct",
	"dojo/dom-class",
	"icm/widget/menu/Toolbar",
	"icm/widget/menu/MenuManager",
	"dojo/dom-style",
    "icm/util/Dom"
], 
function(declare, template, CaseToolbarContentPane, domGeom, idxHtml, domConstruct, domClass, toolBar, MenuManager, domStyle){

    return declare("v11.ewf.pgwidget.casetoolbar.EWFCaseToolbarContentPane", [CaseToolbarContentPane], {
        templateString: template,        
        widgetsInTemplate: true,
		
		buildToolbar : function(toolbarAttachPoint){
            var invalidCtx = [];
			var destroyExisting = false;
			
			if (this.topToolbar){
				this.wrapTopToolbar.removeChild(this.topToolbar);
			    MenuManager.destroyMenu(this.topToolbar);
				this.topToolbar = null;
				destroyExisting = true;
			}
             
            this.topToolbar = new toolBar({
             	dojoAttachPoint: toolbarAttachPoint
            });
            //this.wrapTopToolbar.addChild(this.topToolbar);
                 
            // activate menu
            //this.topToolbar.startup();
			if(destroyExisting){
			    MenuManager.refreshMenus(this.id);
			}
        }, 
		
		renderUI: function(caseItem) {
			if(this.showCaseInfo){
	    		domStyle.set(this.caseToolbarCaseId, "display", "inline");
	    		domStyle.set(this.caseToolbarVBar0, "display", "inline");
	    		domStyle.set(this.caseToolbarLastModifiedDateLabel, "display", "inline");
	    		domStyle.set(this.caseToolbarLastModifiedDateValue, "display", "inline");
	    		domStyle.set(this.caseToolbarCaseInfoNode, "display",  "block");
				
	    		// Adjust container spacing
	    		domClass.remove(this.caseToolbarContainer, "ewfwdgtCaseToolbarContentViewContainer2");
	    		domClass.add(this.caseToolbarContainer, "ewfwdgtCaseToolbarContentViewContainer");
	        }else{
	    		domStyle.set(this.caseToolbarCaseId, "display", "none");
	    		domStyle.set(this.caseToolbarVBar0, "display", "none");
	    		domStyle.set(this.caseToolbarLastModifiedDateLabel, "display", "none");
	    		domStyle.set(this.caseToolbarLastModifiedDateValue, "display", "none");
	            domStyle.set(this.caseToolbarCaseInfoNode, "display",  "block");
	            
			    domClass.remove(this.caseToolbarContainer, "ewfwdgtCaseToolbarContentViewContainer");
				domClass.add(this.caseToolbarContainer, "ewfwdgtCaseToolbarContentViewContainer2");
	            if(caseItem.isNewSplit()){
					domStyle.set(this.caseToolbarCaseId, "display", "inline");
				}
			}
		},
		
		updateCaseInfo: function(caseItem) {
			var showingCase =  null;
			if(caseItem.isNewSplit()){
				showingCase = caseItem.getSplitSource();
			}else{
				if(caseItem.getCase() !== undefined && caseItem.getCase() !== null){
					showingCase = caseItem.getCase();
				}
			}
			if(showingCase !== null){
				this.updateCaseTitle(showingCase);
				var lastModificationDateValue = showingCase.getDateLastModified();
				var lastModificationDateValueFormatted = icm.util.Util.getLocaleDate(lastModificationDateValue);
				this.caseToolbarLastModifiedDateLabel.innerHTML = this.resourceBundle["caseLastModDateLabel"]; // Fix 45022
				this.caseToolbarLastModifiedDateValue.innerHTML = lastModificationDateValueFormatted;
				if(caseItem.isNewSplit()) { // for split case
					this.caseToolbarCaseId.innerHTML = dojo.string.substitute(this.resourceBundle["originalCaseId"], [this.caseToolbarCaseId.innerHTML]);
				}
				
				var caseToolbarCaseIdDIV = domGeom.position(this.caseToolbarCaseId,true);	
				var caseToolbarVBar0Div = domGeom.position(this.caseToolbarVBar0,true);	
				var caseToolbarLastModifiedDateLabelDiv = domGeom.position(this.caseToolbarLastModifiedDateLabel,true);	
				var caseToolbarLastModifiedDateValueDiv = domGeom.position(this.caseToolbarLastModifiedDateValue,true);
				var caseDetailsWidth = caseToolbarCaseIdDIV.w + caseToolbarVBar0Div.w + caseToolbarLastModifiedDateLabelDiv.w + caseToolbarLastModifiedDateValueDiv.w + 15;
				console.log('caseDetailsWidth:', caseDetailsWidth);
				domStyle.set(this.caseDetails, "width", caseDetailsWidth+"px");
								
				this.wrapTopToolbar.addChild(this.topToolbar);
				this.topToolbar.startup();
				domClass.remove(this.topToolbar.domNode, "toolbarContainer");
				domClass.add(this.topToolbar.domNode, "ewftoolbarContainer");
			}
		},
		
		destroy: function(){
			if(this.topToolbar){
				this.wrapTopToolbar.removeChild(this.topToolbar);
				MenuManager.destroyMenu(this.topToolbar);
				delete this.topToolbar;
			}
			this.inherited(arguments);
		}
    });
});
