/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2013
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
    "dojo/_base/declare",
	"dojo/_base/lang",
	"icm/widget/menu/Toolbar",
	"v11/ewf/pgwidget/casetoolbar/EWFCaseToolbarContentPane",	
	"icm/pgwidget/casetoolbar/CaseToolbar"  
], function(declare,lang,toolBar,contentPaneWidget,CaseToolbar){

	/** 
	 * Added by Tara - Customized Case tool bar to Remove Extra Spaces 
	 * @name v11.ewf.pgwidget.casetoolbar.EWFCaseToolbar
	 * @class Class that represents CaseToolbar widget
	 */
    return declare("v11.ewf.pgwidget.casetoolbar.EWFCaseToolbar", [contentPaneWidget, CaseToolbar], {
    	/** @lends v11.ewf.pgwidget.casetoolbar.EWFCaseToolbar.prototype */
    	toolbarAttachPoint: null,
    	
		constructor: function(){
			this.inherited(arguments);
        }
    });
});

