define([
	"dojo/_base/declare",
	"dojo/_base/lang",
    "dojo/_base/array",
    "dojo/dom-construct",
    "dijit/Dialog",
    "dijit/form/Button",
	"icm/base/Constants",
	"ecm/widget/dialog/MessageDialog",
	"ecm/widget/dialog/ConfirmationDialog",
	"v11/ewf/util/Util"
],function(declare, lang, array, domConstruct, Dialog, Button, constants, MessageDialog, ConfirmationDialog, Util){
	
	return declare("v11.ewf.pgwidget.activitypanel._SignatureProcessingCoordinationMixin", null, {
	
		setCoordinationCfg: function(editable, coordination){
			coordination.participate(Util.getConstant("EWF_CoordTopic").SIGNATUREPROCESSINGROUTEHANDLE, lang.hitch(this, this.signatureProcessingParticipating));
		},
		
		signatureProcessingParticipating: function(context, complete, abort){
			var valueToSaveToCase = this.singleAndJointOrAccountsList.transformDataForSavingToCase();
			var finalValueToSaveToCase = valueToSaveToCase.concat(this.jointAndAndOthersAccountsList.transformDataForSavingToCase());
			var validationSucceeded = false, failureMsgsToShow = [], custVerification="", staffVerification="";
			var custVerificationFailureMsgs = [], staffVerificationFailureMsgs = [], accountVerificationFailureMsgs = [], anyDataValid = false;
			
			//Customer Verification
			//this.customerSignSelectedReasons, this.customerMatchedCB, this.customerUnMatchedCB
			var customerValidationSucceeded = false;
			if(this.customerMatchedCB.get('checked')){
				customerValidationSucceeded = true;
				custVerification="Matched";
				anyDataValid = true;
			}
			
			if(!customerValidationSucceeded){
				if(this.customerUnMatchedCB.get('checked')){
					custVerification="Unmatched";
					var reasons = this.customerSignSelectedReasons;
					array.forEach(reasons.split(','), lang.hitch(this, function(reason){
						if((reason+'').length>0){
							customerValidationSucceeded = true;
							anyDataValid = true;
						}
					}));
					if(!customerValidationSucceeded)
						custVerificationFailureMsgs.push('<b><u>Customer Level Verification</u></b>');
				}else{
					custVerificationFailureMsgs.push('<b><u>Customer Level Verification</u></b>');
				}
			}
			
			if(!this.customerMatchedCB.get('checked') && !this.customerUnMatchedCB.get('checked'))
				customerValidationSucceeded = true;
			
			//Staff Verification
			//this.staffSignSelectedReasons, this.staffMatchedCB, this.staffUnMatchedCB
			var staffValidationSucceeded = false;
			if(this.staffMatchedCB.get('checked')){
				staffValidationSucceeded = true;
				staffVerification="Matched";
				anyDataValid = true;
			}
			
			if(!staffValidationSucceeded){
				if(this.staffUnMatchedCB.get('checked')){
					staffVerification="Unmatched"
					var reasons = this.staffSignSelectedReasons;
					array.forEach(reasons.split(','), lang.hitch(this, function(reason){
						if((reason+'').length>0){
							staffValidationSucceeded = true;
							anyDataValid = true;
						}
					}));
					if(!staffValidationSucceeded)
						staffVerificationFailureMsgs.push('<b><u>Staff Signature Verification</u></b>');
				}else {
					staffVerificationFailureMsgs.push('<b><u>Staff Signature Verification</u></b>');
				}
			}
			
			if(!this.staffMatchedCB.get('checked') && !this.staffUnMatchedCB.get('checked'))
				staffValidationSucceeded = true;
			
			//Account Verification
			//this.singleAndJointOrAccountsList
			var accountVerificationSucceededForSingleAndJointOr = false;
			var noOfSingleAndJointOrAccountsPassedValidation = 0;
			var singleAndJointOrAccountsListData = this.singleAndJointOrAccountsList.transformDataForSavingToCase();
			if(singleAndJointOrAccountsListData.length > 0){
				accountVerificationSucceededForSingleAndJointOr = array.every(singleAndJointOrAccountsListData, lang.hitch(this, function(account){
					var localBoolean = false;
					var jsonObject = dojo.fromJson(account);
					if(jsonObject.hasOwnProperty("MatchResult")){
	        			if(jsonObject["MatchResult"] === "Matched"){
	        				localBoolean = true;
	        				noOfSingleAndJointOrAccountsPassedValidation++;
	        				anyDataValid = true;
	        			}
					}
					
					if(!localBoolean){
						if(jsonObject.hasOwnProperty("UnMatchResult")){
							var currentAccountNumber = jsonObject['AcctNo'] || '';
		        			if(jsonObject["UnMatchResult"] === "Matched"){
		        				if(jsonObject.hasOwnProperty("SPReasons") && lang.isArray(jsonObject['SPReasons'])){
		        					if((jsonObject['SPReasons']).length > 0){
		        						localBoolean = true;
		        						noOfSingleAndJointOrAccountsPassedValidation++;
		        						anyDataValid = true;
		        					} else{
		        						accountVerificationFailureMsgs.push('Please select reasons ' +  ((currentAccountNumber.length > 0) ? 'for account: <b><u>' + currentAccountNumber : '') + ' </u></b>');
		        					}
		        				}
		        			} else{
		        				if(accountVerificationFailureMsgs.length === 0)
		        					accountVerificationFailureMsgs.push('Please provide decision for any of the accounts shown in <b><u>Account-Level Verification section</u></b>');
		        			}
						}
					}
					
					//If none of the checkboxes are checked --> validation succeeded for that account
					if((jsonObject["MatchResult"] !== "Matched") && (jsonObject["UnMatchResult"] !== "Matched"))
						localBoolean = true;
					
					return localBoolean;
				}));
			} else
				accountVerificationSucceededForSingleAndJointOr = true;
			
			//For populating the failure Messages
			var failureMessagesForAllFailedAccounts = [];
			if(!accountVerificationSucceededForSingleAndJointOr){
				array.forEach(singleAndJointOrAccountsListData, function(account){
					var localBoolean = false;
					var jsonObject = dojo.fromJson(account);
					if(jsonObject.hasOwnProperty("MatchResult")){
	        			if(jsonObject["MatchResult"] === "Matched"){
	        				//Pass case. Do Nothing
	        				localBoolean = true;
	        			}
					}
					
					if(!localBoolean){
						if(jsonObject.hasOwnProperty("UnMatchResult")){
							var currentAccountNumber = jsonObject['AcctNo'] || '';
		        			if(jsonObject["UnMatchResult"] === "Matched"){
		        				if(jsonObject.hasOwnProperty("SPReasons") && lang.isArray(jsonObject['SPReasons'])){
		        					if((jsonObject['SPReasons']).length > 0){
		        						localBoolean = true;
		        					} else {
		        						failureMessagesForAllFailedAccounts.push('<b><u>'+currentAccountNumber+' </u></b>');
		        					}
		        				}
		        			}
						}
					}
				});
			}
			
			//Account Verification
			//this.jointAndAndOthersAccountsList
			var accountVerificationSucceededForJointAndAndOthers = false;
			var noOfJointAndAndOthersAccountsPassedValidation = 0;
			if(this.jointAndAndOthersAccountsList.transformDataForSavingToCase().length > 0){
				accountVerificationSucceededForJointAndAndOthers = array.every(this.jointAndAndOthersAccountsList.transformDataForSavingToCase(), lang.hitch(this, function(account){
					var jsonObject = dojo.fromJson(account);
					var localBoolean = false;
					if(jsonObject.hasOwnProperty("MatchResult")){
	        			if(jsonObject["MatchResult"] === "Matched"){
	        				localBoolean = true;
	        				noOfJointAndAndOthersAccountsPassedValidation++;
	        				anyDataValid = true;
	        			}
					}
					
					if(!localBoolean){
						if(jsonObject.hasOwnProperty("UnMatchResult")){
							var currentAccountNumber = jsonObject['AcctNo'] || '';
		        			if(jsonObject["UnMatchResult"] === "Matched"){
		        				if(jsonObject.hasOwnProperty("SPReasons") && lang.isArray(jsonObject['SPReasons'])){
		        					if((jsonObject['SPReasons']).length > 0){
		        						localBoolean = true;
		        						noOfJointAndAndOthersAccountsPassedValidation++;
		        						anyDataValid = true;
		        					} else{
		        						accountVerificationFailureMsgs.push('Please select reasons ' +  ((currentAccountNumber.length > 0) ? 'for account: <b><u>' + currentAccountNumber : '') + ' </u></b>');
		        					}
		        				}
		        			} else {
		        				if(accountVerificationFailureMsgs.length === 0)
		        					accountVerificationFailureMsgs.push('Please provide decision for any of the accounts shown in <b><u>Account-Level Verification </u></b>');
		        			}
						}
					}
					
					//If none of the checkboxes are checked --> validation succeeded for that account
					if((jsonObject["MatchResult"] !== "Matched") && (jsonObject["UnMatchResult"] !== "Matched"))
						localBoolean = true;
					
					return localBoolean;
				}));
			} else
				accountVerificationSucceededForJointAndAndOthers = true;
			
			
			//For populating the failure Messages
			if(!accountVerificationSucceededForJointAndAndOthers){
				array.forEach(this.jointAndAndOthersAccountsList.transformDataForSavingToCase(), function(account){
					var localBoolean = false;
					var jsonObject = dojo.fromJson(account);
					if(jsonObject.hasOwnProperty("MatchResult")){
	        			if(jsonObject["MatchResult"] === "Matched"){
	        				//Pass case. Do Nothing
	        				localBoolean = true;
	        			}
					}
					
					if(!localBoolean){
						if(jsonObject.hasOwnProperty("UnMatchResult")){
							var currentAccountNumber = jsonObject['AcctNo'] || '';
		        			if(jsonObject["UnMatchResult"] === "Matched"){
		        				if(jsonObject.hasOwnProperty("SPReasons") && lang.isArray(jsonObject['SPReasons'])){
		        					if((jsonObject['SPReasons']).length > 0){
		        						localBoolean = true;
		        					} else {
		        						failureMessagesForAllFailedAccounts.push('<b><u>'+currentAccountNumber+' </u></b>');
		        					}
		        				}
		        			}
						}
					}
				});
			}
			
			if((!this.customerMatchedCB.get('checked') && !this.customerUnMatchedCB.get('checked'))
					&& (!this.staffMatchedCB.get('checked') && !this.staffUnMatchedCB.get('checked'))
					&& !((noOfSingleAndJointOrAccountsPassedValidation + noOfJointAndAndOthersAccountsPassedValidation) >0)
					&& accountVerificationSucceededForSingleAndJointOr && accountVerificationSucceededForJointAndAndOthers){
				anyDataValid = false;
				if(!this.customerMatchedCB.get('checked') && !this.customerUnMatchedCB.get('checked'))
					customerValidationSucceeded = false;
				if(!this.staffMatchedCB.get('checked') && !this.staffUnMatchedCB.get('checked'))
					staffValidationSucceeded = false;
			}
			
			if(anyDataValid && customerValidationSucceeded && staffValidationSucceeded && (accountVerificationSucceededForSingleAndJointOr && accountVerificationSucceededForJointAndAndOthers)){
				var returnValueToSaveToCase=[];
				
				//Consider the Case when no accounts are retrieved from BWCIF (Error scenario)
				
				//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
				//var propertyNameToUpdate = Util.getConstant("EWF_SIGN_PROCESSING_FIELD", this.solutionPrefix);
				var propertyNameToUpdate = Util.getConstant("EWF_SIGN_PROCESSING_FIELD", this.solutionPrefix, this.workItemEditable);
				//End
				
				var valueOnWorkItem = this.workItemEditable.propertiesCollection[propertyNameToUpdate]['value'];
				array.forEach(valueOnWorkItem, lang.hitch(this, function(account){
					var jsonObject = dojo.fromJson(account);
					if(!(jsonObject['AcctNo'] && ((jsonObject['AcctNo']+'').length > 0))){
						jsonObject['CustSignReasons'] = this.customerSignSelectedReasons;
						jsonObject['StaffSignReasons'] = this.staffSignSelectedReasons;
						jsonObject['CustSignMatched'] = custVerification;
						jsonObject['StaffSignMatched'] = staffVerification;
						returnValueToSaveToCase.push(dojo.toJson(jsonObject));
					}
				}));
				
				
				array.forEach(finalValueToSaveToCase, lang.hitch(this, function(account, index){
					var jsonObject = dojo.fromJson(account);
					//Append the Customer and Staff reasons only to the first element in the array
					if(index === 0){
						jsonObject['CustSignReasons'] = this.customerSignSelectedReasons;
						jsonObject['StaffSignReasons'] = this.staffSignSelectedReasons;
						jsonObject['CustSignMatched'] = custVerification;
						jsonObject['StaffSignMatched'] = staffVerification;
					}
					returnValueToSaveToCase.push(dojo.toJson(jsonObject));
				}));
				
				this.workItemEditable.propertiesCollection[propertyNameToUpdate]['value'] = returnValueToSaveToCase;
				this.workItemEditable.propertiesCollection[propertyNameToUpdate]['dirty'] = true;
				complete();
			} else{
				//Or Else, Abort the work item
				//Please complete Staff Signature Verification and/or Customer Level Verification and/or Account Level Verification." 
				var dialog = new Dialog({ title: 'Incomplete' });
				var wrapper = domConstruct.create('div', {style:"align:center"});
				var label = domConstruct.create('label', {innerHTML: 'Please correct the below errors to complete all tasks with Signature Verification<br/><br/>'});
				wrapper.appendChild(label);
				
				var finalMsgToShow = "Please complete ";
				var anythingAdded = false;
				
				failureMsgsToShow = [];
				if(!customerValidationSucceeded){
					failureMsgsToShow = failureMsgsToShow.concat(custVerificationFailureMsgs);
					
					finalMsgToShow += "<b><u>Customer Level Verification</u></b>";
					
					anythingAdded = true;
				}
				
				if(!staffValidationSucceeded){
					failureMsgsToShow = failureMsgsToShow.concat(staffVerificationFailureMsgs);
					
					if(anythingAdded)
						finalMsgToShow += " and/or ";
					
					finalMsgToShow += "<b><u>Staff Signature Verification</u></b>";
					anythingAdded = true;
				}
				
				var accountLevelVerificationSucceeded = false;
				if((!((noOfSingleAndJointOrAccountsPassedValidation + noOfJointAndAndOthersAccountsPassedValidation)>0)) || (!accountVerificationSucceededForSingleAndJointOr || !accountVerificationSucceededForJointAndAndOthers)){
					if(failureMessagesForAllFailedAccounts.length > 0){
						failureMsgsToShow = failureMsgsToShow.concat(failureMessagesForAllFailedAccounts);
					}else{
						failureMsgsToShow = failureMsgsToShow.concat(accountVerificationFailureMsgs);
					}
					if(anythingAdded)
						finalMsgToShow += " and/or ";
					
					finalMsgToShow += "<b><u>Account Level Verification</u></b>";
				}else{
					accountLevelVerificationSucceeded = true;
				}
				
				//Defect 5563 starts here
				if(failureMessagesForAllFailedAccounts.length > 0){
					accountLevelVerificationSucceeded = false;
				}else{
					accountLevelVerificationSucceeded = true;
				}
				if((!this.customerMatchedCB.get('checked') && !this.customerUnMatchedCB.get('checked'))
						&& (!this.staffMatchedCB.get('checked') && !this.staffUnMatchedCB.get('checked'))
						&& !((noOfSingleAndJointOrAccountsPassedValidation + noOfJointAndAndOthersAccountsPassedValidation) >0)
						&& accountVerificationSucceededForSingleAndJointOr && accountVerificationSucceededForJointAndAndOthers
						&& !this.customerUnMatchedCB.get('checked') && !this.staffUnMatchedCB.get('checked')){
					//Case: When none of the Checkboxes are checked in all of UI
					finalMsgToShow = "Please complete <b><u>Staff Signature Verification</u></b> and/or <b><u>Customer Level Verification</u></b> and/or <b><u>Account Level Verification</u></b>";
					if(!this.customerMatchedCB.get('checked') && !this.customerUnMatchedCB.get('checked'))
						customerValidationSucceeded = false;
					if(!this.staffMatchedCB.get('checked') && !this.staffUnMatchedCB.get('checked'))
						staffValidationSucceeded = false;
					
				}else{
					//Case: When something is checked
					//Cases to consider:
					//staffValidationSucceeded (0), customerValidationSucceeded (0), accountLevelVerificationSucceeded (0)
					/*
					 *000 --> Already Handled
					 *001
					 *010
					 *011
					 *100
					 *101
					 *110
					 *111 --> No Need to Handle
					 */
					if(!staffValidationSucceeded && !customerValidationSucceeded && accountLevelVerificationSucceeded){
						finalMsgToShow = "Please select reason in the ";
						var andToBeAdded = false;
						if(!staffValidationSucceeded && this.staffUnMatchedCB.get('checked')){
							finalMsgToShow +=  "<b><u>Staff Signature Verification</u></b> section";
							andToBeAdded = true;
						}
						if(!customerValidationSucceeded && this.customerUnMatchedCB.get('checked')){
							if(andToBeAdded){
								finalMsgToShow +=  " and ";
							}
							finalMsgToShow +=  "<b><u>Customer Level Verification</u></b> section";
						}
					}else if(!staffValidationSucceeded && customerValidationSucceeded && !accountLevelVerificationSucceeded){
						finalMsgToShow = "Please select reason in the ";
						var andToBeAdded = false;
						if(!staffValidationSucceeded && this.staffUnMatchedCB.get('checked')){
							finalMsgToShow +=  "<b><u>Staff Signature Verification</u></b> section";
							andToBeAdded = true;
						}
						if(!accountLevelVerificationSucceeded){
							if(andToBeAdded){
								finalMsgToShow +=  " and ";
							}
							finalMsgToShow +=  "<b><u>Account Level Verification</u></b> section";
						}
					}else if(staffValidationSucceeded && !customerValidationSucceeded && !accountLevelVerificationSucceeded){
						finalMsgToShow = "Please select reason in the ";
						var andToBeAdded = false;
						if(!customerValidationSucceeded && this.customerUnMatchedCB.get('checked')){
							finalMsgToShow +=  "<b><u>Customer Level Verification</u></b> section";
							andToBeAdded = true;
						}
						if(!accountLevelVerificationSucceeded){
							if(andToBeAdded){
								finalMsgToShow +=  " and ";
							}
							finalMsgToShow +=  "<b><u>Account Level Verification</u></b> section";
						}
					}else if(!staffValidationSucceeded && !customerValidationSucceeded && !accountLevelVerificationSucceeded){
						finalMsgToShow = "Please select reason in the ";
						var andToBeAdded = false;
						if(!staffValidationSucceeded && this.staffUnMatchedCB.get('checked')){
							finalMsgToShow +=  "<b><u>Staff Signature Verification</u></b> section";
							andToBeAdded = true;
						}
						if(!customerValidationSucceeded && this.customerUnMatchedCB.get('checked')){
							if(andToBeAdded){
								finalMsgToShow +=  ", ";
							}
							finalMsgToShow +=  "<b><u>Customer Level Verification</u></b> section";
							andToBeAdded = true;
						}
						
						if(!accountLevelVerificationSucceeded){
							if(andToBeAdded){
								finalMsgToShow +=  " and ";
							}
							finalMsgToShow +=  "<b><u>Account Level Verification</u></b> section";
						}
					}else if(!staffValidationSucceeded && customerValidationSucceeded && accountLevelVerificationSucceeded){
						finalMsgToShow = "Please select reason in the ";
						if(!staffValidationSucceeded && this.staffUnMatchedCB.get('checked')){
							finalMsgToShow +=  "<b><u>Staff Signature Verification</u></b> section";
						}
					}else if(staffValidationSucceeded && !customerValidationSucceeded && accountLevelVerificationSucceeded){
						finalMsgToShow = "Please select reason in the ";
						if(!customerValidationSucceeded && this.customerUnMatchedCB.get('checked')){
							finalMsgToShow +=  "<b><u>Customer Level Verification</u></b> section";
						}
					}else if(staffValidationSucceeded && customerValidationSucceeded && !accountLevelVerificationSucceeded){
						finalMsgToShow = "Please select reasons for account(s): ";
						if(!accountLevelVerificationSucceeded){
							finalMsgToShow +=  failureMessagesForAllFailedAccounts;
						}
					}
				}
				
				//Defect 5563 ends here
				
				
				
				
				
				
				//array.forEach(failureMsgsToShow, function(failureMsg){
					//wrapper.appendChild(domConstruct.create('div', {style:"align:center; padding: 10px", innerHTML: failureMsg}));
					wrapper.appendChild(domConstruct.create('div', {style:"align:center; padding: 10px", innerHTML: finalMsgToShow}));
				//});
				var buttonDiv = domConstruct.create('div',{style: "float:right; display: block; margin-top: 10px; margin-right: 10px; margin-bottom: 10px;"});
				var continueButton = new Button({
					label : 'Continue',
					onClick : function (event) {
						dialog.destroy();
						abort({"message": "Aborted"});
					}
				}); 
				buttonDiv.appendChild(continueButton.domNode);
				wrapper.appendChild(buttonDiv);
				dialog.set("content", wrapper);
				dialog.show();
			}
		}
	});
});