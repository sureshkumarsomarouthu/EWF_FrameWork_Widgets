define([
	"dojo/_base/declare",
	"dojo/_base/lang",
    "dojo/Stateful",
    "dojo/_base/array",
	"v11/ewf/pgwidget/signatureprocessing/dijit/SignatureProcessingContentPane",
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",
	"v11/ewf/util/Util",
	"icm/model/properties/controller/ControllerManager",
	"./_SignatureProcessingCoordinationMixin",
	"dijit/TitlePane",
	"dijit/layout/ContentPane",
	"dijit/form/CheckBox"
],function(declare, lang, Stateful, array, SignatureProcessingContentPane, BasePageWidget, BaseActionContext, Util, ControllerManager, _SignatureProcessingCoordinationMixin){
	
	return declare("v11.ewf.pgwidget.signatureprocessing.SignatureProcessing", [SignatureProcessingContentPane, BasePageWidget, BaseActionContext, _SignatureProcessingCoordinationMixin], {
		
		_workItemController: null,
		
		handleCaseInfoReceived: function(){
		
		},
        
		/**
		 * Handler for the icm.SendWorkItem event.
		 * 
		 * @param payload
		 * <ul>
		 * <li> workItemEditable: An {@link icm.model.CaseEditable} object that represents the workitem that is to be displayed.
		 * <li> coordination: An {@link icm.util.Coordination} object that is used internally by the widgets in the same page.
		 * </ul>
		 * <pre>
		 *  Example: payload = { 
		 *				"workItemEditable": workItemEditable,
		 *				"coordination": coordination
		 *			};
		 * </pre>
		 */		
		handleICM_SendWorkItemEvent: function(payload){
			//console.log('handle work item --> SP ', Util.getConstant("EWF_SIGN_PROCESSING_FIELD", this.solutionPrefix));
			var callback = lang.hitch(this, function(workitem){
				//console.log('Workitem --> ', workitem);
				//var caseItem = workitem.getCase();
				this.solutionPrefix = workitem.getCaseType().solution.prefix;
				//if(caseItem!=null){
					//caseItem.retrieveCachedAttributes(lang.hitch(this, function(caseObj){
						//this.caseEditable = caseObj.createEditable();
						//this.cleanActionContext("CaseEditable");
						//this.setActionContext("CaseEditable", this.caseEditable);
						
						//Added by Purna -- Sending the Editable in order to load the CaseType specific prefix constants configured in base constants.
						//var propertyName = Util.getConstant("EWF_SIGN_PROCESSING_FIELD", this.solutionPrefix);
						var propertyName = Util.getConstant("EWF_SIGN_PROCESSING_FIELD", this.solutionPrefix, this.workItemEditable);
						//End
						
						//Fallback Option (if the property is not defined)
						if(!propertyName)
							propertyName = "EWS_ListOfAccounts";
						
						var propertyValueToRender = [];
						//var caseAttributesObject = caseObj['attributes'];
						propertyValueToRender = workitem['icmWorkItem']['attributes'][propertyName];
						
						//Filter the data to render in the Grid
						//this.singleAndJointOrAccountsList should show accounts with Signing Condition S, 1, 9
						// Accounts with Signing Condition S, 1, 9 --> Single
						// Accounts with any other signing condition other than blank --> Joint & Accounts
						// Accounts with no Signing Condition --> Others
						
						//AcctSignatureCondition --> Message from Component on BWCIF Call
						//AcctStatus --> Status of BWCIF call
						
						var statusOfBWCIFCall = {};
						
						var singleAccounts = array.filter(propertyValueToRender, lang.hitch(this, function(item){
							var jsonObject = dojo.fromJson(item);
							var returnDecision = false;
							if(jsonObject.hasOwnProperty('AcctNo')){
								if(jsonObject.hasOwnProperty('AcctSignatureCondition')){
									var signingConditionValue =  jsonObject['AcctSignatureCondition'] || '';
									if(signingConditionValue.length > 0){
										if((signingConditionValue === 'S') || (signingConditionValue === '1') || (signingConditionValue === '9')){
											returnDecision = true;
										}
									}
								}
							}else{
								lang.mixin(statusOfBWCIFCall, jsonObject);
							}
			        		return returnDecision;
						}));
						
						var jointAndAccounts = array.filter(propertyValueToRender, lang.hitch(this, function(item){
							var jsonObject = dojo.fromJson(item);
							var returnDecision = false;
							if(jsonObject.hasOwnProperty('AcctNo')){
								if(jsonObject.hasOwnProperty('AcctSignatureCondition')){
									var signingConditionValue =  jsonObject['AcctSignatureCondition'] || '';
									if(signingConditionValue.length > 0){
										if(!((signingConditionValue === 'S') || (signingConditionValue === '1') || (signingConditionValue === '9')))
											returnDecision = true;
									}
								}
							}else{
								lang.mixin(statusOfBWCIFCall, jsonObject);
							}
			        		return returnDecision;
						}));
						
						var otherAccounts = array.filter(propertyValueToRender, lang.hitch(this, function(item){
							var jsonObject = dojo.fromJson(item);
							var returnDecision = false;
							if(jsonObject.hasOwnProperty('AcctNo')){
								if(jsonObject.hasOwnProperty('AcctSignatureCondition')){
									var signingConditionValue =  jsonObject['AcctSignatureCondition'] || '';
									if(signingConditionValue.length === 0){
										returnDecision = true;
									}
								}
							}else{
								lang.mixin(statusOfBWCIFCall, jsonObject);
							}
			        		return returnDecision;
						}));
						
						this.resetState();
						
						//For Testing Purpose
						/*if(singleAccounts[0] || otherAccounts[0]){
							for(var i=0; i<500; i++){
								singleAccounts.push(singleAccounts[0] || otherAccounts[0]);
								otherAccounts.push(singleAccounts[0] || otherAccounts[0]);
							}
						}*/
						//For Testing Purpose
						
						//Check for the status here
						if(statusOfBWCIFCall.hasOwnProperty('AcctStatus') && (statusOfBWCIFCall['AcctStatus'] !== 'Success')){
							this.singleAndJointOrAccountsList.changeEmptyMessage(statusOfBWCIFCall['AcctSignatureCondition']);
							this.jointAndAndOthersAccountsList.changeEmptyMessage(statusOfBWCIFCall['AcctSignatureCondition']);
						}else if(statusOfBWCIFCall.hasOwnProperty('AcctStatus') && (statusOfBWCIFCall['AcctStatus'] === 'Success') 
								&& !statusOfBWCIFCall.hasOwnProperty('AcctNo')){
							this.singleAndJointOrAccountsList.changeEmptyMessage(statusOfBWCIFCall['AcctSignatureCondition']);
							this.jointAndAndOthersAccountsList.changeEmptyMessage(statusOfBWCIFCall['AcctSignatureCondition']);
						}else{
							this.singleAndJointOrAccountsList.changeEmptyMessage('No Accounts to display.');
							this.jointAndAndOthersAccountsList.changeEmptyMessage('No Accounts to display.');
						}

						//Render the Grid once the case properties are retrieved !!!
						setTimeout(lang.hitch(this, function(){
							this.singleAndJointOrAccountsList.renderGrid(singleAccounts);
						}), 100);
						setTimeout(lang.hitch(this, function(){
							this.jointAndAndOthersAccountsList.renderGrid(jointAndAccounts.concat(otherAccounts));
						}), 100);

						//Check/Un-Check the Staff Signature Verification Section
						
						
						//Check/Un-Check the Customer Signature Verification Section
						
					//}));
				//}
			});
			
			/*
			 * Set context "WorkItemEditable"
			 */
			this.workItemEditable = payload ? payload.workItemEditable : null;			
			this.cleanActionContext("WorkItemEditable");
			this.setActionContext("WorkItemEditable", this.workItemEditable);
			
			if(this.workItemEditable){
				this._workItemController = ControllerManager.bind(this.workItemEditable);
			}
			
			/*
			 * Retrieve caseEditable from WorkItemEditable
			 */
			if(this.workItemEditable){
			   this.workItemEditable.retrieveCachedAttributes(lang.hitch(this,callback));
			}
			
			/*
			 * Set context "Coordination"
			 */
			this.coordination = payload ? payload.coordination : null;
			this.cleanActionContext("Coordination");
			this.setActionContext("Coordination", this.coordination);
			
			
			this.setCoordinationCfg(this.workItemEditable, this.coordination);
			
			/*
			 * Set context "UIState"
			 */
			var uiState = payload.UIState || null;
			if(!uiState){
				uiState = new Stateful();
			}
			
			this.cleanActionContext("UIState");
			this.setActionContext("UIState", uiState);			
		},
        
        destroy: function(){
        	//clean context
        	this.cleanActionContext("WorkItemEditable");
			this.cleanActionContext("CaseEditable");
			this.cleanActionContext("Coordination");
			this.cleanActionContext("UIState");
        	this.inherited(arguments);
        }
	});
});