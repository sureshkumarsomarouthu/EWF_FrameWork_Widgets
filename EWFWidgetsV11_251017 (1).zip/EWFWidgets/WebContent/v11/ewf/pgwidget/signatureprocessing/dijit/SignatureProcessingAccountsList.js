define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/_base/sniff",
	"dojo/_base/event",
	"dojo/_base/query",
	"dojo/_base/connect",
	"dojo/on",
	"dojo/keys",
	"dojo/aspect",
	"dojo/dom-class",
	"icm/base/_BaseWidget",
	"icm/base/BaseActionContext",
	"dojo/text!./templates/SignatureProcessingAccountsList.html",
	"dojo/i18n!../../../nls/common",
	"dijit/focus",
	"gridx/Grid",
	"gridx/modules/RowHeader",
	"gridx/modules/Dod",
	"gridx/modules/CellWidget",
	"gridx/modules/ColumnLock",
	"gridx/modules/VirtualVScroller",
    "gridx/modules/Focus",
    "gridx/modules/ColumnResizer",
    "gridx/modules/Edit",
    "gridx/modules/SingleSort",
    "gridx/core/model/cache/Sync",
    "gridx/modules/ColumnResizer",
    "gridx/modules/move/Row",
    "gridx/modules/select/Row",
    "gridx/modules/extendedSelect/Row",
	"v11/ewf/pgwidget/activitypanel/dijit/_GridDodFocusMixin",
	"dojo/store/Memory",
	"dojo/store/util/QueryResults",
	"dojo/store/util/SimpleQueryEngine",
	"dijit/form/CheckBox",
	"gridx/modules/Body",
	"gridx/modules/select/Row",
	"gridx/modules/select/Column",
	"gridx/modules/select/Cell",
	"gridx/modules/IndirectSelect",
	"gridx/modules/Pagination",
	"gridx/modules/pagination/PaginationBar"
	//Commented by NaveenKK for the proper pagination display for Change of address functionality in 5.2.1 Upgrade.
	//"gridx/modules/pagination/Pagination",
	//"gridx/modules/pagination/PaginationBar"
],function(declare, lang, array, sniff, event, query, connect, on, keys, aspect, domClass, _BaseWidget, BaseActionContext, template, resources, 
		focusUtil, Grid, RowHeader, Dod, CellWidget, ColumnLock, VirtualVScroller, GFocus, ColumnResizer, GEdit, SingleSort, Sync, 
		ColumnResizer, MRow, SRow, ESRow, _GridDodFocusMixin, Memory, QueryResults, SimpleQueryEngine, Checkbox, Body){
	
	return declare("v11.ewf.pgwidget.signatureprocessing.dijit.SignatureProcessingAccountsList", [_BaseWidget], {

		templateString: template,
		
        widgetsInTemplate: true,
        
        valuesToShowInGridColumn: 1,
        
        baseClass: "ewfSignatureProcessingAccountsList",
        
        /*
         * args includes:
         * 			pageWidget: Use pageWidget(SignatureProcessingWidget)'s functions;
         */
        constructor: function(args){
        	lang.extend(Body, {
        		_onCellMouseOver:function(e) {
        			e && e.cellNode && domClass.toggle(e.cellNode, "gridxCellOver", e.type == "mouseover");
                }
        	});
        },
        
        postMixInProperties: function(){
        	this.resourceBundle = resources.SignatureProcessing;
        	this.inherited(arguments);
        },
        
        buildRendering: function(){
        	this.inherited(arguments);
        },
        
        postCreate: function(){
        	this.inherited(arguments);
        	this.accountsListGrid.connect(this.accountsListGrid.body, 'onRender', lang.hitch(this, "onGridRender"));
        },
        
        changeEmptyMessage: function(msg){
        	try{this.accountsListGrid.bodyEmptyInfo = msg;}catch(e){}
        	try{this.accountsListGrid.emptyNode.innerHTML = msg;}catch(e){}
        },
        
        setBodyEmptyInfoMessage: function(){
        	try{this.accountsListGrid.bodyEmptyInfo = this.accountsListGrid.bodyEmptyInfo;}catch(e){}
        	try{this.accountsListGrid.emptyNode.innerHTML = this.accountsListGrid.bodyEmptyInfo;}catch(e){}
        },
        
        /*
         * Update Accounts List.
         */
        renderGrid: function(jsonData){
        	//this.accountsListGrid.setStore(this.getGridSampleData());
        	this.accountsListGrid.setStore(this.transformDataToRenderTheGrid(jsonData));
        	//this.accountsListGrid.columnLock.lock(4);
        	this._A11yFix_ContentList_Gridx();//that could be removed once gridx is upgraded for bettor support on a11y;
        	if(this.pageWidget && this.pageWidget.resize && lang.isFunction(this.pageWidget.resize)){
			    this.pageWidget.resize();
			}
			/*this.accountsListGrid.edit.connect(this.accountsListGrid.edit, "onApply", function(cell, success){
				console.log('Cell --> ' + success + ' --> ', cell);
			    var item = cell.row.data();
			    var id = cell.row.id;
			    cell.grid.resize();
			});*/
        	try{
	        	if(this.accountsListGrid.rowCount() > 0)
	        		this.accountsListGrid.emptyNode.style.display='none';
	        	else
	        		this.setBodyEmptyInfoMessage();
	        }catch(e){}
        },
        
        onGridRender: function(){
        	var _this = this;
        	if(this.accountsListGrid && this.accountsListGrid && this.accountsListGrid.bodyNode){
	        	var bn = this.accountsListGrid.bodyNode;
	        	if(sniff('ie') < 9 && bn && bn.childNodes && bn.childNodes.length){
					query('> .gridxLastRow', bn).removeClass('gridxLastRow');
					domClass.add(bn.lastChild, 'gridxLastRow');
				}
	        	try{
		        	if(this.accountsListGrid.rowCount() > 0)
		        		this.accountsListGrid.emptyNode.style.display='none';
		        }catch(e){}
			}
        	setTimeout(lang.hitch(_this, function(){
        		this.pageWidget.resize();
        		//console.log('Grid Rendered successfully --> ', this.accountsListGrid.rowCount());
        		//Hide the Add Reasons Button later after the rows are rendered
    			for(var i=0; i < this.accountsListGrid.rowCount(); i++){
    				try{
    					if(this.accountsListGrid.row(i).rawData().unmatchedCB === 'Y'){
    						this.accountsListGrid.cell(i, 3).widget().addReasonsBtn.domNode.style.display = "";
    					} else {
    						this.accountsListGrid.cell(i, 3).widget().addReasonsBtn.domNode.style.display = "none";
    					}
    				}catch(e){}
    			}
    			try{
		        	if(this.accountsListGrid.rowCount() > 0)
		        		this.accountsListGrid.emptyNode.style.display='none';
		        	else
		        		this.setBodyEmptyInfoMessage();
		        }catch(e){}
        	})(), 200);
        },
        
        getGridLayout: function(){
        	var _this = this;
        	return [
        	        			{ "width":"17%", "sortable":true, "field":"AcctNo", "name":"Account No.",
        	        				formatter: function(cellObject){
        	        					var returnValue="<div><span style='font-size: 11px; font-weight: bold; color: #00649d'>" + cellObject.AcctNo + "</span></div><div></div>" + "<ul style='padding: 0px 0px 0px 8px; margin: 0px; font-size: 10px; vertical-align: top;'>";
        	        					//returnValue += "<li> Name 1: <b>" + cellObject.AcctName1 + "</b></li>";
        	        					//returnValue += "<li> Name 2: <b>" + cellObject.AcctName2 + "</b></li>";
        	        					returnValue += "</ul><br/>";
        	        					return returnValue;
	    			          		}
        	        				
        	        			},
      			          		{
      			          			"width":"6%", "sortable":false, "field":"matchedCB", "name":"Verified",
	      			          		widgetsInCell: true,
	    			          		decorator: function(){
	    			          			return "<div data-dojo-type='dijit/form/CheckBox' data-dojo-attach-point='matchedCBox'></div>";
	    			          		},
	    			          		setCellValue: function(gridData, storeData, cellWidget){
	    			          			cellWidget.matchedCBox && cellWidget.matchedCBox.reset && cellWidget.matchedCBox.reset();
										
    			          		    	if(cellWidget.matchedCBox._cnnt)
	    			          		    	cellWidget.matchedCBox._cnnt.remove();
	    			          			
	    			          		    if(gridData == 'Y')
	    			          		    	cellWidget.matchedCBox.set('checked', true);
	    			          		    else if(gridData == 'N')
	    			          				cellWidget.matchedCBox.set('checked', false);
	    			          		  	else
	    			          				cellWidget.matchedCBox.set('checked', false);
	    			          		    
	    			          		    cellWidget.matchedCBox._cnnt = on(cellWidget.matchedCBox, 'change', function(isChecked){
	    			          		    	var matchedCheckBox, unMatchedCheckBox, reasonsButton, reasonsHTMLDiv;
	    			          		    	try{matchedCheckBox = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 1).widget().matchedCBox;}catch(e){
	    			          		    		matchedCheckBox = cellWidget.matchedCBox;
	    			          		    	}
	    			          		    	
	    			          		    	var rawData = cellWidget.cell.row.rawData();
	    			          		    	rawData.matchedCB = isChecked ? "Y" : "N";
	    			          		    	
	    			          		    	if(isChecked){
	    			          		    		unMatchedCheckBox = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 2).widget().unmatchedCBox;
	    			          		    		unMatchedCheckBox.set("checked", false);
	    			          		    		rawData.reasons = ",,";
	    			          		    		
	    			          		    		reasonsButton = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().addReasonsBtn;
	    			          		    		reasonsButton.domNode.style.display = "none";
	    			          		    		
	    			          		    		reasonsHTMLDiv = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().selectedReasons;
	    			          		    		reasonsHTMLDiv.style.display="none";
	    			          		    	}
	    			          		    	
	    			          		    	cellWidget.cell.grid.store.put(rawData);
	    			          		    });
	    			          		}
      			          		},
      			          		{
      			          			"width":"7%", "sortable":false, "field":"unmatchedCB", "name":"Failed Verification",
	      			          		widgetsInCell: true,
	    			          		decorator: function(){
	    			          			return "<div data-dojo-type='dijit/form/CheckBox' data-dojo-attach-point='unmatchedCBox'></div>";
	    			          		},
	    			          		setCellValue: function(gridData, storeData, cellWidget){
	    			          			cellWidget.unmatchedCBox && cellWidget.unmatchedCBox.reset && cellWidget.unmatchedCBox.reset();
	    			          			
    			          		    	if(cellWidget.unmatchedCBox._cnnt)
	    			          		    	cellWidget.unmatchedCBox._cnnt.remove();
	    			          			
	    			          		    if(gridData == 'Y')
	    			          		    	cellWidget.unmatchedCBox.set('checked', true);
	    			          		    else if(gridData == 'N')
	    			          				cellWidget.unmatchedCBox.set('checked', false);
	    			          		    else
	    			          				cellWidget.unmatchedCBox.set('checked', false);
	    			          		    
	    			          		    cellWidget.unmatchedCBox._cnnt = on(cellWidget.unmatchedCBox, 'change', function(isChecked){
	    			          		    	
	    			          		    	var matchedCheckBox, unMatchedCheckBox, reasonsButton, reasonsHTMLDiv;
	    			          		    	
	    			          		    	unMatchedCheckBox = cellWidget.unmatchedCBox;
	    			          		    	
	    			          		    	var rawData = cellWidget.cell.row.rawData();
	    			          		    	rawData.unmatchedCB = isChecked ? "Y" : "N";
	    			          		    	
	    			          		    	reasonsHTMLDiv = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().selectedReasons;
    			          		    		reasonsButton = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().addReasonsBtn;
	    			          		    	
	    			          		    	if(isChecked){
	    			          		    		reasonsHTMLDiv.style.display="";
		    			                		try{reasonsButton.domNode.style.display="";}catch(e){}
	    			          		    	}else{
	    			          		    		reasonsHTMLDiv.style.display="none";
	    			          		    		try{reasonsButton.domNode.style.display="none";}catch(e){}
	    			          		    		
	    			          		    		rawData.reasons = ",,";
	    			          		    		reasonsHTMLDiv.innerHTML = '';
	    			          		    	}
		    			                	if(isChecked){
		    			                		matchedCheckBox = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 1).widget().matchedCBox;
		    			                		matchedCheckBox.set("checked", false);
		    			                	}
		    			                	
		    			                	cellWidget.cell.grid.store.put(rawData);
	    			          		    });
	    			          		}
      			          		},
      			          		{ "width":"15%", "sortable":false, "field":"reasons", "name":"Reasons",
	    			          		widgetsInCell: true,
	    			          		decorator: function(){
	    			          			return "<div data-dojo-attach-point='selectedReasons'></div>" 
	    			          			+ "<div class='spcompact' data-dojo-type='dijit/form/Button' data-dojo-attach-point='addReasonsBtn'>Select</div>" 
	    			          			+ "<div data-dojo-type='v11/ewf/dialog/signatureprocessingdialog/SignatureProcessingOptionsDialog' "
	    			          			+ "data-dojo-attach-point='reasonsDialogBox'></div>";
	    			          		},
	    			          		setCellValue: function(gridData, storeData, cellWidget){
	    			          			//console.log('setCellValue --> Column 3');
	    			          			cellWidget.reasonsDialogBox && cellWidget.reasonsDialogBox.reset && cellWidget.reasonsDialogBox.reset();

	    			          			//console.log('gridData ', gridData);
	    			          			//console.log('storeData ', storeData);
	    			          			var selectedReasonsCSV = gridData || ",";
	    			          			var valueToShow="<ul style='padding: 0px 0px 0px 8px; margin: 0px; font-size: xx-small; vertical-align: top;'>";
	    			          			var valsAdded = 0;
	    			          			var totalValuesSelected = 0;
	    			          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
	    			          				if(selReason && ((selReason+"").length > 1))
	    			          					totalValuesSelected++;
	    			          			});
	    			          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
	    			          				if(selReason && ((selReason+"").length > 1))
	    			          					valsAdded++;
	    			          				if(selReason && ((selReason+"").length > 0) && (valsAdded < 2)){
	    			          					valueToShow += "<li>" + selReason + "</li>";
	    			          				} else if(selReason && ((selReason+"").length > 0) && (valsAdded == 2)){
	    			          					if(valsAdded < totalValuesSelected)
	    			          						valueToShow += "<li>" + selReason + "<b>&nbsp;&nbsp;<span style='color: #00649d;'>more ...</span></b>" + "</li>";
	    			          					else
	    			          						valueToShow += "<li>" + selReason + "</li>";
	    			          				}
	    			          			});
	    			          			valueToShow += "</ul>";
	    			          			
    			                        cellWidget.selectedReasons.innerHTML = valueToShow;
	    			          			
    			                        if(cellWidget.addReasonsBtn._cnnt)
    			                        	cellWidget.addReasonsBtn._cnnt.remove();
    			                        
	    			          			cellWidget.addReasonsBtn._cnnt = on(cellWidget.addReasonsBtn, 'click', function(evt){
	    			          				
	    			          				var reasonsDialogBox = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().reasonsDialogBox;
	    			          				reasonsDialogBox.reset();
	    			          				reasonsDialogBox.set('selectedOptions', gridData);
	    			          				reasonsDialogBox.setSelectedOptions(gridData);
	    			          				reasonsDialogBox.createOptions();
	    			          				reasonsDialogBox.show();
	    			          				
	    			          			});
	    			          			
	    			          			if(cellWidget.reasonsDialogBox._okcnnt)
	    			          				cellWidget.reasonsDialogBox._okcnnt.remove();
	    			          			/*if(!cellWidget.reasonsDialogBox._okcnnt){*/
		    			          		    cellWidget.reasonsDialogBox._okcnnt = on(cellWidget.reasonsDialogBox.okButton, 'click', function(evt){
		    			          		    	
		    			          		    	var cellWidgetNew = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget();
		    			          		    	var reasonsButton = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().addReasonsBtn;
		    			          		    	var reasonsHTMLDiv = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().selectedReasons;
		    			          		    	var reasonsDialogBox = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 3).widget().reasonsDialogBox;
		    			          		    	
		    			          		    	var rawData = cellWidget.cell.row.rawData();
		    			                        rawData.reasons = reasonsDialogBox.get('selectedOptions');
		    			                        cellWidget.cell.grid.store.put(rawData);
		    			                        
		    			                        var selectedReasonsCSV = rawData.reasons || ",";
			    			          			var valueToShow="<ul style='padding: 0px 0px 0px 8px; margin: 0px; font-size: xx-small; vertical-align: top;'>";
			    			          			var valsAdded = 0;
			    			          			var totalValuesSelected = 0;
			    			          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
			    			          				if(selReason && ((selReason+"").length > 1))
			    			          					totalValuesSelected++;
			    			          			});
			    			          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
			    			          				if(selReason && ((selReason+"").length > 1))
			    			          					valsAdded++;
			    			          				if(selReason && ((selReason+"").length > 0) && (valsAdded < 2)){
			    			          					valueToShow += "<li>" + selReason + "</li>";
			    			          				} else if(selReason && ((selReason+"").length > 0) && (valsAdded == 2)){
			    			          					if(valsAdded < totalValuesSelected)
			    			          						valueToShow += "<li>" + selReason + "<b>&nbsp;&nbsp;<span style='color: #00649d;'>more ...</span></b>" + "</li>";
			    			          					else
			    			          						valueToShow += "<li>" + selReason + "</li>";
			    			          				}
			    			          			});
			    			          			valueToShow += "</ul>";
			    			          			
			    			          			reasonsHTMLDiv.innerHTML = valueToShow;
		    			                        reasonsDialogBox.hide();
		    			                        cellWidgetNew.domNode.style.display = '';
		    			                        reasonsHTMLDiv.style.display = '';
		    			                        reasonsButton.domNode.style.display = '';
		    			                        cellWidget.cell.grid.resize();
		    			                        /*setTimeout(function(){
		    			                        	cellWidget.addReasonsBtn.domNode.style.display="";
		    			                        }, 200);*/
		    			          		    });	
	    			          			/*}*/
		    			          		    try{
		    			          		    	var unMatchedCheckBox = cellWidget.cell.grid.cell(cellWidget.cell.row.index(), 2).widget().unmatchedCBox;
		    			          		    	if(unMatchedCheckBox.get('checked')){
		    			          		    		cellWidget.selectedReasons.style.display = '';
		    			          		    		cellWidget.addReasonsBtn.domNode.style.display = '';
		    			          		    	}
		    			          		    }catch(e){console.log('Error while enabling display of selected Reasons and Add reasons button. Probably during startup');}
	    			          		}
	    			          	},
	    			          	{ "width":"5%", "sortable":true, "field":"AcctSignatureCondition", "name":"Sign Cond" },
	    			          	{ "width":"5%", "sortable":true, "field":"AcctType", "name":"Ac Type" },
	    			          	{ "width":"4%", "sortable":true, "field":"AcctRelationShip", "name":"Ac Rel" },
	    			          	{ "width":"4%", "sortable":true, "field":"CCPIndicator", "name":"CCP Ind" },
	    			          	{ "width":"6%", "sortable":true, "field":"AcctStatus", "name":"Ac Status" },
	    			          	{ "width":"16%", "sortable":true, "field":"AcctName1", "name":"Ac Name 1" },
	    			          	{ "width":"15%", "sortable":true, "field":"AcctName2", "name":"Ac Name 2" }
    			         ];
        },
        
        transformDataToRenderTheGrid: function(inputJsonArray){
        	var returnGridData = { "identifier": "id", "label": "id", items: [] };
        	//console.log('Rendering grid ');
        	array.forEach(inputJsonArray, lang.hitch(this, function(item, index){
        		var jsonObject = dojo.fromJson(item);
        		
        		//Add id property
        		jsonObject.id=index;
        		
        		//Convert SPReasons in input JSON to reasons property
        		jsonObject.reasons = ",,";
        		if(jsonObject.hasOwnProperty("SPReasons") && lang.isArray(jsonObject['SPReasons'])){
        			 if((jsonObject['SPReasons']).length > 0){
        				 jsonObject.reasons = "";
        				 array.forEach(jsonObject['SPReasons'], function(reason){
        					 jsonObject.reasons += reason + ',';
        				 });
        			 }
        		}
        		
        		//Add/Convert MatchResult in inputJson to matchedCB
        		//&
        		//Add/Convert UnMatchResult in inputJson to unmatchedCB
        		jsonObject.matchedCB = "";
        		jsonObject.unmatchedCB = "";
        		if(jsonObject.hasOwnProperty("MatchResult")){
        			if(jsonObject["MatchResult"] === "Matched"){
        				jsonObject.matchedCB = "Y";
        			}else if(jsonObject["MatchResult"] === "Unmatched"){
        				jsonObject.matchedCB = "N";
        			}
        		}
        		
        		if(jsonObject.hasOwnProperty("UnMatchResult")){
        			if(jsonObject["UnMatchResult"] === "Matched"){
        				jsonObject.unmatchedCB = "Y";
        			}else if(jsonObject["UnMatchResult"] === "Unmatched"){
        				jsonObject.unmatchedCB = "N";
        			}
        		}
        		//if(index <= 5)
        			returnGridData.items.push(jsonObject);
        	}));
        	
        	var store = new Memory({
        		data: returnGridData.items
        	});
        	
        	return store;
        },
        
        
        transformDataForSavingToCase: function(){
        	var returnDataToSave = [];
        	var countOfRows = this.accountsListGrid.rowCount();
        	
        	for(var i=0; i<countOfRows; i++){
        		var jsonObjectOfRow = {};
        		var rowData = this.accountsListGrid.model.store.data[i];
        		var matchedChkBoxWidget = this.accountsListGrid.cell(i, 1).widget();
        		var unmatchedChkBoxWidget = this.accountsListGrid.cell(i, 2).widget();
        		
        		//matchedCBox, unmatchedCBox
        		jsonObjectOfRow['ToLink'] = rowData['ToLink'];
        		jsonObjectOfRow['AcctNo'] = rowData['AcctNo'];
        		jsonObjectOfRow['AcctType'] = rowData['AcctType'];
        		jsonObjectOfRow['AcctStatus'] = rowData['AcctStatus'];
        		jsonObjectOfRow['AcctSignatureCondition'] = rowData['AcctSignatureCondition'];
        		jsonObjectOfRow['AcctName1'] = rowData['AcctName1'];
        		jsonObjectOfRow['AcctName2'] = rowData['AcctName2'];
        		jsonObjectOfRow['CCPIndicator'] = rowData['CCPIndicator'];
        		jsonObjectOfRow['AcctRelationShip'] = rowData['AcctRelationShip'];
        		
        		//Convert reasons in row JSON to SPReasons property
        		jsonObjectOfRow['SPReasons'] = [];
        		if(rowData.hasOwnProperty("reasons")){
        			if((rowData['reasons']+'').length > 0){
        				array.forEach((rowData['reasons']+'').split(','), function(reasonItem){
        					if(reasonItem && (reasonItem.length>0))
        						(jsonObjectOfRow['SPReasons']).push(reasonItem);
        				});
        			}
        		}
        		
        		//Convert matchedCB in row JSON to MatchResult
        		if(rowData.hasOwnProperty("matchedCB")){
        			if(rowData['matchedCB'] === "Y"){
        				jsonObjectOfRow['MatchResult'] = "Matched";
        			}else if(rowData['matchedCB'] === "N"){
        				if(matchedChkBoxWidget && matchedChkBoxWidget.matchedCBox && (matchedChkBoxWidget.matchedCBox.get("checked") === true))
        					jsonObjectOfRow['MatchResult'] = "Unmatched";
        				else
        					jsonObjectOfRow['MatchResult'] = "";
        			}else{
        				jsonObjectOfRow['MatchResult'] = "";
        			}
        		}
        		
        		//Convert unmatchedCB in row JSON to MatchResult
        		if(rowData.hasOwnProperty("unmatchedCB")){
        			if(rowData['unmatchedCB'] === "Y"){
        				jsonObjectOfRow['UnMatchResult'] = "Matched";
        			}else if(rowData['unmatchedCB'] === "N"){
        				if(unmatchedChkBoxWidget && unmatchedChkBoxWidget.unmatchedCBox && (unmatchedChkBoxWidget.unmatchedCBox.get("checked") === true))
        					jsonObjectOfRow['UnMatchResult'] = "Unmatched";
        				else
        					jsonObjectOfRow['UnMatchResult'] = "";
        			}else{
        				jsonObjectOfRow['UnMatchResult'] = "";
        			}
        		}
        		returnDataToSave.push(dojo.toJson(jsonObjectOfRow));
        	}
        	return returnDataToSave;
        },
        getGridSampleData: function(){
        	var returnData = { "identifier": "id", "label": "id", items: [] };
        	returnData.items.push({
				"ToLink": "", //Not Required in Grid
				"AcctNo": "",
				"AcctType": "",
				"AcctStatus": "",
				"AcctSignatureCondition": "",
				"AcctName1": "",
				"AcctName2": "",
				"CCPIndicator": "",
				"AcctRelationShip": "",
				"SPReasons": "",
				"MatchResult": "",
				"UnMatchResult": "",
				"CustVerification": "",
				"CustSignReasons": "",
				"StaffVerification": "",
				"StaffSignReasons": ""
			});
        	var store = new Memory({
        		data: []
        	});
        	
        	return store;
        },
        
        _A11yFix_ContentList_Gridx:function(){
			//the below fix could not be the final solution to fix the issue that editable fields can't get focus.
			try{this.accountsListGrid.disconnect(this.accountsListGrid.gridConnections[0]);}catch(e){}
			
			//F4 pressing can make the dod get focus
			var _onKeyDown = lang.hitch(this, function(grid){
				this.connect(grid.bodyNode, 'onkeydown', function(e){
					if(e.keyCode === keys.F4){
						e.keyCode = 0;
						if(e.preventDefault){
							e.preventDefault();
						}else{
							e.returnValue = false;
						}
					}
				});
				this.connect(grid.body, 'onRender', function(){//fix the issue that vertial crollbar is not shown as expected
					setTimeout(function(){
						grid.resize();
					}, 10);
				});
			});
														
			this._IE8SpaceIssueFix();
		},
		
		//Below function would be removed once applying new version of gridx which could fix the 'space' issue 
		//that 'SPACE' key can not be input into dod panel.
		_IE8SpaceIssueFix:function(){
			var grid = this.accountsListGrid;
														
			var c = grid.select.row._cnnts.pop();
			c.remove && c.remove();
			var t = grid.select.row
			var g = grid;
			grid.select.row.connect(grid, sniff('ff') < 4 ? 'onRowKeyUp' : 'onRowKeyPress', function(e){
				if((t.arg('triggerOnCell') || !e.columnId) && e.keyCode == keys.SPACE){
					var cell = g.cell(e.rowId, e.columnId);
					if(!(cell && cell.isEditing && cell.isEditing())){
						if(sniff('ie') < 9){
							//event.stop(e);
							t._select(e.rowId, g._isCopyEvent(e));
						}
					}
				}
			});
		},
		
		resize: function(){
        	this.inherited(arguments);
        	this.accountsListGrid.resize();
        },

		destroy: function(){
			this.accountsListGrid.destroy();
        	this.inherited(arguments);
        },
        
        resetState: function(){
        	var store = new Memory({
        		data: []
        	});
        	this.accountsListGrid && this.accountsListGrid.setStore && this.accountsListGrid.setStore(store);
        }
	});
});