define([
	"dojo/_base/declare",
	"dojo/_base/connect",
	"dojo/_base/array",
	"dojo/on",
	"dojo/_base/lang",
	"icm/base/_BaseWidget",
	"dojo/text!./templates/SignatureProcessingContentPane.html",
	"dojo/i18n!../../../nls/common",
	"v11/ewf/pgwidget/signatureprocessing/dijit/SignatureProcessingAccountsList"
],function(declare, connect, array, on, lang, _BaseWidget, template, resources){
	
	return declare("v11.ewf.pgwidget.signatureprocessing.dijit.SignatureProcessingContentPane", [_BaseWidget], {

		templateString: template,
		
        widgetsInTemplate: true,
        
        baseClass: "ewfSignatureProcessingPanel",
        
        customerSignSelectedReasons: ",,",
        
        staffSignSelectedReasons: ",,",
        
        postMixInProperties: function(){
        	this.resourceBundle = resources.SignatureProcessing;
        	this.inherited(arguments);
        },
        
        postCreate: function(){
        	this.inherited(arguments);
        	connect.connect(this.singleAndJointOrTitlePane, 'toggle', lang.hitch(this, function(){
        		this.singleAndJointOrAccountsList.resize();
        	}));
        	connect.connect(this.jointAndAndOthersTitlePane, 'toggle', lang.hitch(this, function(){
        		this.jointAndAndOthersAccountsList.resize();
        	}));
        	
        	connect.connect(this.accLevelVerificationTitlePane, 'toggle', lang.hitch(this, function(){
        		this.singleAndJointOrTitlePane.resize();
        		this.jointAndAndOthersTitlePane.resize();
        	}));
        	
        	//staffReasonsBtn, staffMatchedCB, staffUnMatchedCB
        	on(this.staffMatchedCB, 'change', lang.hitch(this, function(isChecked){
        		if(isChecked){
        			if(this.staffUnMatchedCB.get("checked"))
						this.staffUnMatchedCB.set("checked", false);
        			
        			if(!this.staffReasonsBtn.get("disabled"))
            			this.staffReasonsBtn.set('disabled', true);
        			
        			this.staffSignSelectedReasons=",,";
        			this.staffSelectedReasons.innerHTML="";
        		}
        	}));
        	
        	on(this.staffUnMatchedCB, 'change', lang.hitch(this, function(isChecked){
        		if(isChecked){
        			if(this.staffMatchedCB.get("checked"))
						this.staffMatchedCB.set("checked", false);
        			this.staffReasonsBtn.set('disabled', false);
        		}else{
        			if(!this.staffReasonsBtn.get("disabled"))
        				this.staffReasonsBtn.set('disabled', true);
        			this.staffSignSelectedReasons=",,";
        			this.staffSelectedReasons.innerHTML="";
        		}
        	}));
        	this.staffReasonsBtn.set('disabled', true);
        	
        	//customerReasonsBtn, customerMatchedCB, customerUnMatchedCB
        	on(this.customerMatchedCB, 'change', lang.hitch(this, function(isChecked){
        		if(isChecked){
        			if(this.customerUnMatchedCB.get("checked"))
						this.customerUnMatchedCB.set("checked", false);
        			
        			if(!this.customerReasonsBtn.get("disabled"))
            			this.customerReasonsBtn.set('disabled', true);
        			
        			this.customerSignSelectedReasons=",,";
        			this.customerSelectedReasons.innerHTML="";
        		}
        	}));
        	
        	on(this.customerUnMatchedCB, 'change', lang.hitch(this, function(isChecked){
        		if(isChecked){
        			if(this.customerMatchedCB.get("checked"))
						this.customerMatchedCB.set("checked", false);
        			this.customerReasonsBtn.set('disabled', false);
        		}else{
        			if(!this.customerReasonsBtn.get("disabled"))
        				this.customerReasonsBtn.set('disabled', true);
        			this.customerSignSelectedReasons=",,";
        			this.customerSelectedReasons.innerHTML="";
        		}
        	}));
        	this.customerReasonsBtn.set('disabled', true);
        	
        	
        	//Connect the Staff Reasons Dialog to the Staff Reasons button
        	on(this.staffReasonsBtn, 'click', lang.hitch(this, function(evt){
        		this.staffReasonsDialogBox.set('selectedOptions', this.staffSignSelectedReasons);
        		this.staffReasonsDialogBox.setSelectedOptions(this.staffSignSelectedReasons);
        		this.staffReasonsDialogBox.createOptions();
        		this.staffReasonsDialogBox.show();
        	}));
        	
        	if(!this.staffReasonsDialogBox._okcnnt){
        		this.staffReasonsDialogBox._okcnnt = on(this.staffReasonsDialogBox.okButton, 'click', lang.hitch(this, function(evt){
        			this.staffSignSelectedReasons = this.staffReasonsDialogBox.get('selectedOptions');
        			var selectedReasonsCSV = this.staffSignSelectedReasons;
          			var valueToShow="<ul style='padding: 0px 0px 0px 8px; margin: 0px; font-size: xx-small; vertical-align: top;'>";
          			var valsAdded = 0;
          			var totalValuesSelected = 0;
          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
          				if(selReason && ((selReason+"").length > 1))
          					totalValuesSelected++;
          			});
          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
          				if(selReason && ((selReason+"").length > 1))
          					valsAdded++;
          				if(selReason && ((selReason+"").length > 0) && (valsAdded < 2)){
          					valueToShow += "<li>" + selReason + "</li>";
          				} else if(selReason && ((selReason+"").length > 0) && (valsAdded == 2)){
          					if(valsAdded < totalValuesSelected)
          						valueToShow += "<li>" + selReason + "<b>&nbsp;&nbsp;<span style='color: #00649d;'>more ...</span></b>" + "</li>";
          					else
          						valueToShow += "<li>" + selReason + "</li>";
          				}
          			});
          			valueToShow += "</ul>";
                    this.staffSelectedReasons.innerHTML = valueToShow;
                    this.staffReasonsDialogBox.hide();
        		}));
        	}
        	
        	//Connect the Customer Reasons Dialog to the Customer Reasons button
        	on(this.customerReasonsBtn, 'click', lang.hitch(this, function(evt){
        		this.customerReasonsDialogBox.set('selectedOptions', this.customerSignSelectedReasons);
        		this.customerReasonsDialogBox.setSelectedOptions(this.customerSignSelectedReasons);
        		this.customerReasonsDialogBox.createOptions();
        		this.customerReasonsDialogBox.show();
        	}));
        	
        	if(!this.customerReasonsDialogBox._okcnnt){
        		this.customerReasonsDialogBox._okcnnt = on(this.customerReasonsDialogBox.okButton, 'click', lang.hitch(this, function(evt){
        			this.customerSignSelectedReasons = this.customerReasonsDialogBox.get('selectedOptions');
        			var selectedReasonsCSV = this.customerSignSelectedReasons;
          			var valueToShow="<ul style='padding: 0px 0px 0px 8px; margin: 0px; font-size: xx-small; vertical-align: top;'>";
          			var valsAdded = 0;
          			var totalValuesSelected = 0;
          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
          				if(selReason && ((selReason+"").length > 1))
          					totalValuesSelected++;
          			});
          			array.forEach(selectedReasonsCSV.split(','), function(selReason){
          				if(selReason && ((selReason+"").length > 1))
          					valsAdded++;
          				if(selReason && ((selReason+"").length > 0) && (valsAdded < 2)){
          					valueToShow += "<li>" + selReason + "</li>";
          				} else if(selReason && ((selReason+"").length > 0) && (valsAdded == 2)){
          					if(valsAdded < totalValuesSelected)
          						valueToShow += "<li>" + selReason + "<b>&nbsp;&nbsp;<span style='color: #00649d;'>more ...</span></b>" + "</li>";
          					else
          						valueToShow += "<li>" + selReason + "</li>";
          				}
          			});
          			valueToShow += "</ul>";
                    this.customerSelectedReasons.innerHTML = valueToShow;
                    this.customerReasonsDialogBox.hide();
        		}));
        	}
        },
        
        resize: function(){
        	this.inherited(arguments);
        	this.singleAndJointOrAccountsList.resize();
        	this.jointAndAndOthersAccountsList.resize();
        },
        
        resetState: function(){
        	this.staffMatchedCB && this.staffMatchedCB.reset && this.staffMatchedCB.reset();
        	this.staffUnMatchedCB && this.staffUnMatchedCB.reset && this.staffUnMatchedCB.reset();
        	this.customerMatchedCB && this.customerMatchedCB.reset && this.customerMatchedCB.reset();
        	this.customerUnMatchedCB && this.customerUnMatchedCB.reset && this.customerUnMatchedCB.reset();
        	this.singleAndJointOrAccountsList && this.singleAndJointOrAccountsList.resetState && this.singleAndJointOrAccountsList.resetState();
        	this.jointAndAndOthersAccountsList && this.jointAndAndOthersAccountsList.resetState && this.jointAndAndOthersAccountsList.resetState();
        }
	});
});