define(["dojo/_base/declare", 
	"dojo/_base/lang",
	"v11/ewf/util/Util", 
	"ecm/LoggerMixin"], 
	function(declare, lang, Util, LoggerMixin){
    return declare("v11.ewf.pgwidget.imagecropping.ImageCroppingContentPaneEventListener", [LoggerMixin], {
	
		contentPane: null,
		
		constructor: function(contentPane){
			this.contentPane = contentPane;
		},
		
		initContentPane: function()	{
			this.contentPane.showContentNode();	
		},
		
		onHandleSendWorkItem: function(attributes){
			// Get docId value
			var constFile = Util.getConstant("EWF_PropertyName");
			if (!constFile) {
				return;
			}
			var docIdPropName = constFile.DOC_ID;
			if (!docIdPropName) {
				return;
			}
			var docId = attributes[docIdPropName];
			if (!docId) {
				return;
			}
			
			if (docId.indexOf('{') !== 0)
				docId = '{' + docId + '}';		

			// Get the type of the work item
			var workitemType = Util.getWorkItemType(attributes);
			
			// Get the coordinates value	
			var coordName, coordValue;	
			if (workitemType === Util.getConstant("EWF_WorkItemType").FIELD) {
				coordName = Util.getConstant("EWF_PropertyName").FIELD_COORDINATES;	
			} else if (workitemType === Util.getConstant("EWF_WorkItemType").SECTION) {
				coordName = Util.getConstant("EWF_PropertyName").SECTION_COORDINATES;				
			} else {
				coordName = Util.getConstant("EWF_PropertyName").SPECIAL_SECTION_COORDINATES;
			}				
			coordValue = attributes[coordName];
			
			var coordinates = '{' + coordValue + '}';							
						
			// Show the cropped image
			this.contentPane.showImage(docId, coordinates);
		}		
	
	});
});
