define([ "dojo/_base/declare", 
    "dojo/text!./templates/ImageCroppingContentPane.html", 
	"icm/base/_BaseWidget",
	"dojo/dom-geometry",
	"dojo/dom-style"
	], function(declare, template, _BaseWidget, domGeom, domStyle){
	return declare("v11.ewf.pgwidget.imagecropping.dijit.ImageCroppingContentPane", [_BaseWidget], {
		templateString: template,
		widgetsInTemplate: true,
			
		constructor: function(){
			
		},

		postCreate:	function(){
			this.inherited(arguments);
		},
		
		showImage:	function(docId, coordinates){
			var _this = this;
			// Remove the old image
			while(this.imageDiv.hasChildNodes()){
				this.imageDiv.removeChild(this.imageDiv.firstChild);
			}

			// Set the image URL
			// Expected URL is like
			//	'/ewf/web/image-cropping?docId={4F3D9546-E08C-40A6-8E8E-67346DB50D3B}&coord={210,520,1461,630}';			
			var imageUrl = '/v11/ewf/web/image-cropping?docId=' + docId + '&coord=' + coordinates;
			
			// Add the image to HTML document
			var imageNode = dojo.create("img", {"src": imageUrl});
			this.imageDiv.appendChild(imageNode);	
			
			//Auto resize the Image Container to half of the screen
			imageNode.onload = function(){
				var imgHeight = imageNode.height;
				var imgWidth = imageNode.width;
				var fullWindowCoords = domGeom.getContentBox(document.body);
				
				var finalCoordToSet = {h: 0, w: 0};
				finalCoordToSet.w = fullWindowCoords.w * 0.98;
				finalCoordToSet.h = fullWindowCoords.h * 0.40;
				
				if((imgWidth * finalCoordToSet.h) >= (imgHeight * finalCoordToSet.w)){
					if(imgWidth > finalCoordToSet.w){
						domStyle.set(imageNode, "width", "100%");
					}
				}else{
					if(imgHeight > finalCoordToSet.h){
						var newWidth = Math.floor(finalCoordToSet.h / imgHeight * imgWidth);
						domStyle.set(imageNode, "width", newWidth+"px");
					}
				}
				
				if(imgHeight < finalCoordToSet.h){
					finalCoordToSet.h = imgHeight + 10;
				}
				
				finalCoordToSet.h = finalCoordToSet.h + 10;
				
				if(imgWidth <= fullWindowCoords.w){
					finalCoordToSet.w = fullWindowCoords.w;
				}
				
				domGeom.setContentSize(_this.imageDiv, finalCoordToSet);
			}
		}	
	});
});
