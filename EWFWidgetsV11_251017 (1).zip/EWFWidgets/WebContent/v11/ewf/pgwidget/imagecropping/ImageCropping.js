define([ "dojo/_base/declare", 
	"icm/base/BasePageWidget",
	"icm/base/BaseActionContext",		
	"v11/ewf/pgwidget/imagecropping/ImageCroppingContentPaneEventListener",
	"v11/ewf/pgwidget/imagecropping/dijit/ImageCroppingContentPane"], function(declare, BasePageWidget, 
		BaseActionContext, eventHandler, contentPaneWidget){

    return declare("v11.ewf.pgwidget.imagecropping.ImageCropping", [contentPaneWidget, BasePageWidget, BaseActionContext], {
 
		contentPaneEventListener: null,

		postCreate: function(){
			this.inherited(arguments);
			this.contentPaneEventListener = new eventHandler(this);
			this.contentPaneEventListener.initContentPane();
		},
		
		handleICM_SendWorkItemEvent: function(payload){
			this.logEntry("handleICM_SendWorkItemEvent");
			if(!payload || !payload.workItemEditable) {
				this.logError("handleICM_SendWorkItemEvent -- payload: ", payload);
				return;
			} 
			
			// Get the work item object
			var workItem = payload.workItemEditable.getWorkItem();
			// Check if the work item attributes have been retrieved
			if (!workItem.getCaseTaskId()) {
				// retrieves the work item attributes
				workItem.retrieveCachedAttributes(dojo.hitch(this, function(workItem){
					this.contentPaneEventListener.onHandleSendWorkItem(workItem.attributes);
				}));
			}
			else {
				this.contentPaneEventListener.onHandleSendWorkItem(workItem.attributes);
			}						
			this.logExit("handleICM_SendWorkItemEvent");
		}						

	});
});
