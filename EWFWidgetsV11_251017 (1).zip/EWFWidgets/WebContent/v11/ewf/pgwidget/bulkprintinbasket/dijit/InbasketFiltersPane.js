define([
    "dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/dom-style",
	"icm/pgwidget/inbasket/dijit/InbasketFiltersPane"
], 
function(
	declare,
	lang,
	domStyle,	
	InbasketFiltersPane
){
	return declare("v11.ewf.pgwidget.bulkprintinbasket.dijit.InbasketFiltersPane", [InbasketFiltersPane], {			
		
        _handleChoiceList: function(attributes) {
			var caseProps = this.filterContainer.cp.caseProps;
			for(var i = 0; i < attributes.length; i++) {
				for(var j = 0; j < caseProps.length; j++) {
					if(attributes[i].field == this.filterContainer.cp.transactionTypePE && caseProps[j].id == this.filterContainer.cp.transactionTypeCE) {
						console.log("TransactionType : im in attributes[i] : ", attributes[i], "caseProps[j]:", caseProps[j]);
						attributes[i].choiceList = caseProps[j].choiceList;
						break;
					} else if(attributes[i].field == this.filterContainer.cp.processingTeamCE) {						
						var newChoicesList = {};
						newChoicesList.displayName = "EWF_LocationChoiceList";
						newChoicesList.choices = [];
						if(this.filterContainer.cp.processingTeams != null && this.filterContainer.cp.processingTeams != []) {
							dojo.forEach(this.filterContainer.cp.processingTeams, function(list, index){								
								var _options = {
									displayName: list.displayName,
									value: list.value
								};
								newChoicesList.choices.push(_options);
							});
							console.log("newChoicesList::", newChoicesList);
							attributes[i].choiceList = newChoicesList;
						}
						break;
					} else if(attributes[i].field == this.filterContainer.cp.coutryListCE) {						
						var newChoicesList = {};
						newChoicesList.displayName = "UserCountry";
						newChoicesList.choices = [];
						if(this.filterContainer.cp.coutryList != null && this.filterContainer.cp.coutryList != []) {
							dojo.forEach(this.filterContainer.cp.coutryList, function(list, index){								
								var _options = {
									displayName: list.displayName,
									value: list.value
								};
								newChoicesList.choices.push(_options);
							});
							console.log("newChoicesList::", newChoicesList);
							attributes[i].choiceList = newChoicesList;
						}
						break;
					} else if(attributes[i].operator == "equals" && attributes[i].field == caseProps[j].id && caseProps[j].choiceList != null) {						
						attributes[i].choiceList = caseProps[j].choiceList;
						break;
					}
				}
			}			
		}
   });
});
