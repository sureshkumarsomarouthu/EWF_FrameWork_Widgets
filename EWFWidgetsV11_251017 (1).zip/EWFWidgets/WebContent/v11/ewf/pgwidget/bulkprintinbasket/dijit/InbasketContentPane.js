define([
    "dojo/_base/declare", 
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/dom-construct",
	"dojo/dom-style",
	"dijit/form/Button",
	"dojo/json",
	"dojo/aspect",
	"dojo/request/iframe",
	"v11/ewf/widget/ContentList",
	"icm/widget/listView/modules/RowContextualMenu",
	"icm/widget/listView/modules/Toolbar",
	"gridx/modules/extendedSelect/Row",
	"gridx/modules/ColumnResizer",
	"gridx/modules/RowHeader",
	"gridx/modules/IndirectSelect",
	"gridx/modules/VirtualVScroller",
	"gridx/modules/move/Row",
	"v11/ewf/pgwidget/bulkprintinbasket/dijit/InbasketFilterContainer",
	"icm/pgwidget/inbasket/dijit/InbasketContentPane",
	"v11/ewf/util/Util",
	"v11/ewf/dialog/bulkPrintDialog/BulkPrintConfirmDialog",
	"dojox/timing/_base",
	"dojo/dom-class"
], function(declare, lang, array, construct, domStyle, Button, json, aspect, iframe, ContentList, RowContextualMenu, icmToolbar, exSelectRow, ColumnResizer, RowHeader, 
		IndirectSelect, VirtualVScroller, MoveRow, InbasketFilterContainer, InbasketContentPane, Util, ConfirmationDialog, timerBase, domClass){
	
	return declare("v11.ewf.pgwidget.bulkprintinbasket.dijit.InbasketContentPane", [InbasketContentPane], {
		maxItemsToDisplay: 100,
		docData : null,
		wobId : [],
		intervalTime: 120000,
		
		
		createInbasketTab: function(tabs) {			
			for(var i = 0; i < tabs.length; i++) {
				var cl = new ContentList(tabs[i]);
				cl.setContentListModules(this._getContentListModules());
				cl.setGridExtensionModules(this._getGridExtensionModules());
				cl.setCustomInbasketScope(this);
				this.tabContainer.addChild(cl);
				this.contentLists.push(cl);
			}
		},
		
		createContentList: function(index) {
			var cl = new ContentList(this.tabs[index]);
			cl.inbasketName = this.ecmInbaskets[index].name;
			cl.queueName = this.ecmInbaskets[index].queueName;
			cl.setGridExtensionModules(this._getContentListGridModules());
			cl.setContentListModules(this._getContentListModules());
			cl.setGridExtensionModules(this._getGridExtensionModules());
			aspect.after(cl, "onSelectItem", lang.hitch(this,this.onSelectItem),true);
			if(this.autoHeight) {
			    aspect.after(cl, "_createGrid", lang.hitch(this,this._createGrid),true);
			}
			this.tabContainer.addChild(cl);
			this.contentLists.push(cl);
        },
        
		_getGridExtensionModules: function(){
			var gridModules = [RowHeader, exSelectRow, IndirectSelect, 
								{
									moduleClass: VirtualVScroller,
									lazyTimeout: 200,
									lazy: false
								},
								//Pagination
			];
			return gridModules;
		},
		
		_getContentListModules: function() {
			var array = [];
			array.push ({
				moduleClass: RowContextualMenu,
				dojoAttachPoint: "inbasketContextualMenu"
			});
			array.push ({
				moduleClass: icmToolbar,
				dojoAttachPoint: "InbasketToolbar"
			});
			//array.push(Column);
			return array;
		},
		
		configureFilterArea: function(index) {
			if (this.filterContainers[index] && this.filterContainers[index].domNode) {
                this._filterContainer = this.filterContainers[index];
                domStyle.set(this._filterContainer.domNode, "display", "");
				if(this.filterPayload && this.filterPayload.filters) {
						this._filterContainer.filterPane.UpdateFilterValue(this.filterPayload,this.preFilterPayload,false);
						this._filterContainer.updateFilterSummary();
						this._preFilter();
				}
                this._renderContentList(index);
                this.setTimer();
            } else {
                this.solution.retrieveCaseTypes(lang.hitch(this,function(caseTypes){
                    this.caseTypes = caseTypes;
                    var model = {};
                    model.inbasket = this.selectedInbasket;
                    model.allowUserConfigureShowLockedWorkItem = this.widgetProperties.allowUserConfigureShowLockedWorkItem;
                    model.hideLockByOtherLabel = this.resourceBundle.hideLockByOtherLabel;
                    model.solutionProps = this.solutionProps;
                    model.caseTypes = this.caseTypes;
                    model.region = "top";
                    model.contentList = this.contentLists[index];
					model.cp = this;
                    this._filterContainer = new InbasketFilterContainer(model);
					if(this.filterPayload && this.filterPayload.filters) {
						this._filterContainer.filterPane.UpdateFilterValue(this.filterPayload,this.preFilterPayload,false);
						this._filterContainer.setStaticFilterSummaryText(this.filterPayload);
						this._preFilter();
						
					}
					
                    this._connectFilterQuery();
                    this.filterContainers[index] = this._filterContainer;
					this._renderContentList(index);
					this.setTimer();
                }));
                
				this.setDisplayPrintButton();
				this.setDisplayUnlockButton();
				this.addNote();
            }
            construct.place(this._filterContainer.domNode, this.contentLists[index].topContainer.domNode, "after");
		},
		
		_onHighlightChange: function(rowId, checkStatus)
		{
						
		},
		
		addNote: function() {
			var noteLabel = construct.create("label",{"innerHTML": " " + Util.getConstant("BULK_PRINT_NOTE", this.solution.prefix), "style": "color: red"});
			this._filterContainer.domNode.appendChild(noteLabel);
		},
		
		setTimer: function() {
			if(this.timer) {
				this.timer.stop();
			}
			this.timer = new dojox.timing.Timer(this.intervalTime);
			console.log('Timer started at Time :' + new Date());
			this.timer.onTick = lang.hitch(this, function() {
				if(this.printInProgress) {
					this.timer.stop();
				} else {
					var msg = 'Refresh to get latest items as the inactive interval reached ' + (this.intervalTime/60000) + ' minutes. <br/><br/>';
					this.showDialog(msg, 'Refresh');
					console.log('Timer onTick at Time :' + new Date());
				}
			});
			this.timer.start();
		},
		
		showDialog: function(message, dialogTitle) {
			if(this.dialog){
				try { this.dialog.destroy(); } catch(e){console.log(e);}
			}
			var dialog = new dijit.Dialog({ title: dialogTitle });
			var wrapper = dojo.create('div', {style:"align:center"});
			var label = dojo.create('label', {innerHTML: message});
			wrapper.appendChild(label);
			var buttonDiv = dojo.create('div',{style: "float:right; display: block; margin-top: 10px; margin-right: 10px; margin-bottom: 10px;"});
			var continueButton = new dijit.form.Button({
				label : 'Continue',
				onClick : lang.hitch(this, function(event){
					dialog.destroy();
					this.onRefresh();
					this.setTimer();
					this.wobId = [];
					this.printInProgress = false;
				})
			}); 
			buttonDiv.appendChild(continueButton.domNode);
			wrapper.appendChild(buttonDiv);
			dialog.set("content", wrapper);
			dialog.show();
			this.dialog = dialog;
		},
		
		setDisplayUnlockButton: function() {
			var callback = lang.hitch(this, "unlockWorkItems", "unlockCase");
			var buttonsDiv = construct.create("span",{style: "background: none repeat scroll 0 0 transparent; border: medium none; box-shadow: none;color: #105CB6; min-width: 0; padding: 5px 0 9px; width: auto;"});
			var button = new Button(
			{
				label: "Unlock",
				onClick: callback
			});
			buttonsDiv.appendChild(button.domNode);
			this._filterContainer.domNode.appendChild(buttonsDiv);
		},
	
		unlockWorkItems: function(unlockMethod, unlockWorkitems) {
			var _this =this;
			var inbasketIndex = [];
			try{
				var selectedWorkItems = '';
				if(unlockWorkitems && unlockWorkitems instanceof Array){
					selectedWorkItems = unlockWorkitems;
				}else{
					var grid = this.contentLists[this.selectedIndex].grid;
					var selectedItems = grid.select.row.getSelected();
					selectedItems = this.trimArrayOnMaxSize(selectedItems); //If the count of items is more than 100 remove last items
					dojo.forEach(selectedItems, function(item, index){
						var currentItemIndex = grid.row(item).index();
						inbasketIndex.push(currentItemIndex);
					});
					var sortedIndex = inbasketIndex.sort();
					
					if(_this.wobId.length > 0)
					{
						_this.wobId = [];
					}
					dojo.forEach(sortedIndex, function(item, index){
						var currentItem = grid.row(item).item();
						_this.wobId.push(currentItem.id);
					});
					selectedWorkItems =	this.wobId;
				}
				
				if(selectedWorkItems.length > 0)
				{
					var jsonData = dojo.toJson(selectedWorkItems);
					console.log('jsonData - >', jsonData);
					var params={
						QueueName: this.selectedInbasket.queueName,
						objectStore: this.solution.targetObjectStore.id,
						method : (this.selectedIndex == 0) ? unlockMethod : "unlockWorkItems",
						userId: this.solution.targetObjectStore.userId
					};
					var requestBody={
						WobNumber: jsonData,
					};
					this.doBulkPrintPluginServiceCall(params, requestBody, lang.hitch(this,function(result){
						console.log('result  ->', result);
						if(result.response == "FAILED"){
							var msg = 'Exception occurred during Unlock. Please contact admin with the below error details. <br/>' + result.Failure + '<br/><br/>';
							this.showDialog(msg, 'Error');
						}else if(result.FailedCases){
							var msg = "Failed to unlock the below cases. Please unlock manually or retry after some time.<br/><br/><b>";
							var splitIndex = 0;
							array.forEach(result.FailedCases, function(caseRefNum, index){
								msg = msg + caseRefNum;
								splitIndex = splitIndex + 1;
								if(index != (result.FailedCases.length - 1))
									msg = msg + ", ";
								else
									msg = msg + "</b>";
								if(splitIndex >= 4){
									msg = msg + "<br/>";
									splitIndex = 0
								}
							});
							this.showDialog(msg, 'Error');
						}else{
							_this.onRefresh();
							_this.wobId = [];
							_this.printInProgress = false;
							_this.setTimer();
						}
					}));
				}
				else
				{
					alert('Please Select at least one Case to Print');
				}
			}
			catch(e){
				console.log('Error in print Event Method - >',e);
			}
		},
		
		setTabDisplayName: function(name,count,index){
			//this.tabContainer.tablist.getChildren()[index].setLabel(value);
			var countWithSpace = '';
			if (count > this.maxItemsToDisplay)
			{
				countWithSpace = "&nbsp(100 of " + count + ")&nbsp";
			}
			else
			{
				countWithSpace = "&nbsp(" + count + ")&nbsp";
			}
			var htmlValue = '<span class="inbasketTabInLine inbasketTabLabel">'+name+'</span>'+
							'<span class="inbasketTabInLine inbasketTabCount">'+countWithSpace+'</span>';
			this.tabContainer.tablist.getChildren()[index].setLabel(htmlValue);
		},
		
		setDisplayPrintButton: function() {
			var callback = lang.hitch(this, "wodIdSort");
			var buttonsDiv = construct.create("span",{style: "background: none repeat scroll 0 0 transparent; border: medium none; box-shadow: none;color: #105CB6; min-width: 0; padding: 5px 0 9px; width: auto;"});
			this.printButton = new Button(
			{
				label: "Print Documents",
				onClick: callback
			});
			buttonsDiv.appendChild(this.printButton.domNode);
			this._filterContainer.domNode.appendChild(buttonsDiv);
		},
		
		wodIdSort: function() {
			this.printInProgress = true;	
			var _this = this;
			var inbasketIndex = [];
			var grid = this.contentLists[this.selectedIndex].grid;
			var selectedItems = grid.select.row.getSelected();
			selectedItems = this.trimArrayOnMaxSize(selectedItems);
			if(_this.wobId.length > 0)
			{
				_this.wobId = [];
			}
			 dojo.forEach(selectedItems, function(item, index){
				var currentItemIndex = grid.row(item).index();
				inbasketIndex.push(currentItemIndex);
				
			 });
			var sortedIndex = inbasketIndex.sort(function(a,b){return a - b});
			dojo.forEach(sortedIndex, function(item, index){
				var currentItem = grid.row(item).item();
				_this.wobId.push(currentItem.id);
			});
			_this.printEvent();
		},
			
		printEvent: function()
		{
			try{
				this.docData = '';
				//var selectedWorkItems = this.contentLists[this.selectedIndex].grid.select.row.getSelected();
				var selectedWorkItems = this.wobId;
				if(selectedWorkItems.length > 0)
				{
					var jsonData = dojo.toJson(selectedWorkItems);
					var isBulkReprint = (this.selectedIndex == 0) ? false : true;
					console.log('isBulkReprint:', isBulkReprint, 'jsonData - >', jsonData);
					//standByWidget.show();
					var params={
						QueueName: this.selectedInbasket.queueName,
						objectStore: this.solution.targetObjectStore.id,
						method : "GetDocumentIDS",
						userId: this.solution.targetObjectStore.userId,
						isBulkReprint: isBulkReprint,
						countOfItems: selectedWorkItems.length
					};
					var requestBody={
						WobNumber: jsonData,
					};
					this.doBulkPrintPluginServiceCall(params, requestBody, lang.hitch(this,function(result){
						if(result.InProcessCases || result.CompletedCases || result.LockedCases || result.LockFailedCases || result.response == "FAILED") {
							this.showSkipOrProceedDialog(result, jsonData);
						} else {
							this.sendPrintEventPayload(result, jsonData);
						}
					}));
				}
				else
				{
					alert('Please Select at least one Case to Print');
				}
			}
			catch(e){
				console.log('Error in print Event Method - >',e);
			}
		},
		
		sendPrintEventPayload: function(result, jsonData) {
			result.repositoryId = this.solution.targetObjectStore.repositoryId;
			result.objectStoreName = this.solution.targetObjectStore.id;
			result.userId = ecm.model.desktop.userId;
			result.WobNumber = jsonData;
			if(this.selectedIndex == 0){
				result.printLabel = "Printed";
			}else{
				result.printLabel = "RePrinted";
			}
			this.docData = result;
			this.onBroadcastEvent("icm.print.sendWorkItem", result);
		},
		
		trimArrayOnMaxSize: function(selectedItems){
			if(selectedItems.length <= this.maxItemsToDisplay)
				return selectedItems;
			
			var tempArr = [];
			for(var i=0; i<this.maxItemsToDisplay; i++){
				tempArr[i] = selectedItems[i];
			}
			return tempArr;
		},
		
		showSkipOrProceedDialog: function(result, jsonData) {
			if(result.response == "FAILED"){
				var msg = 'Exception occurred during Bulk Print. Please contact admin with the below error details. <br/>' + result.Failure + '<br/><br/>';
				this.showDialog(msg, 'Error');
				return;	
			}
			var callback = lang.hitch(this, function(){
				if(result.succesWobIDs && result.succesWobIDs instanceof Array && result.succesWobIDs.length > 0) {
					jsonData = dojo.toJson(result.succesWobIDs);
					this.sendPrintEventPayload(result, jsonData);
				}else{
					this.onRefresh();
					this.wobId = [];
					this.printInProgress = false;
					this.setTimer();
				}
			});
			var confirmDialog = new ConfirmationDialog({
				parent: this,
				result: result,
				onSkip: callback,
				onCancel: lang.hitch(this, function(){
					confirmDialog.hide();
					if(result.succesWobIDs && result.succesWobIDs instanceof Array && result.succesWobIDs.length > 0) {
						this.unlockWorkItems("unlockCase", result.succesWobIDs);
					}else{
						console.log('There are no success cases to unlock!', result);
						this.onRefresh();
						this.wobId = [];
						this.printInProgress = false;
						this.setTimer();
					}
				})
			});
			confirmDialog.show();
		},
		
		errorDialog: function(result) {
			var _this = this;
			var dialog = new dijit.Dialog({ title: 'Error' });
			var wrapper = dojo.create('div', {style:"align:center"});
			var label = dojo.create('label', {innerHTML: result + '<br/><br/>'});
			wrapper.appendChild(label);
			var buttonDiv = dojo.create('div',{style: "float:right; display: block; margin-top: 10px; margin-right: 10px; margin-bottom: 10px;"});
			var continueButton = new dijit.form.Button({
				label : 'Continue',
				onClick : function (event) {
					dialog.destroy();
				}
			}); 
			buttonDiv.appendChild(continueButton.domNode);
			wrapper.appendChild(buttonDiv);
			dialog.set("content", wrapper);
			dialog.show();
		},
		
		dispatchWorkItems: function(payload) {
			var _this = this;
			//var jsonData = dojo.toJson(payload);
			if(this.selectedIndex==0)
			{
				var params={
					QueueName: this.selectedInbasket.queueName,
					objectStore: this.solution.targetObjectStore.id,
					solutionPrefix: this.solution.prefix,
					method : "dispatchPrintedCases",
					userId: this.solution.targetObjectStore.userId
				};
				var requestBody={
					WobNumber: payload
				};
				this.doBulkPrintPluginServiceCall(params, requestBody, lang.hitch(this,function(result){
					_this.generateIndexForPrintedDocs();
					_this.onRefresh();
					_this.wobId = [];
					_this.printInProgress = false;
					_this.setTimer();
				}));
			}
			if(this.selectedIndex==1)
			{
				var params={
					QueueName: this.selectedInbasket.queueName,
					objectStore: this.solution.targetObjectStore.id,
					method : "dispatchReprintedCases",
					userId: this.solution.targetObjectStore.userId
				};
				var requestBody={
					WobNumber: payload
				};
				this.doBulkPrintPluginServiceCall(params, requestBody, lang.hitch(this,function(result){
					console.log('Final result ', result);
					_this.generateIndexForPrintedDocs();
					_this.onRefresh();
					_this.wobId = [];
					_this.printInProgress = false;
					_this.setTimer();
				}));
			}
		},
		
		generateIndexForPrintedDocs: function(){
			var _this = this;
			var wrapper = dojo.create('div', {style:"align:center", id:"reportsResult"});
			this.contentNode.appendChild(wrapper);
			_this.cancelDeffered=false;
			if(this._deferred) {
				this.cancelDeffered = true;
				this._deferred.cancel();
			}
			
			
			this._deferred = iframe("/ewfreports/bprest/bulkPrint",{
			
				data : {"reportData": dojo.toJson(this.docData)},
				method : "POST",
				handleAs: "text"
			});
			this._deferred.then(function(data){
					construct.place("<p>data:<code>"+JSON.stringify(data)+"</code></p>","reportsResult");
				},
				function(err){
					console.log("Entered into err",err);
					if(this.cancelDeffered) {
						this.cancelDeffered = false;
					} 
				}
			);
		},
		
		doBulkPrintPluginServiceCall: function(requestParams, postContent, callback) {
			console.log('Request Params ->', requestParams, 'Post Content ->', postContent);
			requestCompleteCallback = lang.hitch(this, function(response) {
				callback(response);
			});
			
			requestFailedCallback = lang.hitch(this, function(response) {
				callback(response);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFBulkPrintPluginService", "text/json",
				{
    	            requestParams: requestParams,
					requestBody: postContent,
    	            requestCompleteCallback: requestCompleteCallback,
    	            requestFailedCallback: requestFailedCallback					
				}
			);
			return request;
		},

		destroy: function(){
			this.inherited(arguments);
			console.log('inside destroy of timer');
			try {
				this.wobId = [];
				if(this.timer) {
					this.timer.stop();
				}
				this.timer = null;
			} catch(e){console.log(e);}
		},
		
		_eof: null

   });
});
