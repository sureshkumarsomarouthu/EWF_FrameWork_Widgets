define([
    "dojo/_base/declare",
    "dojo/_base/lang",
	"v11/ewf/pgwidget/bulkprintinbasket/dijit/InbasketFiltersPane",
	"icm/pgwidget/inbasket/dijit/InbasketFilterContainer",
], 
function(declare, lang, InbasketFiltersPane, InbasketFilterContainer){
	
	return declare("v11.ewf.pgwidget.bulkprintinbasket.dijit.InbasketFilterContainer", [InbasketFilterContainer], {
		
        _renderFilterPane: function(){
            this.filterPane = new InbasketFiltersPane(); //Instantiate EWF FiltersPane. Hence overridden
            var model = {};
            model.inbasket = this.inbasket;
            model.allowUserConfigureShowLockedWorkItem = this.allowUserConfigureShowLockedWorkItem;
            model.hideLockByOtherLabel = this.hideLockByOtherLabel;
            model.solutionProps = this.solutionProps;
            model.caseTypes = this.caseTypes;
			model.filterContainer = this;
            this.filterPane.render(model);
        }
   });
});
