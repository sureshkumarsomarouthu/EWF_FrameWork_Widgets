define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"icm/pgwidget/inbasket/Inbasket",
	"v11/ewf/pgwidget/bulkprintinbasket/dijit/InbasketContentPane",
	"v11/ewf/util/Util"
], function(declare, lang, array, Inbasket, ContentPaneWidget, Util) {
	return declare("v11.ewf.pgwidget.bulkprintinbasket.BulkPrintInbasket", [Inbasket, ContentPaneWidget], {
		caseRefNumber: 'EWS_CaseReferenceNumber',
		
		constructor : function(pgWidget) {
			this.pgWidget = pgWidget;
		},
		
		postCreate: function() {
			this.inherited(arguments);
			this.intUserID = "";
			this.retrieveIntUserId();			
		},
		
		_openInbasket: function(index){
            if(!this.ecmInbaskets || index == -1){
                return;
            }
            this.selectedInbasket = this.ecmInbaskets[index];
            this.selectInbasket();
            this.selectedIndex = index;
            this.setInbasketSortInfo(this.selectedInbasket);
            this.setPushInbasketActionContext();
            if(this.widgetProperties.inbasketModeOption == "pushInbasketModel" && this.selectedInbasket.queueType == "processQueue") {
                this.openPushInbasket(index);
            } else{
                this.openPullInbasket(index);
            }
            this._renderContentList(index);
        },
		
		openPullInbasket: function(index) {
			var isHideFilter = this._isHideFilter(this.selectedInbasket);
            this.setPushInbasketActionContext();
            this.solution.retrieveAttributeDefinitions(lang.hitch(this,function(properties, taskProperties){
                this.solutionProps = [];
				if(this.solution.caseTypes && this.solution.caseTypes[0]) {
					this.solution.caseTypes[0].retrieveAttributeDefinitions(lang.hitch(this, function(caseProps) {
						this.caseProps = caseProps;
						if (properties){
							var i;
							for (i=0;i<properties.length;i++){
								var prop = properties[i];
								this.solutionProps.push(prop);
							}
						}
                
						if (taskProperties){
							var i;
							for (i=0; i<taskProperties.length; i++){
								var taskProp = taskProperties[i];
								if (!this.solution.attributeDefinitionsById[taskProp.id]){
									this.solutionProps.push(taskProp);
								}
							}
						}
						if(!isHideFilter){
							this.selectedInbasket.retrieveFilterCriteria(lang.hitch(this, function() {
								if(this.selectedInbasket.filterClass !== null || 
									(this.widgetProperties !== null && this.widgetProperties.allowUserConfigureShowLockedWorkItem)) {
									this.configureFilterArea(index);
								} else {
									this._renderContentList(index);
								}
								this._renderContentList(index);
							}));
						} else{
							this.hideFilterArea(index);
							this._renderContentList(index);
						}
					}));
				} else {
					console.log('No casetypes exist:');
				}
				
            }), undefined, undefined, true);
		},
		
		retrieveCasePropsCompleted: function(caseProps) {			
			this.caseProps = caseProps;
		},
		
		retrieveIntUserId: function(callback, payload){
			var params = {
				userId: ecm.model.desktop.userId,
				method: "convertUserIdToInt",
				objectStore: this.solution.targetObjectStore.id
			};
			this.doBulkPrintPluginServiceCall(params, null, lang.hitch(this, function(result){
				if(result.intUserId){
					console.log('userId  ->', ecm.model.desktop.userId, ' intUserId: ', result.intUserId);
					this.intUserID = result.intUserId;
					if(callback && payload){
						callback(payload);
					}
				}
			}));
		},
		
		handleApplyFilter: function(payload){
			if(this.intUserID == ""){
				var callback = lang.hitch(this, "handleApplyFilter");
				this.retrieveIntUserId(callback, payload);
			}
			
			array.forEach(payload.dynamicFilters, lang.hitch(this, function(filters, index) {
				if(filters.queryFilter){
					var tmpFilter = "(" + filters.queryFilter + " AND (F_Locked=0 OR F_LockUser=" + this.intUserID + "))";
					payload.dynamicFilters[index].queryFilter = tmpFilter;
				}
			}));
			
            this.filterPayload = payload;
            if(this.ecmInbaskets){
                this.ecmInbasketReady = true;
                this._handleApplyFilter();
            }
		},
		
		handleReceivePrintMessage: function(payload) {
			console.log('handleReceivePrintMessage', payload);
			this.dispatchWorkItems(payload);
		},
		
		handleReceivePrintCancelMessage: function(payload) {
			this.unlockWorkItems("unlockCase");
		},
		
		getInbasketQueryFilter: function(inbasket){
            var uiQueryFilter = this.queryMap[inbasket.queueName][inbasket.name].uiQueryFilter;
            var queryFilter = this.queryMap[inbasket.queueName][inbasket.name].queryFilter;
			var filter = null;
            if(queryFilter){
				filter = queryFilter;
            }
            
            if(uiQueryFilter){
                filter = (filter !== null) ? (filter + " AND " + uiQueryFilter) : uiQueryFilter;
            }

            return filter;
        },
		
		publishSelectWorkItem: function(){
			var payload = {};
			var workItem = this.getActionContext("WorkItem");
			var icmWorkItemEditable = workItem[0].createEditable();
			payload.workItemEditable=icmWorkItemEditable;
			//this.onPublishEvent("icm.SelectWorkItem", payload); //Don't publish the event to open work item
		},

		publishSelectedWorkItems: function(payload) {
			var result = {};
			result.extraData = payload;
			var workItems = this.getActionContext("WorkItem");
			result.selectWorkItems = workItems;
			//this.onPublishEvent("icm.SendSelectWorkItems", result); //Don't publish the event for selected work items
		},
		
		_createGrid:  function() {	
			// Set autoHeight for grid
			var cl =  this.contentLists[this.selectedIndex];
			cl.grid.autoHeight = this.autoHeight;
			
			var resultSet = cl.getResultSet();
			// Resize to the minimum height if result set is empty
			var bEmpty = !resultSet || !resultSet.items || resultSet.items.length === 0;
			if( bEmpty ){
				this.resize();
				return;
			}

			// Connect to grid body for resizing grid height after rows are all filled	
			if (this.gridHandler)
				dojo.disconnect(this.gridHandler);
			this.gridHandler = dojo.connect(cl.grid.body, "onAfterRow", this, dojo.hitch(this, function(row){
				var cl =  this.contentLists[this.selectedIndex];
				var index = cl.grid.model.idToIndex(row.id);
				if (index === cl.getResultSet().items.length - 1) {
					this.resize();
				}
			}));
			//this.disableEvents();
		},
		
		disableEvents: function() {
			var gridConnections = this.contentLists[this.selectedIndex].grid.gridConnections;
			for ( var i in gridConnections) {
				this.contentLists[this.selectedIndex].grid.disconnect(gridConnections[i]);
			}
			console.log('events-->', this.contentLists[this.selectedIndex].grid.gridConnections);
		},
		
		getColumnDecorator: function(){
			var deco = {};
			deco[this.caseRefNumber] = lang.hitch(this, function(data, rowId, rowIndex){
				if(this.selectedIndex != -1)
				{
					var c1 = this.contentLists[this.selectedIndex];
					var item = c1.grid.row(rowId).item();
					var value = item.getDisplayValue(this.caseRefNumber);
					return value;
				}
			});
		},
		
	    _eoc_: null
	});
});