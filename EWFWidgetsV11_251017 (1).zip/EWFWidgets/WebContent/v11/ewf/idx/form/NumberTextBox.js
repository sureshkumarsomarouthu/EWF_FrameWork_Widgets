/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/has",
	"dojo/dom-style",
	"idx/form/NumberTextBox",
	"idx/widget/HoverHelpTooltip"
], function(declare, lang, has, domStyle, idxNumberTextBox, HoverHelpTooltip) {
	var iForm = lang.getObject("idx.oneui.form", true); // for backward compatibility with IDX 1.2
	var NumberTextBox = declare([idxNumberTextBox], {
		displayMessage: function(/*String*/ message, /*Boolean*/ force){
			if(message){
				if(!this.messageTooltip){
				 this.tooltipPosition[0]="above";
					this.messageTooltip = new HoverHelpTooltip({
						connectId: [this.ewficonNode],
						label: message,
						position: this.tooltipPosition,
						forceFocus: false
					});
				}else{
					this.messageTooltip.set("label", message);
				}
				if(this.focused || force){
					var node = domStyle.get(this.ewficonNode, "visibility") == "hidden" ? this.oneuiBaseNode : this.ewficonNode;
					this.messageTooltip.open(node);
				}
			}else{
				this.messageTooltip && this.messageTooltip.close();
			}
		}
	});
	return iForm.NumberTextBox = declare("v11.ewf.idx.form.NumberTextBox", NumberTextBox);
});
