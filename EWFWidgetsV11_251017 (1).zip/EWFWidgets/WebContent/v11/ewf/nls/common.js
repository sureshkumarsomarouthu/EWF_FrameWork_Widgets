define({
    root:
    ({
        "ActivityPanel": {
            "widgetDescription": "Show activities list.",
            "filterTaskId": "Show",
            "myTasks": "My Activities",
            "allTasks": "All Activities",
            "activityInsLabel": "Instructions:",
            "showAll": "Show All",
            "msg_abort":"the operation will be terminated because of the choice of users.",
            "text_reject":"Reject case by sending Email or manual(outside system)?",
            "label_manual":"Manual",
            "label_email":"Email",
            "title_reject":"Reject Case",
            "text_raiseException":"Exception Case - Send the current case to Exception Handling",
            "label_raiseException":"Raise Exception",
            "title_raiseException":"Raise Exception",
            "text_exception":"The case will be ended with exception handling",
            "label_exception":"Continue",
            "title_exception":"Exception Handling",
            "text_pend":"The case will be pended",
            "label_pend":"Pend",
            "title_pend":"Pending Case",
            "text_extensionProvider":"Please enter your extension number",
            "label_extensionProvider":"OK",
            "title_extensionProvider":"Enter Extension",
            "text_inComplete":"Please complete all necessary activities.",
            "label_inComplete":"InComplete",
            "label_inCompleteCancel":"OK",
            "title_inComplete":"InComplete",
            "text_failed":"The transaction has failed and will be cancelled and terminated",
            "label_failed":"Continue",
            "label_failedCancel":"Cancel",
            "title_failed":"Failed Case",
            "label_followUp":"Continue",
            "text_followUp":"Please review the lists of Follow Up items. If any Follow Up(EM) activities exist, they will be processed first.",
            "label_followUpCancel":"Cancel",
            "title_followUp":"Follow Up Options",
            "label_sendEmail":"Send",
            "label_sendEmailCancel":"Cancel",
            "title_sendEmail":"Email"
        },
        
        "SignatureProcessing": {
            "widgetDescription": "Show Accounts list.",
            "msg_abort":"the operation will be terminated because of the choice of users."
        },

        "Actions": {
            "title_ValidationFailure": "Invalid Data",
            "text_ValidationFailure": "The data provided is invalid.Please resolve the errors before completing this activity.",
            "label_Failure":"OK",
            "title_Review":"Reviewed Confirmation",
            "text_Review":"No changes have been detected. Have you reviewed the activity?",
            "label_Reviewed":"Reviewed",
            "title_Failure":"Validation Failed",
            "text_Failure": "Validation failed for this activity.Would you like to overrride or fail the activity?",
            "label_Failed": "Fail",
            "label_Override": "Override",
            "text_em_cb":"Would you like to email the business unit or send to Call Back?",
            "label_Email":"Email",
            "label_cb":"Call Back",
            "text_Email":"Would you like to email the business unit?",
            "text_cb":"Would you like to send to Call Back?",
            "title_followUpOptions":"Follow Up Options",
            "text_Reviewed":"Please provide a reason for reviewed.",
            "title_Reviewed":"Reviewed",
            "text_Rework":"Please provide a reason for rework.",
            "title_Rework":"Rework",
            "label_Rework":"Rework",
            "text_Denied":"Please provide a reason.All changes made to the activity will be saved.",
            "title_Denied":"Deny Activity",
            "label_Denied":"Deny",

            "text_bizInValid":"Validation failed for this activity. Please provide a reason. All changes made to this activity will be saved.",
            "title_bizInValid":"Validation Failed",
            "label_bizInValid":"Confirm",

            "title_sendEmail":"Email",
            
            "errDialogTitle": "Incomplete.",
            "errDialogText": "Invalid data detected in the fields, please correct!",
            "redactionFailedMsg": "Failed to apply Redactions on the signatures because of Internal Error. Please contact support team."
        },

        "DataEntry": {
            "instructionDefault": "Key in the data from the image above."
        },
		
		"SuggestionList": {
			"noQueryResult": "No rows are found to match the input.",
			"initSearch": "Enter at least ${0} characters to initiate search."
		},
		//added by rahul
		"DRWarnings" :{
			"label_inComplete_RTO":"Route to Orphan",
			"label_inCompleteCancel_RTO":"OK",
			"text_RTO": "<B>Orphan document is associated to a parent Case</B><P>Click on 'Complete' button to associate orphan document to parent case or remove the association before you click on 'Route to Orphan'</P>",
			"label_inComplete_RTOC":"Route to OC",
			"label_inCompleteCancel_RTOC":"OK",
			"text_RTOC": "<B>Orphan document is associated to a parent Case</B><P>Click on 'Complete' button to associate orphan document to parent case or remove the association before you click on 'Route to OC'</P>",
			"text_PendDocProcessingCenterRTOC": "<B>'Pend Doc Processing Center' field is blank</B><P>Please select a value before clicking 'Route to OC'</P>",
			"label_inComplete":"Incomplete Work",
			"label_inCompleteCancel":"OK",
			"text_Incomplete": "<P>Orphan case is not associated to any parent case</P><P>Please associate the orphan case to a parent case</P>",
			"text_reject":"Please provide Rejection Reason",
			"label_OK":"OK",
			"title_reject":"Reject",
			"text_RTDR":"<P>Please provide a reason for returning case to DR operator</P><P>Please provide the EWF Case Reference Number for the parent case</P>",
			"title_RTDR":"Return to DR",
			"msg_abort":"the operation will be terminated because of the choice of users."
		}

	})
});
