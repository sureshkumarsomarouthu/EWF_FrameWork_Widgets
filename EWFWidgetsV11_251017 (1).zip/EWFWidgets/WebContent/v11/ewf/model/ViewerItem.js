/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/_base/sniff",
	"dojox/html/entities",
	"idx/html",
	"ecm/model/_ModelObject",
	"ecm/model/ContentItem",
	"ecm/widget/viewer/model/ViewerItem"
], function(declare, lang, array, has, entities, idxHtml, _ModelObject, ContentItem, ViewerItem) {

	var ViewerItem = declare("v11.ewf.model.ViewerItem", [ViewerItem], {
		
	});

	ViewerItem.loadSecure = function(targetWindow, url, newWindow){
		var urlAndQuery = url.split("?");
		var uri = urlAndQuery[0];
		var queryString = (urlAndQuery.length > 1 ? urlAndQuery[1] : null);
		if (queryString == null) {
			targetWindow.location = url; // If there are no query parameters, just set it.  This will probably never happen.
		} else if(queryString.indexOf('useEWFViewer=true') > -1){
			//If the url is having a parameter to use EWF Viewer, set the url directly since we are not using any jsp.
			targetWindow.location = url;
		}else {
			var formHtml = "<html><head></head><body><form id=\"_loadSourceForm\" action=\"" + uri + "\" method=\"POST\">";
			var parameters = queryString.split("&");
			var n;

			for (n in parameters) {
				var parameter = parameters[n];
				var keyValue = parameter.split("=");
				if (keyValue.length > 0) {
					formHtml += ("<input type=\"hidden\" name=\"" + idxHtml.escapeHTML(keyValue[0]) + "\" value=\"");
					if (keyValue.length > 1) {
						formHtml += idxHtml.escapeHTML(decodeURIComponent(keyValue[1]));
					}

					formHtml += ("\"'>");
				}
			}

			formHtml += "</form></body></html>";

			if (newWindow === true || has("ie")) {
				targetWindow.document.write(formHtml);
			} else {
				targetWindow.document.documentElement.innerHTML = formHtml;
			}

			var form = targetWindow.document.getElementById("_loadSourceForm");
			if (form)
				form.submit();
		}
	};

	return ViewerItem;
});
