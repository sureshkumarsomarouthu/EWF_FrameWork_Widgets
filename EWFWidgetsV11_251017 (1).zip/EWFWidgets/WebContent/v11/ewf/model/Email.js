/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012, 2013 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/json",
	"ecm/model/_ModelObject",
    "icm/model/_Utils"
    ], function(declare, lang, JSON, _ModelObject, _Utils){

	/**
	 * Constructor
	 *
	 * @param properties
	 *            The properties for the model object. The properties can be any of the public fields as defined below
	 *            and on ecm.model._ModelObject.
	 * @name ecm.model.Email
	 * @class Represents a list of Email templates and template detail.
	 * @augments ecm.model._ModelObject
	 */
	return declare("v11.ewf.model.Email", [
		_ModelObject
	], {
		/** @lends ecm.model.Email.prototype */


		/**
		 * An instance of {@link ecm.model.Repository} for the repository containing or owning this activity list.
		 */
		repository: null,
		
		/**
         * The parent Case of these email templates.
         * @public
         */
		parentCase: null,	

		/**
		 * Retrieve the Email Templates.
		 *
		 * @param callback
		 *            A function that is called when the Email template list have been retrieved. 
		 */
		retrieveEmailTemplates: function(callback) {
			this.logEntry("retrieveEmailTemplates");
			
			requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.caseType = this.parentCase.getCaseType().id;
			requestParams.method = "listTemplate";
			
			requestCompleteCallback = lang.hitch(this, function(response) {
				this._retrieveEmailTemplatesCompleted(response, callback);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFEmailService", 
			"text/json",
			{
    	            requestParams: requestParams,
    	            requestCompleteCallback: requestCompleteCallback,
    	            requestFailedCallback: requestCompleteCallback					
			});
			this.logExit("retrieveEmailTemplates");
			return request;
		},

		_retrieveEmailTemplatesCompleted: function(response, callback) {
			this.logEntry("_retrieveEmailTemplatesCompleted");
			
			callback(response);
			
			this.logExit("_retrieveEmailTemplatesCompleted");
		},

		/**
		 * Retrieve the Email Template detail.
		 *
		 * @param callback
		 *            A function that is called when the Email template detail was retrieved. 
		 * @param templateName
		 *            Which template detail need to get.
		 * @param prefillValue
		 *            Boolean, Default is true; 
		 */
		retrieveEmailTemplateDetail: function(callback, templateName, prefillValue) {
			this.logEntry("retrieveEmailTemplateDetail");
			
			requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.caseId = this.parentCase.id;
			requestParams.template = templateName;
			requestParams.prefillValue = prefillValue;
			requestParams.method = "getTemplateData";
			
			requestCompleteCallback = lang.hitch(this, function(response) {
				this._retrieveEmailTemplateDetailCompleted(response, callback);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFEmailService", 
			"text/json",
			{
    	            requestParams: requestParams,
    	            requestCompleteCallback: requestCompleteCallback,
    	            requestFailedCallback: requestCompleteCallback	
			});
			
			this.logExit("retrieveEmailTemplateDetail");
			return request;
		},

		_retrieveEmailTemplateDetailCompleted: function(response, callback) {
			this.logEntry("_retrieveEmailTemplateDetailCompleted");

			callback(response);
			
			this.logExit("_retrieveEmailTemplateDetailCompleted");
		}
	});
});
