define([  "dojo/_base/declare",
                "dojo/_base/lang",
                "dojo/_base/json",
				"dojo/aspect",
		      	"ecm/model/_ModelObject",
		      	"ecm/model/Item",
		      	"ecm/model/Request",
		      	"icm/base/Constants",
                "icm/model/_Utils",
				"icm/model/PropertyEditable",
		      	"v11/ewf/model/Activity"], function(declare, lang, json, aspect, _ModelObject, Item, Request, IcmBaseConst, _Utils, PropertyEditable, EWFActivity) {

    /**
     * Constructs a ActivityEditable object.  A ActivityEditable object is typically constructed internally
     * by other model objects.
     *
     * @param properties
     *          The properties for the ActivityEditable object.  The properties can be any of the public fields as defined below
     *          and on ecm.model._ModelObject. 
     * @name ewf.model.ActivityEditable
     * @class Represents the scratchpad state editing a activity. 
     * @augments ecm.model._ModelObject
     */
	var ActivityEditable = declare("v11.ewf.model.ActivityEditable", [Item], {
	    /** @lends ewf.model.ActivityEditable.prototype */

        /**
         * @private
         */
		icmBaseConst: IcmBaseConst,

		/**
		 * An instance of {@link ecm.model.Repository} for the repository containing or owning this activity list.
		 */
		repository: null,
		
        /**
         *The last user who updated the activity.
         * @public
         */
		lastUserID: null,	

        /**
         *The last status of the activity.
         * @public
         */
		lastStatus: null,		

        /**
         *The last comment on the activity.
         * @public
         */
		lastComment: null,		

		 /**
         *The current comment on the activity.
         * @public
         */
		currentComment: null,		


        /**
         *The current status of the activity.
         * @public
         */
		currentStatus: null,
		
		/**
         *The instruction about how to operation on the activity.
         * @public
         */
		instruction: null,
		
		/**
		 * The Activity object corresponding to this Editable object. For a new activity, the object cannot be
         * obtained until the Editable object is saved.
		 * @public
		 */
		ewfActivity: null,
		
		 /**
         * The parent Case of this activity.
         * @public
         */
		parentCase: null,
		
        /**
         * The ActivityType object for this ActivityEditable.  This is only set for a ActivityEditable
         * that represents a new activity.
         * @public
         */
        activityType: null,

		/**
         * The collection of PropertyEditable objects that represent the activity attributes.
         * of this step.
         * @public
         */
        propertiesCollection: null,
        
        /**
         * Will be non-null if integrating with an external data service
         */
		externalDataIdentifier: undefined,
		
		/**
         *The contentItem representing the activity.
         * @public
         */
		contentItem: null,    
		
		/* New Properties added during COA start here */
		
		/**
         *The AP Rule Matrix Information.
         * @public
         */
		rulesMatrixInformation: null,
		
        /**
         * @private
         */		
		constructor: function() {
            // TODO: probably temporary variable.  Get prefix from Solution object somehow.
			
			this._ewfActivityRefreshHandle = null;
		},

		_initializeFromActivity: function(activity){
		    if (activity) {
				this.ewfActivity = activity;
				// Reinitialize when activity object is refreshed, could be as a result
			    // of changes caused by this object
			    // TODO: release this handle at some point
			    this._ewfActivityRefreshHandle = aspect.after(this.ewfActivity, "onRefresh", lang.hitch(this, this._onActivityRefresh), false);
			}
			
			
			if (!this.propertiesCollection){
			    this.propertiesCollection = {};
			}
			
			this._loadPropertiesParentContext();
			var otherParams = {};
			otherParams.modifiable = true;
			otherParams.parentContext = this._propertiesParentContext;
			//added by suresh as part of 5.2.1 upgrade we need to pass provide
          //  otherParams.provider = "F_CaseActivity";
            otherParams.provider = "F_CaseFolder";	
			//End change
			var attrId;
			for (attrId in this.ewfActivity.attributes) {
			    if (this.ewfActivity.attributes.hasOwnProperty(attrId) && this.ewfActivity.attributeDefinitions.hasOwnProperty(attrId)) {
			        var property;
			        otherParams.value = this.ewfActivity.attributes[attrId];
			        if (this.ewfActivity.originalAttributes.hasOwnProperty(attrId)) {
			            otherParams.originalValue = this.ewfActivity.originalAttributes[attrId];
					}
			        else if (otherParams.hasOwnProperty("originalValue")) {
			            delete otherParams.originalValue;
					}
					
			        if (this.propertiesCollection.hasOwnProperty(attrId)) {
			            property = this.propertiesCollection[attrId];
			            property._initializeFromParameters(this.ewfActivity.attributeDefinitions[attrId], otherParams, "afterSave");
			        }
			        else {
			            var attrDef = this.ewfActivity.attributeDefinitions[attrId];
			            var attrName = attrDef.name;
			            //Modified By Gopi As part of ICM 5.2.1 Upgrade
			            property = PropertyEditable._createProperty(attrId, attrName, attrDef, otherParams,this.repository);
			            this.propertiesCollection[property.id] = property;
			        }
					
					property["_propRef"] = this.ewfActivity.attributeDefinitions[attrId]["_propRef"] || "Activity";//indicating whether the property is from Case or Activity itself
					//Add three properties for highlighted properties
					property["logicRequired"] = this.ewfActivity.attributeDefinitions[attrId]["logicRequired"];
					property["updated"] = this.ewfActivity.attributeDefinitions[attrId]["updated"];
					property["failureType"] = this.ewfActivity.attributeDefinitions[attrId]["failureType"];
					
					
					//Modified by Purna for PLA - For multi value properties add the "failIndexes" and "failureTypes" arrays for index level highlighting
					if(this.ewfActivity.attributeDefinitions[attrId]["failIndexes"]){
						property["failIndexes"] = this.ewfActivity.attributeDefinitions[attrId]["failIndexes"];
					}
					if(this.ewfActivity.attributeDefinitions[attrId]["failureTypes"]){
						property["failureTypes"] = this.ewfActivity.attributeDefinitions[attrId]["failureTypes"];
					}
					if(this.ewfActivity.attributeDefinitions[attrId]["updatedIndexes"]){
						property["updatedIndexes"] = this.ewfActivity.attributeDefinitions[attrId]["updatedIndexes"];
					}
					//End Changes
					
			    }
			}
			
		},
		
		customizeProperties: function(attributes){
			var property;
			for (property in this.propertiesCollection){
				if(this.propertiesCollection.hasOwnProperty(property) 
						&& !this.propertiesCollection[property].system 
						&& !this.propertiesCollection[property].inherited 
						&& this.propertiesCollection[property].dataType !== "xs:attachment"){
					var propertyName = property;
					if(property.indexOf(this.getCaseType().solution.prefix) > -1) {
						propertyName = property.slice(this.getCaseType().solution.prefix.length + 1); //slice the solution prefix
					}
					
					lang.mixin(this.propertiesCollection[property], attributes[propertyName]);
				}
			}
		},
		
		_loadPropertiesParentContext: function() {
            if (!this._propertiesParentContext) {
                this._propertiesParentContext = {
                    externalDataSupported: this.ewfActivity.externalDataIdentifier || null
                };
            }
		},
		
		_onActivityRefresh: function() {
		    this._initializeFromActivity();
		    this.onRefresh();
		},
		
        /**
         * Called when the entire state of the object is refreshed, primarily
         * when the attributes have been updated based on updated information
         * from the server.
         */
		onRefresh: function() {
		},
		
		
		/**
		 * Called on creating a new activity 
		 * */
		_initializeProperties: function(properties, externalDataIdentifier){
			if (!this.propertiesCollection) {
			    this.propertiesCollection = {};
			}
			this.externalDataIdentifier = externalDataIdentifier;
            this._loadPropertiesParentContext();
			var otherParams = {};
			otherParams.modifiable = true;
			otherParams.parentContext = this._propertiesParentContext;
			//added by suresh as part of 5.2.1 upgrade we need to pass provide
           // otherParams.provider = "F_CaseActivity";
            otherParams.provider = "F_CaseFolder";		
			var i;
			for (i=0;i<properties.length;i++){
			    var property;
			    // TODO: this should only be called when initializing properties the first time
			    // so this test can probably be taken out
			    if (this.propertiesCollection.hasOwnProperty(properties[i].symbolicName)) {
			        property = this.propertiesCollection[properties[i].symbolicName];
			        property._initializeFromParameters(properties[i], otherParams, "afterSave");
			    }
			    else {
			    //added by suresh pass this.repository.id as a perameter for 5.2.1 upgrade
				    property = PropertyEditable._createProperty(properties[i].symbolicName, properties[i].displayName, properties[i], otherParams,this.repository);
    				this.propertiesCollection[property.id] = property;
				}
			}
		},
		
		/**
		 * Retrieves all attributes of the activity object and updates this ActivityEditable
		 * object with the new set of attributes.
		 * <p>
		 * This is a convenience method equivalent to calling retrieveAttributes() on the
		 * Activity object corresponding to this ActivityEditable.  This ActivityEditable is refreshed
		 * after the attributes have been retrieved by the Activity object. 
		 * <p> 
		 * If this ActivityEditable represents
		 * a new Activity that has not yet been saved, no action is taken and the callback is
		 * called immediately.
		 * <p>
		 * @param callback Callback function called with this ActivityEditable as an argument
		 *                 when the request completes.
		 */
		retrieveAttributes: function(callback) {
            var self = this;
		    this.ewfActivity.retrieveAttributes(function() {
		        if (callback) {
		            callback(self);
				}
		    });
		},

        /**
         * Ensures that the full set of attributes has been retrieved.  This is a convenience
         * method equivalent to calling retrieveCachedAttributes() on the Activity object corresponding
         * to this ActivityEditable.  This ActivityEditable is refreshed after the attributes
         * have been retrieved by the Activity object, if the full set needs to be retrieved.
         * <p>
         * If this ActivityEditable represents a new Activity that has not yet been saved, no
         * action is taken and the callback is called immediately.
         * <p>
         * @param callback Callback function called with this ActivityEditable as an argument
         *                 after the request completes.
         */		
		retrieveCachedAttributes: function(callback) {
            var self = this;
            this.ewfActivity.retrieveCachedAttributes(function() {
                 if (callback) {
                      callback(self);
                 }
            });
		},
		
		_createServiceParams: function() {
			var params = {};
			params.repositoryId =  this.repository.id;
			params.activityId = this.id;
			return params;
		},   
		
	   	_ActivityServiceCompleted: function(result, callback) {
    	    this.logEntry("_ActivityServiceCompleted");
			if (result) {
				var self = this;
        		self.ewfActivity._refreshFromResultProperties(result.properties, result.externalDataIdentifier);
        			// This editable will be updated when onRefresh called.
        		if (callback) {
        			callback(self);
				}
			}
			else if (callback) {
				callback(this);
			}
			this.currentComment = null;
		},
		
	    /**
	     * @deprecated Use ewfActivity property
	     * @private
	     */
	    getActivity: function() {
	    	return this.ewfActivity;
	    },

		/**
		 * Returns the last user id who updated the activity.
		 * 
		 * @return (string) last user id
		 * 
		 */
		getLastUserID: function() {
		    return this.lastUserID;
		},
		
		/**
		 * set the last user id who updated the activity.
		 * 
		 * @param (string) lastUserID
		 * 
		 */
		setLastUserID: function(lastUserID) {
		    this.lastUserID = lastUserID;
		},
		
		/**
		 * Returns the last status of the activity.
		 * 
		 * @return (string) last status
		 * 
		 */
		getLastStatus: function() {
		    return this.lastStatus;
		},
		
		/**
		 * set the status of the activity.
		 * 
		 * @param (string) lastStatus
		 * 
		 */
		setLastStatus: function(lastStatus) {
		    this.lastStatus = lastStatus;
		},
		
		/*New methods added during COA dev starts here */
		/**
		 * Returns the last user id who updated the activity.
		 * 
		 * @return (string) last user id
		 * 
		 */
		getRulesMatrixInformation: function() {
		    return this.rulesMatrixInformation;
		},
		
		/**
		 * set the last user id who updated the activity.
		 * 
		 * @param (string) lastUserID
		 * 
		 */
		setRulesMatrixInformation: function(rulesMatrixInformation) {
		    this.rulesMatrixInformation = rulesMatrixInformation;
		},
		/*New methods added during COA dev ends here */
		
		/**
		 * Returns the last comment on the activity.
		 * 
		 * @return (string) last comment
		 * 
		 */
		getLastComment: function() {
		    return this.lastComment;
		},
		
		/**
		 * set the last comment on the activity.
		 * 
		 * @param (string) lastComment
		 * 
		 */
		setLastComment: function(lastComment) {
		    this.lastComment = lastComment;
		},

		/**
		 * Returns the current comment on the activity.
		 * 
		 * @return (string) last comment
		 * 
		 */
		getCurrentComment: function() {
		    return this.currentComment;
		},
		
		/**
		 * set the current comment on the activity.
		 * 
		 * @param (string) currentComment
		 * 
		 */
		setCurrentComment: function(currentComment) {
		    this.currentComment = currentComment;
		},
		
		/**
		 * Returns the current Status of the activity.
		 * 
		 * @return (string) the current Status
		 * 
		 */
		getCurrentStatus: function() {
		    return this.currentStatus;
		},
		
		/**
		 * set the current Status of the activity.
		 * 
		 * @param (string) currentStatus
		 * 
		 */
		setCurrentStatus: function(currentStatus) {
		    var tmp = this.currentStatus;
		    this.currentStatus = currentStatus;
			this.lastStatus = tmp;
		},
		
        /**
         * @deprecated Use activityType property
         * @private
         */
	    getActivityType: function() {
	        return this.activityType;
	    },

        /**
         * Returns the Case object associated with this ActivityEditable.
         *
         * @return icm.model.Case object.
         */
	    getCase: function() {
	        var caseInst;
	        caseInst = this.ewfActivity.getCase();
	        return caseInst;
	    },

        /**
         * Returns the CaseType associated with this ActivityEditable.
         *
         * @return icm.model.CaseType object.
         */
	    getCaseType: function() {
	        var ct;
	        ct = this.ewfActivity.getCaseType();
	        return ct;
	    },
		
		/**
		 * Returns the id of the activity item
		 * 
		 * @return  (string) id
		 * 
		 */
		getActivityId: function() {
		    return this.ewfActivity.getActivityId();
		},
	    
		/**
		 * Returns the type of the activity
		 * 
		 * @return (string) The activity Type.
		 * 
		 */
		getActivityType: function() {
		    return this.activityType;
		},
		

        /**
         * Returns the activity name.
         *
         * @return (string) The activity name.
         */
        getActivityName: function() {
            var n = null;
            n = this.ewfActivity.getActivityName();
            
            return n;
        },
        
        /**
		 * Returns the System Message of the activity
		 * 
		 * @return (string) The System Message.
		 * 
		 */
		getSystemMessage: function() {
		    return this.ewfActivity.getSystemMessage();
		},
		
		/**
		 * Returns the System Message of the activity
		 * 
		 * @return (string) The System Message Name.
		 * 
		 */
		getSystemMessageName: function() {
		    return this.ewfActivity.getSystemMessageName();
		},

        /**
         * Returns the activity Id.  The activity Id will only be returned if this represents
         * an existing case.
         *
         * @return The activity id.
         */
        getActivityId: function() {
            var activityId = null;
            if (this.ewfActivity){
                activityId = this.ewfActivity.getActivityId();
			}
            return activityId;
        },

		/**
		 * @deprecated Use propertiesCollection member property.
		 * @private
		 */
		_getPropertiesCollection: function() {
			return this.propertiesCollection;
		},
		
    	/**
    	 * Returns true if any PropertyEditable objects in this object's collection
    	 * has a true value for its dependentsRetrievalPending property.
    	 *
    	 * @return (boolean) true if any dependents retrieval is pending
    	 */
    	isDependentPropertiesRetrievalPending: function() {
    	    var pending = false;
			var v;
    	    for (v in this.propertiesCollection) {
    	        if (this.propertiesCollection.hasOwnProperty(v)) {
    	            var prop = this.propertiesCollection[v];
    	            if (prop.dependentsRetrievalPending) {
    	                pending = true;
    	                break;
    	            }
    	        }
    	    }
    	    return pending;
    	},
		
	    _createPropertiesBody: function(payloadType) {
    	    if (!payloadType) {
    	        payloadType = "update";
			}
            var propertiesBody = [];
			var v;
            for (v in this.propertiesCollection) {
                if (this.propertiesCollection.hasOwnProperty(v)) {
                    var prop = this.propertiesCollection[v];
                    var updateObj = prop._getPayloadObject(payloadType);
                    if (updateObj) {
					    updateObj["_propRef"] = prop["_propRef"];
						updateObj["symbolicName"] = updateObj["name"];//TODO: this line would be removed once back-end service is ready since ICM always use name instead of symbolic name
                        propertiesBody.push(updateObj);
					}
                }
            }
            return propertiesBody;
    	},
		
		getUpdatedPropertiesCollection: function(payloadType, propertyType) {
    	    if (!payloadType) {
    	        payloadType = "update";
			}
			
            var updatedPropertiesCollection = {};
			var v;
            for (v in this.propertiesCollection) {
                if (this.propertiesCollection.hasOwnProperty(v)) {
                    var prop = this.propertiesCollection[v];
					if(prop["_propRef"] && (!propertyType || prop["_propRef"] === propertyType)){
						var updateObj = prop._getPayloadObject(payloadType);
						if (updateObj) {
							updatedPropertiesCollection[v] = this.propertiesCollection[v];
							//updatedPropertiesCollection.push(prop);
						}
					}
                }
            }
            return updatedPropertiesCollection;
    	},
    	
		_createUpdateContent: function(action, discard) {
            var propertiesBody = [];
			if(!discard){
				propertiesBody = this._createPropertiesBody("update");
			}
            var postContent = {};
			postContent.activityType = this.getActivityType();
			postContent.caseType = this.getCaseType().id;
			postContent.caseId = this.getCase().id;
			postContent.id = this.id;
			postContent.userAction = action;
			postContent.status = this.getCurrentStatus();
			postContent.comment = this.currentComment;
            postContent.properties = propertiesBody;
            if (this.externalDataIdentifier) {
                postContent.externalDataIdentifier = this.externalDataIdentifier;
			}
            
            return postContent;
		},
	
        /**
         * Saves the activity changes.
         *
         * @param callback Callback function called with this ActivityEditable object as an argument
         *                 when the request completes.
         */
	    save: function(callback, errCallback, action, discard) {
	        var self = this;
	        // TODO: allow an existing activity to be saved as well (only the name could be modified currently)
	       
	        var params = {};
	        params.repositoryId = this.repository.id;
	        
	        params.method = "saveActivity";
	        var postContent = {};
	        postContent = this._createUpdateContent(action, discard);
				
	        var clientCtx = _Utils.generateClientContext();
			postContent.clientContext = clientCtx;
	        var postParams = {
                requestParams: params,
                requestBody: postContent,
                requestCompleteCallback: function(response) {
                    self._ActivityServiceCompleted(response, callback);
                }
    		};
			// TODO: once API is ready, we will open the next codes;
            if (errCallback)
            {
                postParams.requestFailedCallback = errCallback;
            }
	        var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFActivityService", "text/json", postParams);
			return request;
	       
	    },
	    
	    _eoc_:null

	});

    /**
     * A factory method that gets a ActivityEditable object from a Activity object.
     *
     * @public
     * @function
     * @name ewf.model.ActivityEditable.fromActivity
     * @static
     * 
     * @param activity
     *      the ewf.model.Activity object
     *
     * @return ewf.model.ActivityEditable
     */
	ActivityEditable.fromActivity = function(activity){
		var params = {};
		params.id = activity.id;
		params.name = activity.name;
		params.parentCase = activity.parentCase;
		params.activityType = activity.activityType;
		params.ewfActivity = activity;
		params.repository = activity.repository;
		params.lastUserID = activity.lastUserID;
		params.lastStatus = activity.lastStatus;
		params.lastComment = activity.currentComment;
		params.currentStatus = activity.currentStatus;
		params.instruction = activity.instruction;
		params.contentItem = activity.contentItem;
		params.rulesMatrixInformation = activity.rulesMatrixInformation;

		var t = new ActivityEditable(params);
		t._initializeFromActivity(activity);
		return t;
    };
 
	return ActivityEditable;
});