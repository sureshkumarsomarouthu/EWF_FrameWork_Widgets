define([  "dojo/_base/declare", 
	"ecm/model/ContentClass"], function(declare, ContentClass) {

    /**
     * Constructs a ActivityType object.  A ActivityType object is typically constructed internally
     * by other model objects.
     *
     * @param properties
     *          The properties for the ActivityType object.  The properties can be any of the public fields as defined below
     *          and on ecm.model.ContentClass. 
     * @name ewf.model.ActivityType
     * @class Represents a activity type in a deployed case management solution.
     * @augments ecm.model.ContentClass
     */
	var ActivityType = declare("v11.ewf.model.ActivityType", [ContentClass], {
		/** @lends ewf.model.ActivityType.prototype */
		
		/**
		 * The case type of this activity type
		 * @public
		 */
		caseType: null,
        
        /**
         * The GUID of the activity class for this activity type
         * @public
         */
		activityClassId: null,
        
        /**
         * The descriptive text of this activity type.
         * @public
         */
		description: null,
        
        /**
         * Indicates whether this activity type is a container activity type.
         * @public
         */
		container: null,
        
        /**
         * Indicates whether the user has permission to create instances of this activity type.
         * @public
         */
		instanceCreationRights: null,

        /**
         * @deprecated Use caseType property
         * @private
         */
		getCaseType: function(){
			return this.caseType;
		},				
		
        /**
         * @deprecated Use activityClassId property
         * @private
         */
		getClassId: function(){
			return this.activityClassId;
		},		
		
        /**
         * @deprecated Use description property
         * @private
         */
		getDescription: function(){
			return this.description;
		},
		
        /**
         * @deprecated Use container property
         * @private
         */
	    isContainer: function() {
	    	return this.container;
	    },		
	   
	    /**
         * @deprecated Use hasInstanceCreationRights property
         * @private
	     */
	    hasInstanceCreationRights: function() {
	    	return this.instanceCreationRights;
	    },
	    
	    _eoc_:null    
	});

    /**
     * @private
     */
	ActivityType._fromCaseType = function(caseType, activityClassId, activityName, activityDisplayName, description, hasInstanceCreationRights, isContainer, externalDataSupported) {

		var params = {};
		params.id = activityName;
		params.name = activityDisplayName;
		params.repository = caseType.repository;

		var activityType = new ActivityType(params);

		activityType.caseType = caseType;
		activityType.activityClassId = activityClassId;
		activityType.description = description;
		activityType.instanceCreationRights = hasInstanceCreationRights;
		activityType.container = isContainer;
		activityType.externalDataSupported = externalDataSupported;

		return activityType;
	};

	return ActivityType;
});
	
