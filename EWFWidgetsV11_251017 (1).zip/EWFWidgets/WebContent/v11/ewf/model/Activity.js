define([  "dojo/_base/declare",
          "dojo/_base/lang", 
          "dojo/date/stamp",
          "dojo/_base/json",
	"ecm/model/_ModelObject", 
	"ecm/model/Item",
	"ecm/LoggerMixin",
	"icm/base/Constants", 
	"icm/model/_Utils",
	"ecm/model/Request",
	"gridx/modules/Dod",
	"icm/model/PropertyEditable",
	"v11/ewf/model/ActivityEditable"], function(declare, lang, stamp, json, _ModelObject, Item, LoggerMixin, Constants, _Utils, Request,Dod,PropertyEditable, ActivityEditable) {


    /**
     * Constructs a Activity object.  A Activity object is typically constructed internally
     * by other model objects.
     *
     * @param properties
     *          The properties for the Activity object.  The properties can be any of the public fields as defined below
     *          and on ecm.model.Item or ecm.model._ModelObject. 
     * @name ewf.model.Activity
     * @class Represents a activity.
     * @augments ecm.model.Item
     */
	var Activity = dojo.declare("v11.ewf.model.Activity", [Item, LoggerMixin], {
		/** @lends ewf.model.Activity.prototype */
		
		CONSTANTS: Constants,
		
        /**
         *The last user who updated the activity.
         * @public
         */
		lastUserID: null,	

		/* New Properties added during COA start here */
		
		/**
         *The AP Rule Matrix Information.
         * @public
         */
		rulesMatrixInformation: null,
		
		
		/**
         *The first user who updated the activity.
         * @public
         */
		/*initialUserID: null,*/
		
		/**
         *The first status of the activity.
         * @public
         */
		/*initialStatus: null,*/
		
		/**
         *The first run date/time of the activity.
         * @public
         */
		/*initialRunDateTime: null,*/
		
		/**
         *The last modified date/time of the activity.
         * @public
         */
		/*lastModifiedDateTime: null,*/
		
		/* New Properties added during COA end here */
		
        /**
         *The last status of the activity.
         * @public
         */
		lastStatus: null,		

        /**
         *The last comment on the activity.
         * @public
         */
		lastComment: null,		

        /**
         *The current status of the activity.
         * @public
         */
		currentStatus: null,
		
		 /**
         *The instruction about how to operation on the activity.
         * @public
         */
		instruction: null,
		
        /**
         * A CaseEditable object of parent Case of this activity.
         * @public
         */
		parentCase: null,
		
		/**
         * The type of the activity.
         * @public
         */
		activityType: null,
        
        
		/**
         * Holds the original values of the attributes corresponding to the current
         * attributes loaded into the attributes property.  Some of the values may be
         * different if the current values were modified by an external data service.
         * If an attribute in the attributes property doesn't have a corresponding
         * value in originalAttributes, the original value should be considered
         * the same as the current value.
         */
        originalAttributes: null,
		
		/**
	     * AttributeDefinition objects that correspond to the attributes collection
	     * of this WorkItem.
	     */
        attributeDefinitions: null,

        /**
         * Will be non-null if integrating with an external data service
         */
        externalDataIdentifier: undefined,

		/**
         *The contentItem representing the activity.
         * @public
         */
		contentItem: null,    
				
        /**
         * @private
         */
        constructor: function() {
		    if (!this.attributeDefinitions) {
		        this.attributeDefinitions = {};
			}
		    if (!this.originalAttributes) {
		        this.originalAttributes = {};
			}
		    // TODO: properties collection to be removed from the Case class and only the base
		    // Item attributes and related members to be managed.
		    this._properties = null;
            this._fullAttrsRetrieved = false;
            
            this.overrideDodLoad();
        },
		
	//Added by suresh for Activity panel activity is open after complete the each Activity
		overrideDodLoad: function() {
		lang.extend(Dod, {
		
		load:function (args, deferStartup) {
            var t = this, g = t.grid, m = g.model;
            t._rowMap = {};
            t.connect(g.body, "onAfterCell", "_onAfterCell");
            t.connect(g.body, "onAfterRow", "_onAfterRow");
            t.connect(g.bodyNode, "onclick", "_onBodyClick");
            t.connect(g.body, "onUnrender", "_onBodyUnrender");
            t.connect(g, "onCellKeyDown", "_onCellKeyDown");
            t.connect(g.body, "_onRowMouseOver", "_onRowMouseOver");
           //t.connect(m, "onSet", "_onModelSet");
            if (g.isIE) {
                t.aspect(t.grid.body, "renderRows", function (s, c, p) {
                    if (p === "top" || p === "bottom") {
                        return;
                    }
                    var i, rowInfo, _row, temp, rm = t._rowMap;
                    for (var k in rm) {
                        temp = rm[k];
                        temp.dodLoaded = false;
                        temp.dodLoadingNode = null;
                        temp.dodNode = null;
                    }
                }, t, "before");
            }
            if (t.grid.columnResizer) {
                t.connect(t.grid.columnResizer, "onResize", "_onColumnResize");
            }
            t.loaded.callback();
        }
       
        });
        },		
        /**
         * Retrieves all attributes for the item. Depending on how the item was originally created, it might only contain
         * a subset of the attributes. This function retrieves any additional missing attributes.
         * @param callback
         *            a function that is called when the attribute retrieve has completed.
         *            This object is passed as an argument to the method.
         */
        retrieveAttributes: function(callback) {
            var self = this;
			
			
			
            var params = this._createServiceParams();
            
            ecm.model.Request.invokePluginService(
                    "EWFWidgetsPluginv11", 
                    "EWFActivityService",
                    {
                        requestParams: params,
                        requestCompleteCallback: 
                            function(response) {
                                self._activityServiceCompleted(response, callback);
                            }
                    });
        },
        
        /**
         * Ensures that the full set of attributes has been retrieved.  If the full set
         * has already been retrieved, the callback is called right away.  Otherwise
         * retrieveAttributes() is called to retrieve all the attributes.
         * 
         * @param callback
         *            a function that is called when the attribute retrieve has completed.
         *            This object is passed as an argument to the method.
         */
        retrieveCachedAttributes: function(callback) {
            if (this._fullAttrsRetrieved) {
                if (callback){
                    callback(this);
				}
            }
            else {
                this.retrieveAttributes(callback);
            }
        },
		

        
		/**
		 * @deprecated Use name property
		 * @private
	     */
		getActivityName: function() {
			return this.name || this.activityName;
		},
		
        /**
         * @deprecated Use parentCase property
         * @private
         */
		getCase: function() {
		    return this.parentCase.getCase();
		},
		
		/**
		 * Returns the CaseType of the parent Case
		 * 
		 * @return icm.model.CaseType
		 * 
		 */
		getCaseType: function() {
		    var ct;
		    if (this.parentCase){
		        ct = this.parentCase.getCaseType();
			}
		    return ct;
		},
		
		/**
		 * Returns the id of the activity item
		 * 
		 * @return  (string) id
		 * 
		 */
		getActivityId: function() {
		    return this.id;
		},
		
		/**
		 * Returns the last user id who updated the activity.
		 * 
		 * @return (string) last user id
		 * 
		 */
		getLastUserID: function() {
		    return this.lastUserID;
		},
		
		/**
		 * set the last user id who updated the activity.
		 * 
		 * @param (string) lastUserID
		 * 
		 */
		setLastUserID: function(lastUserID) {
		    this.lastUserID = lastUserID;
		},
		
		/*New methods added during COA dev starts here */
		/**
		 * Returns the last user id who updated the activity.
		 * 
		 * @return (string) last user id
		 * 
		 */
		getRulesMatrixInformation: function() {
		    return this.rulesMatrixInformation;
		},
		
		/**
		 * set the last user id who updated the activity.
		 * 
		 * @param (string) lastUserID
		 * 
		 */
		setRulesMatrixInformation: function(rulesMatrixInfo) {
		    this.rulesMatrixInformation = rulesMatrixInfo;
		},
		/*New methods added during COA dev ends here */
		
		/**
		 * Returns the last status of the activity.
		 * 
		 * @return (string) last status
		 * 
		 */
		getLastStatus: function() {
		    return this.lastStatus;
		},
		
		/**
		 * set the status of the activity.
		 * 
		 * @param (string) lastStatus
		 * 
		 */
		setLastStatus: function(lastStatus) {
		    this.lastStatus = lastStatus;
		},
				
		/**
		 * Returns the last comment on the activity.
		 * 
		 * @return (string) last comment
		 * 
		 */
		getLastComment: function() {
		    return this.lastComment;
		},
		
		/**
		 * set the last comment on the activity.
		 * 
		 * @param (string) lastComment
		 * 
		 */
		setLastComment: function(lastComment) {
		    this.lastComment = lastComment;
		},
		
		/**
		 * Returns the current Status of the activity.
		 * 
		 * @return (string) the current Status
		 * 
		 */
		getCurrentStatus: function() {
		    return this.currentStatus;
		},
		
		/**
		 * set the current Status of the activity.
		 * 
		 * @param (string) currentStatus
		 * 
		 */
		setCurrentStatus: function(currentStatus) {
		    var tmp = this.currentStatus;
		    this.currentStatus = currentStatus;
			this.lastStatus = tmp;
		},
			
        /**
		 * Returns the type of the activity
		 * 
		 * @return (string) The activity Type.
		 * 
		 */
		getActivityType: function() {
		    return this.activityType;
		},

		/**
		 * Returns the System Message of the activity
		 * 
		 * @return (string) The System Message.
		 * 
		 */
		getSystemMessage: function() {
		    return this.attributes["SystemMessage"];
		},
		
		/**
		 * Returns the System Message of the activity
		 * 
		 * @return (string) The System Message Name.
		 * 
		 */
		getSystemMessageName: function() {
		    return this.attributeDefinitions["SystemMessage"] && this.attributeDefinitions["SystemMessage"].name;
		},
		
		/**
         * @deprecated Use id property
         * @private
	     */
		getActivityId: function() {
			return this.id;
		},
		
	    /**
	     * Gets an Editable object in order to make scratchpad changes to the activity and possibly save 
	     * those changes. The changes are not permanent until save() is called on the Editable object.
	     *
	     * @return icm.model.ActivityEditable    
	     */
	    createEditable: function() {
	    	return ActivityEditable.fromActivity(this);
	    },

        _activityServiceCompleted: function(result, callback) {
			this.logEntry("_activityServiceCompleted called");
			if (result) {
				this.logEntry("Response received");
				this._refreshFromResultProperties(result.attributes);
				this._fullAttrsRetrieved = true;
				if (callback){
					callback(this);
				}
			}
		},

		_createServiceParams: function() {
			var params = {};
			params.repositoryId =  this.repository.id;
			params.caseType = this.getCaseType().id;
			params.caseId = this.getCase().id;
			params.activityId = this.id;
			params.method = "getActivity";
			return params;
		},	   
		
		/**
		 * TODO: how to initialize a activity from ContentItem need to be discussed based on the activity model
		 * */
		_initializeFromContentItem: function(ecmContentItem, parentCase, resolutionCallback){
		    var methodName = "_initializeFromContentItem";
		    var self = this;
            this.parentCase = parentCase;
			
			this.retrieveCachedAttributes(resolutionCallback);
		},	
		
		_initializeFromJSON: function(params, parentCase, resolutionCallback){
			this.parentCase = parentCase;
			this.retrieveCachedAttributes(resolutionCallback);
		},

		_initializeItemAttributes: function(attributes) {
			var i;
            for (i=0;i<attributes.length;i++){
                var payloadProp = attributes[i];
                // TODO: Not sure if AttributeDefinition should be tied to a ContentClass.  It is not the actual CaseType
                // of this Case because there could be instance specific settings injected by an EDS.
                // We could bake up a pseudo ContentClass to be specific to this Case instance.
                var attrDef = _Utils.createAttributeDefinitionFromServiceResult(payloadProp, this.repository, null);
				
				//indicate whether the attribute is from Case or Activity itself
				if(payloadProp.hasOwnProperty("_propRef")){
					attrDef["_propRef"] = payloadProp["_propRef"];
				}
				//Add three properties for highlighted properties
				if(payloadProp.hasOwnProperty("logicRequired")){
					attrDef["logicRequired"] = payloadProp["logicRequired"];
				}
				if(payloadProp.hasOwnProperty("updated")){
					attrDef["updated"] = payloadProp["updated"];
				}
				if(payloadProp.hasOwnProperty("failureType")){
					attrDef["failureType"] = payloadProp["failureType"];
				}
				
				//Modified by Purna for PLA - For multi value properties add the "failIndexes" and "failureTypes" arrays for index level highlighting
				if(payloadProp.hasOwnProperty("failIndexes")){
					attrDef["failIndexes"] = payloadProp["failIndexes"];
				}
				if(payloadProp.hasOwnProperty("failureTypes")){
					attrDef["failureTypes"] = payloadProp["failureTypes"];
				}
				if(payloadProp.hasOwnProperty("updatedIndexes")){
					attrDef["updatedIndexes"] = payloadProp["updatedIndexes"];
				}
				//End Changes
				 
                this.attributeDefinitions[attrDef.id] = attrDef;
                var val = (payloadProp.hasOwnProperty("value") ? payloadProp.value : null);
                val = _Utils.convertPayloadValue(attrDef.dataType, val);
                if (payloadProp.hasOwnProperty("originalValue")) {
                    var origVal = payloadProp.originalValue;
                    origVal = _Utils.convertPayloadValue(attrDef.dataType, origVal);
                    this.originalAttributes[attrDef.id] = origVal;
                }
                else if (this.originalAttributes.hasOwnProperty(attrDef.id)) {
                    delete this.originalAttributes[attrDef.id];
				}
                this.attributes[attrDef.id] = val;
                this.attributeTypes[attrDef.id] = attrDef.dataType;
            }
		},
        // TODO: temporary until all code uses attributes from Activity object
        _initializePropertiesCollectionFromAttributes: function() {
            if (!this._properties) {
                this._properties = {};
			}
            var otherParams = {};
            otherParams.modifiable = false;
            //added by suresh as part of 5.2.1 upgrade we need to pass provide
           // otherParams.provider = "F_CaseActivity";
           otherParams.provider = "F_CaseFolder";		
			var attrId;
            for (attrId in this.attributes) {
                if (this.attributes.hasOwnProperty(attrId) && this.attributeDefinitions.hasOwnProperty(attrId)) {
                    var property;
                    otherParams.value = this.attributes[attrId];
                    if (this.originalAttributes.hasOwnProperty(attrId)) {
                        otherParams.originalValue = this.originalAttributes[attrId];
					}
                    else if (otherParams.hasOwnProperty("originalValue")) {
                        delete otherParams.originalValue;
					}
                    if (this._properties.hasOwnProperty(attrId)) {
                        property = this._properties[attrId];
                        property._initializeFromParameters(this.attributeDefinitions[attrId], otherParams, "afterSave");
                    }
                    else {
                        var attrDef = this.attributeDefinitions[attrId];
                        var attrName = attrDef.name;
                        //Modified By Gopi As part of ICM 5.2.1 Upgrade
                        property = PropertyEditable._createProperty(attrId, attrName, attrDef, otherParams,this.repository);
                        this._properties[property.id] = property;
                    }
                }
            }
        },
		
		resetParameters:function(){
			this.setLastUserID(this.getValue("LastModifier"));
			this.setLastStatus(this.getValue("LastStatus"));
			this.setLastComment(this.getValue("LastComment"));
			this.setCurrentStatus(this.getValue("ActivityStatus"));
			/*Added during COA Dev starts here */
			this.setRulesMatrixInformation(this.contentItem.getValue("EWS_APRuleMatrixInfo"));
			/*Added during COA Dev ends here */
		},
		
		refreshContentItem:function(attributes){
			this.contentItem.setValue("LastModifier", this.getLastUserID());
			this.contentItem.setValue("LastStatus", this.getLastStatus());
			this.contentItem.setValue("LastComment", this.getLastComment());
			this.contentItem.setValue("ActivityStatus", this.getCurrentStatus());
			
			/*Added during COA Dev starts here */
			this.contentItem.setValue("EWS_APRuleMatrixInfo", this.getRulesMatrixInformation());
			/*Added during COA Dev ends here */
			
			//update whole grid, has issues.
			//this.contentItem.resultSet.onChange(this.contentItem.resultSet);
			
			//update updated activity row.
			var gridStore = this.contentItem.resultSet.store;
			gridStore.onSet(this.contentItem);
		},
		
		/**
         * Called when the entire state of the object is refreshed, primarily
         * when the attributes have been updated based on updated information
         * from the server.
         */
        onRefresh: function() {
        	/* Added during COA Dev starts here */
        	this.rulesMatrixInformation = this.contentItem.getValue("EWS_APRuleMatrixInfo");
        	/* Added during COA Dev ends here */
        },
        
		// Also called by ActivityEditable when changes are saved
		_refreshFromResultProperties: function(attributes, externalDataIdentifier) {
			if(!attributes){
				return;
			}
		    this._initializeItemAttributes(attributes);
		    this.externalDataIdentifier = externalDataIdentifier;
		    // TODO: temporary until everyone is using attributes instead of collection of
            // non-modifiable properties
            this._initializePropertiesCollectionFromAttributes();
			
			if(this._fullAttrsRetrieved){
				this.resetParameters(); //reset the parameters after setting;
				this.refreshContentItem();//Refresh ContentItem associated with the activity
			}
			
            this._fullAttrsRetrieved = true;
            this.onRefresh();
		},
		
	    _eoc_:null
	    
	});
	
    /**
     * A factory method that obtains an Activity object corresponding to a ContentItem object.
     * Typically, this ContentItem is obtained as part of a set of search results.
     * No services call is made to retrieve the attributes for the case, but before the
     * attributes can be edited, such as by obtaining a ActivityEditable object, the retrieveAttributes() method
     * must be called to fully retrieve the attributes.
     *
     * @public
     * @function
     * @name ewf.model.Activity.fromContentItem
     * @static
     *
     * @param contentItem
     *      the ecm.model.ContentItem object for the case folder containing the activity item
     * @param parentCase
     *      either a Case object or CaseType object.  Case object is passed in if the Activity is being built
     *      relative to a method on a Case instance, such as retrieving all of the activitys of a case.
     *      At a minimum the CaseType should be passed in and should be retrieved from the Solution
     *      ahead of time if necessary (based on the service payload).  If only the CaseType is passed in,
     *      a Case instance will be constructed as part of initializing the Activity.       *      
	 * @param resolutionCallback
     *      In constructing the Activity object, it may be necessary to resolve certain attributes.
     *      Currently this is the CaseType of the Case containing the Activity.  It may be necessary to 
	 *      perform the resolution asynchronously, for example, if the activity object is in a different solution
     *      than the solution the user is currently working with and case types have not yet been retrieved. 
     *      Provide a callback function for this argument and it will be called when any resolution is complete. 
     *      If no asynchronous resolution is necessary, the callback will be called right away.  
     *      The callback function is called with the same acitivity object that this factory method returns.
     * @return ewf.model.Activity
     */
	Activity.fromContentItem = function(contentItem, parentCase, resolutionCallback) {
		console.log('Activity Object --> ', contentItem);
    	var params = {};
    	params.id = contentItem.id;
    	params.name = contentItem.name;
    	params.repository = contentItem.repository;
		params.attributes = contentItem.attributes;
		params.attributeTypes = contentItem.attributeTypes;
		params.attributeFormats = contentItem.attributeFormats;
		params.attributeDisplayValues = contentItem.attributeDisplayValues;
		params.attributeReadOnly = contentItem.attributeReadOnly;
		params.lastUserID = contentItem.getValue("LastModifier");
		params.lastStatus = contentItem.getValue("LastStatus");
		params.lastComment = contentItem.getValue("LastComment");
		params.currentStatus = contentItem.getValue("ActivityStatus");
		params.instruction = contentItem.getValue("$_Instruction");
		params.activityType = contentItem.getValue("$_ActivityType");
		
		params.contentItem = contentItem;
		
		params._properties = contentItem._properties;
		
		var thisActivity = new Activity(params);
		
		thisActivity._initializeFromContentItem(contentItem, parentCase, resolutionCallback);
		
		return thisActivity;

    };

	

    /**
     * A factory method that obtains a Activity object corresponding to a JSON representation of the Activity object.
     * Typically, this JSON object is obtained as part of a service call on the case instance.
     *
     * @param activityJSON
     *      the JSON object representing the activity
     * @param parentCase
     *      either a Case object or CaseType object.  Case object is passed in if the Activity is being built
     *      relative to a method on a Case instance, such as retrieving all of the activitys of a case.
     *      At a minimum the CaseType should be passed in and should be retrieved from the Solution
     *      ahead of time if necessary (based on the service payload).  If only the CaseType is passed in,
     *      a Case instance will be constructed as part of initializing the Activity.  
     *      
     * @return icm.model.Activity
     * @private
     */
	Activity._fromJSON = function(activityJSON, parentCase, resolutionCallback){
		var params = {};
		params.id = activityJSON.activityId;
		params.name = activityJSON.activityName;
		params.parentCase = parentCase;
		params.activityType = activityJSON.activityType;
		//TODO: repository should be initialized to the ecm.model.Repository object
		params.repository = activityJSON.activityRepository;

		var activity = new Activity(params);
		activity._initializeFromJSON(activityJSON, parentCase, resolutionCallback);
		return activity;
	};
	
	return Activity;
});