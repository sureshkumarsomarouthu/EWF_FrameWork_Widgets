define(["dojo/_base/lang",
		"dojo/_base/array",
        "v11/ewf/model/properties/controllers/StringPropertyController",
		"v11/ewf/model/properties/controllers/IntegerPropertyController",
		"v11/ewf/model/properties/controllers/FloatPropertyController",
		"v11/ewf/model/properties/controllers/DatetimePropertyController",
		"v11/ewf/model/properties/controllers/BooleanPropertyController",
		"v11/ewf/model/properties/controllers/AttachmentPropertyController",
		"v11/ewf/model/properties/controllers/GroupPropertyController",
        "v11/ewf/model/properties/controllers/LinesPropertyController",
        "v11/ewf/model/properties/controllers/MultiColumnsWidgetPropertyController",
        "v11/ewf/model/properties/controllers/ContactNumberPropertyController",
        "v11/ewf/model/properties/controllers/SpecialContactNumberPropertyController",
        "v11/ewf/model/properties/controllers/AdditionalNumbersPropertyController",
        "v11/ewf/model/properties/controllers/ShowOrHidePropertiesPropertyController",
        "v11/ewf/model/properties/controllers/PostalCodeSearchWidgetPropertyController",
        "v11/ewf/model/properties/controllers/LongStringPropertyController",
        "v11/ewf/model/properties/controllers/SuggestionListPropertyController",
        "v11/ewf/model/properties/controllers/YesNoSelectPropertyController",
        "v11/ewf/model/properties/controllers/SplYesNoSelectPropertyController",
        "v11/ewf/model/properties/controllers/CheckBoxPropertyController",
        "v11/ewf/model/properties/controllers/CheckBoxListPropertyController",
        "v11/ewf/model/properties/controllers/RadioButtonSetPropertyController",
		"v11/ewf/model/properties/controllers/DecisionWidgetController",
		"v11/ewf/model/properties/controllers/CPFStatementWidgetPropertyController",
		"v11/ewf/model/properties/controllers/AddCardsWidgetPropertyController",
		"v11/ewf/model/properties/controllers/CustomRegExpWidgetPropertyController",
		"v11/ewf/model/properties/controllers/OthersOptionController"],
		function(lang,array,ewfStringPropertyController,ewfIntegerPropertyController,ewfFloatPropertyController,ewfDatetimePropertyController,ewfBooleanPropertyController,ewfAttachmentPropertyController,ewfGroupPropertyController,ewfLinesPropertyController,ewfMultiColumnsWidgetPropertyController,ewfContactNumberPropertyController,ewfSpecialContactNumberPropertyController,ewfAdditionalNumbersPropertyController,ewfShowOrHidePropertiesPropertyController,ewfPostalCodeSearchWidgetPropertyController,ewfLongStringPropertyController,ewfSuggestionListPropertyController,ewfYesNoSelectPropertyController,ewfSplYesNoSelectPropertyController,
		ewfCheckBoxPropertyController,ewfCheckBoxListPropertyController,ewfRadioButtonSetPropertyController,ewfDecisionWidgetController,ewfCPFStatementWidgetPropertyController,ewfAddCardsWidgetPropertyController,ewfCustomRegExpWidgetPropertyController,ewfOthersOptionController){
	
	var propertyExtensionTypes = {
			"LinesWidget": "lines",
			"multiColumns": "multiColumns",
			"ContactNumberWidget": "contactNumber",
			"SpecialContactNumberWidget": "specialContactNumber",
			"additionalNumbers": "additionalNumbers",
			"showOrHide": "showOrHide",
			"postalCodeSearch": "postalCodeSearch",
			"textarea": "longString",
			"suggestionList" : "suggestionList",
			"yesnocb": "yesNoSelect",
			"splyesnocb": "splYesNoSelect",
			"checkBox": "checkBox",
			"checkBoxList": "checkBoxList",
			"radioButtonSet": "radioButtonSet",
			"DecisionWidget": "decisionWdgt",
			"CPFStWdgt": "CPFStWdgt",
			"CustomRegExpWdgt":"CustomRegExpWdgt",
			"AddCardsWidget": "AddCardsWidget",
			"OthersOptionWdgt": "OthersOptionWdgt"
		};
	//var supportedTypes = ["string", "xs:string", "integer", "xs:integer", "xs:long", "float", "xs:double", "datetime", "xs:timestamp", "boolean", "xs:boolean", "xs:attachment", "xs:group"];
	
	
	var ewfConfig = {
			types: {
				"string": {
					controllerClass: ewfStringPropertyController
				},
				"integer": {
					controllerClass: ewfIntegerPropertyController
				},
				"float": {
					controllerClass: ewfFloatPropertyController
				},
				"datetime": {
					controllerClass: ewfDatetimePropertyController
				},
				"boolean": {
					controllerClass: ewfBooleanPropertyController
				},
				"attachment": {
					controllerClass: ewfAttachmentPropertyController
				},
				"group": {
					controllerClass: ewfGroupPropertyController
				},
				"lines": {
					controllerClass: ewfLinesPropertyController
				},
				"multiColumns": {
					controllerClass: ewfMultiColumnsWidgetPropertyController
				},
				"contactNumber": {
					controllerClass: ewfContactNumberPropertyController
				},
				"specialContactNumber": {
					controllerClass: ewfSpecialContactNumberPropertyController
				},
				"additionalNumbers": {
					controllerClass: ewfAdditionalNumbersPropertyController
				},
				"showOrHide": {
					controllerClass: ewfShowOrHidePropertiesPropertyController
				},
				"postalCodeSearch": {
					controllerClass: ewfPostalCodeSearchWidgetPropertyController
				},
				"longString": {
					controllerClass: ewfLongStringPropertyController
				},
				"suggestionList": {
					controllerClass: ewfSuggestionListPropertyController
				},
				"yesNoSelect": {
					controllerClass: ewfYesNoSelectPropertyController
				},
				"splYesNoSelect": {
					controllerClass: ewfSplYesNoSelectPropertyController
				},
				"checkBox": {
					controllerClass: ewfCheckBoxPropertyController
				},
				"checkBoxList": {
					controllerClass: ewfCheckBoxListPropertyController
				},
				"radioButtonSet": {
					controllerClass: ewfRadioButtonSetPropertyController
				},
				"decisionWdgt": {
					controllerClass: ewfDecisionWidgetController
				},
				"CPFStWdgt": {
					controllerClass: ewfCPFStatementWidgetPropertyController
				},
				"CustomRegExpWdgt": {
					controllerClass: ewfCustomRegExpWidgetPropertyController
				},
				"AddCardsWidget": {
					controllerClass: ewfAddCardsWidgetPropertyController
				},
				"OthersOptionWdgt": {
					controllerClass: ewfOthersOptionController
				}
			},
			bindings: {
				property: {
					attributes: {
						common:{
							systemDefined: {
								get: "system"
							},
							logicRequired: {
								get: "logicRequired"
							},
							failureType: {
								get: "failureType"
							},
							updated: {
								get: "updated"
							},
							label: {
								//getter: function(){
								get: function(model){
									if(model.label){
										return model.label;
									}else{
										return model.name;
									}
								}
							},
							rowRequired:{ // Used by the PropertyTable container
								//getter:function () {
								get:function (model) {
									//return this.model.required;
									return model.required;
								}
							},
							fieldWidth: {
								get: "fieldWidth"
							},
							maxLength: {
								//getter:function () {
								get:function (model) {
									return model.maxLength;
								}								
							},
							autoTruncate: {
								//getter:function () {
								get:function (model) {
									if (model.autoTruncate == undefined || model.autoTruncate == null) {
										return false;
									}
									return model.autoTruncate;
								}			
							},
							hint: {
								get: "hint"
							},
							hintPosition: {
								get: "hintPosition"
							},
							value: {
							get: function(model) {
								return this.convertModelValue(model, model.value);
							},
							set: function(model, value) {
								model.setValue(this.convertControllerValue(model, value));
							},
							change: {
								event: "onValueChanged",
								handler: function(model, value) {
									return this.convertModelValue(model, value);
								}
							},
							controlled: function(model) {
								return model.dirty || (model.externalDataModifications && model.externalDataModifications.value);
							}
						},
							type: {
								get: function(model) {
									return this.convertDataType(model.dataType, model);
								}
							}
						},
						types: {
							"string":{
								"pattern":{
									get: "regExp"
								},
								"invalidMessage": {
									//getter: function(){
									get:function (model) {
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model) {
										return model.promptMessage || null;									
									}
								}
							},
							"datetime":{
								"formatLength":{
									get: "formatLength"
								},
								"datePattern": {
									get: "datePattern"
								},
								"strict": {
									get: "strict"
								}
							},
							"lines": {
								"invalidMessage": {
									//getter: function(){
									get:function (model) {
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model) {
										return model.promptMessage || null;									
									}
								},
								"linePattern":{
									get: "linePattern"
								},
								"lineCount":{
									get: "lineCount"
								},
								"nameLabel":{
									get: "nameLabel"
								},
								"maxLengthLine": {
									get: "maxLengthLine"
								},
								"editorArgs": {
									get: "editorArgs"
								}
							},
							"multiColumns": {
								"invalidMessage": {
									//getter: function(){
									get:function (model) {
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model) {
										return model.promptMessage || null;									
									}
								},
								"widgetLimit": {
									get: "widgetLimit"
								},
								"widgetsAdded": {
									get: "widgetsAdded"
								},
								"participantsConfig": {
									get: "participantsConfig"
								},
								"allowNullOrBlankValues": {
									get: "allowNullOrBlankValues"
								},
								"buttonLabel": {
									get: "buttonLabel"
								}
							},
							"contactNumber": {
								"invalidMessage": {
									//getter: function(){
									get:function (model) {
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model) {
										return model.promptMessage || null;									
									}
								},
								"regExps": {
									get: "regExps"
								}
							},
							"specialContactNumber": {
								"invalidMessage": {
									//getter: function(){
									get:function (model) {
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model) {
										return model.promptMessage || null;									
									}
								}
							},
							"additionalNumbers": {
								"invalidMessage": {
									//getter: function(){
									get:function (model) {
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model) {
										return model.promptMessage || null;									
									}
								}
							},
							"suggestionList": {
								"invalidMessage": {
									//getter: function(){
									get:function (model){
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model){
										return model.promptMessage || null;									
									}
								},
								"initStrLength": {
									get: "initStrLength"
								},
								"suggestionList": {
									get: "suggestionList"
								}
							},
							"showOrHide": {
								"invalidMessage": {
									//getter: function(){
									get:function (model){
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model){
										return model.promptMessage || null;									
									}
								},
								"checkBoxLogic": {
									get: "checkBoxLogic"
								},
                                                               //added by sravanthi.
								"isDropdown": {
									get: "isDropdown"
								}
								//End by sravanthi
							},
							"postalCodeSearch": {
								"invalidMessage": {
									//getter: function(){
									get:function (model){
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model){
										return model.promptMessage || null;									
									}
								},
								"populateLogic": {
									get: "populateLogic"
								},
								"codePattern": {
									get: "codePattern"
								}
							},
							"checkBoxList": {
								"options": {
									//getter: function() {
									get: function(model) {
										//return this.__convertChoiceList(this.model.choiceList);
										return this.convertChoiceList(model.choiceList);
									},
									change: {
										event: "onChoiceListChanged",
										handler: function(model, choiceList) {
											//return this.__convertChoiceList(choiceList);
											return this.convertChoiceList(choiceList);
										}
									}
								},
								"choices": {
									//getter: function() {
									get: function(model) {
										return null;
									},
									change: {
										event: "onChoiceListChanged",
										handler: function(model,choiceList) {
											return null;
										}
									}
								},
								"multiple": {
									get: "multiple"
								}
							},
							"radioButtonSet": {
								"options": {
									//getter: function() {
									get:function (model){
										//return this.__convertChoiceList(model.choiceList);
										return this.convertChoiceList(model.choiceList);
									},
									change: {
										event: "onChoiceListChanged",
										handler: function(choiceList) {
											//return this.__convertChoiceList(choiceList);
											return this.convertChoiceList(choiceList);
										}
									}
								},
								"choices": {
									//getter: function() {
									get:function (model){
										return null;
									},
									change: {
										event: "onChoiceListChanged",
										handler: function(choiceList) {
											return null;
										}
									}
								}
							},
							"CPFStWdgt": {
								"invalidMessage": {
									//getter: function(){
									get:function (model){
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model){
										return model.promptMessage || null;									
									}
								},
								"populateLogic": {
									get: "populateLogic"
								},
								"participantsConfig": {
									get: "participantsConfig"
								},
								"noOfMonths": {
									get: "noOfMonths"
								},
								"codePattern": {
									get: "codePattern"
								}
							},
							"CustomRegExpWdgt": {
								"invalidMessage": {
									//getter: function(){
									get:function (model){
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model){
										return model.promptMessage || null;									
									}
								},
								"populateLogic": {
									get: "populateLogic"
								},
								"codePattern": {
									get: "codePattern"
								}
							},
							"decisionWdgt": {
								"caseType": {
									get: "caseType"
								},
								"prefix": {
									get: "prefix"
								},
								"panel": {
									get: "panel"
								}
							},
							"AddCardsWidget": {
								"invalidMessage": {
									//getter: function(){
									get:function (model){
										return model.invalidMessage || null;
									}
								},
								"promptMessage": {
									//getter: function(){
									get:function (model){
										return model.promptMessage || null;									
									}
								},
								"widgetLimit": {
									get: "widgetLimit"
								},
								"widgetsAdded": {
									get: "widgetsAdded"
								},
								"participantsConfig": {
									get: "participantsConfig"
								},
								"allowNullOrBlankValues": {
									get: "allowNullOrBlankValues"
								},
								"buttonLabel": {
									get: "buttonLabel"
								},
								"noOfCols": {
									get: "noOfCols"
								},
								"defaultOpen": {
									get: "defaultOpen"
								},
								"storeJSONData": {
									get: "storeJSONData"
								},
								"editorArgs": {
									get: "editorArgs"
								}
							},
							"OthersOptionWdgt": {
								"configuration": {
									get: "configuration"
								},
								"otherFieldConfig": {
									get: "otherFieldConfig"
								},
								"enableValue": {
									get: "enableValue"
								}
							}
						}
					}
				},
				sandbox: {
										
					convertDataType: function(dataType, model){
							var extensionType = '';
							if(model) {
								extensionType = model.propertyExtensionType;
							}
							var _type;
							if(extensionType){
								_type = propertyExtensionTypes[extensionType];
							}
							if(!_type){
								_type =  {
									"xs:string": "string",
									"xs:integer": "integer",
									"xs:double": "float",
									"xs:timestamp": "datetime",
									"xs:boolean": "boolean",
									"xs:attachment": "attachment",
									"xs:group": "group"
								}[dataType];
							}
							return _type;
						}
				}
			}
	};
	
	return ewfConfig;
});