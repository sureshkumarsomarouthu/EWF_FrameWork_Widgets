/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2013, 2014, 2015 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/dom-class",
	"dojo/dom-style",
	"dojo/dom-geometry",
	"dojo/on",
	"dojo/aspect",
	"dijit/form/_TextBoxMixin",
	"pvr/controller/value/Value",
	"pvr/widget/editors/mixins/_EditorMixin",
	"dojo/i18n!pvr/nls/common"
], function(declare, lang, array, domClass, domStyle, domGeometry, on, aspect, _TextBoxMixin, Value, _EditorMixin, resources) {

	
	var _EditorMixin = declare("v11.ewf.model.properties.pvr.widget.editors.mixins._EditorMixin", _EditorMixin, {
		/** @lends pvr.widget.editors.mixins._EditorMixin.prototype */
		
		_getErrorAttr: function(row) {
		    // this.inherited(arguments);
		    //console.log("this in _getErrorAttr@@@!! : ",this);
			//var externalError = this.get("externalError");
			var internalError = this.get("internalError");
			var duplicatesError = this.get("duplicatesError");
			var externalError = null;
			//var internalError = null;
			//var duplicatesError = null;
			if (lang.isArray(externalError)) {
				var error = [];
				var extent = Math.max(externalError.length, internalError.length, duplicatesError.length);
				for (var i = 0; i < extent; i++) {
					error.push(externalError[i] || internalError[i] || duplicatesError[i] || null);
				}
				return typeof(row) === "number" ? error[row] : error;
			} else {
				return externalError || internalError || duplicatesError || null;
			}
		},
		 _hasError:function () {
		    var externalError = null;
            if (lang.isArray(externalError)) {
                return array.some(this.externalError, function (item) {
                    return !!item;
                });
            } else {
                return !!externalError;
            }
        }

	});
	
	return _EditorMixin;
});
