/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2013, 2014
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"pvr/controller/types/mixins/features/_PatternPropertyControllerMixin",
	"pvr/controller/types/mixins/features/_ChoicesPropertyControllerMixin",
	"pvr/controller/attributes/Attribute",
	"pvr/controller/converters/StringConverter",
	"pvr/controller/converters/IntegerConverter",
	"pvr/controller/converters/BooleanConverter",
	"v11/ewf/model/properties/pvr/controller/validators/StringValidator"
], function(declare, _PatternPropertyControllerMixin, _ChoicesPropertyControllerMixin, Attribute, StringConverter, IntegerConverter, BooleanConverter, StringValidator) {

	/**
	 * @name pvr.controller.types._StringPropertyControllerMixin
	 * @class Mix-in class for custom property controllers of type "string".
	 *        <p>
	 *        Some applications may wish to add custom attributes to property controllers of all types. A recommended
	 *        pattern for this includes the following steps.
	 *        <ul>
	 *        <li>Extend the {@link pvr.controller._PropertyController} class to include the custom attributes.</li>
	 *        <li>For each supported data type, extend the custom property controller class and mix in the
	 *        corresponding type-specific mix-in class, specifically the
	 *        {@link pvr.controller.types._StringPropertyControllerMixin} class for properties of type "string".
	 *        </p>
	 * @augments pvr.controller.types.mixins.features._PatternPropertyControllerMixin,
	 *           pvr.controller.types.mixins.features._ChoicesPropertyControllerMixin
	 * @public
	 */
	return declare("v11.ewf.model.properties.pvr.controller.types.mixins._StringPropertyControllerMixin", [
		_PatternPropertyControllerMixin,
		_ChoicesPropertyControllerMixin
	], {
		/** @lends pvr.controller.types.mixins._StringPropertyControllerMixin.prototype */

		/**
		 * Overloaded to include the pattern, choices and string attributes.
		 */
		createTypeMixinAttributes: function() {
			this.createPatternAttributes();
			this.createChoicesAttributes();
			this.addAttribute(new Attribute({
				controller: this,
				name: "minLength",
				defaultValue: null,
				valueDependsOn: true,
				errorDependsOn: true,
				converter: IntegerConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "maxLength",
				defaultValue: null,
				valueDependsOn: true,
				errorDependsOn: true,
				converter: IntegerConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "minMessage",
				defaultValue: "",
				valueDependsOn: true,
				errorDependsOn: true,
				converter: StringConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "maxMessage",
				defaultValue: "",
				valueDependsOn: true,
				errorDependsOn: true,
				converter: StringConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "rangeMessage",
				defaultValue: "",
				valueDependsOn: true,
				errorDependsOn: true,
				converter: StringConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "autoTruncate",
				typeIsBoolean: true,
				defaultValue: false,
				valueDependsOn: true,
				errorDependsOn: true,
				converter: BooleanConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "requiredCase",
				defaultValue: "normal",
				valueDependsOn: true,
				errorDependsOn: true,
				converter: StringConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "autoAdjustCase",
				typeIsBoolean: true,
				defaultValue: false,
				valueDependsOn: true,
				errorDependsOn: true,
				converter: BooleanConverter.Default
			}));
		},

		/**
		 * Overloaded to create a {@link pvr.controller.converters.StringConverter} object.
		 * 
		 * @returns The string converter.
		 */
		createConverter: function() {
			return new StringConverter(this);
		},

		/**
		 * Overloaded to create a {@link pvr.controller.validators.StringValidator} object.
		 * 
		 * @returns The string validator.
		 */
		createValidator: function() {
			return new StringValidator(this);
		},

		/**
		 * Determines whether the "minLength" setting in the editor widget will be obtained from the controller or the
		 * view layer.
		 * 
		 * @param controllerValue
		 *            The controller setting.
		 * @param viewValue
		 *            The view setting.
		 * @returns The selected setting.
		 */
		reconcileMinLengthSetting: function(controllerValue, viewValue) {
			viewValue = viewValue === undefined ? null : viewValue;
			return controllerValue !== null && viewValue !== null ? Math.max(controllerValue, viewValue) : controllerValue !== null ? controllerValue : viewValue;
		},

		/**
		 * Determines whether the "maxLength" setting in the editor widget will be obtained from the controller or the
		 * view layer.
		 * 
		 * @param controllerValue
		 *            The controller setting.
		 * @param viewValue
		 *            The view setting.
		 * @returns The selected setting.
		 */
		reconcileMaxLengthSetting: function(controllerValue, viewValue) {
			viewValue = viewValue === undefined ? null : viewValue;
			return controllerValue !== null && viewValue !== null ? Math.min(controllerValue, viewValue) : controllerValue !== null ? controllerValue : viewValue;
		},

		/**
		 * Determines whether the "requiredCase" setting in the editor widget will be obtained from the controller or
		 * the view layer.
		 * 
		 * @param controllerValue
		 *            The controller setting.
		 * @param viewValue
		 *            The view setting.
		 * @returns The selected setting.
		 */
		reconcileRequiredCaseSetting: function(controllerValue, viewValue) {
			controllerValue = controllerValue || "normal";
			viewValue = viewValue || "normal";
			return controllerValue !== "normal" ? controllerValue : viewValue;
		}

	});

});
