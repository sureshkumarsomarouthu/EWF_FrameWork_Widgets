/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2013, 2014
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/has",
	"dojo/dom-class",
	"idx/form/TextBox",
	//"pvr/widget/editors/mixins/_EditorMixin",
	"v11/ewf/model/properties/pvr/widget/editors/mixins/_EditorMixin",
	"pvr/widget/editors/mixins/_TextMixin",
	"dojo/i18n!dijit/form/nls/validate"
], function(declare, lang, has, domClass, TextBox, _EditorMixin, _TextMixin, dijitResources) {

	var defaultPattern = ".*";

	/**
	 * @name pvr.widget.editors.TextBoxEditor
	 * @class Provides a text box editor widget for editing properties of type "string".
	 * @augments idx.form.TextBox, pvr.widget.editors.mixins._EditorMixin, pvr.widget.editors.mixins._TextMixin,
	 */
	var TextBoxEditor = declare("v11.ewf.model.properties.pvr.widget.editors.TextBoxEditor", [
		TextBox,
		_EditorMixin,
		_TextMixin
	], {
		/** @lends pvr.widget.editors.TextBoxEditor.prototype */

		instantValidate: true,

		selectOnClick: true,

		editorClass: "pvrTextBoxEditor",

		textDir: has("text-direction"),

		_setPatternAttr: function(pattern) {
			this.inherited(arguments, [
				pattern || defaultPattern
			]);

			try {
				// validate pattern
				this.isValid();
			} catch (e) {
				// invalid pattern, reset to default pattern.
				this.inherited(arguments, [
					defaultPattern
				]);
			}
		}
	});

	lang.mixin(TextBoxEditor, {

		adjustValue: function(value, editorParams) {
			var valueAdjustment = _TextMixin.adjustValue(value, editorParams);
			return valueAdjustment.error ? valueAdjustment : {
				value: valueAdjustment.value,
				error: TextBoxEditor._computeError(valueAdjustment.value, editorParams)
			};
		},

		_computeError: function(value, editorParams) {
			if (value !== null) {
				// Validate the pattern.
				if (editorParams.pattern && editorParams.pattern !== defaultPattern) {
					var re = TextBoxEditor._computeRegExp(editorParams.pattern);
					if (re) {
						var valid = (new RegExp("^(?:" + re + ")$")).test(value);
						if (!valid) {
							return editorParams.invalidMessage ? editorParams.invalidMessage : dijitResources.invalidMessage;
						}
					}
				}
			}

			// The value is valid.
			return null;
		},

		_computeRegExp: function(pattern) {
			var p = pattern;
			var partialre = "";
			// parse the regexp and produce a new regexp that matches valid subsets
			// if the regexp is .* then there's no use in matching subsets since everything is valid
			if (p !== ".*") {
				p.replace(/\\.|\[\]|\[.*?[^\\]{1}\]|\{.*?\}|\(\?[=:!]|./g, function(re) {
					switch (re.charAt(0)) {
					case '{':
					case '+':
					case '?':
					case '*':
					case '^':
					case '$':
					case '|':
					case '(':
						partialre += re;
						break;
					case ")":
						partialre += "|$)";
						break;
					default:
						partialre += "(?:" + re + "|$)";
						break;
					}
				});
			}
			try { // this is needed for now since the above regexp parsing needs more test verification
				"".search(partialre);
			} catch (e) { // should never be here unless the original RE is bad or the parsing is bad
				partialre = pattern;
				console.warn('RegExp error in pvr.widget.editors.TextBoxEditor: ' + pattern);
				return null;
			} // should never be here unless the original RE is bad or the parsing is bad
			return p;
		}

	});

	return TextBoxEditor;
});
