/**
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2013, 2014
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"pvr/controller/validators/_Validator",
	"pvr/controller/validators/mixins/_RequiredValidatorMixin",
	"pvr/controller/validators/mixins/_LengthValidatorMixin",
	"pvr/controller/validators/mixins/_CaseValidatorMixin",
	"pvr/controller/validators/mixins/_ChoicesValidatorMixin",
	"pvr/controller/value/Value"
], function(declare, _Validator, _RequiredValidatorMixin, _LengthValidatorMixin, _CaseValidatorMixin, _ChoicesValidatorMixin, Value) {

	/**
	 * @name pvr.controller.validators.StringValidator
	 * @class Extends {@link pvr.controller.validators._Validator} to validate values of type "string".
	 *        <p>
	 *        Values of type "string" are represented by JavaScript string primitives.
	 *        </p>
	 * @augments pvr.controller.validators._Validator, pvr.controller.validators.mixins._RequiredValidatorMixin,
	 *           pvr.controller.validators._LengthValidatorMixin, pvr.controller.validators._CaseValidatorMixin,
	 *           pvr.controller.validators._ChoicesValidatorMixin
	 */
	return declare("v11.ewf.model.properties.pvr.controller.validators.StringValidator", [
		_Validator,
		_RequiredValidatorMixin,
		_LengthValidatorMixin,
		_CaseValidatorMixin,
		_ChoicesValidatorMixin
	], {
		/** @lends pvr.controller.validators.StringValidator.prototype */

		/**
		 * Validate the specified value.
		 * 
		 * @param value
		 *            The value.
		 * @param ignoreChoices
		 *            Indicates whether choices should be considered in the validation.
		 * @return The validation error message or null if valid.
		 */
		validate: function(value, ignoreChoices) {
			value = new Value(value);
			var error = null;
			error = this.validateRequired(error, value);
			//error = this.validateLength(error, value);
			error = this.validateCase(error, value);
			if (!ignoreChoices) {
				error = this.validateChoices(error, value);
			}
			return error;
		}

	});

});
