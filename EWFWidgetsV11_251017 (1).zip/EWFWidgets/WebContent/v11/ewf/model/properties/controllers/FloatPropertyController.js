define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/_PropertyController",
	"pvr/controller/types/mixins/_FloatPropertyControllerMixin"
], function(declare, _PropertyController, _FloatPropertyControllerMixin) {
	
	/**
	 * Controller class for a property of type "float".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * <p>
	 * The following attributes are supported by this class in addition to those supported by 
	 * {@link icm.model.properties.controller.types._PropertyController}.
	 * <ul>
	 * <li> places - The number of decimal places allowed.
	 * <li> autoRound - Indicates whether numbers are automatically rounded the specified number of decimal places.
	 * <li> zeroIfNull - Indicates whether null values are automatically coerced to zero.
	 * <li> minValue - The minimum value allowed.
	 * <li> maxValue - The maximum value allowed.
	 * <li> pattern - The validation pattern to be applied to the text.
	 * <li> choices - The choices for the value.
	 * </ul>
	 * 
	 * @name ewf.model.properties.controllers.FloatPropertyController
	 * @class Controller class for property of type "float".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.FloatPropertyController", [_PropertyController, _FloatPropertyControllerMixin], {
		/** @lends  ewf.model.properties.controllers.FloatPropertyController.prototype */
		
	});
	
});

