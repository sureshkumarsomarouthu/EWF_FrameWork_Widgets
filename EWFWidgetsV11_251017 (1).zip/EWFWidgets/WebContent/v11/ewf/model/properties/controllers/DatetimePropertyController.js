define([
	"dojo/_base/declare",	
	"v11/ewf/model/properties/controllers/_PropertyController",
	"pvr/controller/converters/BooleanConverter",
	"pvr/controller/attributes/Attribute",
	"pvr/controller/types/mixins/_DatetimePropertyControllerMixin"
], function(declare, _PropertyController, BooleanConverter,Attribute, _DatetimePropertyControllerMixin) {
	
	/**
	 * Controller class for a property of type "datetime".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * <p>
	 * The following attributes are supported by this class in addition to those supported by 
	 * {@link icm.model.properties.controller.types._PropertyController}.
	 * <ul>
	 * <li> formatLength - The format length. May be "short", "medium", "long" or "full".
	 * <li> datePattern - The date pattern applied when parsing or formatting text.
	 * <li> timePattern - The time pattern applied when parsing or formatting text.
	 * <li> minValue - The minimum value allowed.
	 * <li> maxValue - The maximum value allowed.
	 * <li> choices - The choices for the value.
	 * </ul>
	 * 
	 * @name ewf.model.properties.controllers.DatetimePropertyController
	 * @class Controller class for a property of type "datetime".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.DatetimePropertyController", [_PropertyController, _DatetimePropertyControllerMixin], {
		/** @lends  ewf.model.properties.controllers.DatetimePropertyController.prototype */
		
		createAttributes: function() {
			this.inherited(arguments);	
			this.addAttribute(new Attribute({
				controller: this,
				name: "strict",
				typeIsBoolean: true,
				defaultValue: true,
				valueDependsOn: true,
				converter: BooleanConverter.Default
			}));	
		}
		
	});
	
});

