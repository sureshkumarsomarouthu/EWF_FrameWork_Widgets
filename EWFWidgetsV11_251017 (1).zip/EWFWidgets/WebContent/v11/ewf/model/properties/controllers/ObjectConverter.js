define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/_base/json",
	"pvr/controller/converters/_Converter",
	"dojo/i18n!pvr/nls/common"
], function(declare, lang, array, json, _Converter, Value, resources) {
	
	return declare("v11.ewf.model.properties.controllers.ObjectConverter", _Converter, {
		
		constructor: function(controller) {
			this.controller = controller;
		},
		
		parse: function(value, localized) {
			
			return value;
		}
		
	});
});

