define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/StringPropertyController",
	"pvr/controller/attributes/Attribute",
	"pvr/controller/converters/StringConverter",
	"pvr/controller/converters/IntegerConverter"
], function(declare, StringPropertyController, Attribute, StringConverter, IntegerConverter) {
	
	/**
	 * Controller class for a property of type "additionalNumbers".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * <p>
	 * The following attributes are supported by this class in addition to those supported by 
	 * {@link icm.model.properties.controller.types._PropertyController}.
	 * <ul>
	 * <li> maxLength - The maximum number of characters allowed.
	 * <li> autoTruncate - Indicates whether automatic truncation is enabled.
	 * <li> requiredCase - The required case. May be "normal", "upper", "lower" or "proper".
	 * <li> autoAdjustCase - Indicates whether automatic case conversion is enabled.
	 * <li> pattern - The validation pattern to be applied to the text.
	 * <li> choices - The choices for the value.
	 * </ul>
	 * 
	 * @name icm.model.properties.controller.types.StringPropertyController
	 * @class Controller class for a property of type "additionalNumbers".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.AdditionalNumbersPropertyController", [ StringPropertyController], {
		/** @lends  ewf.model.properties.controllers.AdditionalNumbersPropertyController.prototype */
		
		type: "additionalNumbers",
		
		createAttributes: function() {
			this.inherited(arguments);
		}
	});
	
});

