define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/_PropertyController",
	"icm/model/properties/controller/types/AttachmentPropertyController"
], function(declare, _PropertyController, AttachmentPropertyController) {
	
	/**
	 * Controller class for a property of type "attachment".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * @name ewf.model.properties.controllers.AttachmentPropertyController
	 * @class Controller class for a property of type "attachment".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.AttachmentPropertyController", [_PropertyController, AttachmentPropertyController], {
		/** @lends  ewf.model.properties.controllers.AttachmentPropertyController.prototype */
				
	});
	
});

