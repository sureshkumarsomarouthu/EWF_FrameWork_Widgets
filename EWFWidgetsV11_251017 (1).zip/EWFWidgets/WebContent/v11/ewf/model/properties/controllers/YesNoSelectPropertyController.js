define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/_PropertyController",
	"icm/model/properties/controller/types/BooleanPropertyController"
], function(declare, _PropertyController, BooleanPropertyController) {
	
	/**
	 * Controller class for a property of type "yesNoSelect".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * <p>
	 * The following attributes are supported by this class in addition to those supported by 
	 * {@link icm.model.properties.controller.types._PropertyController}.
	 * <ul>
	 * <li> falseIfNull - Indicates whether null values are automatically coerced to false.
	 * <li> choices - The choices for the value.
	 * </ul>
	 * 
	 * @name icm.model.properties.controller.types.BooleanPropertyController
	 * @class Controller class for a property of type "boolean".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.YesNoSelectPropertyController", [_PropertyController, BooleanPropertyController], {
		/** @lends  ewf.model.properties.controllers.YesNoSelectPropertyController.prototype */
		
		type: "yesNoSelect"
	
	});
	
});
