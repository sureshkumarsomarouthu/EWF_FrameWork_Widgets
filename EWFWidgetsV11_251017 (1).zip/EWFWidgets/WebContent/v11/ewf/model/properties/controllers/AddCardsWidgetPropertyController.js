define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/StringPropertyController",
	"pvr/controller/attributes/Attribute",
	"pvr/controller/converters/StringConverter",
	"pvr/controller/converters/IntegerConverter",
	"pvr/controller/converters/BooleanConverter",
	"v11/ewf/model/properties/controllers/ObjectConverter"
], function(declare, StringPropertyController, Attribute, StringConverter, IntegerConverter, BooleanConverter, ObjectConverter) {
	
	/**
	 * Controller class for a property of type "AddCardsWidget".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * <p>
	 * The following attributes are supported by this class in addition to those supported by 
	 * {@link icm.model.properties.controller.types._PropertyController}.
	 * <ul>
	 * <li> maxLength - The maximum number of characters allowed.
	 * <li> autoTruncate - Indicates whether automatic truncation is enabled.
	 * <li> requiredCase - The required case. May be "normal", "upper", "lower" or "proper".
	 * <li> autoAdjustCase - Indicates whether automatic case conversion is enabled.
	 * <li> pattern - The validation pattern to be applied to the text.
	 * <li> choices - The choices for the value.
	 * </ul>
	 * 
	 * @name icm.model.properties.controller.types.StringPropertyController
	 * @class Controller class for a property of type "lines".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.AddCardsWidgetPropertyController", [StringPropertyController], {
		/** @lends  ewf.model.properties.controllers.AddCardsWidgetPropertyController.prototype */
		
		type: "AddCardsWidget",
		
		createAttributes: function() {
			this.inherited(arguments);
			this.addAttribute(new Attribute({
				controller: this,
				name: "widgetLimit",
				typeIsBoolean: false,
				defaultValue: false,
				converter: IntegerConverter.Default
			}));  
			this.addAttribute(new Attribute({
				controller: this,
				name: "participantsConfig",
				typeIsBoolean: false,
				defaultValue: false,
				array: true,
				converter: new ObjectConverter(this)
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "allowNullOrBlankValues",
				typeIsBoolean: false,
				defaultValue: false,
				converter: new ObjectConverter(this)
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "buttonLabel",
				typeIsBoolean: false,
				defaultValue: false,
				converter: new StringConverter(this)
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "noOfCols",
				typeIsBoolean: false,
				defaultValue: false,
				converter: IntegerConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "defaultOpen",
				typeIsBoolean: true,
				defaultValue: false,
				converter: BooleanConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "storeJSONData",
				typeIsBoolean: true,
				defaultValue: false,
				converter: BooleanConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				name: "editorArgs",
				typeIsBoolean: false,
				defaultValue: false,
				converter: new ObjectConverter(this)
			})); 
		}
	});
	
});

