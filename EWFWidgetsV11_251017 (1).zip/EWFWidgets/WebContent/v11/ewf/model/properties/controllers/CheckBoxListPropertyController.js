define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/_PropertyController",
	//"icm/model/properties/controller/types/StringPropertyController",
	"v11/ewf/model/properties/controllers/StringPropertyController",
	"pvr/controller/attributes/Attribute",
	"v11/ewf/model/properties/controllers/ObjectConverter",
	"pvr/controller/converters/BooleanConverter"
], function(declare, _PropertyController, StringPropertyController, Attribute, ObjectConverter, BooleanConverter) {
	
	/**
	 * Controller class for a property of type "checkBoxList".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * <p>
	 * The following attributes are supported by this class in addition to those supported by 
	 * {@link icm.model.properties.controller.types._PropertyController}.
	 * <ul>
	 * <li> falseIfNull - Indicates whether null values are automatically coerced to false.
	 * <li> choices - The choices for the value.
	 * </ul>
	 * 
	 * @name icm.model.properties.controller.types.BooleanPropertyController
	 * @class Controller class for a property of type "boolean".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.CheckBoxListPropertyController", [_PropertyController, StringPropertyController], {
		/** @lends  ewf.model.properties.controllers.CheckBoxListPropertyController.prototype */
		
		type: "checkBoxList",
		
		createAttributes: function() {
			this.inherited(arguments);
			this.addAttribute(new Attribute({
				controller: this,
				name: "options",
				typeIsBoolean: false,
				defaultValue: null,
				array: true,
				converter: new ObjectConverter(this)
			}));  
			this.addAttribute(new Attribute({
				controller: this,
				name: "multiple",
				typeIsBoolean: true,
				defaultValue: true,
				valueDependsOn: true,
				converter: BooleanConverter.Default
			})); 
		}
	
	});
	
});
