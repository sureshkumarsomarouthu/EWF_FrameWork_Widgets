define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/_PropertyController",
	"icm/model/properties/controller/types/GroupPropertyController"
], function(declare, _PropertyController, GroupPropertyController) {
	
	/**
	 * Controller class for a property of type "group".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * @name ewf.model.properties.controllers.GroupPropertyController
	 * @class Controller class for a property of type "group".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.GroupPropertyController", [_PropertyController, GroupPropertyController], {
		/** @lends  ewf.model.properties.controllers.GroupPropertyController.prototype */
		
		
	});
	
});

