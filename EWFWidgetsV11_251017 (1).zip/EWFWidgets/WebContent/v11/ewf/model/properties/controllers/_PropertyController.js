define([
	"dojo/_base/declare",
	"icm/model/properties/controller/types/_PropertyController",
	"pvr/controller/attributes/Attribute",
	"pvr/controller/converters/BooleanConverter",
	"pvr/controller/converters/StringConverter"
], function(declare, _PropertyController, Attribute, BooleanConverter, StringConverter) {
	
	/**
	 * Base controller class for a ewf property.
	 * 
	 * @name ewf.model.properties.controllers._PropertyController
	 * @class Base controller class for a property.
	 * @public
	 */
	return declare("v11.ewf.model.properties.controllers._PropertyController", [_PropertyController], {
		/** @lends  ewf.model.properties.controllers._PropertyController.prototype */
		
		createAttributes: function() {
			this.inherited(arguments);
			this.addAttribute(new Attribute({
				controller: this,
				name: "logicRequired",
				typeIsBoolean: true,
				defaultValue: false,
				converter: BooleanConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				typeIsBoolean: false,
				name: "failureType",
				defaultValue: null,
				converter: StringConverter.Default
			}));
			this.addAttribute(new Attribute({
				controller: this,
				typeIsBoolean: true,
				name: "updated",
				defaultValue: false,
				converter: BooleanConverter.Default
			}));
		}
	
	});
	
});
