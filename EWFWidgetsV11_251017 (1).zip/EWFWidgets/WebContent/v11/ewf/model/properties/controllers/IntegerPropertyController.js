define([
	"dojo/_base/declare",
	"v11/ewf/model/properties/controllers/_PropertyController",
	"pvr/controller/types/mixins/_IntegerPropertyControllerMixin"
], function(declare, _PropertyController, _IntegerPropertyControllerMixin) {
	
	/**
	 * Controller class for property of type "integer".
	 * 
	 * <p>
	 * A collection of property controllers is created and managed by a {@link icm.model.properties.controller.PropertyCollectionController}
	 * object. This class should not be instantiated directly.
	 * 
	 * <p>
	 * The following attributes are supported by this class in addition to those supported by 
	 * {@link icm.model.properties.controller.types._PropertyController}.
	 * <ul>
	 * <li> autoRound - Indicates whether numbers are automatically rounded the specified number of decimal places.
	 * <li> zeroIfNull - Indicates whether null values are automatically coerced to zero.
	 * <li> minValue - The minimum value allowed.
	 * <li> maxValue - The maximum value allowed.
	 * <li> pattern - The validation pattern to be applied to the text.
	 * <li> choices - The choices for the value.
	 * </ul>
	 * 
	 * @name ewf.model.properties.controllers.IntegerPropertyController
	 * @class Controller class for property of type "integer".
	 * @augments icm.model.properties.controller.types._PropertyController
	 */
	return declare("v11.ewf.model.properties.controllers.IntegerPropertyController", [_PropertyController, _IntegerPropertyControllerMixin], {
		/** @lends  ewf.model.properties.controllers.IntegerPropertyController.prototype */
		
	});
	
});

