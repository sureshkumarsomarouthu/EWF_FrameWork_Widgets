define(["dojo/_base/lang",
        "v11/ewf/widget/dataentry/SugestionListBox",
        "v11/ewf/widget/dataentry/SugestionListBoxFormatter",
        "v11/ewf/widget/dataentry/LinesWidget",
        "v11/ewf/widget/dataentry/MultiColumnsWidget",
        "v11/ewf/widget/dataentry/ContactNumberWidget",
        "v11/ewf/widget/dataentry/SpecialContactNumberWidget",
		"v11/ewf/widget/dataentry/AdditionalNumbersWidget",
		"v11/ewf/widget/dataentry/ShowOrHidePropertiesWidget",
		"v11/ewf/widget/dataentry/PostalCodeSearchWidget",
        "v11/ewf/widget/dataentry/YesNoWidget",
        "v11/ewf/widget/dataentry/SpecialYesNoWidget",
		"v11/ewf/widget/dataentry/CheckBoxWidget",
        "v11/ewf/widget/dataentry/CheckBoxListWidget",
        "v11/ewf/widget/dataentry/DateTextBoxWidget",		
        "v11/ewf/widget/dataentry/RadioButtonSetWidget",
		"v11/ewf/widget/dataentry/DecisionWidget",
		"v11/ewf/widget/dataentry/CPFStatementWidget",
		"v11/ewf/widget/dataentry/AddCardsWidget",
		"v11/ewf/widget/dataentry/CustomRegExpWidget",
		"v11/ewf/widget/dataentry/OthersOptionWidget"],
		function(lang,SugestionListBox,SugestionListBoxFormatter,LinesWidget,MultiColumnsWidget,ContactNumberWidget,
		SpecialContactNumberWidget,AdditionalNumbersWidget,ShowOrHidePropertiesWidget,PostalCodeSearchWidget,
		YesNoWidget,SpecialYesNoWidget,CheckBoxWidget,CheckBoxListWidget,DateTextBoxWidget,RadioButtonSetWidget,
		DecisionWidget,CPFStatementWidget,AddCardsWidget,CustomRegExpWidget,OthersOptionWidget){
	
	var ewfConfig = 
		{editors: {
			editorConfigs: {
				"suggestionList": { // TODO Rename this "group" to be consistent with conventions and CB.
					label: "SuggestionList",
					//editorClass: "v11/ewf/widget/dataentry/SugestionListBox",
					editorClass: SugestionListBox,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px",
					multiEditorRequired: true,
					//formatter: "v11/ewf/widget/dataentry/SugestionListBoxFormatter"
					formatter: SugestionListBoxFormatter
				},
				"showOrHide": { // TODO Rename this "group" to be consistent with conventions and CB.
					label: "Show Or Hide Label",
					//editorClass: "v11/ewf/widget/dataentry/ShowOrHidePropertiesWidget",
					editorClass: ShowOrHidePropertiesWidget,
					defaultFieldWidth: "250px",
					defaultColumnWidth: "250px"
				},
				"postalCodeSearch": { // TODO Rename this "group" to be consistent with conventions and CB.
					label: "Show Or Hide Label",
					//editorClass: "v11/ewf/widget/dataentry/PostalCodeSearchWidget",
					editorClass: PostalCodeSearchWidget,
					defaultFieldWidth: "250px",
					defaultColumnWidth: "250px"
				},
				"CPFStWdgt": { 
					label: "CPF Stmt Wdgt",
					//editorClass: "v11/ewf/widget/dataentry/CPFStatementWidget",
					editorClass: CPFStatementWidget,
					defaultFieldWidth: "250px",
					defaultColumnWidth: "250px"
				},
				"lines": {
					label: "LinesWidget",
					//editorClass: "v11/ewf/widget/dataentry/LinesWidget",
					editorClass: LinesWidget,
					defaultFieldWidth: "100%",
					defaultColumnWidth: "100%"
				},
				"multiColumns": {
					label: "Multiple Columns",
					//editorClass: "v11/ewf/widget/dataentry/MultiColumnsWidget",
					editorClass: MultiColumnsWidget,
					defaultFieldWidth: "100%",
					defaultColumnWidth: "100%"
				},
				"contactNumber": {
					label: "ContactNumberWidget",
					//editorClass: "v11/ewf/widget/dataentry/ContactNumberWidget",
					editorClass: ContactNumberWidget,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},
				"specialContactNumber": {
					label: "ContactNumberWidget",
					//editorClass: "v11/ewf/widget/dataentry/SpecialContactNumberWidget",
					editorClass: SpecialContactNumberWidget,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},
				"additionalNumbers": {
					label: "AdditionalNumbersWidget",
					//editorClass: "v11/ewf/widget/dataentry/AdditionalNumbersWidget",
					editorClass: AdditionalNumbersWidget,
					defaultFieldWidth: "250px",
					defaultColumnWidth: "250px"
				},
				"yesNoSelect": {
					label: "yesNoSelect",
					//editorClass: "v11/ewf/widget/dataentry/YesNoWidget",
					editorClass: YesNoWidget,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},
				"splYesNoSelect": {
					label: "splYesNoSelect",
					//editorClass: "v11/ewf/widget/dataentry/SpecialYesNoWidget",
					editorClass: SpecialYesNoWidget,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},
				"checkBox":{
					label: "checkBoxWidget",
					//editorClass: "v11/ewf/widget/dataentry/CheckBoxWidget",
					editorClass: CheckBoxWidget,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},
				"checkBoxList":{
					label: "checkBoxListWidget",
					//editorClass: "v11/ewf/widget/dataentry/CheckBoxListWidget",
					editorClass: CheckBoxListWidget,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},
				"datetime":{
					label: "DateTextBoxWidget",
					//editorClass: "v11/ewf/widget/dataentry/DateTextBoxWidget",
					editorClass: DateTextBoxWidget,
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},				
				"longString": {
					defaultFieldWidth: "180px"
				},
				"radioButtonSet": {
					label: "ewfRadioButtonSetWidget",
					//editorClass: "v11/ewf/widget/dataentry/RadioButtonSetWidget",
					editorClass: RadioButtonSetWidget,
					minimumFieldWidth: "20px",
					defaultFieldWidth: "180px",
					defaultColumnWidth: "180px"
				},
				"decisionWdgt": {
					label: "DecisionWidget",
					//editorClass: "v11/ewf/widget/dataentry/DecisionWidget",
					editorClass: DecisionWidget,
					defaultFieldWidth: "100%",
					defaultColumnWidth: "100%"
				},
				"AddCardsWidget": {
					label:"Add Cards",
					//editorClass:"v11/ewf/widget/dataentry/AddCardsWidget",
					editorClass:AddCardsWidget,
					defaultFieldWidth: "100%",
					defaultColumnWidth: "100%"
				},
				"CustomRegExpWdgt": { 
					label: "Custom Regular Expression Widget",
					//editorClass: "v11/ewf/widget/dataentry/CustomRegExpWidget",
					editorClass: CustomRegExpWidget,
					defaultFieldWidth: "250px",
					defaultColumnWidth: "250px"
				},
				"OthersOptionWdgt": { 
					label: "Others Option Field Widget",
					//editorClass: "v11/ewf/widget/dataentry/OthersOptionWidget",
					editorClass: OthersOptionWidget,
					defaultFieldWidth: "100%",
					defaultColumnWidth: "100%"
				}
			},
			mappings: {
				types: {
					"lines": {
						both: {
							editorConfigs: ["lines"],
							defaultEditorConfig: "lines"
						}
					},
					"multiColumns": {
						both: {
							editorConfigs: ["multiColumns"],
							defaultEditorConfig: "multiColumns"
						}
					},
					"contactNumber": {
						both: {
							editorConfigs: ["contactNumber"],
							defaultEditorConfig: "contactNumber"
						}
					},
					"specialContactNumber": {
						both: {
							editorConfigs: ["specialContactNumber"],
							defaultEditorConfig: "specialContactNumber"
						}
					},
					"additionalNumbers": {
						both: {
							editorConfigs: ["additionalNumbers"],
							defaultEditorConfig: "additionalNumbers"
						}
					},
					"longString": {
						both: {
							editorConfigs: ["longString"],
							defaultEditorConfig: "longString"
						}
					},
					"suggestionList": {
						both: {
							editorConfigs: ["suggestionList"],
							defaultEditorConfig: "suggestionList"
						}
					},
					"showOrHide": {
						both: {
							editorConfigs: ["showOrHide"],
							defaultEditorConfig: "showOrHide"
						}
					},
					"postalCodeSearch": {
						both: {
							editorConfigs: ["postalCodeSearch"],
							defaultEditorConfig: "postalCodeSearch"
						}
					},
					"CPFStWdgt": {
						both: {
							editorConfigs: ["CPFStWdgt"],
							defaultEditorConfig: "CPFStWdgt"
						}
					},
					"yesNoSelect": {
						both: {
							editorConfigs: ["yesNoSelect"],
							defaultEditorConfig: "yesNoSelect"
						}
					},
					"splYesNoSelect": {
						both: {
							editorConfigs: ["splYesNoSelect"],
							defaultEditorConfig: "splYesNoSelect"
						}
					},					
					"checkBox": {
						both: {
							editorConfigs: ["checkBox"],
							defaultEditorConfig: "checkBox"
						}
					},
					"checkBoxList": {
						both: {
							editorConfigs: ["checkBoxList"],
							defaultEditorConfig: "checkBoxList"
						}
					},
					"datetime": {
						both: {
							editorConfigs: ["datetime"],
							defaultEditorConfig: "datetime"
						}
					},					
					"radioButtonSet": {
						both: {
							editorConfigs: ["radioButtonSet"],
							defaultEditorConfig: "radioButtonSet"
						}
					},
					"decisionWdgt": {
						both: {
							editorConfigs: ["decisionWdgt"],
							defaultEditorConfig: "decisionWdgt"
						}
					},
					"CustomRegExpWdgt": {
						both: {
							editorConfigs: ["CustomRegExpWdgt"],
							defaultEditorConfig: "CustomRegExpWdgt"
						}
					},
					"AddCardsWidget": {
						both: {
							editorConfigs: ["AddCardsWidget"],
							defaultEditorConfig: "AddCardsWidget"
						}
					},
					"OthersOptionWdgt": {
						both: {
							editorConfigs: ["OthersOptionWdgt"],
							defaultEditorConfig: "OthersOptionWdgt"
						}
					}
				}
			}
		}
	};
	
	return ewfConfig;
});