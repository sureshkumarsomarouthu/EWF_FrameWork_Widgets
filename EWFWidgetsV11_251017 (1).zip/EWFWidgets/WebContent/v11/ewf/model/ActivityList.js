/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012, 2013 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/json",
	"ecm/model/_ModelObject",
	"ecm/model/ResultSet",
	"dojo/text!./ActivityList2.json",
    "dojo/text!./ActivityList3.json"
    ], function(declare, lang, JSON, _ModelObject, ResultSet, ActivityListJson2, ActivityListJson3){

	/**
	 * Constructor
	 *
	 * @param properties
	 *            The properties for the model object. The properties can be any of the public fields as defined below
	 *            and on ecm.model._ModelObject.
	 * @name ecm.model.ActivityList
	 * @class Represents a list of activity items. For routing IBM Content Manager documents, this class represents an IBM
	 *        Content Manager activity list.
	 * @augments ecm.model._ModelObject
	 */
	return declare("v11.ewf.model.ActivityList", [
		_ModelObject
	], {
		/** @lends ecm.model.ActivityList.prototype */

		/**
		 * A description to use for the activity list.
		 */
		description: null,

		/**
		 * An instance of {@link ecm.model.Repository} for the repository containing or owning this activity list.
		 */
		repository: null,
		
		/**
         * The parent Case of these activity items.
         * @public
         */
		parentCase: null,	

		/**
		 * Retrieve the activity items in this activity list.
		 *
		 * @param callback
		 *            A function that is called when the activity items have been retrieved. When the function is called, an
		 *            instance of {@link ecm.model.ResultSet} is passed as a single argument which provides access to
		 *            the activity items.
	     * @param status
		 *            A string array indicating which status the activity items are retrieved.
		 	 * @param orderBy
		 *            A string value indicating the column property to order the result set by.
		 * @param descending
		 *            A boolean value indicating the direction of the sort. True is descending.
		 */
		retrieveActivityItems: function(callback, status, orderBy, descending) {
			this.logEntry("retrieveActivityItems");
			
			requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.caseId = this.parentCase.id;
			requestParams.caseType = this.parentCase.getCaseType().id;
			requestParams.method = "listActivity";
			if(status.length > 0){
				requestParams.includeStatus = status.toString();
			}
			
			requestCompleteCallback = lang.hitch(this, function(response) {
				this._retrieveActivityItemsCompleted(response, callback);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFActivityService", 
			"text/json",
			{
    	            requestParams: requestParams,
    	            requestCompleteCallback: requestCompleteCallback
					
			});
			this.logExit("retrieveActivityItems");
			return request;
		},

		_retrieveActivityItemsCompleted: function(response, callback) {
			this.logEntry("_retrieveActivityItemsCompleted");

			response.repository = this.repository;
			response.parentFolder = this;
			response.setType = "Activity";
			var results = new ResultSet(response);
			callback(results);
			this.logExit("_retrieveActivityItemsCompleted");
		},

		_getActivityItemIDsParam: function(activityItems) {
			var activityIDsParam = '{';
			for ( var i in activityItems) {
				activityIDsParam = activityIDsParam + '"activityItemId' + i + '":"' + activityItems[i].id + '",';
			}
			activityIDsParam = activityIDsParam.substring(0, activityIDsParam.length - 1) + '}';
			return activityIDsParam;
		},

		/**
		 * Event fired when the ActivityList has been updated.
		 *
		 * @param ActivityList
		 *            A pointer to this {@link ecm.model.ActivityList} object.
		 */
		onRefreshActivityList: function(ActivityList) {
			// event for refresh activity items for this ActivityList
		}
	});
});
