/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012, 2013 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/json",
	"ecm/model/_ModelObject",
    "icm/model/_Utils",
	"dojo/text!./AdviceTemplateList.json",
    "dojo/text!./AdviceTemplateDetail.json"
    ], function(declare, lang, JSON, _ModelObject, _Utils, templateList, templateDetail){

	/**
	 * Constructor
	 *
	 * @param properties
	 *            The properties for the model object. The properties can be any of the public fields as defined below
	 *            and on ecm.model._ModelObject.
	 * @name ecm.model.Advice
	 * @class Represents a list of Advice templates and template detail.
	 * @augments ecm.model._ModelObject
	 */
	return declare("v11.ewf.model.Advice", [
		_ModelObject
	], {
		/** @lends ecm.model.Advice.prototype */


		/**
		 * An instance of {@link ecm.model.Repository} for the repository containing or owning this activity list.
		 */
		repository: null,
		
		/**
         * The parent Case of these advice templates.
         * @public
         */
		parentCase: null,	

		/**
		 * Retrieve the Advice Templates.
		 *
		 * @param callback
		 *            A function that is called when the Advice template list have been retrieved. 
		 */
		retrieveAdviceTemplates: function(callback) {
			this.logEntry("retrieveAdviceTemplates");
			
			requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.caseType = this.parentCase.getCaseType().id;
			requestParams.method = "listTemplate";
			
			requestCompleteCallback = lang.hitch(this, function(response) {
				this._retrieveAdviceTemplatesCompleted(response, callback);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFAdviceService", 
			"text/json",
			{
    	            requestParams: requestParams,
    	            requestCompleteCallback: requestCompleteCallback,
    	            requestFailedCallback: requestCompleteCallback					
			});
			this.logExit("retrieveAdviceTemplates");
			return request;
		},

		_retrieveAdviceTemplatesCompleted: function(response, callback) {
			this.logEntry("_retrieveAdviceTemplatesCompleted");
			
			//response = dojo.fromJson(templateList);
			
			callback(response);
			
			this.logExit("_retrieveAdviceTemplatesCompleted");
		},

		/**
		 * Retrieve the Advice Template detail.
		 *
		 * @param callback
		 *            A function that is called when the Advice template detail was retrieved. 
		 * @param templateName
		 *            Which template detail need to get.
		 * @param prefillValue
		 *            Boolean, Default is true; 
		 */
		retrieveAdviceTemplateDetail: function(callback, templateName, prefillValue) {
			this.logEntry("retrieveAdviceTemplateDetail");
			
			requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.caseId = this.parentCase.id;
			requestParams.template = templateName;
			requestParams.prefillValue = prefillValue;
			requestParams.method = "getTemplateData";
			
			requestCompleteCallback = lang.hitch(this, function(response) {
				this._retrieveAdviceTemplateDetailCompleted(response, callback);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFAdviceService", 
			"text/json",
			{
    	            requestParams: requestParams,
    	            requestCompleteCallback: requestCompleteCallback,
    	            requestFailedCallback: requestCompleteCallback	
			});
			
			this.logExit("retrieveAdviceTemplateDetail");
			return request;
		},

		_retrieveAdviceTemplateDetailCompleted: function(response, callback) {
			this.logEntry("_retrieveAdviceTemplateDetailCompleted");

			//response = dojo.fromJson(templateDetail);			
			callback(response);
			
			this.logExit("_retrieveAdviceTemplateDetailCompleted");
		},
		
		/**
		 * Generate Advice.
		 *
		 * @param callback Callback function called with this ActivityEditable object as an argument
         *                 when the request completes. 
		 */
		generateAdvice: function(callback, errCallback, adviceFields, adviceTemplate, adviceTemplateName) {
			this.logEntry("generateAdvice");
			
			requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.caseId = this.parentCase.id;
			requestParams.method = "generateAdvice";
			
			var postContent = {};
	        postContent = {
	        	"attributes": adviceFields,
	        	"template": adviceTemplate,
	        	"displayName": adviceTemplateName
	        };
	        
	        var clientCtx = _Utils.generateClientContext();
			postContent.clientContext = clientCtx;
			
			requestCompleteCallback = lang.hitch(this, function(response) {
				this._retrieveAdviceTemplateDetailCompleted(response, callback);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFAdviceService", 
			"text/json",
			{
    	            requestParams: requestParams,
                    requestBody: postContent,
    	            requestCompleteCallback: requestCompleteCallback,
    	            requestFailedCallback: requestCompleteCallback	
			});
			
			this.logExit("generateAdvice");
			return request;
		},

		_generateAdviceCompleted: function(response, callback) {
			this.logEntry("_generateAdviceCompleted");

			//response = dojo.fromJson(templateDetail);			
			callback(response);
			
			this.logExit("_generateAdviceCompleted");
		}
	});
});
