define(["dojo/_base/declare"], function(declare){
	var UMMFilter = declare("v11.ewf.scriptadapters.UmmFilteringScriptAdapter", null, {
		getProfileFilter: function(ummResponse){
			if(ummResponse == null || ummResponse.username == null || ummResponse.profile == null){
				console.error("Invalid user profile.");
				console.error(ummResponse);
				return;
			}
			console.dir(["umm response", ummResponse]);

			var  customerSegmentStmt = " CustomerSegment = :A ";
			console.log("customerSegmentStmt = " + customerSegmentStmt );
			var accessToStaffStmt = " StaffIndicator = :A ";
			console.log("accessToStaffStmt = " + accessToStaffStmt );

			var queryFields = [];

			var UserCountryValues = [];
			var ProductTypeValues = [];
			var ProcessingCentreValues = [];
			var TransactionTypeValues = [];
			var UserLocationValues = [];

			var combinationMatricesStmt = "";
			var combinationMStmt = "";
			for(var i = 0; i < ummResponse.profile.combinationMatrices.length; i++){
				var combinationMatrice = ummResponse.profile.combinationMatrices[i];
				combinationMStmt = "(";
				if(combinationMatrice.country && combinationMatrice.country.code!=null){
					combinationMStmt = combinationMStmt + " UserCountry ='"+combinationMatrice.country.code+"'";
					
				} else {
						;
				}
				
				if(combinationMatrice.productType && combinationMatrice.productType.code!=null){
					combinationMStmt = combinationMStmt + " AND ProductType = '"+combinationMatrice.productType.code+"'";
					
				} else {
						;
				}
				
				if(combinationMatrice.processingCentre && combinationMatrice.processingCentre.code != null){
					combinationMStmt = combinationMStmt + " AND ProcessingCentre = '"+combinationMatrice.processingCentre.code+"'";
					
				} else {
						;
				}
				
				if(combinationMatrice.transactionType && combinationMatrice.transactionType.code != null){
					combinationMStmt = combinationMStmt + " AND TransactionType = '"+combinationMatrice.transactionType.code+"'";
					
				} else {
						;
				}
				
				if(combinationMatrice.userLocation && combinationMatrice.userLocation.code != null){
					combinationMStmt = combinationMStmt + " AND UserLocation = '"+combinationMatrice.userLocation.code+"'";
					
				} else {
						;
				}

				if(currUserRole.indexOf('Call Back Operator') > -1){
					combinationMStmt = combinationMStmt + " AND UPPER(EWF_SPUserID) != '"+(this.getSolution().getTargetOS().userId + '').toUpperCase()+"'";
					console.log("Inside the Call Back");
					
				} else {
						;
				}

				combinationMStmt = combinationMStmt + " ) ";

				console.log("combinationMStmt  = " + combinationMStmt );
				
				if(i ==0){
					combinationMatricesStmt = "( "+combinationMStmt;
				} else {
					combinationMatricesStmt = combinationMatricesStmt + " OR " + combinationMStmt;
				}	
			}
					

			combinationMatricesStmt = combinationMatricesStmt + " )";
			console.log("combinationMatricesStmt = " + combinationMatricesStmt );
			var customerSegmentValues = [];
			var customerSegmentsStmt = "";

			for(var i = 0; i < ummResponse.profile.segments.length; i++){
				var segment = ummResponse.profile.segments[i];
				customerSegmentStmt = "";
				if(segment && segment.code != null){
					customerSegmentStmt = " CustomerSegment = :A  ";
					customerSegmentValues.push(segment.code);
				} else {
					customerSegmentStmt = " CustomerSegment is null ";
				}

				if(i ==0){
					customerSegmentsStmt = customerSegmentStmt;
				} else {
					customerSegmentsStmt = customerSegmentsStmt + " OR " + customerSegmentStmt;
				}	
			}

			if(customerSegmentsStmt != "") {
				customerSegmentsStmt = customerSegmentsStmt + " OR CustomerSegment = :A ";
			} else {
				customerSegmentsStmt = " CustomerSegment = :A ";
			}
			customerSegmentValues.push("NA");
			console.log("customerSegmentsStmt  = " + customerSegmentsStmt );

			if(customerSegmentValues.length > 0){
				queryFields.push({
					"name":"CustomerSegment",
					"type":"xs:string",
					"value":customerSegmentValues
				});
			}

			var queryFilter = "( "+combinationMatricesStmt + " AND ( " + customerSegmentsStmt + ")  ";

			if(ummResponse.profile.accessToStaff && ummResponse.profile.accessToStaff.name != null){
				var changedName;
				if(ummResponse.profile.accessToStaff.name == "No"){
					changedName = "N";	
					accessToStaffStmt = " StaffIndicator = :A  ";
					queryFields.push({
						"name":"StaffIndicator",
						"type":"xs:string",
						"value":changedName
					});
					queryFilter = queryFilter + "AND  " + accessToStaffStmt;
				} else {
				    
				   accessToStaffStmt = " True ";
				}
			} else {
				accessToStaffStmt = " StaffIndicator is null ";
			}

			queryFilter = queryFilter +" )";



			console.log("queryFilter  = " + queryFilter );
			var dynamicFilters = [];
			console.dir(["queryFields", queryFields]);
			console.dir(["this.inbasketArray", this.inbasketArray]);
			if(this.inbasketArray){
				for(var i = 0; i<this.inbasketArray.length; i++){
					var inbasketItem = this.inbasketArray[i];
					var dynamicFilterJSON = {
						"queueName":inbasketItem.queueName,
						"inbasketName": inbasketItem.inbasketName,
						"hideFilterUI":false,
						"queryFilter": queryFilter,
						"queryFields":queryFields,
						"hideLockedByOther":false
					};
					console.dir(["dynamicFilterJSON",dynamicFilterJSON]);
					var dynamicFilter = icm.model.InbasketDynamicFilter.fromJSON(dynamicFilterJSON);
					dynamicFilters.push(dynamicFilter);
				}

			}

			var newPayload = {"dynamicFilters": dynamicFilters};
			console.dir(["payload", newPayload ]);
			var event = new Array();
			event["name"] = "icm.SendEventPayload";
			event["type"] = "published";
			event["payload"] = newPayload;
			return event;
		}
	});

	return new UMMFilter();
});
