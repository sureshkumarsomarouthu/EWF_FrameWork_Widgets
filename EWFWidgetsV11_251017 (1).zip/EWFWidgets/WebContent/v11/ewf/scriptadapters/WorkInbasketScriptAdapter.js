var currUserRole = ecm.model.desktop.currentRole.id;
var userId = this.getSolution().getTargetOS().userId;

var UMMFilter = require('v11/ewf/scriptadapters/UmmFilteringScriptAdapter');

var buildFiltersfunction = dojo.hitch(this, UMMFilter.getProfileFilter);

var callUmmCallback = dojo.hitch(this, function() {
					if (this.ummUserProfile == null) {
						var params = {};
						params.subUmmPath = encodeURIComponent("/uamusers/userdetails?username="
								+ userId);
						params.operation = "stop";
						ecm.model.Request.invokePluginService(
										"EWFWidgetsPluginv11",
										"EWFUMMService",
										{
											requestParams : params,
											requestCompleteCallback : dojo.hitch(this, function(response) {
												this.ummUserProfile = response;
												buildFiltersfunction(this.ummUserProfile);
											})
										});
					} else {
						var eventPayload = buildFiltersfunction(this.ummUserProfile);
						this.setSentEvent(eventPayload);
					}
				});

if (this.inbasketArray) {
	callUmmCallback();
} else {
	this.role.retrieveWorklists(dojo.hitch(this, function(inbaskets) {
		var ecmInbaskets = inbaskets;
		this.inbasketArray = [];
		for ( var i = 0; i < ecmInbaskets.length; i++) {
			var inbasket = ecmInbaskets[i];
			if (inbasket.queueType != "userQueue") {
				this.inbasketArray.push({
					queueName : inbasket.queueName,
					inbasketName : inbasket.auth_name

				});
			}
		}
		callUmmCallback();
	}), false);
}

return {};