define(["dojo/_base/declare"], function(declare) {
	var Constants = declare("v11.ewf.base.Constants", null, {
		DataType: {
			"DATETIME": "xs:timestamp",
			"STRING": "xs:string",
			"BOOLEAN": "xs:boolean"
		},

		//The EWF data types for fields
		EWF_DataType: {
			"BOOLEAN": "boolean",
			"BINARY_LIST": "binarylist",
			"BOOLEAN_LIST": "booleanlist",
			"BYTE": "byte",
			"DATE": "date",
			"DATE_TIME": "datetime",
			"DATE_TIME_LIST": "datetimelist",
			"DECIMAL": "decimal",
			"DEPENDENT_OBLECT_LIST": "dependentobjectlist",
			"DOUBLE": "double",
			"ENGINE_OBJECT": "engineobject",
			"FLOAT": "float",
			"ID": "id",
			"ID_LIST": "idlist",
			"INDEPENDENT_OBJECT_SET": "independentobjectset",
			"INPUT_STREAM": "inputstream",
			"INTEGER": "integer",
			"INTEGER_LIST": "integerList",
			"OBJECT": "object",
			"STRING": "string",
			"STRING_LIST": "stringlist",
			"STRING_ARRAY": "stringarray",
			"STRING_LIST_REPLACE": "replace"			
		},

		EWF_PropertyName: {
			FIELD_NAME: "FieldName",
			SECTION_FIELD_NAMES: "WF_SectionFieldNames",
			SPECIAL_SECTION_FIELD_NAMES: "WF_SpecialSectionFieldNames",
			
			SECTION_NAME: "WF_SectionName",
			SPECIAL_SECTION_NAME: "WF_SpecialSectionName",
			
			FIELD_COORDINATES: "FieldCoordinates",
			SECTION_COORDINATES: "SectionCoordinates",
			SPECIAL_SECTION_COORDINATES: "WF_SpecialSectionFieldCoordinates",
			MULTI_SECTION_COORDINATES: "WF_MSFieldCoordinates",
			
			DOC_ID: "WF_DocId",
			FIELD_VALUE: "FieldValue",
			FIELD_VALUE_DE1: "FieldValueDE1",
			FIELD_VALUE_DE2: "FieldValueDE2",
			
			DATA_TYPE: "DataType",
			SECTION_DATA_TYPE: "WF_SectionFieldDataTypes",
			SPECIAL_SECTION_DATA_TYPE: "WF_SpecialSectionFieldDataTypes",
			
			SECTION_COLUMN_TYPE: "SectionColumnType", // column count
			
			FIELD_INFO: "FieldInfo",
			
			REASON_MESSAGE: "ReasonMessage",
			REASON_MESSAGE_DE1: "ReasonMessageDE1",
			REASON_MESSAGE_DE2: "ReasonMessageDE2",
			DE_MATCH_RESULT: "DEMatchResult",
			DE_REASON_MATCH: "DEReasonMatch",
			DE3_MATCH: "DE3Match",
			DE3_REASON: "DE3Reason"			
		},
		
		EWF_WorkItemType: {
			FIELD: "Field",
			SECTION: "Section",
			SPECIAL_SECTION: "SpecialSection",
			MULTI_SECTION: "MultiSection"
		},
		
		EWF_DEReasonMessage: {
			ENTER: "Enter Pressed",
			CLOSE: "Close",
			UNCLEAR_IMAGE: "Unclear Image",
			ALTERED_IMAGE: "Altered Image"
		},
		
		EWF_DEStepName: {
			DE1_NUMERIC: "DE1 Numeric",
			DE1_ALPHANUMERIC: "DE1 AlphaNumeric",
			DE1_PROCESS: "DE1 Process",
			DE2_NUMERIC: "DE2 Numeric",
			DE2_ALPHANUMERIC: "DE2 AlphaNumeric",
			DE2_PROCESS: "DE2 Process",
			DE3_PROCESS: "DE3 Process"
		},
		
		SolutionPrefix: {
			"CCA": "COPC",
			"OTT": "EWF",
			"COA": "AMT"
		},
		
		/**
         * Constants for ewf coordination topics. It contains the following string type properties:
         * <ul>
         *  <li><b>MANUALPROCESSINGROUTEHANDLE</b>       the topic specially for a coordination step for page widgets to accept user inputs and processing on manual processing step(e.g. call External Data Service).</li>
         *  <li><b>CALLBACKROUTEHANDLE</b>       the topic specially for a coordination step for page widgets to accept user inputs and processing on call back step(e.g. call External Data Service).</li>
         *  <li><b>DRROUTEHANDLE</b>       the topic specially for a coordination step for page widgets to processing on DR step.</li>
         *  <li><b>REVIEWROUTEHANDLE</b>       the topic specially for a coordination step for page widgets to accept user inputs and processing on review step(e.g. call External Data Service).</li>
         *  <li><b>EXCEPTIONROUTEHANDLE</b>       the topic specially for a coordination step for page widgets to accept user inputs and processing on exception handling step(e.g. call External Data Service).</li>
         *  <li><b>COMMIT</b>       the topic for a coordination step for page widgets to accept user inputs and processing(e.g. call External Data Service).</li>
         *  <li><b>VALIDATE</b>     the topic for a coordination step for page widgets to do data validation.</li>
         *  <li><b>BEFORESAVE</b>   the topic for a coordination step for page widgets to do pre-processing before save.</li>
         *  <li><b>SAVE</b>         the topic for a coordination step for page widgets to do processing when save.</li>
         *  <li><b>AFTERSAVE</b>    the topic for a coordination step for page widgets to do post-processing after save.</li>
         *  <li><b>BEFORECOMPLETE</b>       the topic for a coordination step for page widgets to do pre-processing before complete activity.</li>
         *  <li><b>COMPLETE</b>     the topic for a coordination step for page widgets to do processing when complete activity.</li>
         *  <li><b>AFTERCOMPLETE</b>    the topic for a coordination step for page widgets to do post-processing after complete activity.</li>
         *  <li><b>BEFORECANCEL</b>     the topic for a coordination step for page widgets to do pre-processing before cancel a editing/adding an activity.</li>
         *  <li><b>CANCEL</b>           the topic for a coordination step for page widgets to do processing when cancel a editing/adding an activity.</li>
         *  <li><b>AFTERCANCEL</b>      the topic for a coordination step for page widgets to do post-processing after cancel a editing/adding an activity.</li>
         *  <li><b>LOADWIDGET</b>           the topic for a coordination step for page widgets to tell it's in ready state, which means all initialization completed.</li>
         *  <li><b>AFTERLOADWIDGET</b>      the topic for a coordination step for telling page widgets that all page widgets which participates in LOADWIDGET step are all in ready state. In the context of the step, there is an attribute widgetLoadTime which tell the exactly the ready time. </li>
         *  <li><b>BEFOREHIDE</b>       the topic for a coordination step for page widgets to do pre-processing before hiding the details of activity.</li>
         *  <li><b>HIDE</b>     the topic for a coordination step for page widgets to do processing when hiding the details of activity.</li>
         *  <li><b>AFTERHIDE</b>    the topic for a coordination step for page widgets to do post-processing after hiding the details of activity.</li>
          * </ul>
         */		
		
		EWF_CoordTopic:{
			MANUALPROCESSINGROUTEHANDLE: "MANUALPROCESSINGROUTEHANDLE",
			CALLBACKROUTEHANDLE: "CALLBACKROUTEHANDLE",
			DRROUTEHANDLE: "DRROUTEHANDLE",// added by rahul for DR
			REVIEWROUTEHANDLE: "REVIEWROUTEHANDLE",
			EXCEPTIONROUTEHANDLE: "EXCEPTIONROUTEHANDLE",
			COMMIT: "ACTIVITY_COMMIT",
            VALIDATE: "ACTIVITY_VALIDATE",
            BEFORESAVE: "ACTIVITY_BEFORESAVE",
            SAVE: "ACTIVITY_SAVE",
            AFTERSAVE: "ACTIVITY_AFTERSAVE",
            BEFORECOMPLETE: "ACTIVITY_BEFORECOMPLETE",
            COMPLETE: "ACTIVITY_COMPLETE",
            AFTERCOMPLETE: "ACTIVITY_AFTERCOMPLETE",
            BEFORECANCEL: "ACTIVITY_BEFORECANCEL",
            CANCEL: "ACTIVITY_CANCEL",
            AFTERCANCEL: "ACTIVITY_AFTERCANCEL",
            LOADWIDGET: "ACTIVITY_LOADWIDGET",
            AFTERLOADWIDGET: "ACTIVITY_AFTERLOADWIDGET",
            BEFOREHIDE:"ACTIVITY_BEFOREHIDE",
            HIDE:"ACTIVITY_HIDE",
            AFTERHIDE:"ACTIVITY_AFTERHIDE",
            BEFOREFOLLOWUP:"ACTIVITY_BEFOREFOLLOWUP",
            FOLLOWUP:"ACTIVITY_FOLLOWUP",
            AFTERFOLLOWUP:"ACTIVITY_AFTERFOLLOWUP",
            BEFOREADVICE:"BEFOREADVICE",
            ADVICE:"ADVICE",
            AFTERADVICE:"AFTERADVICE",
            SIGNATUREPROCESSINGROUTEHANDLE: "SPCOMPLETE",
            DATAPOSTADVICE: "DATAPOSTADVICE"
		},

        /**
         * Constants for the context of coordination topics carry through all steps of a coordination.
         * <ul>
         *  <li><b>ACTIVITY</b>     indicating the coordination is for the operation on an activity if its true.</li>
         * </ul>
         */
        EWF_CoordContext: {
            ACTIVITY: "FORACTIVITY",
			ACTIVITYTYPE: "ACTIVITYTYPE",
			ACTIVITYID: "ACTIVITYID",
			ACTIVITYRESPONSE:"ACTIVITYRESPONSE"
        },
		
		/**
         * Constants for the dispatch of workitem.
         * <ul>
         *  <li><b>PEND</b>the pend dispatch for a work item.</li>
		 *  <li><b>UNPEND</b>the unpend dispatch for a work item.</li>
		 *  <li><b>EXCEPTION</b>the exception dispatch for a work item.</li>
		 *  <li><b>COMPLETE</b>the complete dispatch for a work item.</li>
		 *  <li><b>REJECT</b>the reject dispatch for a work item.</li>
		 *  <li><b>RERUN</b>the re-run dispatch for a work item.</li>
         * </ul>
         */
        EWF_DISPATCH: {
            PEND: "Pend",
			UNPEND: "Unpend",
			EXCEPTION: "Exception",
			COMPLETE: "Complete",
			REJECT: "Reject",
			RESUME: "Resume",
			RERUN: "AP Rule Rerun",
			NOTIFYSCANHUB: "Notify ScanHub",// added by rahul for DR
			ROUTETOORPHAN: "Route to Orphan",
			ROUTETOOC:"Route to OC",
			RETURNTODR:"Return to DR",
			ACCEPT: "Accept",
			SENDTOCOPC:"Send To COPC",
			SENDTOPFS:"Send To PFS"
        },
		
		/**
         * Constants for the status of acitivity.
         * <ul>
         *  <li><b>PENDREPAIR</b>  the status of Pend-Repair.</li>
		 *  <li><b>PENDREVIEW</b>  the status of Pend-Review.</li>
		 *  <li><b>ERROR</b>  the status of Error.</li>
		 *  <li><b>FLAGGED</b>  the status of Flagged.</li>
		 *  <li><b>FOLLOWUPCB</b>  the status of Follow-up(CB).</li>
		 *  <li><b>FOLLOWUPEM</b>  the status of Follow-up(EM).</li>
		 *  <li><b>REVIEWED</b>  the status of Reviewed.</li>
		 *  <li><b>OVERRIDEN</b>  the status of Overridden.</li>
		 *  <li><b>FAILED:</b>  the status of Failed.</li>
         * </ul>
         */
        EWF_AcitivityStatus: {
            PENDREPAIR: "Pend-Repair",
			PENDREVIEW: "Pend-Review",
			ERROR: "Error",
			FLAGGED: "Flagged",
			FOLLOWUPCB: "Follow-up(CB)",
			FOLLOWUPEM: "Follow-up(EM)",
			REVIEWED: "Reviewed",
			OVERRIDEN: "Overridden",
			FAILED: "Failed"
        },
        
        EWF_CallBackChecklistProperty: "EWS_CallBackCheckList",
		
		//Added by Purna - New constants introduced to handle reused props in diff solutions. For any new processes reusing props from diff sols can be included here.
		"Solution_Reused_Prefixes": {
			"COPC": ["EWS", "EWF", "AMT", "EWFSV"],
			"AMT": ["EWS", "EWF", "COPC", "EWFSV"]
		},
		//End
		
		//Added by Rahul - enable the annotations to a specific solution 
		/*
			Solution prefix : specify True if annotation should enable or false to disable - If othere solution prefix did not specify by default annotations will be disable  
		*/
		EWF_ANNOTATION_ENABLE: {
			"COPC" : "true",
			"LNOP" : "true",
			"EWFSV" : {"EWS_TransactionType":["CCAP","DCAP","RECR","RTTR"]} //Enable only for few transaction types
		},
		//End
		
		//Added by Purna - The Util js works on the global Constants variable. Changing the prefix model from current sol prefix to process specific prefix which can be configured here
		//Verify the Plugin js file for further information
		"Global_Constants_Prefix": {
			//"CaseTypeName": "PrefixSpecifiedInPluginJs"
			"COPC_DebitCard": "DC",
			"COPC_PermanentLineAdjustment": "PLA",
			"AMT_OnlineAccountOpening": "OAO"
		},
		//End
		
		//Added by Purna - For PTH Activities Complete shouldn't prompt Override/Fail dialog.So special handling is required for handling these
		//Activities. Configure all those activities here for future processes too.
		"PTH_Activities": ["COPC_PTHSecondPass","COPC_PTHIncomeUpdate","COPC_PostToHost","COPC_DC_PostToHostCheck","COPC_PLA_PosttoHostCheck"],
		//End
		
		//Added by Purna for data post advice dialog
		//Added the other role names for COA July QR.
		"ROLE_NAMES": {
			"MANUAL_PROCESSING": "Manual Processing Operator",
			"SIGNATURE_PROCESSING":"Signature Processing Operator",
			"REVIEWER":"Review Operator",
			"CALLBACK":"Call Back Operator",
			"FORM_DE_OPERATOR":"Form Data Entry Operator",
			"SNP_MANUAL_PROCESSING":"Manual Processing SNP",
			"SNP_REVIEWER":"Reviewer SNP",
			"SNP_CALLBACK":"Callback SNP"
			
		},
		//End
		
		//Added by Purna for PBDocArchival changes - Primary document class name
		PRIMARY_DOCUMENT_CLASS: "EWSDocument",
		//End change
		
		//Added By Sagar for DE Corp Contact Person Issue
		ARRAY_SEPERATOR:"|||", 
		//End change
		
		//Added by Purna for OTT Bulk Print changes. Configure the note to be displayed in the Inbasket here
		"BULK_PRINT_NOTE": "Please peform Bulk Print immediately after login",
		//Case Reference Number property
		"CASE_REF_NUMBER_PROP": "EWS_CaseReferenceNumber",
		//End changes by Purna
		
		//Added by Purna for L&S - Redactions info property symbolic name
		"REDACTIONS_CASE_FIELD": "EWS_ExistingAddressInfo",
		//End change by Purna
		
		//Added by Sagar for COA July QR-Maker Checker at activity Level
		EWF_CASE_TYPE:{
			CHANGE_OF_ADDRESS:"AMT_ChangeOfAddress",
			SCAN_AND_POST:"EWFSV_ScanAndPost"
		},
		MAKER_CHECKER_FIELDS:{
			MP_USER_FIELD:"AccountName1_Old",
			RV_USER_FIELD:"AccountNumber_Old",
			CB_USER_FIELD:"CustomerName2_Old",
			SP_USER_FIELD:"AccountName2_Old",
			DE_USER_FIELD:"CustomerName1_Old",
			REWORK_FIELD:"EWS_RequestorLANID"
		}
		
		
		//End Change
	});

	return new Constants();
});
