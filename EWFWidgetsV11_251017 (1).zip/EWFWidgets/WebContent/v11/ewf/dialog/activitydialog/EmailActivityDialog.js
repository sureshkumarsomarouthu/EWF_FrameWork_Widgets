/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define(["dojo/_base/declare", 
		"dojo/_base/connect", 
		"dojo/_base/lang", 
		"dojo/dom-class", 
		"dojo/dom-attr", 
		"dojo/dom-style", 
		"ecm/widget/dialog/BaseDialog",
		"v11/ewf/model/Email",
		"dojo/data/ItemFileReadStore",
		"dojo/text!./templates/EmailActivityDialogContent.html",
		"./modules/ActivityListViewDetail"
		], //
function(declare, 
		 connect, 
		 lang, 
		 domClass, 
		 domStyle, 
		 domAttr, 
		 BaseDialog,
		 EmailModel,
		 ItemFileReadStore,
		 template,
		 ActivityListViewDetail) {

	/**
	 * @name ewf.dialog.activitydialog.EmailActivityDialog
	 * @class Provides a dialog box that is used to send email for an activity with status 'Follow Up(EM)'.
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("v11.ewf.dialog.activitydialog.EmailActivityDialog", [
		BaseDialog
	], {
		/** @lends ewf.dialog.activitydialog.EmailActivityDialog.prototype */

		title: "Follow Up Email",
		buttonLabel: ecm.messages.yes,
		contentString: template,
		cancelButtonDefault: false,
		enableReminder: true,
		resultSet:null,
		isNotifyToScanHub: false,
		postCreate: function() {
			this.inherited(arguments);
			this.renderEmailTemplateList();
			this.initFromEmailAddress();
			
			this.connect(this.templateId, "onChange", "renderTemplateContents");
		},

		init: function(){
			domClass.add(this.domNode, "v11ewfEmailActivityDialog");
			this.setResizable(false);
			this.autofocus = false; // will focus on the first field
			this.setTitle(this.title || this.buttonLabel);
			
			var contentListModules = this.getContentListModules();
        	this._EmailActivityList.setContentListModules([]);
			
			if(this.resultSet){
				this.setActivityListResultSet(this.resultSet);
			}
			
			if(!this.enableReminder){
				domStyle.set(this._reminderArea, "style", "display:none");
				domStyle.set(this._EmailActivityListNode, "style", "display:none");
				domStyle.set(this.description, "style", "display:none");
			}else{
				domStyle.set(this._reminderArea, "style", "display:inline");
				domStyle.set(this._EmailActivityListNode, "style", "display:inline");
				domStyle.set(this.description, "style", "display:inline");
			}
			//don't show the follow up email activity items information any more
			domStyle.set(this._EmailActivityListNode, "style", "display:none");
			domStyle.set(this.description, "style", "display:none");
			
			var button;
			var buttonObj = null;
			for(button in this.buttonsCollection){
				if(this.buttonsCollection.hasOwnProperty(button)){
					buttonObj = this.buttonsCollection[button];
					var b1 = this.addButton(buttonObj.buttonLabel, buttonObj.onExecute, buttonObj.disabled||false, !this.cancelButtonDefault);
					connect.connect(b1, "onClick", lang.hitch(this, function(){this.hide();}));
					
					if(buttonObj.disabled){
						var _enableDisabledButton = lang.hitch(this, function(b1){
							if(this._toEmailAddress.isValid()
							   && this._ccEmailAddress.isValid()
							   && this._fromEmailAddress.isValid()
							   && this._emailSubject.isValid()){
							   var emailContentData = this._emailContent.get("value");
							   emailContentData = emailContentData.replace(/^(|<br \/>)*(.*?)(|<br \/>)*$/,"$2");// to trim the "<br />"
							   emailContentData = emailContentData.trim();
							   if(emailContentData ===""){
									b1.set("disabled", true);
								}
								else if(this.enableReminder){
									if(this._reminder.isValid()){
										b1.set("disabled", false);
									}else{
										b1.set("disabled", true);
									}
								}else{
									b1.set("disabled", false);
								}
							}else{
								b1.set("disabled", true);
							}
						}, b1);
						connect.connect(this.templateId, "onChange", _enableDisabledButton);//Added by Sravanthi for COA Apr QR 2017 - Add one more event onChange
						connect.connect(this._emailContent, "onKeyUp", _enableDisabledButton);
						connect.connect(this._toEmailAddress, "onKeyUp", _enableDisabledButton);
						connect.connect(this._toEmailAddress, "onChange", _enableDisabledButton);//Added by Purna for COA Apr QR 2017 - Add one more event onChange
						//connect.connect(this._fromEmailAddress, "onKeyUp", _enableDisabledButton);
						connect.connect(this._ccEmailAddress, "onKeyUp", _enableDisabledButton);
						connect.connect(this._emailSubject, "onKeyUp",_enableDisabledButton);
						connect.connect(this._reminder, "onKeyUp", _enableDisabledButton);
					}
					
				}
			}
			
			// Make the cancel button the default if requested.
			if (this.cancelButtonDefault) {
				this.autofocus = false;
				connect.connect(this, "onKeyDown", this, function(event) {
					if (event.keyCode == 13)
						this[onCancel]();
				});
			}
			this.resize();
		},

		initFromEmailAddress: function(){
			this._fromEmailAddress.set("readOnly", true);
			if(icmglobal && icmglobal.ewfCurrentUser 
				&& icmglobal.ewfCurrentUser.email
				&& icmglobal.ewfCurrentUser.email != null
				&& icmglobal.ewfCurrentUser.email != ""){
				this._fromEmailAddress.set("value", icmglobal.ewfCurrentUser.email);
				this._ccEmailAddress.set("value", icmglobal.ewfCurrentUser.email);
				
			} else {
				var userId = ecm.model.desktop.userId;
				var params = {};
				params.subUmmPath = encodeURIComponent("/uamusers/email?username="+userId);
				params.operation = "stop";
				ecm.model.Request.invokePluginService(
				    "EWFWidgetsPluginv11", 
				    "EWFUMMService",
				    {
				     requestParams: params,
				     requestCompleteCallback: dojo.hitch(this,function(response){
				        if(response && response.email){
				        	if(icmglobal.ewfCurrentUser == null){
				        		icmglobal.ewfCurrentUser = {};
				        	}
				        	icmglobal.ewfCurrentUser.email = response.email;
				        	this._fromEmailAddress.set("value", icmglobal.ewfCurrentUser.email);
				        	this._ccEmailAddress.set("value", icmglobal.ewfCurrentUser.email);
				        }
				    })
				});

			}
			this.init();
		},
		
		
		renderEmailTemplateList: function(){
			var _showTemplateList = lang.hitch(this, function(response){
				//added by rahul for DR Changes If response is Notify to Scan Hub then we need to hide other email templates 
				var tempChoices = []; 
				if(this.isNotifyToScanHub){
					
					dojo.forEach(response.choices, lang.hitch(this, function(choice){
						if(choice.displayName == "Notify Scan Hub"){
							tempChoices.push(choice);
						}
					}));
					response.choices = tempChoices;
				}else{
					
					dojo.forEach(response.choices, lang.hitch(this, function(choice){
						if(choice.displayName != "Notify Scan Hub"){
							tempChoices.push(choice);
						}
					}));
					response.choices = tempChoices;
				}
				//end
				var choices = {
						identifier: "value",
						label: "displayName",
						items: response.choices
				};
				
				var templateStore = new ItemFileReadStore({data: choices});				
				
				this.templateId.set("store", templateStore);	
	        	this.templateId.set("searchAttr", "displayName");
	        	if(choices && choices.items && (choices.items.length > 0))
	        		this.templateId.set("value", choices.items[0].value);
			});
			
			this.emailModel = new EmailModel({
				repository: this.repository,
				parentCase: this.parentCase
			});
			
			this.emailModel.retrieveEmailTemplates(_showTemplateList);
		},
		
		
		renderTemplateContents: function(){	
		
			var _showFields = lang.hitch(this, function(response){
				for (var i=0; i<response.attributes.length; i++){
					for (var name in response.attributes[i]) {
						if(name === "TemplateData"){
							var attribute = response.attributes[i].TemplateData;
							//added by suresh as part of upgrade multiple vertical scroll bars issue at emailtemplate body
							//begin change
							console.log("includes return value is : ",attribute.indexOf('overflow-y: overlay') != -1);
							if(attribute && attribute.indexOf('overflow-y: overlay;') !=-1){
							attribute = attribute.replace("overflow-y: overlay;","overflow-y: hidden;");
							}
							//end change
							this._emailContent.set("value", attribute);
						}
					}
				}
			});
			
			var templateName = this.templateId.get("value");
			
			if(templateName){
				this.emailModel.retrieveEmailTemplateDetail(_showFields, templateName, true);
				var emailSubjectValue = this.templateId.get("displayedValue");
				this._emailSubject.set("value", emailSubjectValue);
			}
			if(this.isNotifyToScanHub){
				// added by rahul for Notify scan hub we need to retrieve the ToEmail from Database based on Template Name 
				var _showToEmail = 	lang.hitch(this, function(response){
					console.log('Response got  - >', response);
					if(this.isNotifyToScanHub) {
						this._emailSubject.set("value", "EWF - CCA/CP Supporting Document attached to " +  this.parentCase.caseTitle + " requires follow-up");
					}
					if(response) { 
						if(response.toEmail){
							this._toEmailAddress.set("value", response.toEmail);
						}
					}
				});				
				if(templateName){
					
					this.retrieveToEmailFromDB(_showToEmail, templateName, true);
					
				}
			}
		},
		
		retrieveToEmailFromDB: function(callback, templateName, prefillValue) {
			this.logEntry("Entry retrieveToEmailFromDB");
			
			requestParams = {};
			requestParams.repositoryId = this.repository.id;
			requestParams.caseId = this.parentCase.id;
			requestParams.caseType = this.caseType.id;
			requestParams.template = this.templateId.get("displayedValue");
			requestParams.prefillValue = prefillValue;
			requestParams.method = "getTemplateToEmail";
			
			requestCompleteCallback = lang.hitch(this, function(response) {
				this.emailModel._retrieveEmailTemplateDetailCompleted(response, callback);
			});
			
			var request = ecm.model.Request.postPluginService("EWFWidgetsPluginv11", "EWFEmailService", 
			"text/json",
			{
    	            requestParams: requestParams,
    	            requestCompleteCallback: requestCompleteCallback,
    	            requestFailedCallback: requestCompleteCallback	
			});
			
			this.logExit("Exit retrieveToEmailFromDB");
			return request;
		},
			
		
		setActivityListResultSet:function(resultSet){
			this._EmailActivityList.setResultSet(resultSet);
			this.resize();
		},
		
		getContentListModules: function(){
        	var array = [];
        	var viewDetail = this.getViewDetailModule();
        	array.push(viewDetail);
        	return array;
        },
        
        getViewDetailModule: function() {
			var view = {
				moduleClass: ActivityListViewDetail
			};
			return view;
		},
		
		getFromEmailAddress:function(){
			this._fromEmailAddress.get("value");
		},
		
		getToEmailAddress:function(){
			this._toEmailAddress.get("value");
		},
		
		getCcEmailAddress:function(){
			this._ccEmailAddress.get("value");
		},
		
		getEmailSubject:function(){
			this._emailSubject.get("value");
		},
		
		getEmailContent:function(){
			this._emailContent.get("value");
		},
		
		getReminder:function(){
			this._reminder.get("value");
		},

		show: function() {
			this.inherited(arguments);
			if (this.cancelButtonDefault) {
				setTimeout(lang.hitch(this, function() {
					this.cancelButton.focus();
				}, 300));
			}
		}
	});
});
