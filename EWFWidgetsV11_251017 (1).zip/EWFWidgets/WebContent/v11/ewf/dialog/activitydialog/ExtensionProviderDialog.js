/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([ "dojo/_base/declare", 
		"dojo/_base/connect", 
		"dojo/_base/lang", 
		"dojo/dom-class", 
		"dojo/dom-attr", 
		"dojo/dom-style", 
		"ecm/widget/dialog/BaseDialog", 
		"dojo/text!./templates/ExtensionProviderDialogContent.html" ], //
function(declare, 
		 connect, 
		 lang, 
		 domClass, 
		 domStyle, 
		 domAttr, 
		 BaseDialog, 
		 template) {

	/**
	 * @name ewf.dialog.ExtensionProviderDialog
	 * @class Provides a dialog box which is showing for complete operation on activity.
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("v11.ewf.dialog.ExtensionProviderDialog.ExtensionProviderDialog", [ BaseDialog ], {
		/** @lends ewf.dialog.ExtensionProviderDialog.ExtensionProviderDialog.prototype */

		text: "confirm?",
		buttonLabel: ecm.messages.yes,
		contentString: template,
		cancelButtonDefault: false,
		containReason: true,

		postCreate: function() {
			this.inherited(arguments);
			domClass.add(this.domNode, "ecmConfirmationDialog");
			domAttr.set(this.domNode, "aria-describedby", this.description.id);
			this.setTitle(this.title || this.buttonLabel);
			
			//Added by Purna on 25/01/2017 - Hide Contact Person field for OTT
			if(this.solutionPrefix && this.solutionPrefix == "EWF"){
				domStyle.set(this.ContactPersonRow, "style", "display:none");
			}
			//End change by Purna
			
			if(!this.containReason){
				domStyle.set(this.reasonArea, "style", "display:none");
			}else{
				domStyle.set(this._starArea, "style", "display:none");
			}
			
			var button;
			var buttonObj = null;
			for(button in this.buttonsCollection){
				if(this.buttonsCollection.hasOwnProperty(button)){
					buttonObj = this.buttonsCollection[button];
					var b1 = this.addButton(buttonObj.buttonLabel, buttonObj.onExecute, buttonObj.disabled||false, !this.cancelButtonDefault);
					connect.connect(b1, "onClick", lang.hitch(this, function(){this.hide();}));
					if(this._ExtensionNubmer && buttonObj.disabled){
						domStyle.set(this._starArea, "style", "display:inline");
						connect.connect(this._ExtensionNubmer, "onKeyUp", lang.hitch(this, function(b1){
							if(this._ExtensionNubmer.get("value").length > 0){
								b1.set("disabled", false);
							}else{
								b1.set("disabled", true);
							}
						}, b1));
					}
					
				}
			}

			// Make the cancel button the default if requested.
			if (this.cancelButtonDefault) {
				this.autofocus = false;
				connect.connect(this, "onKeyDown", this, function(event) {
					if (event.keyCode == 13)
						this[onCancel]();
				});
			}
		},

		show: function() {
			this.inherited(arguments);
			if (this.cancelButtonDefault) {
				setTimeout(lang.hitch(this, function() {
					this.cancelButton.focus();
				}, 300));
			}
		}
	});
});
