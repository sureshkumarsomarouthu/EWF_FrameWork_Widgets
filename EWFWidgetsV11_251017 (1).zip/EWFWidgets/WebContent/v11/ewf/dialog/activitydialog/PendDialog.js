/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([ "dojo/_base/declare", 
		"dojo/_base/connect", 
		"dojo/_base/lang",
		"dojo/store/Memory",		
		"dojo/dom-class", 
		"dojo/dom-attr", 
		"dojo/dom-style", 
		"ecm/widget/dialog/BaseDialog", 
		"dojo/text!./templates/PendDialogContent.html" ], //
function(declare, 
		 connect, 
		 lang,
		 Memory,
		 domClass, 
		 domStyle, 
		 domAttr, 
		 BaseDialog, 
		 template) {

	/**
	 * @name ewf.dialog.PendDialog
	 * @class Provides a dialog box which is showing for complete operation on activity.
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("v11.ewf.dialog.PendDialog.PendDialog", [ BaseDialog ], {
		/** @lends ewf.dialog.PendDialog.PendDialog.prototype */

		text: "confirm?",
		buttonLabel: ecm.messages.yes,
		contentString: template,
		cancelButtonDefault: false,
		containReason: true,
		reasonList: null,
		handleReasonChange: null,

		postCreate: function() {
			this.inherited(arguments);
			domClass.add(this.domNode, "ewfPendDialog");
			this.setResizable(false);
			this.autofocus = false; // will focus on the first field
			this.setTitle(this.title || this.buttonLabel);
			
			if(!this.containReason){
				domStyle.set(this.reasonArea, "style", "display:none");
			}
			
			/*
        	 * Init pend reason store
        	 */
			 
			 pendReasonList = this.reasonList;
         	
        	var pendReasonStore = new Memory({idProperty: "value", data: pendReasonList});
        	this.reason.labelAttr = "label";
        	this.reason.setStore(pendReasonStore, "0.5", {sort:[{attribute:"id", descending: true}]}); 
			
			var button;
			var buttonObj = null;
			for(button in this.buttonsCollection){
				if(this.buttonsCollection.hasOwnProperty(button)){
					buttonObj = this.buttonsCollection[button];
					var b1 = this.addButton(buttonObj.buttonLabel, buttonObj.onExecute, buttonObj.disabled||false, !this.cancelButtonDefault);
					connect.connect(b1, "onClick", lang.hitch(this, function(){this.hide();}));
					if(this._detailReason && buttonObj.disabled){
						var _enablePend = lang.hitch(this, function(b1){
							if(this._detailReason.get("value").length > 0 ){
								if(this.reason.getValue() === "-2" && (!(this._futureTransactionReminder.isValid()))){
									b1.set("disabled", true);
								}else{
									b1.set("disabled", false);
								}
							}else{
								b1.set("disabled", true);
							}
						}, b1);
						
						
						connect.connect(this.reason, "onChange", _enablePend);
						connect.connect(this._detailReason, "onKeyUp", _enablePend);
						connect.connect(this._futureTransactionReminder, "onKeyUp", _enablePend);
						connect.connect(this._futureTransactionReminder, "onChange", _enablePend);
					}
					
				}
			}
			
			if(!this.handleReasonChange){
            	this.handleReasonChange = this.connect(this.reason, "onChange", "setDurationValue");
        	}

			// Make the cancel button the default if requested.
			if (this.cancelButtonDefault) {
				this.autofocus = false;
				connect.connect(this, "onKeyDown", this, function(event) {
					if (event.keyCode == 13)
						this[onCancel]();
				});
			}
		},
		
		setDurationValue: function(){
			var durationValue = this.reason.getValue();
			if(durationValue*1.00 >= 0){
				domStyle.set(this._reminder, "style", "display:inline-block");
				domStyle.set(this._futureTransactionReminder, "style", "display:none");
				domStyle.set(this._starArea, "style", "display:inline");
				this._reminderLabel.innerHTML = "Reminder:&nbsp;";
				this._timeLabelArea.innerHTML = "&nbsp;hour(s) from now";
				this._reminder.set("value", durationValue*1.00);//maybe we could get a function to caculate what's the duration time for next business day
			}else if(durationValue === "-1"){
				domStyle.set(this._reminder, "style", "display:none");
				domStyle.set(this._futureTransactionReminder, "style", "display:none");
				domStyle.set(this._starArea, "style", "display:none");
				this._reminderLabel.innerHTML = "Pend to";
				this._timeLabelArea.innerHTML = "&nbsp;next business day";
				this._reminder.set("value", durationValue);
			}else{
				domStyle.set(this._reminder, "style", "display:none");
				domStyle.set(this._starArea, "style", "display:inline");
				domStyle.set(this._futureTransactionReminder, "style", "display:inline-block");
				this._reminderLabel.innerHTML = "Pend to:";
				this._timeLabelArea.innerHTML = "&nbsp;";
				this._reminder.set("value", durationValue);
			}
		},

		show: function() {
			this.inherited(arguments);
			if (this.cancelButtonDefault) {
				setTimeout(lang.hitch(this, function() {
					this.cancelButton.focus();
				}, 300));
			}
		}
	});
});
