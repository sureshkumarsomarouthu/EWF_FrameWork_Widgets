/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define(["dojo/_base/declare", 
		"dojo/_base/connect", 
		"dojo/_base/lang", 
		"dojo/dom-class", 
		"dojo/dom-attr", 
		"dojo/dom-style", 
        "dojo/_base/array",
		"ecm/widget/dialog/BaseDialog",
		"dojo/text!./templates/FollowUpDialogContent.html",
		"./modules/ActivityListViewDetail",
		"v11/ewf/util/Util"
		], //
function(declare, 
		 connect, 
		 lang, 
		 domClass, 
		 domStyle, 
		 domAttr,
         array,		 
		 BaseDialog,
		 template,
		 ActivityListViewDetail,
		 Util) {

	/**
	 * @name ewf.dialog.activitydialog.FollowUpDialog
	 * @class Provides a dialog box that is used to show all activities with status 'Follow Up(EM)' or 'Follow Up(CB)' .
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("v11.ewf.dialog.activitydialog.FollowUpDialog", [
		BaseDialog
	], {
		/** @lends ewf.dialog.activitydialog.FollowUpDialog.prototype */

		title: "Follow Up Options",
		buttonLabel: ecm.messages.yes,
		contentString: template,
		cancelButtonDefault: false,
		resultSet: null,
		cbResultSet:null,
		emResultSet:null,

		postCreate: function() {
			this.inherited(arguments);
			domClass.add(this.domNode, "ewfFollowUpDialog");
			//this.setResizable(false);
			this.setResizable(true);
			this.autofocus = false; // will focus on the first field
			this.setTitle(this.title || this.buttonLabel);
			
			var contentListModules = this.getContentListModules();
        	this._cbActivityList.setContentListModules([]);
			this._emActivityList.setContentListModules([]);
			var showDialog = false;
			
			var emItems = [];
			var cbItems = [];
			
			var items = this.resultSet.getItems();
			array.forEach(items, function(item){
				if(item && item.getValue("ActivityStatus") === Util.getConstant("EWF_AcitivityStatus").FOLLOWUPEM){
					emItems.push(item);
				}
				
				if(item && item.getValue("ActivityStatus") === Util.getConstant("EWF_AcitivityStatus").FOLLOWUPCB){
					cbItems.push(item);
				}
			}, this);
			
			if(emItems.length > 0){
				this.emResultSet  = lang.mixin({},this.resultSet);
				this.emResultSet.items = emItems;
				this.setEMActivityListResultSet(this.emResultSet);
			}else{
				domStyle.set(this.emFollowUp, "style", "display:none");
			}
			
			if(cbItems.length > 0){
				this.cbResultSet  = lang.mixin({},this.resultSet);
				this.cbResultSet.items = cbItems;
				this.setCBActivityListResultSet(this.cbResultSet);
			}else{
				domStyle.set(this.cbFollowUp, "style", "display:none");
			}
			
			this.resultSet.items = items;
			
			var button;
			var buttonObj = null;
			for(button in this.buttonsCollection){
				if(this.buttonsCollection.hasOwnProperty(button)){
					buttonObj = this.buttonsCollection[button];
					var b1 = this.addButton(buttonObj.buttonLabel, buttonObj.onExecute, buttonObj.disabled||false, !this.cancelButtonDefault);
					connect.connect(b1, "onClick", lang.hitch(this, function(){this.hide();}));
					
					if(buttonObj.disabled){
						//FollowUp is not any disable scenario
					}
					
				}
			}

			// Make the cancel button the default if requested.
			if (this.cancelButtonDefault) {
				this.autofocus = false;
				connect.connect(this, "onKeyDown", this, function(event) {
					if (event.keyCode == 13)
						this[onCancel]();
				});
			}
			this.resize();
		},
		
		setEMActivityListResultSet:function(resultSet){
			this._emActivityList.setResultSet(resultSet);
			this.resize();
		},
		
		setCBActivityListResultSet:function(resultSet){
			this._cbActivityList.setResultSet(resultSet);
			this.resize();
		},
		
		getContentListModules: function(){
        	var array = [];
        	var viewDetail = this.getViewDetailModule();
        	array.push(viewDetail);
        	return array;
        },
        
        getViewDetailModule: function() {
			var view = {
				moduleClass: ActivityListViewDetail
			};
			return view;
		},

		show: function() {
			this.inherited(arguments);
			this.setSize(760,350);
			if (this.cancelButtonDefault) {
				setTimeout(lang.hitch(this, function() {
					this.cancelButton.focus();
				}, 300));
			}
		}
	});
});
