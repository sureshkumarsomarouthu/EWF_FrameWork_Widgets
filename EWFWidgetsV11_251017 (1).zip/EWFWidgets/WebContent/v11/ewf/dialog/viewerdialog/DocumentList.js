define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/store/Memory",
	"dojo/data/ObjectStore",
	"dojo/data/ItemFileWriteStore",
	"dijit/form/Form",
	"dijit/Dialog",
	"dojo/dom-construct",
	"dijit/form/Button",
	"dijit/form/TextBox",
	"dojo/on",
	"dojox/grid/DataGrid",
	"dojo/i18n!../../nls/common",
	"gridx/modules/RowHeader",
	"gridx/Grid",
	"gridx/core/model/cache/Sync",
	"gridx/modules/CellWidget",
	"gridx/modules/ColumnResizer",
	"gridx/modules/ColumnWidth",
	"gridx/modules/move/Row",
	"gridx/modules/Focus",
	"gridx/modules/VirtualVScroller",
	"gridx/modules/select/Row",
	"gridx/modules/select/Column",
	"gridx/modules/select/Cell",
	"dojo/_base/sniff",
	"dojo/keys",
	"gridx/modules/extendedSelect/Row",
	"gridx/modules/IndirectSelect"
],function(declare, lang, array,  Memory, ObjectStore, AndOrWriteStore, Form, Dialog, domConstruct, Button, TextBox,on, DataGrid,   
	  resources, RowHeader, Grid, Cache, CellWidget, ColumnResizer, ColumnWidth, MoveRow, Focus, VirtualVScroller, SelectRow, SelectColumn, Cell, sniff, keys, exSelectRow, IndirectSelect){	
	return declare("v11.ewf.dialog.viewerdialog.DocumentList", [], {
		
		documentGrid : null,
		parentThis : null,
		constructor: function(args){
        	this.documentGrid = args.documentGrid;
			this.parentThis = args.object;
			
        },
        
		postCreate: function(){
        	this.inherited(arguments);
			
        }, 
		postMixInProperties: function(){
        	this.resourceBundle = resources.ActivityPanel;
    		this.inherited(arguments);
        },
		
		getNLSValue : function(name){
			return resources.ActivityPanel[name] || null;
		},

		
        createGrid: function(dataStore){	
			console.log('createGrid');
			var _this = this;			
			//added by Naveen (MITS) for document name word wrap in MY Upgrade issue
			var structure = [
				{name: 'Document', width: '36%', field: 'Document',style :'white-space:initial' },
				{name: 'PageCount', width: '25%', field: 'PageCount',style :'white-space:initial'},
				{name: 'AddedBy',  width: '39%',field: 'addedBy',style :'white-space:initial'}
			];			
			var gridModules = [ CellWidget, {moduleClass: SelectRow}, SelectColumn, Cell,												   
								MoveRow,
								Focus,
								exSelectRow,
								IndirectSelect,
								{
									moduleClass: VirtualVScroller,
									lazyTimeout: 200,
									lazy: true
								},
								RowHeader
			];
			console.log('gridModules ->', gridModules);
			var gStore = new AndOrWriteStore({data: dataStore});
			console.log('gStore ->', gStore);
			
			var divElement = domConstruct.create('div', {style: "width: '100%'; height: '100%';"}, _this.parentThis.documentGrid);
			console.log(' documentGrid ', _this.parentThis.documentGrid);
			
			var grid = new Grid({
				cacheClass: Cache,
				store: gStore,
				structure: structure,
				modules: gridModules,
				autoHeight: true,
				autoWidth: false
			},divElement);
			
						
			grid.startup();
			_this.parentThis.grid = grid;
			
		},
		
		destroy: function(){
        	this.inherited(arguments);
			
        }		

	});
});