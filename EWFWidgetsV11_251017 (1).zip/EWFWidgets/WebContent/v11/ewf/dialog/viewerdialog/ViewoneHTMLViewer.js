/***********************************************************************************************************************
 * IBM Confidential OCO Source Materials 5725Q02, 5725Q03, 5725Q04 (C) Copyright IBM Corp, 1997, 2014 The source code
 * for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited
 * with the U. S. Copyright Office.
 **********************************************************************************************************************/

define([
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/xhr",
	"dojo/_base/url",
	"dojo/on",
	"dojo/aspect",
	"dojo/dom",
	"dojo/dom-style",
	"dojo/dom-construct",
	"dojo/io-query",
	"dojo/has",
	"ecm/widget/virtualViewer/ViewoneHTMLViewer",
	"dojo/text!./templates/ViewoneHTMLViewer.html",
	"ecm/model/ContentItem",
	"ecm/model/Request",
	"ecm/widget/dialog/ConfirmationDialog",
	"ecm/widget/dialog/YesNoCancelDialog",
	"ecm/widget/dialog/SelectReasonDialog",
	"ecm/widget/dialog/ErrorDialog",
	"ecm/model/ContentClass",
	"ecm/widget/dialog/AddContentItemDialog",
	"ecm/model/Message",
	"ecm/LoggerMixin"
], function(declare, lang, xhr, url, on, aspect, dom, domStyle, domConstruct, ioQuery, has, ViewoneHTMLViewer, template, ContentItem, Request, ConfirmationDialog, YesNoCancelDialog, SelectReasonDialog, ErrorDialog, ContentClass, AddContentItemDialog, Message, LoggerMixin) {

	var ViewoneHTMLViewer = declare("v11.ewf.dialog.viewerdialog.ViewoneHTMLViewer", [ViewoneHTMLViewer], {
		templateString: template,
		showErrorOnFallback: false,
		_dirty: false,
		_printing: false,
		viewerId: 'v',
		viewer: null,
		docURL: null,
		saveAnnotURL: null,
		coldTemplateParam: "templateid",
		_loadingViewer: false,
		_loadingBootstrap: false,
		_loadedBootstrap: false,
		_loadingViewoneBootstrap: false,
		_loadedViewoneBootstrap: false,
		_loadingConfig: false,
		_loadedConfig: false,
		_loadingDocument: false,
		_loadedDocument: false,
		_startingViewer: false,
		_inRedactionMode: false,
		_redactionCheckoutDocument: false,
		_OK_STATUS: "ok",
		_CANCEL_STATUS: "cancel",
		_redactionSavedItem: null,
		_redactionSaveMode: null,
		_isSetRedactionTransparent: false,

		REDACTION_SAVE_MODE_NEW_VERSION: "newVersion",
		REDACTION_SAVE_MODE_NEW_DOCUMENT: "newDocument",
		REDACTION_SAVE_MODE_LOCAL_FILE: "localFile",
		REDACTION_SAVE_MODE_USER_SELECT: "userSelect",
		REDACTION_ADD_DOCUMENT_MODE_STANDARD: "standard",
		REDACTION_ADD_DOCUMENT_MODE_ENTRY_TEMPLATE: "entryTemplate",

		postCreate: function() {
			this.viewerId = "nav_" + this.id;
			var methodName = "postCreate - " + this.viewerId;
			this.logEntry(methodName + ": ViewONE Virtual created. ");
			if (ViewoneHTMLViewer._securityTokenHandler == null) {
				this.logDebug(methodName, "Setting up security token refresh handler.");
				ViewoneHTMLViewer._securityTokenHandler = aspect.after(ecm.model.Request, "onSecurityTokenChange", function() {
					ViewoneHTMLViewer._updateSecurityToken();
				});
			}
			this.logExit(methodName);
		},

		isLoading: function() {
			this.logEntry("isLoading - " + this.viewerId);
			return this.viewer == null || this._isLoadingInProgress();
		},

		isLoaded: function() {
			var viewerLoaded = this.viewer != null && !this._isLoadingInProgress();
			this.logEntry("isLoaded - " + this.viewerId + ": " + viewerLoaded);
			return viewerLoaded;
		},

		_isLoadingInProgress: function() {
			return (this._loadingDocument || this._loadingConfig || this._loadingViewoneBootstrap || this._loadingBootstrap);
		},

		getPageNumber: function() {
			var methodName = "getPageNumber - " + this.viewerId;
			this.logEntry(methodName);

			if (this.viewer != null) {
				this.logDebug(methodName, "retrieving page number from viewer");
				this._pageNumber = this.viewer.getPage();
			}
			this.logExit(methodName + ": " + this._pageNumber);
			return this._pageNumber;
		},

		/* sets the _item property which is the document information */
		setItem: function(item, pageNumber) {
			var methodName = "setItem - " + this.viewerId;
			this.logEntry(methodName);
			this.inherited(arguments);
			this._destroyViewer();

			this._loadingDocument = false;
			this._loadingBootstrap = false;
			this._loadedBootstrap = false;
			this._loadingConfig = false;
			this._loadedConfig = false;
			this._loadingViewoneBootstrap = false;
			this._loadedViewoneBootstrap = false;
			this._loadedDocument = false;
			this._isSetRedactionTransparent = false;
			this.item = item;
			this.docURL = item.getContentUrl();
			this.docUrlBreak = this.docURL.split("?");
			this.mimetype = item.mimetype;

			var queryString = this.docURL.substring(this.docURL.indexOf('?'));
			var serverType = item.repository.type;
			var serviceURL = ecm.model.desktop.getServicesUrl();

			this.saveAnnotURL = serviceURL + "/" + serverType + "/updateAnnotations.do" + queryString;
			this.logDebug(methodName, "Annotation Save URL: " + this.saveAnnotURL);

			this.coldTemplateURL = this._getColdTemplateUrlStr();
			this.logDebug(methodName, "Cold Template URL: " + this.coldTemplateURL);

			this.logExit(methodName);
		},

		_getColdTemplateUrlStr: function() {
			var urlBase = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port;
			return urlBase + this.docUrlBreak[0] + "?" + this.coldTemplateParam + "=0&" + this.docUrlBreak[1];
		},

		/* Called when the viewer is displayed. 
		 * arguments: Item and pageNumber
		 */
		showItem: function(callback) {
			var methodName = "showItem - " + this.viewerId;
			this.logEntry(methodName);
			this.setIsLoading(true);
			if (this.viewer == null) {
				if (!this._loadedViewoneBootstrap) {
					this._loadViewoneBootstrap();
				} else if (!this._loadedConfig) {
					this._loadViewerConfig();
				} else if (!this._loadedBootstrap) {
					this._loadBootstrap();
				}
			} else if (!(this.viewer == null || this._loadedDocument)) {
				this._loadDocument();
			} else if (this.viewer != null) {
				this.viewer.setFocus(true);
			}

			this.logExit(methodName);
			return true;
		},

		/* test the open and use the fallback if it fails and another viewer 
		 * should get the opportunity to attempt to open the item. */
		openItem: function() {
			var methodName = "openItem - " + this.viewerId;
			this.logEntry(methodName);

			this.logExit(methodName);
			//return this._loaded || this._loading || this._loadingConfig;
		},

		/* Called by Navigator to cleanup when document tab closed. Call close on viewer to prompt for any user response required */
		closeItem: function() {
			var methodName = "closeItem - " + this.viewerId;
			this.logEntry(methodName);
			this._checkRedectionCheckout(true);
			this.inherited(arguments);

			if (this.viewer) {
				this.viewer.closeDocument();
			}
			this._loadingDocument = false;
			this._loadedDocument = false;
			this._dirty = false;
			this._isSetRedactionTransparent = false;
			this.logExit(methodName);
			return false;
		},

		_destroyViewer: function() {
			var methodName = "_destroyViewer - " + this.viewerId;
			this.logEntry(methodName);

			if (this.viewer != null) {
				if (window.com && window.com.ibm && window.com.ibm.dv && window.com.ibm.dv.client && window.com.ibm.dv.client.Viewer && window.com.ibm.dv.client.Viewer.stop) {
					try {
						window.com.ibm.dv.client.Viewer.stop(this.viewerId);
					} catch (error) {
						this.logError(methodName, error);
					}
				}

				if (window[this.viewerId + "_listener"]) {
					delete window[this.viewerId + "_listener"];
				}
				
				if ( window[this.viewerId + "_setRedactionReason"] ) {
					delete window[this.viewerId + "_setRedactionReason"];
				}

				if ( window[this.viewerId + "_isRedaction"] ) {
					delete window[this.viewerId + "_isRedaction"];
				}
				
				if (window[this.viewerId]) {
					delete window[this.viewerId];
				}

				this.viewer = null;
			}

			this.logExit(methodName);
		},

		destroy: function() {
			var methodName = "destroy - " + this.viewerId;
			this.logEntry(methodName);
			this._destroyViewer();
			if (this.selectSaveMode) {
				this.selectSaveMode.destroyRecursive();
				this.selectSaveMode = null;
			}
			if (this._errorDialog) {
				this._errorDialog.destroyRecursive();
				this._errorDialog = null;
			}
			if (this.addContentItemDialog) {
				// Release the reference. The contents are self-destroyed.
				this.addContentItemDialog = null;
			}
			this.inherited(arguments);
		},

		_refreshItem: function(itemToRefresh) {
			if (itemToRefresh) {
				itemToRefresh.refresh();
				if (has("ie") || has("trident")) {
					setTimeout(function() {
						window.self.focus();
					}, 3000);
				}
			}
		},

		/* called whenever the viewer tab is closed to allow form prompting of the user for saving of annotations */
		isDirty: function() {
			this.logEntry("isDirty - " + this.viewerId + ": " + this._dirty);
			return this._dirty;
		},

		/* Call when save has completed. */
		callback: function() {
			this.logEntry("callback - " + this.viewerId);
		},

		/**
		 * Saves all annotation changes.
		 * 
		 * @param callback
		 *            If specified, call the callback upon completion of the save.
		 */
		saveAnnotations: function(callback) {
			// Call via setTimeout to deal with JavaScript STRICT mode in IE.
			setTimeout(lang.hitch(this, function() {
				this._saveAnnotations(callback)
			}, 50));
		},

		_saveAnnotations: function(callback) {
			var methodName = "_saveAnnotations";
			this.logEntry(methodName);

			if (this.viewer.saveAnnotations && this.saveCompleted == null) {
				this.saveCompleted = callback;
				this.logDebug(methodName, "Saving ViewONE Virtual annotations.");
				this.viewer.saveAnnotations();
			} else if (!this.viewer.saveAnnotations) {
				// TODO: Implement viewer.saveAnnotations and hook it up here.
				this.logError(methodName, "this.viewer.saveAnnotations function not available.");
			}

			this.logExit(methodName);
		},

		/* Called when window closing. */
		isPrinting: function() {
			this.logEntry("isPrinting - " + this.viewerId + ": " + this._printing);
			return this._printing;
		},

		/**
		 * Return the Daeja ViewONE Virtual viewer instance.
		 * 
		 * @since 2.0.3.3
		 */
		getNativeViewer: function() {
			return this.viewer;
		},

		/* this is called from Navigator after showItem */
		onDocumentLoaded: function() {
			var methodName = "onDocumentLoaded - " + this.viewerId;
			this.logEntry(methodName);
			this.inherited(arguments);
			this.viewer = window[this.viewerId];
			this.viewer.printDocument();
			this.logExit(methodName);
		},

		/* Indicates config has loaded. */
		onConfigLoaded: function() {
			this._loadingConfig = false;
			this._loadedConfig = true;
			this.logDebug("onConfigLoaded", this.viewerId + ": viewer configuration loaded ");
			if (this._loadedBootstrap && !this._loadedDocument) {
				this.viewerReadyToStart();
			} else if (!this._loadedBootstrap) {
				this._loadBootstrap();
			}
		},

		/*  Viewer listener methods    */
		viewerReadyEvent: function(id, text) {
			var methodName = "viewerReadyEvent - " + this.viewerId;
			this.logEntry(methodName + ": loadedConfig=" + this._loadedConfig + "; loadedDocument=" + this._loadedDocument);
			this.viewer = window[this.viewerId];
            var params = Request.setSecurityToken({});
            this.viewer.updateRequestParameter("security_token", params.security_token);
			this._startingViewer = false;
			this._loadingViewer = false;
			if (this._loadedConfig && !this._loadedDocument) {
				this._loadDocument();
			}
			this.logExit(methodName);
		},

		documentReadyEvent: function(id, text) {
			var methodName = "documentReadyEvent - " + this.viewerId;
			this.logEntry(methodName);
			this._loadingDocument = false;
			this._loadedDocument = true;
			this.setIsLoading(false);

			//call superclass method
			setTimeout(lang.hitch(this, function() {
				this.onDocumentLoaded(); // DO bother!!  It is an event call that other widgets might be listening for!!
			}), 3000);
			this.logExit(methodName);
		},

		annotLoadedEvent: function(id, text) {
			this.logEntry("annotLoadedEvent - " + this.viewerId);
			this._dirty = false;
			this.onDirty(this._dirty);
		},

		annotLoadFailedEvent: function(id, text) {
			this.logEntry("annotLoadFailedEvent - " + this.viewerId);
		},

		documentLoadFailedEvent: function(id, text) {
			var methodName = "documentLoadFailedEvent";
			this.logEntry(methodName + " - " + this.viewerId);

			this._loadingDocument = false;
			this._loadedDocument = true;

			//call superclass method
			setTimeout(lang.hitch(this, function() {
				this.onDocumentLoaded(); // DO bother!!  It is an event call that other widgets might be listening for!!
			}), 3000);
			this.logDebug(methodName, "Document load failed: " + text);
			setTimeout(lang.hitch(this, function() {
				this.onFallback();
			}, 1));
		},

		annotEditEvent: function(id, text) {
			this.logEntry("annotEditEvent - " + this.viewerId + ": " + text);
			this._dirty = true;
			this.onDirty(this._dirty);
		},

		annotRestoredEvent: function(id, text) {
			this.logEntry("annotRestoredEvent - " + this.viewerId + ": " + text);
			this._dirty = false;
			this.onDirty(this._dirty);
		},

		annotSavedEvent: function(id, text) {
			var methodName = "annotSavedEvent";
			this.logEntry(methodName + " - " + this.viewerId);
			if (this.saveCompleted != null) {
				this.logDebug(methodName, "Calling saveCallback");
				this.saveCompleted();
				this.saveCompleted = null;
			}

			// for CM8 repository, refresh parent folder after annotation is updated, if class is set to always create new version
			if (this.item.repository.type == "cm") {
				var contentClass = this.item.getContentClass();
				contentClass.retrieveAttributeDefinitions(lang.hitch(this, function() {
					if (contentClass.versionControl && contentClass.versionControl == ContentClass.VERSION_CONTROL.ALWAYS) {
						this._refreshItem(this.item.parent);
					}
				}));
			}

			this._dirty = false;
			this.onDirty(this._dirty);
		},

		printStartEvent: function(id, text) {
			this.logEntry("printStartEvent - " + this.viewerId);
			this._printing = true;
		},

		printFinishEvent: function(id, text) {
			this.logEntry("printFinishEvent - " + this.viewerId);
			this._printing = false;
		},

		modeChangeEvent: function(modeId) {
			this.logEntry("modeChangeEvent - " + this.viewerId);
			if (this._inRedactionMode === false) {
				this._inRedactionMode = true;
				this._redactionSavedItem = null;

				this._selectRedactionSaveMode();
			} else {
				this._inRedactionMode = false;
				this._checkRedectionCheckout(false);
			}
			this.logExit("modeChangeEvent - " + this.viewerId);
		},

		redactTaskStartEvent: function(id, taskId, callbackId) {
			this.logEntry("redactTaskStartEvent - " + this.viewerId);
			this._doCallback(callbackId, this._OK_STATUS);
			this.logExit("redactTaskStartEvent - " + this.viewerId);
		},

		redactTaskStartedEvent: function(id, taskId, callbackId) {
			this.logEntry("redactTaskStartedEvent - " + this.viewerId);
			this._doCallback(callbackId, this._OK_STATUS);
			this.logExit("redactTaskStartedEvent - " + this.viewerId);
		},

		redactTaskStatusEvent: function(id, taskId, status, json) {
			var methodName = "redactTaskStatusEvent";
			this.logEntry(methodName + " - " + this.viewerId);
			switch (status) {
			case "ok":
				this.logDebug(methodName, "Redaction completed.");
				if (this._redactionCheckoutDocument === true) {
					this._performCheckinRedaction(json);
				} else {
					if (this._redactionSaveMode == this.REDACTION_SAVE_MODE_NEW_DOCUMENT) {
						this._performAddNewDocument(json);
					} else {
						var response = JSON.parse(json);
						this._performDownload(response.url[0]);
					}
				}
				break;
			case "error":
				this.logDebug(methodName, "Redaction error.");
				break;
			case "usercancelled":
				this.logDebug(methodName, "Redaction cancelled.");
				break;
			}
			this.logExit(methodName + " - " + this.viewerId);
		},
		
		_setRedactionReasonEvent: function() {
			var methodName = "_setRedactionReasonEvent";
			this.logEntry(methodName + " - " + this.viewerId);
			
			if ( this.viewer && this.viewer.getActiveAnnotation ) {
				var annotation = this.viewer.getActiveAnnotation();
				var annotProperties = this.viewer.getAnnotation(annotation);
				var selectedReason = this.getAnnotationProperty(this.viewer.getDelimiter(), annotProperties, "F_REASON_CODE");
				this.logDebug(methodName, "Annotation's current reason value is: " + selectedReason);
				
				if ( annotation && annotation.startsWith("Redact") ) {
					if (!this._selectReasonDialog) {
					    this._selectReasonDialog = new SelectReasonDialog({
						    title: "Select Reason",
							onOk: lang.hitch(this, function() {
								selectedReason = this._selectReasonDialog.getSelectedReason();
								this.logDebug(methodName, "Setting redaction reason to value: " + selectedReason);
								this.viewer.modifyAnnotation(this._selectReasonDialog._activeAnnotation, "CUSTOMPROPERTY = F_REASON_CODE="+selectedReason+"<P>CUSTOMPROPERTY = F_IS_FROM_PROCESS=false");
								this._selectReasonDialog.hide();
							}),
							onShow: lang.hitch(this, function() {
							}),
							onHide: lang.hitch(this, function() {
							})
						});
					    
					    this.own(this._selectReasonDialog);
					}

					this._selectReasonDialog.configureDialog(this._viewoneBootstrap.editRedactionReasons, selectedReason, annotation);
					this._selectReasonDialog.show();
				}
			}
			
			this.logExit(methodName + " - " + this.viewerId);
		},
		
		_toggleRedactionsEvent: function() {
			var methodName = "_toggleRedactionsEvent";
			this.logEntry(methodName + " - " + this.viewerId);
			if ( this.viewer ) {
				this._isSetRedactionTransparent = !this._isSetRedactionTransparent;
				this.viewer.setAnnotationsSemiTransparent(this._isSetRedactionTransparent, "redacttypes");
			}
			this.logExit(methodName + " - " + this.viewerId);			
		},
		
		getAnnotationProperty: function(annotationDelimiter, annotProp, propName) {
		   var customVal = null;
		  
		   if (annotProp.indexOf(propName) > -1)
		   {
		      var value = annotProp.substring(annotProp.indexOf(propName));
		      if (value.indexOf(annotationDelimiter) > -1)
		      {
		         value = value.substring(0,value.indexOf(annotationDelimiter));
		      }

		      if (value.indexOf("=") > -1)
		      {
		         value = value.substring(value.indexOf("=")+1);
		      }

		      customVal = value.trim();
		   }
		   
		   return customVal;
		},
		
		_isRedaction: function() {
			return true;
		},

		_performDownload: function(responseUrl) {
			ecm.model.desktop.getActionsHandler(lang.hitch(this, function(actionsHandler) {
				var parsedUrl = new url(responseUrl);
				var params = ioQuery.queryToObject(parsedUrl.query);

				params.forDownload = "true";
				actionsHandler._performDownload("v1/viewoneAction", "", params);
			}));
		},

		_doCallback: function(callbackId, state) {
			this.logEntry("doCallback - callback Id: " + callbackId + ", state: " + state);
			this.viewer.setEventHandlerCallbackResponse(callbackId, state);
			this.logExit("doCallback");
		},

		_isRoundtripRedactionSupported: function() {
			var supported = false;

			if (this.item && this.item.repository && this.item.repository.type) {
				supported = this.item.repository.type == "cm" || this.item.repository.type == "p8";
			}

			return supported;
		},

		_selectRedactionSaveMode: function() {
			if (this._isRoundtripRedactionSupported()) {
				this._redactionSaveMode = this._getRedactionSaveMode();
				var canCheckoutDocument = this._canCheckoutDocument();
				var isVersioningavailable = this._isVersioningAvailable();
				var userSelectMode = false;
				if (this._redactionSaveMode == this.REDACTION_SAVE_MODE_NEW_VERSION) {
					if (canCheckoutDocument) {
						this._performCheckoutItem();
					} else {
						// if default save mode is new version but document can't be checked out, then ask user to save as new doc or local file
						userSelectMode = true;
					}
				} else if (this._redactionSaveMode == this.REDACTION_SAVE_MODE_USER_SELECT) {
					userSelectMode = true;
				}

				if (userSelectMode == true) {
					if (this.selectSaveMode)
						this.selectSaveMode.destroyRecursive(false);

					var repository = ecm.model.desktop.getRepository(this.item.repository.id);
					var canAddItem = repository ? (repository.getPrivilege("addItem") && (!ecm.model.desktop.fileIntoFolder || repository.getPrivilege("foldering"))) : false;

					// if document can be checked out, then ask user to choose save mode from "new version", "new document", or "local file"
					// For CM8, if document can be checked out, but is not versionable, save options will be "new content", "new document", or "local file"
					if (canCheckoutDocument && (isVersioningavailable || this.item.repository.type == "cm")) {
						var newVersionButton = ecm.messages.viewer_redaction_add_new_version_button;
						if (!isVersioningavailable) {
							newVersionButton = ecm.messages.viewer_redaction_add_new_version_button_version_never;
						}
						if (canAddItem) {
							// let user select from create new document, create new version, or save as local file
							var dialogText = ecm.messages.viewer_redaction_add_document_confirmation_question;
							if (!isVersioningavailable) {
								dialogText = ecm.messages.viewer_redaction_add_document_confirmation_question_version_never;
							}

							this.selectSaveMode = new YesNoCancelDialog({
								text: dialogText,
								title: ecm.messages.viewer_redaction_save_mode_title,
								yesLabel: newVersionButton,
								noLabel: ecm.messages.viewer_redaction_add_document_button,
								cancelButtonLabel: ecm.messages.viewer_redaction_add_local_file_button,
								onYes: lang.hitch(this, function() {
									this._redactionSaveMode = this.REDACTION_SAVE_MODE_NEW_VERSION;
									this._performCheckoutItem();
									this.selectSaveMode.hide();
								}),
								onNo: lang.hitch(this, function() {
									this._redactionSaveMode = this.REDACTION_SAVE_MODE_NEW_DOCUMENT;
									this.selectSaveMode.hide();
								}),
								onCancel: lang.hitch(this, function() {
									this._redactionSaveMode = this.REDACTION_SAVE_MODE_LOCAL_FILE;
								}),
							});
							this.selectSaveMode.setWidth(600);
						} else {
							// let user select from create new version or save as local file
							var dialogText = ecm.messages.viewer_redaction_new_version_confirmation_question;
							if (!isVersioningavailable) {
								dialogText = ecm.messages.viewer_redaction_new_version_confirmation_question_never;
							}

							this.selectSaveMode = new ConfirmationDialog({
								text: dialogText,
								buttonLabel: newVersionButton,
								cancelButtonLabel: ecm.messages.viewer_redaction_new_document_cancel_button,
								title: ecm.messages.viewer_redaction_save_mode_title,
								onExecute: lang.hitch(this, function() {
									this._redactionSaveMode = this.REDACTION_SAVE_MODE_NEW_VERSION;
								}),
								onCancel: lang.hitch(this, function() {
									this._redactionSaveMode = this.REDACTION_SAVE_MODE_LOCAL_FILE;
								}),
							});
						}
					} else if (canAddItem) {
						// let user select from create new document or save as local file
						this.selectSaveMode = new ConfirmationDialog({
							text: ecm.messages.viewer_redaction_new_document_confirmation_question,
							buttonLabel: ecm.messages.viewer_redaction_new_document_button,
							cancelButtonLabel: ecm.messages.viewer_redaction_new_document_cancel_button,
							title: ecm.messages.viewer_redaction_save_mode_title,
							onExecute: lang.hitch(this, function() {
								this._redactionSaveMode = this.REDACTION_SAVE_MODE_NEW_DOCUMENT;
							}),
							onCancel: lang.hitch(this, function() {
								this._redactionSaveMode = this.REDACTION_SAVE_MODE_LOCAL_FILE;
							}),
						});
					} else {
						// only save as local file is allowed for current user
						userSelectMode = false;
						this._redactionSaveMode = this.REDACTION_SAVE_MODE_LOCAL_FILE;
					}

					if (userSelectMode)
						this.selectSaveMode.show();
				}
			} else {
				this._redactionSaveMode = this.REDACTION_SAVE_MODE_LOCAL_FILE;
			}
		},

		_onAddDocumentCompleted: function(newItem) {
			if (newItem) {
				this._dirty = false;
				this.onDirty(this._dirty);
			}

			if (this.item.parent)
				this._refreshItem(this.item.parent);
		},

		_performAddNewDocument: function(json) {
			var repository = ecm.model.desktop.getRepository(this.item.repository.id);

			// always fetch item's parent folders since item.parent value is not always accurate
			this._performAddNewDocumentNoParentFolder(json, repository);
		},

		_performAddNewDocumentNoParentFolder: function(json, repository) {
			// when item's parent folder is unknown/invalid, try to fetch folders item is filed in
			this.getItem(lang.hitch(this, function(item) {
				item.retrieveFoldersFiledIn(lang.hitch(this, function(foldersFiledIn) {
					if (foldersFiledIn && foldersFiledIn.length == 1) {
						// if folders filed in just 1 folder, set it as the parent folder to add new item dialog.
						// in this mode user can't change parent folder. This is how add new item dialog implemented.
						this._onAddNewDocument(foldersFiledIn[0], json, repository);
					} else {
						// if item has no parent property or filed to multiple folders, pass null as parent folder and add new item dialog will point to root folder.
						// in this case user can select different parent folder, since ICN folder selector only supports start from root folder.
						this._onAddNewDocument(null, json, repository);
					}
				}));
			}));
		},

		_onAddNewDocument: function(folder, json, repository) {
			this.addContentItemDialog = new AddContentItemDialog({
				destroyWhenFinished: true
			});

			var partFileName = this._getPartFileName();
			partFileName = partFileName.substr(0, partFileName.lastIndexOf('.')) || partFileName;

			this.addContentItemDialog.setRedactionContent(json, partFileName);

			var addNewDocumentMode = this._getRedactionAddNewDocumentMode();
			if (addNewDocumentMode && addNewDocumentMode === this.REDACTION_ADD_DOCUMENT_MODE_ENTRY_TEMPLATE) {
				this.addContentItemDialog.showUsingTemplateItem(repository, folder, true, false, lang.hitch(this, this._onAddDocumentCompleted), null, null);
			} else {
				this.addContentItemDialog.setDefaultContentClass(this.item.getContentClass());

				var checkForTeamspace = folder && folder.repository.teamspacesEnabled;
				if (checkForTeamspace) {
					folder.retrieveTeamspace(lang.hitch(this, function(teamspace) {
						this.addContentItemDialog.show(repository, folder, true, false, lang.hitch(this, this._onAddDocumentCompleted), teamspace, false, null);
					}));
				} else {
					this.addContentItemDialog.show(repository, folder, true, false, lang.hitch(this, this._onAddDocumentCompleted), null, false, null);
				}
			}
		},

		_performCheckinRedaction: function(json) {
			this.getItem(lang.hitch(this, function(item) {
				item.checkInRedaction(json, lang.hitch(this, function(item, error) {
					if (item && !error) {
						this._redactionCheckoutDocument = false;
						this._redactionSavedItem = item;
						this._dirty = false;
						this.onDirty(this._dirty);

						if (this._editItem != item) {
							// item returned from checkInRedaction is not the same as returned from getItem (this._editItem),
							// so refresh...
							if (this._editItem.origItem) {
								// propagate the origItem...
								item.origItem = this._editItem.origItem;
							}

							// replace...
							this._editItem = item;
						}

						if (item.origItem) {
							item.origItem.update(item);
						}

						// lock item again so user can save new redaction again
						this._performCheckoutItem();
					} else {
						// show error dialog
						this._showErrorDialog("viewer_redaction_checkin_failed");
					}
				}), lang.hitch(this, function(response) {
					// show error dialog
					this._showErrorDialog("viewer_redaction_checkin_failed");
				}), this._getPartFileName());
			}));
		},

		_performCheckoutItem: function() {
			this.getItem(lang.hitch(this, function(item) {
				var items = [];
				items.push(item);

				item.repository.lockItems(items, lang.hitch(this, function(returnedItems) {
					if (returnedItems && returnedItems.length && (item.id == returnedItems[0].id)) {
						this._redactionCheckoutDocument = true;
						if (item.origItem) {
							item.origItem.update(item);
						}
					} else {
						this._redactionCheckoutDocument = false;
					}
				}), "released");
			}), true);
		},

		_checkRedectionCheckout: function(closingViewerWindow) {
			if (this._redactionCheckoutDocument === true) {
				var repository = this.item.repository;
				var items = [];
				items.push(this.item);
				repository.unlockItems(items);
				this._redactionCheckoutDocument = false;
				if (!closingViewerWindow && this._redactionSavedItem) {
					this.setItem(this._redactionSavedItem);
					this.showItem();
				}
			}
		},

		_startViewer: function(viewerId, retry) {
			var methodName = "_startViewer";
			if (window.com && window.com.ibm && window.com.ibm.dv && window.com.ibm.dv.client && window.com.ibm.dv.client.Viewer && window.com.ibm.dv.client.Viewer.start) {
				for (prop in window.com.ibm.dv.client.Viewer) {
					var propVal = window.com.ibm.dv.client.Viewer[prop];
					this.logDebug(methodName, "Viewer." + prop + " = " + propVal);
				}
				this.logDebug(methodName, "Starting " + viewerId + ", on retry " + retry);
				window.com.ibm.dv.client.Viewer.start(viewerId);
			} else if (retry < 5) {
				this.logDebug(methodName, "Viewer not found, starting delayed (" + retry + ")");
				setTimeout(lang.hitch(this, function() {
					this._startViewer(viewerId, ++retry);
				}, 1000));
			} else {
				this._startingViewer = false;
				this.logError(methodName, "Retry limit exceeded.  Viewer start failed.");
			}
		},

		/*  Method to be called when viewer download has completed and code is available to start viewer. */
		viewerReadyToStart: function() {
			this._loadingBootstrap = false;
			this._loadedBootstrap = true;

			var methodName = "viewerReadyToStart - id=" + this.viewerId;
			this.logEntry(methodName);
			var viewerLoaded = window[this.viewerId] && typeof (window[this.viewerId].openFile) == 'function';
			if (window.viewoneLoader && !viewerLoaded && !this._loadingViewer && this._loadedConfig) {
				this._startingViewer = true;
				this._loadingViewer = true;
				//window.viewoneLoader['isReady'] = true;
				this.logDebug(methodName, "attaching viewone listener methods");
				//check the viewer definition is present
				var viewerDefinition = document.getElementById(this.viewerId);
				if (viewerDefinition) {
					//attach viewer listener methods.
					window[this.viewerId + "_listener"] = {};

					var v1Interface = window[this.viewerId + "_listener"];
					this.logInfo("Viewer listener created: " + this.viewerId + "_listener");
					v1Interface.onSessionCheck = lang.hitch(this, "viewoneSessionCheck");
					v1Interface.onViewerReady = lang.hitch(this, "viewerReadyEvent");
					v1Interface.onDocReady = lang.hitch(this, "documentReadyEvent");
					v1Interface.onAnnotLoaded = lang.hitch(this, "annotLoadedEvent");//used for restore also
					v1Interface.onAnnotEdit = lang.hitch(this, "annotEditEvent");
					v1Interface.onAnnotRestore = lang.hitch(this, "annotRestoredEvent");
					v1Interface.onAnnotSaved = lang.hitch(this, "annotSavedEvent");
					v1Interface.onPrintStart = lang.hitch(this, "printStartEvent");
					v1Interface.onPrintFinish = lang.hitch(this, "printFinishEvent");
					v1Interface.onAnnotLoadFailure = lang.hitch(this, "annotLoadFailedEvent");
					v1Interface.onDocLoadFailure = lang.hitch(this, "documentLoadFailedEvent");
					v1Interface.onViewerModeChanged = lang.hitch(this, "modeChangeEvent");
					v1Interface.onRedactButtonPressed = lang.hitch(this, "redactTaskStartEvent");
					v1Interface.onRedactionTaskStarted = lang.hitch(this, "redactTaskStartedEvent");
					v1Interface.onRedactionTaskStatusChanged = lang.hitch(this, "redactTaskStatusEvent");
					
					window[this.viewerId + "_setRedactionReason"] = lang.hitch(this, "_setRedactionReasonEvent");
					window[this.viewerId + "_toggleRedactions"] = lang.hitch(this, "_toggleRedactionsEvent");
					
					var self = this;
					window[this.viewerId + "_isRedaction"] = function() {
						var returnValue = 0;
						var viewer = window[self.viewerId];
						
						if ( viewer && viewer.getActiveAnnotation ) {
							var annotation = viewer.getActiveAnnotation();
							if ( annotation && annotation.startsWith("Redact") ) {
							    returnValue = 5; // enable
							}
						}
						
						self.logDebug(self.viewerId + "_isRedaction returning: " + returnValue);
						return returnValue;
					};

					this.logInfo(methodName + ": starting viewer.");
					//start the viewer - viewer definition replaced with viewer
					this._startViewer(this.viewerId, 0);
				} else {
					this.logError("Daeja HTML Viewer configuration object not found");
				}
			} else if (this._loadingViewer) {
				this.logDebug(methodName, "viewer startup already in progress");
				if (!this._startingViewer) {
					this.logDebug(methodName, "viewer startup timed out, trying again.");
					this._startingViewer = true;
					this._startViewer(this.viewerId, 0);
				}
			} else if (viewerLoaded) { //picks up the DIV by id in Chrome
				this.logDebug(methodName, "viewer already loaded.");
				this.viewer = window[this.viewerId];
				this._loadDocument();
			} else {
				this.logDebug(methodName, "bootstrap not ready.");
			}
			this.logExit(methodName);
		},

		viewoneSessionCheck: function(id, responseText, callback) {
			var methodName = "viewoneSessionCheck";
			this.logEntry(methodName);

			if (id != 64)
				callback.onComplete('ignored', null);

			if (responseText && (responseText.indexOf("{") == 0 || responseText.indexOf("[") == 0)) {
				var responseObj = null;
				try {
					if (JSON) {
						if (responseText.length > 4 && responseText.substring(0, 4) == "{}&&") {
							responseText = responseText.substring(4);
						}
						responseObj = JSON.parse(responseText);
					} else if (dojojson) {
						responseObj = dojojson.fromJson(responseText);
					}

					if (responseObj.errors) {
						var theDesktop = null;
						var ecmContext = window;
						while (!(ecmContext.contentViewerPane || ecmContext.parent == ecmContext || ecmContext.parent == null))
							ecmContext = ecmContext.parent;

						if (ecmContext.ecm)
							theDesktop = ecmContext.ecm.model.desktop;

						if (theDesktop) {
							for ( var i in responseObj.errors) {
								var error = responseObj.errors[i];
								if (error.text && error.number && (error.number == 1003 || error.number == 1007)) {
									var dummyRequest = new ecmContext.ecm.model.Request();
									if (callback && callback.onComplete) {
										dummyRequest.viewoneCallback = callback;
										dummyRequest.retry = function() {
											var params = {
												"security_token": ""
											};
											var propertyUpdate = {};
											ecmContext.ecm.model.Request.setSecurityToken(params);
											propertyUpdate.name = 'security_token';
											propertyUpdate.value = params.security_token;
											this.viewoneCallback.onComplete('loggedIn', propertyUpdate);
										};
									}
									callback = null; //ensure it is not handled a the end of this method.
									theDesktop.onSessionExpired(dummyRequest, error);
									break;
								}
							}
						}
					}
				} catch (e) {
					if (callback) {
						try {
							callback.onComplete("error: " + e.message, null);
							callback = null;
						} catch (e) {
							callback = null;
						}
					}
				}
			}
			if (callback) {
				callback.onComplete("ok", null);
				callback = null;
			}

			this.logExit(methodName);
		},

		/*  End of viewer listener methods.      */
		_loadViewerConfig: function(dialogscope) {
		  
		    
			var methodName = "_loadViewerConfig - " + this.viewerId;
			this.logEntry(methodName);
			if (this._loadingConfig || this._loadedConfig) {
				this.logExit(methodName + ": loading config already in progress.");
				return;
			}

            console.log("dialogscope is  : ",dialogscope);
			
			console.log("selectedDocuments is are : ",dialogscope.selectedDocuments);
			
			var selectedFiles = JSON.parse(dialogscope.selectedDocuments);
			
			var repositoryId=selectedFiles.repositoryId;
			
			var userId= selectedFiles.userId;
			
			var objectStoreName=dialogscope.payload.Case.caseType.objectStore.symbolicName;
			
			//var caseReferenceNumber=dialogscope.payload.Case.caseObject.caseIdentifier;
			
			var selectedItemsArray=selectedFiles.items;
								
			var docIDsArray=new Array();
						
			console.log("repository id is : ",repositoryId);
			
			console.log("objectStoreName is : ",objectStoreName);
			
			console.log("selectedItemsArray  is : ",selectedItemsArray);
			
			var caseReferenceNumber_new=null;
			
			for(var i = 0; i < selectedItemsArray.length; i++)
			{
			     docIDsArray.push(selectedItemsArray[i].docIDs);
			     
			     caseReferenceNumber_new=selectedItemsArray[i].CaseRefNo;
				 				 
			}
			
			console.log("caseReferenceNumber_new  is#### ::: ",caseReferenceNumber_new);
			
			//console.log("caseReferenceNumber  is ::: ",caseReferenceNumber);
			
			console.log("repository id is : ",repositoryId);
									
			console.log("iddocIDsArray  is : ",docIDsArray);
			
			console.log("this.viewerId  is#### : ",this.viewerId);
			
			var FinalDocIdAray=docIDsArray[0];
			
			console.log("FinalDocIdAray  is : ",FinalDocIdAray);
			
			var methodName = "_loadViewerConfig - " + this.viewerId;


			this._loadingConfig = true;

			var params = {
				plugin: "ViewONEPlugin",
				action: "ViewONEVirtualViewer",
				viewerId: this.viewerId,
				preview: this.preview,
				mimetype: "image/tiff",
				//docurlbreak: this.docUrlBreak[1],
			};

			if (this._viewoneBootstrap != null) {
				params.viewoneBoostrapJSON = JSON.stringify(this._viewoneBootstrap);
			}
			else{
			   console.log("elseeeeeeeeeeeee1122333");
			   var viewerDataJson=new Object();
			   viewerDataJson.viewerId=this.viewerId;
			   var viewerJson=JSON.stringify(viewerDataJson);
			   params.viewoneBoostrapJSON = viewerJson;
			    console.log("params : ",params);
			}

			if (this.item && this.item.repository && this.item.repository) {
				if (this.item.repository.id) {
					params["repositoryId"] = this.item.repository.id;
				}

				if (this.item.repository.type) {
					//params["repositoryType"] = this.item.repository.type;
					params["repositoryType"] = "p8";
				}
			}

              params["repositoryId"] = repositoryId;
              
              //params["repositoryType"] = "p8";

		    Request.setSecurityToken(params);
			
			var security_token=ecm.model.Request.getSecurityToken(params);

            var idprint2 = '';
			var labelPrint = '';
			var pageCount2 = 0;
			var theLink2 = '/navigator/p8/getDocument.do?';
			var label = '';
			for(var i = 0; i < FinalDocIdAray.length; i++)
			{				
				var documentList=FinalDocIdAray[i].docID;
				var vsId=FinalDocIdAray[i].vsID;
				var toatlPages=FinalDocIdAray[i].totalPages;
				var docTitle = FinalDocIdAray[i].docTitle;
				var documentListAftersplit = documentList.split(",");
				var template_name=documentListAftersplit[0];
				var docid=documentListAftersplit[1];
				console.log("template_name is : ",template_name);
				console.log("docid is : ",docid);
				console.log("vsID is : ",vsId);
				console.log("toatlPages is : ",toatlPages);
				
				label ='Case Ref : '+caseReferenceNumber_new+', Doc Name: '+docTitle+',Printed  by: '+userId;
				
				var url2 = theLink2+'docid='+docid+'&template_name='+template_name+'&repositoryId='+repositoryId+'&vsId='+vsId+'&objectStoreName='+objectStoreName+'&security_token='+security_token;
												
						for(var j=1; j<=toatlPages; j++)
						{
							pageCount2 = pageCount2+1;
							idprint2 = idprint2+'<param value="'+url2+'#'+j+'" name="page'+pageCount2+'">';
							console.log("idprint2 url is ::: ",idprint2);
							
							var labelValue ='Case Ref #: '+caseReferenceNumber_new+', Doc Name: '+docTitle+', Page: '+j+' of '+toatlPages+', Printed  by: '+userId;
			                labelPrint = labelPrint+'<param value="'+labelValue+'" name="pageLabel'+pageCount2+'">';
			
						}
				
			}
			
			console.log("idprint2 final @@@@######: ",idprint2);

			request = ecm.model.Request.invokeService("v1/viewoneAction", null, params, lang.hitch(this, function(data, args) {
				
				//this.viewoneHtmlViewerContainer.innerHTML = data.responseHTML;
				
				console.log("44444444444444444444444444 ");
				var eventhandler11_Value=this.viewerId+"_listener.onDocLoadFailure";
				var eventhandler10_Value=this.viewerId+"_listener.onAnnotLoadFailure";
				var eventhandler9_Value=this.viewerId+"_listener.onAnnotLoaded";
				var eventhandler8_Value=this.viewerId+"_listener.onPrintStart";
				var eventhandler7_Value=this.viewerId+"_listener.onPrintFinish";
				var eventhandler6_Value=this.viewerId+"_listener.onAnnotSaved";
				var eventhandler5_Value=this.viewerId+"_listener.onAnnotRestore";
				var eventhandler4_Value=this.viewerId+"_listener.onAnnotEdit";
				var eventhandler3_Value=this.viewerId+"_listener.onViewerReady";
				var eventhandler2_Value=this.viewerId+"_listener.onDocReady";
				var eventhandler1_Value=this.viewerId+"_listener.onSessionCheck";
				
				console.log("eventhandler11_Value : ",eventhandler11_Value);
				//added by suresh
	            var body = 	'<object class="com.ibm.dv.client.Viewer" id="'+this.viewerId+'" width="100%" height="100%"'+
				'<param name="userId" value="p8admin"/>'+
				'<param name="traceNet" value="false"/>'+
				'<param name="annotate" value="true"/>'+
				'<param name="filenetSystem" value="4"/>'+
				'<param name="eventinterest11" value="61"/>'+
				'<param name="eventinterest10" value="60"/>'+
				'<param name="eventinterest9" value="59"/>'+
				'<param name="eventinterest8" value="57"/>'+
				'<param name="eventinterest7" value="26,27"/>'+
				'<param name="eventinterest6" value="24"/>'+
				'<param name="eventinterest5" value="33"/>'+
				'<param name="eventinterest4" value="30,32"/>'+
				'<param name="eventinterest3" value="22"/>'+
				'<param name="eventinterest2" value="5"/>'+
				'<param name="eventinterest1" value="64"/>'+
				'<param name="fileButtons" value="false"/>'+
				'<param name="traceAnnotations" value="false"/>'+
				'<param name="modifiedDocumentCheckMethod" value="uniqueid"/>'+
				'<param name="eventhandler11" value="'+eventhandler11_Value+'"/>'+
				'<param name="eventhandler10" value="'+eventhandler10_Value+'"/>'+
				'<param name="language" value="en"/>'+
				'<param name="trace" value="false"/>'+
				'<param name="eventhandler9" value="'+eventhandler9_Value+'"/>'+
				'<param value="true" name="printAnnotations">'+
				'<param value="true" name="annotate">'+
				'<param name="language" value="en">'+
                '<param name="trace" value="false">'+
				'<param name="backColor" value="240,240,240">'+
				'<param name="annotationHideButtons" value="hyperlink,transparent"/>'+
				'<param name="eventhandler8" value="'+eventhandler8_Value+'"/>'+
				'<param name="eventhandler7" value="'+eventhandler7_Value+'"/>'+
				'<param name="eventhandler6" value="'+eventhandler6_Value+'"/>'+
				'<param name="eventhandler5" value="'+eventhandler5_Value+'"/>'+
				'<param name="eventhandler4" value="'+eventhandler4_Value+'"/>'+
				'<param name="eventhandler3" value="'+eventhandler3_Value+'"/>'+
				'<param name="eventhandler2" value="'+eventhandler2_Value+'"/>'+
				'<param name="eventhandler1" value="'+eventhandler1_Value+'"/>'+
				'<param name="platform" value="navigator"/>'+
				'<param name="annotationUnits" value="inches"/>'+
				'<param name="annotationColorMask" value="0bgr"/>'+
				'<param name="obfuscateUV" value="false"/>'+
				'<param name="annotationAutoPrompt" value="false"/>'+
				'<param name="customAnnotationToolTip" value="&#x20;Created&#x20;By&#x3a;&#x20;&lt;creator&gt;,&#x20;&#x20;Created&#x20;On&#x3a;&#x20;&lt;createdate&gt;"/>'+
				'<param name="viewmode" value="fullpage"/>'+
				'<param name="scale" value="ftow"/>'+
				'<param name="invertButtons" value="true"/>'+
				'<param name="annotationSuppressEmptyMessages" value="true"/>'+
				'<param name="filenetAlwaysRubberband" value="true"/>'+
				'<param name="filenet" value="true"/>'+
				'<param name="javascriptExtensions" value="true"/>'+
				'<param name="annotationJavaScriptExtensions" value="true">'+
				'<param name="annotationEncoding" value="UTF8"/>'+
				'<param name="routeDocs" value="true"/>'+
				'<param name="xScroll" value="0"/>'+
				'<param name="yScroll" value="100"/>'+
				'<param name="DocIdMarker" value="id&#x3d;"/>'+
				'<param name="addEscapeCharactersToXML" value="true"/>'+
				'<param name="annotationJavascriptExtensions" value="true"/>'+
				'<param name="flipOptions" value="true"/>'+
				'<param name="annotateEdit" value="true"/>'+
				'<param name="FilenetAnnotationOutputCreator" value="true"/>'+
				'<param name="backColor" value="240,240,240"/>'+
				//'<param name="pageLabel" value="Myfirst page"/> '+
				'<param value="true" name="defaultPrintDoc"/>'+
				//'<param name="eventhandler" Value="'+printEventHandlerFunc+'">'+
				// '<param name="eventinterest" Value="57" >'+
				//'<param name="eventhandler" Value="'+this.printEventHandler(this.viewerId)+'">'+
			    '<param name="eventInterest" Value="38" >'+
				'<param NAME="printDocumentAllowed" Value="true">'+
				'<param value="true" name="allowPrintHeader"/>'+
				'<param value="true" name="printingColorHeader"/>'+
				'<param name="printLabels" value="true" />'+
				'<param name="printHeader" value="sample header text">'+
				idprint2+
				labelPrint+
				'<param name="filenetedition" value="2"></object>';
                				
				console.log("modifiedResponce HTML is1111 : ",body);
				
				//this.viewoneHtmlViewerContainer.innerHTML = body;
				

				
				dialogscope.viewer.innerHTML = body;
				
				
				
				
				
				this.logDebug(methodName, "configuration attached to document");
				this.onConfigLoaded();
			}), null, null, lang.hitch(this, function(data, args) {
				// the error will be routed to the desktop for handling/display.  So just log it here.
				this.logError(methodName + ": error loading viewer configuration" + data);
			}), false); // set background is false to prevent status dialog blurring the popup

			this.logExit(methodName);
		},

		_loadBootstrap: function() {
			var methodName = "_loadBootstrap - " + this.viewerId;
			this.logEntry(methodName);
			var bootstrapId = "viewoneBootstrapIni";
			//var listener = this;
			if (!window.viewoneBootstrap && document.getElementById(bootstrapId) == null && !this._loadedBootstrap || this.loadingBootstrap) {
				window.viewoneBootstrap = {
					"loading": "true"
				};

				this._loadingBootstrap = true;
				var loadCompleted = lang.hitch(this, "viewerReadyToStart");

				var stubUrl = ecm.model.desktop.getServicesUrl() + "/jaxrs/v1/viewoneAction?";
				var requestContent = {
					op: 'com.ibm.dv.client.Viewer',
					security_token: "token",  // per Daeja Development
					plugin: 'ViewONEPlugin',
					action: 'ViewONEPlatform',
					helpParameters: "security_token,action,plugin"
				};

				this.logDebug(methodName, "requesting bootstrap script");
				xhr.get({
					url: stubUrl,
					//handleAs: "json",//default is 'text'
					content: requestContent,//JSON.stringify(requestContent), 

					load: lang.hitch(this, function(data, args) {

						if (data.indexOf('<div ') == 0) {
							this._loadingBootstrap = false;
							this.viewoneHtmlViewerContainer.innerHTML = data;
						} else {
							var oHead = document.getElementsByTagName('HEAD').item(0);
							var oScript = document.createElement("script");
							oScript.language = "javascript";
							oScript.type = "text/javascript";
							oScript.id = bootstrapId;
							oScript.defer = "true";
							oScript.text = data;
							oHead.appendChild(oScript);
							this.logDebug(methodName, "viewer bootstrap script loaded ");

							if (window.viewoneLoader) {
								window.viewoneLoader.loadCompleted = loadCompleted;
							} else {
								this.logError("Error starting viewer bootstrap.");
							}
						}
					}),

					error: lang.hitch(this, function(data, args) {
						this._loadingBootstrap = false;
						this.viewoneHtmlViewerContainer.innerHTML = data;
						this.logError("Error retrieving viewer bootstrap");
					})
				});
			} else if (document.getElementById(bootstrapId) != null && !this._loadedBootstrap && window.initViewer) {
				this.logDebug(methodName, "ViewOne bootstrap was loaded by another viewer - initialising viewer object.");
				//bootstrap was loaded by another viewer. 
				this._loadingBootstrap = false;
				this._loadedBootstrap = true;
				this.viewerReadyToStart();
			} else {
				if (document.getElementById(bootstrapId) != null) {
					this._loadingBootstrap = false;
					this._loadedBootstrap = true;
					this.logDebug(methodName, "ViewOne bootstrap already loaded.");
					if (window[bootstrapId]) {
						this.viewerReadyToStart();
					} else {
						this.logError(methodName + ": viewer load failure.");
					}
				} else if (this._loadingBootstrap) {
					this.logDebug(methodName, "already loading bootstrap.")
				}
			}
			this.logExit(methodName);
		},

		_getAnnotHideButtons: function(bootstrap) {
			if (bootstrap != null && bootstrap.viewOneParameters && bootstrap.viewOneParameters.annotationHideButtons)
				return bootstrap.annotationHideButtons;
			else if (this.isFederated)
				return 'line, solidtext, highlightpoly, rectangle, poly, openpoly, oval, hyperlink, transparent';
			else
				return 'hyperlink,transparent';
		},

		_getAnnotHideContextButtons: function(bootstrap) {
			if (bootstrap != null && bootstrap.viewOneParameters && bootstrap.viewOneParameters.annotationHideContextButtons)
				return bootstrap.annotationHideContextButtons;
			else if (this.isFederated)
				return 'save,text, hyperlink,behind, transparent,security';
			else
				return 'hyperlink,behind,transparent,security';
		},

		_getAnnotHideContextButtonIds: function(bootstrap) {
			if (bootstrap != null && bootstrap.viewOneParameters && bootstrap.viewOneParameters.annotationHideContextButtonIds)
				return bootstrap.annotationHideContextButtonIds;
			else if (this.isFederated)
				return 'note, freehand, stamp, arrow, highlight, text, transparent';
			else
				return null;
		},

		_getPartFileName: function() {
			if (this._viewoneBootstrap && this._viewoneBootstrap.partFileName)
				return this._viewoneBootstrap.partFileName;

			return ecm.messages.viewer_redaction_new_version_default_filename;
		},

		_getRedactionSaveMode: function() {
			if (this._viewoneBootstrap)
				return this._viewoneBootstrap.redactionSaveMode;

			return this.REDACTION_SAVE_MODE_USER_SELECT;
		},

		_getRedactionAddNewDocumentMode: function() {
			if (this._viewoneBootstrap && this._viewoneBootstrap.redactionAddDocumentMode)
				return this._viewoneBootstrap.redactionAddDocumentMode;

			return this.REDACTION_ADD_DOCUMENT_MODE_STANDARD;
		},

		_canCheckoutDocument: function() {
			return this._viewoneBootstrap && this._viewoneBootstrap.versionCheckoutAvailable === true;
		},

		_isVersioningAvailable: function() {
			return this._viewoneBootstrap && this._viewoneBootstrap.versioningAvailable === true;
		},

		_loadViewoneBootstrap: function() {
			this._loadingViewoneBootstrap = true;

			var params = {
				docUrl: this.viewerDef.getDocUrl(this._item),
				repositoryId: this._item.repository.id,
				preview: this.preview,
				viewer: "virtual"
				//canEdit: this._item.hasPrivilege("privEditDoc"),
				//viewerId: this.viewerId
			};

			ecm.model.Request.invokeService("getViewoneBootstrap", this._item.repository.type, params, lang.hitch(this, function(response) {
				this._loadingViewoneBootstrap = false;
				this._loadedViewoneBootstrap = true;
				this._viewoneBootstrap = response.viewOneBootstrap;
				this._loadViewerConfig();
			}), null, null, lang.hitch(this, function(response) {
				this._loadingViewoneBootstrap = false;
				this._loadedViewoneBootstrap = true;
				this._viewoneBootstrap = null;
				this._loadViewerConfig();
			}), false); // set background is false to prevent status dialog blurring the popup
		},

		_loadDocument: function() {
			var methodName = "_loadDocument - " + this.viewerId;
			this.logEntry(methodName);
			if (!this._loadingDocument) {
				this._loadingDocument = true;
				this._loadDocumentProcessor(this._viewoneBootstrap);
			} else {
				this.logDebug(methodName, "document already loading.");
			}
			this.logExit(methodName);
		},

		_loadDocumentProcessor: function(bootstrap) {
			var methodName = "_loadDocumentProcessor - " + this.viewerId;
            console.log("this in loaddocument processor :",this);
            var repositoryType="p8";
			//set the annot load url
			this.logDebug(methodName, "page=" + this._pageNumber + "; docURL=" + this.docURL);

			var pageList = [];
			var isFederated = false;

			if (bootstrap != null) {
				if (bootstrap.getContentUrl) {
					this.docURL = bootstrap.getContentUrl;
				}

				if (bootstrap.getAnnotationUrl) {
					this.viewer.setAnnotationFile(bootstrap.getAnnotationUrl);
				}

				if (bootstrap.updateAnnotationUrl) {
					this.viewer.setAnnotationSavePost(bootstrap.updateAnnotationUrl);
				}

				if (this.viewer.setFileNetCOLDTemplateResource) {
					if (bootstrap.coldTemplateUrl) {
						this.viewer.setFileNetCOLDTemplateResource(bootstrap.coldTemplateUrl);
					}
				} else {
					this.logDebug(methodName, "Method setFileNetCOLDTemplateResource was not found.");
				}

				if (bootstrap.contentElements) {
					pageList = bootstrap.contentElements;
				}

				if (this.item.replicationGroup) {
					this.isFederated = this.item.replicationGroup != null;
				}
			//} else if (this.item.repository.type == "p8") {
			} else if (repositoryType == "p8") {
				this.viewer.setAnnotationFile(this.docURL + "&alt_output=Annotations");
				//set the annot save url
				this.viewer.setAnnotationSavePost(this.saveAnnotURL);

				if (this.viewer.setFileNetCOLDTemplateResource) {
					this.viewer.setFileNetCOLDTemplateResource(this.coldTemplateURL);
				} else {
					this.logDebug(methodName, "Method setFileNetCOLDTemplateResource was not found.");
				}

			/*	var contentElementsPresent = this.item.attributes.ContentElementsPresent;
				if (contentElementsPresent) {
					for (var e = 0; e < contentElementsPresent.length; e++) {
						if (!ContentItem.NoContentMimeTypes[contentElementsPresent[e]]) {
							pageList.push(e);
						}
					}
				}

				if (this.item.replicationGroup) {
					this.isFederated = this.item.replicationGroup != null;
				}*/
			}

			var annotHideButtons = this._getAnnotHideButtons(bootstrap);
			var annotHideContextButtons = this._getAnnotHideContextButtons(bootstrap);
			var annotHideContextButtonIds = this._getAnnotHideContextButtonIds(bootstrap);

			if (this.viewer.setAnnotationHideButtons) {
				this.viewer.setAnnotationHideButtons(annotHideButtons);
			} else {
				this.logDebug(methodName, "Method setAnnotationHideButtons was not found.");
			}

			if (this.viewer.setAnnotationHideContextButtons) {
				this.viewer.setAnnotationHideContextButtons(annotHideContextButtons);
			} else {
				this.logDebug(methodName, "Method setAnnotationHideContextButtons was not found.");
			}

			if (this.viewer.setAnnotationHideContextButtonsIds) {
				if (annotHideContextButtonIds != null) {
					this.viewer.setAnnotationHideContextButtonsIds(annotHideContextButtonIds);
				}
			} else {
				this.logDebug(methodName, "Method setAnnotationHideContextButtonsIds was not found.");
			}

			//open document
			if (pageList.length <= 1)
				this.viewer.openFile(this.docURL, this._pageNumber);
			else {
				this.viewer.initializePageArray(pageList.length);

				for (var n = 0; n < pageList.length; n++)
					this.viewer.setPageArray(this.docURL + '&element=' + pageList[n], n);

				this.viewer.openPageArray(this._pageNumber);
			}

		//	this.viewer.setAnnotationsSemiTransparent(this._isSetRedactionTransparent, "redacttypes");
		//	this.viewer.setFocus(true);
		},

		_showErrorDialog: function(key, callback) {
			if (!this._errorDialog) {
				this._errorDialog = new ErrorDialog({
					onShow: lang.hitch(this, function() {
					}),
					onHide: lang.hitch(this, function() {
						if (callback && callback != null) {
							callback();
						}
					})
				});
			}

			var message = Message.createErrorMessage(key);
			message.text = message.text + this._errorDialog.showMessage(message);
		},

		/** @private */
		uninitialize: function() {
			var methodName = "uninitialize";
			this.logEntry(methodName);
			if (!this._uninitialized) {
				if (this.selectSaveMode) {
					this.selectSaveMode.destroyRecursive(false);
					this.selectSaveMode = null;
				}

				if (this._errorDialog) {
					this._errorDialog.destroyRecursive(false);
					this._errorDialog = null;
				}

				this._uninitialized = true;
			}
		}
	});

	ViewoneHTMLViewer._securityTokenHandler = null;

	ViewoneHTMLViewer._updateSecurityToken = function() {
		if (window.com && window.com.ibm && window.com.ibm.dv && window.com.ibm.dv.client //
				&& window.com.ibm.dv.client.Viewer && window.com.ibm.dv.client.Viewer.updateRequestParameter) {
			var params = {};
			ecm.model.Request.setSecurityToken(params);
			window.com.ibm.dv.client.Viewer.updateRequestParameter("security_token", params.security_token);
		}
	};

	return ViewoneHTMLViewer;
});
