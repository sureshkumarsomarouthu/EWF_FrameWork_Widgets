define([ "dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/_base/array",
         "dojo/on",
         "ecm/widget/dialog/BaseDialog",
         "dojo/text!./templates/SignatureProcessingOptionsDialog.html",
         "dojo/dom-construct",
         "dijit/form/CheckBox",
         "dijit/form/TextBox",
         "v11/ewf/widget/dataentry/ValidationTextarea",
         "dojo/Deferred",
         "dojo/when"
       ], function(declare, lang, baseArray, on, BaseDialog, template, domConstruct, CheckBox, TextBox, ValidationTextarea, Deferred, when){
	
	return declare("v11.ewf.dialog.signatureprocessingdialog.SignatureProcessingOptionsDialog", [BaseDialog], {
		
		contentString: template,
		
		title: "Select Reasons",
		
		parentCellForReasons: null,
		
		selectedOptions: "",
		
		createdWidgets: [],
		
		promiseForTextBox: null,
		
		othersTextBox: null,
		
		availableOptions: [ 
		                    "Account under maintenance",
							"Signature is a thumbprint",
							"Signatory status is not active",
							"Irregular signatures",
							"Does not comply with mandate",
							"Unable to verify"
						],
		availableOptionsForStaff: [
							"Signature Irregular",
							"Short/Missing of authorized signatures",
							"RM/Team Head/ Division Head/ Sector Head/ Business Support Signature and approval required",
							"Not according to the Authorized signatory list/Signatue/BU transaction Grid",
							"BU/Branch Stamp/Name of authorized signatory/ staff code not clear or not provided",
							"CTC of instruction/ supporting doc - authorized signatures required",
							"Reason for approval not provided",
							"Unable to verify"
		                ],
        availableOptionsForStaffChangesMap: {
       							"Short/Missing of authorized signatures": "Short/ Missing of Authorized Signature(s)",
       							"RM/Team Head/ Division Head/ Sector Head/ Business Support Signature and approval required": "RM/ Team Head/ Division Head/ Sector Head/ Business Support signature and approval required",
       							"Not according to the Authorized signatory list/Signatue/BU transaction Grid": "Not according to the Authorized Signatory list/ Signature/ BU Transaction Grid",
       							"BU/Branch Stamp/Name of authorized signatory/ staff code not clear or not provided": "BU/ Branch stamp/ Name of Authorized Signatory/ Staff Code not clear or not provided",
       							"CTC of instruction/ supporting doc - authorized signatures required": "CTC of instruction/ Supporting doc - Authorized Signature(s) required"
        },
		constructor: function(args){
			declare.safeMixin(this, args);
		},
		
		postCreate: function(){
			this.inherited(arguments);
			this.setTitle(this.title);
			var okButtonObj = {
				buttonLabel: "Ok",
				onExecute: this.onOkClick,
				disabled: false,
				isDefault: false
			};
			this.okButton = this.addButton(okButtonObj.buttonLabel, okButtonObj.onExecute, okButtonObj.disabled, okButtonObj.isDefault);
		},
		
		onOkClick: function(){
			var _this = this;
			//Massage the options selected (if required)
			var selectedOptionsCSV = _this.selectedOptions;
			if(selectedOptionsCSV && (selectedOptionsCSV.indexOf("Unable to verify") > -1)){
				if(selectedOptionsCSV.indexOf("Unable to verify(") > -1){
					//Remove the Earlier value and replace with Others (without the brackets)
					var selectedOptionsSubString = selectedOptionsCSV.substring(selectedOptionsCSV.indexOf("Unable to verify("));
					
					var earlierTextBoxValue = selectedOptionsSubString.slice(selectedOptionsSubString.indexOf("Unable to verify("), selectedOptionsSubString.indexOf(")")+1);
					
					var replacedString = _this.replaceAndReturn(selectedOptionsCSV, earlierTextBoxValue, "Unable to verify");
					_this.set('selectedOptions', replacedString);
				}
				selectedOptionsCSV = _this.selectedOptions;
				//Then append the new value to the selectedOptions property
				var valueToSave = _this.othersTextBox.get('value');
				/*try{
					var tempObj = {'key': _this.othersTextBox.get('value')};
					valueToSave = JSON.stringify(tempObj['key']);
				}catch(e){
					valueToSave = _this.othersTextBox.get('value');
				}*/
				var replacedString = _this.replaceAndReturn(selectedOptionsCSV, "Unable to verify", "Unable to verify(" + valueToSave + ")");
				_this.set('selectedOptions', replacedString);
			}
			
			//One point to set the updated values from availableOptionsForStaffChangesMap
		},
		
		setSelectedOptions: function(value){
			this.selectedOptions = value;
		},
		
		createOptions: function(){
			var _this=this;
			baseArray.forEach(this.createdWidgets, function(widget){
				try{widget && widget.destroyRecursive && widget.destroyRecursive();}catch(e){}
			});
			_this.othersTextBox = null;
			_this.promiseForTextBox && _this.promiseForTextBox.cancel && _this.promiseForTextBox.cancel("");
			_this.promiseForTextBox = new Deferred(function(reason){/*Thread Cancelled !!*/});
			domConstruct.empty(this.optionsArea);
			
			var optionsArray = this.availableOptions;
			
			//For Staff, use the other set of options to render
			if(_this.populateReasonsFor && (_this.populateReasonsFor === 'Staff'))
				optionsArray = _this.availableOptionsForStaff;
			
			var selectedOptionsCSV = this.selectedOptions;
			
			var cb, table = domConstruct.create("table", {style: "width: 99%;"}), tr, td1, td2, currentOption, oldOption;
			for(var i=0; i<optionsArray.length; i++){
				currentOption = optionsArray[i];
				oldOption = optionsArray[i];
				if(_this.availableOptionsForStaffChangesMap.hasOwnProperty(currentOption) && _this.availableOptionsForStaffChangesMap[currentOption]){
					currentOption = _this.availableOptionsForStaffChangesMap[currentOption];
				}
				cb = new CheckBox({
					value: currentOption,
					name: currentOption,
			        onChange: function(isChecked){
			        	var currentValue = this.get("name");
			        	
			        	//To Add a textbox if in case Others Options is selected --> Starts here
			        	if((currentValue === "Unable to verify") || (currentValue.indexOf("Unable to verify") === 0)){
			        	    //added by suresh for dialog resize issue after upgrade to 5.2.1 
			        	   _this.setSize(600,500);
			        		var trForTextBox, tdForTextBox;
			        		if(_this.othersTextBox === null){
			        			_this.othersTextBox = new ValidationTextarea({
			        				"style": "width: 95%; height: 100px;", 
			        				"maxLength": 250,
			        				/*"pattern": '[a-zA-Z0-9`~!@#$%^&*-_=+;:,<.>?{[}]|%\\s]*',*/
			        				'pattern': '[a-zA-Z0-9`~!@#^?$@#!,+\-=_:.&*%\\s]*',
			        				"invalidMessage": "Does not accept '{', '}', '[', ']', \''\', '\"', '(' and ')'. Please correct and retry."
			        			});
			        			trForTextBox = domConstruct.create("tr");
			        			tdForTextBox = domConstruct.create("td");
			        			tdForTextBox.colSpan=2;
			        			trForTextBox.appendChild(tdForTextBox);
			        			
			        			tdForTextBox.appendChild(domConstruct.create("div", {"innerHTML": "(Max 250 chars)"}));
			        			
			        			tdForTextBox.appendChild(_this.othersTextBox.domNode);
			        			cb.domNode.parentNode.parentNode.parentNode.appendChild(trForTextBox);
			        			_this.othersTextBox.startup();
			        			_this.createdWidgets.push(_this.othersTextBox);
			        			
			        			if(isChecked){
			        				_this.othersTextBox.domNode.style.display='inline-block';
			        				try{_this.othersTextBox.domNode.parentElement.style.display = '';}catch(e){}
			        			}else{
			        				try{_this.othersTextBox.domNode.parentElement.style.display = 'none';}catch(e){}
			        				_this.othersTextBox.domNode.style.display='none';
			        			}
			        			
								_this.promiseForTextBox.resolve("TextBox created");
			        			
			        			_this.keyUpHandlerForTextArea = on(_this.othersTextBox, 'keyup', function(){
			        				if(_this.othersTextBox){
			        					if(_this.othersTextBox.isValid && _this.othersTextBox.isValid()){
			        						_this.okButton.set('disabled', false);
			        					}else{
			        						_this.okButton.set('disabled', true);
			        					}
			        				}else{
			        					_this.okButton.set('disabled', false);
			        				}
			        			});
			        		}else{
			        			if(isChecked){
			        				try{_this.othersTextBox.domNode.parentElement.style.display = '';}catch(e){} 
			        				_this.othersTextBox.domNode.style.display='inline-block';
			        				_this.keyUpHandlerForTextArea = on(_this.othersTextBox, 'keyup', function(){
				        				if(_this.othersTextBox){
				        					if(_this.othersTextBox.isValid && _this.othersTextBox.isValid()){
				        						_this.okButton.set('disabled', false);
				        					}else{
				        						_this.okButton.set('disabled', true);
				        					}
				        				}else{
				        					_this.okButton.set('disabled', false);
				        				}
				        			});
			        			}else{
			        				try{_this.othersTextBox.domNode.parentElement.style.display = 'none';}catch(e){}
			        				_this.othersTextBox.domNode.style.display='none';
			        				
			        				//if Unchecked unable to verify, remove the key handler and enable ok button
			        				_this.keyUpHandlerForTextArea && _this.keyUpHandlerForTextArea.remove && _this.keyUpHandlerForTextArea.remove();
			        				_this.othersTextBox.set("value", "");
			        				_this.okButton.set('disabled', false);
			        			}
			        		}
			        	}
			        	//To Add a textbox if in case Others Options is selected --> ends here
			        	
			        	if(_this.selectedOptions.indexOf(",") > -1){
			        		if(_this.selectedOptions.indexOf(currentValue) < 0){
		        				if(isChecked){
		        					_this.selectedOptions = _this.selectedOptions + "," + currentValue;
		        				}
		        			}else{
		        				if(!isChecked){
		        					
		        					//Do special Processing - starts here
		        					if(currentValue === "Unable to verify"){
		        						if(_this.selectedOptions.indexOf("Unable to verify(") > -1){
		        							//Remove the Earlier value and replace with Unable to verify (without the brackets)
		        							//var earlierTextBoxValue = _this.selectedOptions.slice(_this.selectedOptions.indexOf("Unable to verify("), _this.selectedOptions.lastIndexOf(")")+1);
		        							var selectedOptionsSubString = _this.selectedOptions.substring(_this.selectedOptions.indexOf("Unable to verify("));
		        							var earlierTextBoxValue = selectedOptionsSubString.slice(selectedOptionsSubString.indexOf("Unable to verify("), selectedOptionsSubString.indexOf(")")+1);
		        							
		        							
		        							var replacedString = _this.replaceAndReturn(_this.selectedOptions, earlierTextBoxValue, "Unable to verify");
		        							_this.set('selectedOptions', replacedString);
		        						}
		        					}
		        					//Do special Processing - ends here
		        					var replacedString = _this.replaceAndReturn(_this.selectedOptions, currentValue, "");
		        					_this.selectedOptions = replacedString;
		        				}
		        			}
		        		}else{
		        			if(isChecked){
		        				_this.selectedOptions = currentValue;
		        			} else{
		        				_this.selectedOptions = _this.selectedOptions + "";
		        				
		        				//Do special Processing - starts here
		        				if(currentValue === "Unable to verify"){
	        						if(_this.selectedOptions.indexOf("Unable to verify(") > -1){
	        							//Remove the Earlier value and replace with Others (without the brackets)
	        							//var earlierTextBoxValue = _this.selectedOptions.slice(_this.selectedOptions.indexOf("Unable to verify("), _this.selectedOptions.lastIndexOf(")")+1);
	        							var selectedOptionsSubString = _this.selectedOptions.substring(_this.selectedOptions.indexOf("Unable to verify("));
	        							var earlierTextBoxValue = selectedOptionsSubString.slice(selectedOptionsSubString.indexOf("Unable to verify("), selectedOptionsSubString.indexOf(")")+1);
	        							
	        							var replacedString = _this.replaceAndReturn(_this.selectedOptions, earlierTextBoxValue, "Unable to verify");
	        							_this.set('selectedOptions', replacedString);
	        						}
	        					}
		        				//Do special Processing - ends here
		        				var replacedString = _this.replaceAndReturn(_this.selectedOptions, currentValue, "");
		        				_this.selectedOptions = replacedString;
		        			}
		        		}
			        }
			    });
				
				if(_this.availableOptionsForStaffChangesMap.hasOwnProperty(oldOption) && _this.availableOptionsForStaffChangesMap[oldOption]){
					/*var booleanToCheck = true && (selectedOptionsCSV.indexOf(oldOption) > -1);
					if(!booleanToCheck){
						var changedOption = availableOptionsForStaffChangesMap[oldOption];
						booleanToCheck = true && (selectedOptionsCSV.indexOf(oldOption) > -1);
					}*/
					cb.set("checked", (selectedOptionsCSV.indexOf(oldOption) > -1) || (selectedOptionsCSV.indexOf(currentOption) > -1));
				}else{
					cb.set("checked", selectedOptionsCSV.indexOf(currentOption) > -1);
				}
				
				//If Others Checkbox is checked, populate the text box with the data provided
				if((selectedOptionsCSV.indexOf(currentOption) > -1) && (currentOption==="Unable to verify")){
					when(_this.promiseForTextBox.promise, function(value){
						_this.othersTextBox.domNode.style.display='inline-block';
						try{_this.othersTextBox.domNode.parentElement.style.display = '';}catch(e){}
						
						if(selectedOptionsCSV.indexOf("Unable to verify(") > -1){
							//var textBoxValue = selectedOptionsCSV.slice(selectedOptionsCSV.indexOf("Unable to verify(")+17, selectedOptionsCSV.lastIndexOf(")"));
							var selectedOptionsSubString = selectedOptionsCSV.substring(selectedOptionsCSV.indexOf("Unable to verify("));
							var textBoxValue = selectedOptionsSubString.slice(selectedOptionsSubString.indexOf("Unable to verify(")+17, selectedOptionsSubString.indexOf(")"));
							var valueToShow = textBoxValue;
							/*try{
								valueToShow = dojo.fromJson(textBoxValue);
							}catch(e){}*/
							_this.othersTextBox.set('value', valueToShow);
						}
					});
				}
				
				tr = domConstruct.create("tr");
				td1 = domConstruct.create("td");
				td2 = domConstruct.create("td");
				td1.appendChild(cb.domNode);
				td2.appendChild(domConstruct.toDom("<span><b>" + currentOption + "</b></span>"));
				tr.appendChild(td1);
				tr.appendChild(td2);
				table.appendChild(tr);
				cb.startup();
				_this.createdWidgets.push(cb);
			}
			domConstruct.place(table, this.optionsArea, "only");
		},
		
		_setSelectedOptionsAttr: function(value){
			this.selectedOptions = value;
		},
		
		_getSelectedOptionsAttr: function(){
			return this.selectedOptions;
		},
		
		replaceAll: function(a, b){
			this.selectedOptions.replace(new RegExp(a, "g"), b);
		},
		
		replaceAndReturn: function(sourceString, searchTarget, replaceString){
			var tmpSep1 = "forwardSlash";
			var tmpSep2 = "parenthesisBracketOpen";
			var tmpSep3 = "parenthesisBracketClose";
			//Convert all the '/' (forward slashes), '(' && ')' in the source string to a temporary separator
			var tmpSourceString = sourceString.replace(/\//g, tmpSep1).replace(/\(/g, tmpSep2).replace(/\)/g, tmpSep3);
			var tmpSearchTarget = searchTarget.replace(/\//g, tmpSep1).replace(/\(/g, tmpSep2).replace(/\)/g, tmpSep3);
			var tmpReplaceString = replaceString.replace(/\//g, tmpSep1).replace(/\(/g, tmpSep2).replace(/\)/g, tmpSep3);
			var returnString = tmpSourceString.replace(new RegExp(tmpSearchTarget, "g"), tmpReplaceString);
			returnString = returnString.replace(new RegExp(tmpSep1, "g"), "/").replace(new RegExp(tmpSep2, "g"), "(").replace(new RegExp(tmpSep3, "g"), ")");
			return returnString;
		},
		
		reset: function(){
			baseArray.forEach(this.createdWidgets, function(widget){
				try{widget && widget.destroyRecursive && widget.destroyRecursive();}catch(e){}
			});
			domConstruct.empty(this.optionsArea);
		}
	});
});