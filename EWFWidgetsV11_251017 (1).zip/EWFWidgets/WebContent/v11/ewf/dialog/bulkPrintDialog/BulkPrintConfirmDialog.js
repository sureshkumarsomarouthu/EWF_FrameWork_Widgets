/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([
	"dojo/_base/declare", 
	"dojo/_base/connect", 
	"dojo/_base/lang", 
	"dojo/dom-class", 
	"dojo/dom-attr", 
	"dojo/dom-style", 
	"ecm/widget/dialog/BaseDialog", 
	"dojox/lang/functional",
	"dojo/_base/array",
	"dojo/dom-construct",
	"dojo/text!./templates/BulkPrintConfirmContent.html" 
], 
function(declare, connect, lang, domClass, domStyle, domAttr, BaseDialog, functional, array, construct, template) {

	/**
	 * @name v11.ewf.dialog.bulkPrintDialog.BulkPrintConfirmDialog
	 * @class Provides a confirmation dialog box
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("v11.ewf.dialog.bulkPrintDialog.BulkPrintConfirmDialog", [ BaseDialog ], {
		/** @lends v11.ewf.dialog.bulkPrintDialog.BulkPrintConfirmDialog.prototype */

		text: 'Do you want to Proceed with Bulk Print by skipping the below cases.If yes press <b>Skip</b> Button.',
		title: 'Confirm',
		contentString: template,
		cancelButtonDefault: true,
		containReason: false,

		postCreate: function() {
			this.inherited(arguments);
			domClass.add(this.domNode, "ewfBulkPrintDialog");
			domAttr.set(this.domNode, "aria-describedby", this.description.id);
			
			if(this.result.InProcessCases && this.result.CaseStatusDetails){
				var table = "<br><b><u>In-Process Cases:</u></b><br><table border='1' style='width: 95%; height: auto;'><thead><tr><th>Case Ref Number</th><th>Case Status</th></tr></thead>";
				array.forEach(this.result.InProcessCases, lang.hitch(this, function(caseRef) {
					if(this.result.CaseStatusDetails[caseRef]){
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>" + this.result.CaseStatusDetails[caseRef] + "</td></tr>"; 
					}else{
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>In-Process</td></tr>";
					}
				}));
				table = table + "</table><br>";
				this.bulkPrintInfo.appendChild(construct.toDom(table));
			}
			if(this.result.CompletedCases && this.result.CaseStatusDetails){
				var table = "<br><b><u>Completed Cases:</u></b><br><table border='1' style='width: 95%; height: auto;'><thead><tr><th>Case Ref Number</th><th>Case Status</th></tr></thead>";
				array.forEach(this.result.CompletedCases, lang.hitch(this, function(caseRef) {
					if(this.result.CaseStatusDetails[caseRef]){
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>" + this.result.CaseStatusDetails[caseRef] + "</td></tr>";
					}else{
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>Completed</td></tr>";
					}
				}));
				table = table + "</table><br>";
				this.bulkPrintInfo.appendChild(construct.toDom(table));
			}
			if(this.result.LockedCases && this.result.CaseStatusDetails){
				var table = "<br><b><u>Locked Cases:</u></b><br><table border='1' style='width: 95%; height: auto;'><thead><tr><th>Case Ref Number</th><th>Case Status</th><th>Locked By</th></tr></thead>";
				functional.forIn(functional.keys(this.result.LockedCases), lang.hitch(this, function(caseRef) {
					var lockedById = this.result.LockedCases[caseRef];
					if(this.result.CaseStatusDetails[caseRef]){
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>" + this.result.CaseStatusDetails[caseRef] + "</td><td>" + lockedById + "</td></tr>";
					}else{ 
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>Locked</td><td>" + lockedById + "</td></tr>";
					} 
				}));
				table = table + "</table><br>";
				this.bulkPrintInfo.appendChild(construct.toDom(table));
			}
			if(this.result.LockFailedCases && this.result.CaseStatusDetails){
				var table = "<br><b><u>Lock Failed Cases:</u></b><br><table border='1' style='width: 95%; height: auto;'><thead><tr><th>Case Ref Number</th><th>Case Status</th><th>Lock Fail Reason</th></tr></thead>";
				functional.forIn(functional.keys(this.result.LockFailedCases), lang.hitch(this, function(caseRef) {
					var lockFailReason = this.result.LockFailedCases[caseRef];
					if(this.result.CaseStatusDetails[caseRef]){
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>" + this.result.CaseStatusDetails[caseRef] + "</td><td>" + lockFailReason + "</td></tr>";
					}else{
						table = table + "<tr align='center'><td>" + caseRef + "</td><td>Lock Failed</td><td>" + lockFailReason + "</td></tr>";
					} 
				}));
				table = table + "</table><br>";
				this.bulkPrintInfo.appendChild(construct.toDom(table));
			}
			this.setResizable(true);
			var b1 = this.addButton('Skip', this.onSkip, false, !this.cancelButtonDefault);
			connect.connect(b1, "onClick", lang.hitch(this, function(){this.hide();}));
					
			// Make the cancel button the default if requested.
			if (this.cancelButtonDefault) {
				this.autofocus = false;
				connect.connect(this, "onKeyDown", this, function(event) {
					if (event.keyCode == 13)
						this[onCancel]();
				});
			}
		},

		show: function() {
			this.inherited(arguments);
			if (this.cancelButtonDefault) {
				setTimeout(lang.hitch(this, function() {
					this.cancelButton.focus();
				}, 300));
			}
		}
	});
});
