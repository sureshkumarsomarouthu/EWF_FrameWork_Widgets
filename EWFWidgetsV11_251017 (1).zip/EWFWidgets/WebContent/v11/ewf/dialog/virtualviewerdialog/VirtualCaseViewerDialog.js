/**
 * Licensed Materials - Property of IBM (C) Copyright IBM Corp. 2012 US Government Users Restricted Rights - Use,
 * duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
define([ "dojo/_base/declare", 
		"dojo/_base/connect", 
		"dojo/_base/lang", 
		"dojo/store/Memory",
		"dojo/dom-class", 
		"dojo/dom-attr", 
		"dojo/dom-style", 
		"dojo/json",
		"dojo/dom-construct",
		"v11/ewf/dialog/viewerdialog/DocumentList",
        "v11/ewf/dialog/virtualviewerdialog/ViewoneHTMLViewer",
		'dojo/date/locale',
		"ecm/widget/dialog/BaseDialog",
		"dojo/request",
		"v11/ewf/util/Util",
		"dojo/text!./templates/CaseViewerDialogWidget.html" ], 
function(declare, 
		 connect, 
		 lang, 
		 Memory,
		 domClass, 
		 domAttr, 
		 domStyle, 
		 json,
		 domConstruct,
		 DocumentList,
         ViewoneHTMLViewer,
		 dojoLocale,
		 BaseDialog,
		 request,
		 Util, 
		 template) {

	/**
	 * @name ewf.dialog.viewerdialog.CaseViewerDialog
	 * @class Provides a dialog box which is showing for complete operation on activity.
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	return declare("v11.ewf.dialog.virtualviewerdialog.VirtualCaseViewerDialog", [ BaseDialog ], {
		/** @lends ewf.dialog.viewerdialog.CaseViewerDialog.prototype */

		text: "confirm?",
		buttonLabel: ecm.messages.yes,
		contentString: template,
		cancelButtonDefault: false,
		objectDataForDialog : null,
		b1 : null,
		documentListForComment : [],
		noPageCountDocumentListForComment : [],
		_vIframe: null,
		viwerHTML : '/EWFWidgetsv11/v11/ewf/viewer/CaseViewer.html',
		viwerHTML1 : '/EWFWidgetsv11/v11/ewf/viewer/CaseViewerNoCount.html',
		noCountDocuments : [],
		printerDocCount : 0,
		noCountViewerOpen : false,
		primaryDocClass: '',
		viewerRolename: null,
		viewerPrefix:null,
		
		postCreate: function() {
			this.inherited(arguments);
			this.setTitle(this.title || this.buttonLabel);
			this._initializeIframe();
			this._renderDocumentGrid();
			var button;
			var buttonObj = null;
			
		    viewerRolename= ecm.model.desktop.currentRole.name;
			//viewerPrefix = ""+this.payload.Solution.prefix;
			
			for(button in this.buttonsCollection){
				if(this.buttonsCollection.hasOwnProperty(button)){
					buttonObj = this.buttonsCollection[button];
					var b1 = this.addButton(buttonObj.buttonLabel,  buttonObj.onExecute,  buttonObj.disabled||false, !this.cancelButtonDefault);
					connect.connect(b1, "onClick",  lang.hitch(this, "showViewer"));
				
					b1.set("disabled", false);
				}
			}

			this.cancelButton.set("label", this.cancelButtonLabel);

			// Make the cancel button the default if requested.
			if (this.cancelButtonDefault) {
				this.autofocus = false;
				connect.connect(this, "onKeyDown", this, function(event) {
					if (event.keyCode == 13)
						this[onCancel]();
				});
			}
			
			this.setSize("1000","600");
			this.grid.resize({w: '400', h: '400'});
			
			console.log('this. gid ',this.grid);
			
			//Added by Purna for PBDocArchival changes - get the Primary document class name
			this.primaryDocClass = Util.getConstant("PRIMARY_DOCUMENT_CLASS");
			//End change
		},
		_renderDocumentGrid: function(){
			console.log('_renderGrid');
			var params = {
				documentGrid: this.documentGrid,
				object: this
			}
			var documentList = new DocumentList(params);
			documentList.createGrid(this.objectDataForDialog.tempStore);	
		},
		_initializeIframe: function() {
			if (this.viewer.children.length > 0) {
				this.viewer.removeChild(this.viewer.children[0]);
				this._vIframe = null;
			}
			this._vIframe = domConstruct.create('iframe', {
				style: {
					margin: "0px",
					padding: "0px",
					width: "100%",
					height: "100%"
				}
			});
			this.viewer.appendChild(this._vIframe);
			this._vIframe.docViewer = this;
			this._vIframe.title = "IframeDocViewer";

			//connect.connect(this._viewerIframe, "onload", this, "onLoad");
		},
		showViewer: function(){
			console.log('showViewer');
			//var documentURL = this.viwerHTML+'?security_token='+this.objectDataForDialog.token;
			var _payload = '';
			this.noPageCountDocumentListForComment = [];
			this.documentListForComment = [];
			if (this.viewer.children.length == 0) {
				this._initializeIframe();
			}
			var selectedDocuments = this.grid.select.row.getSelected();
			if(selectedDocuments.length > 0)
			{
				_payload = this.buildDocumentList(selectedDocuments);
				if(_payload != null)
				{
					var updatedPayload = {
						objectStoreName: this.objectDataForDialog.objectStoreName,
						items:_payload,
						repositoryId : this.objectDataForDialog.repositoryId,
						userId : ecm.model.desktop.userId
					};
					var temp = json.stringify(updatedPayload);
					console.log('temp',temp);
					this.selectedDocuments=temp;
					//this._vIframe.docIdData = temp;
					//this._vIframe.src = documentURL;	
					//this.resize();
					
					var ViewoneHTMLViewerObj= new ViewoneHTMLViewer();
			        ViewoneHTMLViewerObj._loadViewerConfig(this); 
					
				}else
				{
					this.openDocNoPageCount();
				}
			}else
			{
				alert('Please Select at least one Document to Print');
			}
			
			//_payload = [{'CaseRefNo':'SG-_COC141106ATMA25001','docIDs':[ {'docID':'Document,{05FE8A69-FECA-409E-A3F1-10D14F80F76B},{59D447E0-D2BE-4248-B02D-91959AB62408}', 'vsID': '{B11D816D-A07A-4B2F-A80D-23E4C2BF6B5C}','totalPages':'3','docTitle':'ATM Application Form'}]}];

			// temp end
			
			//added on 14/10/2016 to call virtual viewer for icm 5.2.1 migration changes 
			
			//var ViewoneHTMLViewerObj= new ViewoneHTMLViewer();
			
			//ViewoneHTMLViewerObj._loadViewerConfig(this); 	
			
		},
		buildDocDataNoCount : function(){
			var _this = this;
			var _docId = _this.noCountDocuments[0].docID;
			var _vsID = _this.noCountDocuments[0].vsID;
			var _docTitle = _this.noCountDocuments[0].docTitle;
			var _CaseRefNo = _this.objectDataForDialog.caseReferenceNumber;
			var selectedDocuments = this.grid.select.row.getSelected();
			_this.noCountDocuments = _this.buildDocListNoPageCount(selectedDocuments);
			console.log("_this.noCountDocuments !!!! : ",_this.noCountDocuments);
			//var documentURL = _this.viwerHTML1+'?security_token='+_this.objectDataForDialog.token;
			var updatedPayload = {
				objectStoreName: _this.objectDataForDialog.objectStoreName,
				docId:_docId, 
				vsID:_vsID,
				items:_this.noCountDocuments,
				repositoryId : this.objectDataForDialog.repositoryId,
				docTitle: _docTitle,
				CaseRefNo: _CaseRefNo,
				repositoryId : _this.objectDataForDialog.repositoryId,
				userId : ecm.model.desktop.userId
			};
			var temp = json.stringify(updatedPayload);
			return temp;
		},
		openDocNoPageCount: function(){
			
			console.log('Entered into openDocNoPageCount NA=== :');
			
			var _this = this;
			
			console.log('_this.noCountViewerOpen=== :',_this.noCountViewerOpen);
			
			
			//if (this.viewer.children.length == 0 && _this.noCountViewerOpen == false) {
			//	this._initializeIframe();
			//}
			//var documentURL = _this.viwerHTML1+'?security_token='+_this.objectDataForDialog.token;
			
			
			var selectedDocuments = this.grid.select.row.getSelected();
			
			//console.log('_this.noCountDocuments=== :',_this.noCountDocuments[0].docIDs.length);
			
			//console.log('_this.noCountDocuments length=== :',_this.noCountDocuments[0].docIDs.length);
			
			if((_this.noCountViewerOpen == false) && (_this.noCountDocuments.length==0))
			{
				
				_this.noCountDocuments = _this.buildDocListNoPageCount(selectedDocuments);
				
				var _docId = _this.noCountDocuments[0].docID;
			    var _vsID = _this.noCountDocuments[0].vsID;
			    var _docTitle = _this.noCountDocuments[0].docTitle;
			    var _CaseRefNo = _this.objectDataForDialog.caseReferenceNumber;
				var updatedPayload = {
				objectStoreName: _this.objectDataForDialog.objectStoreName,
				docId:_docId, 
				vsID:_vsID,
				items:_this.noCountDocuments,
				repositoryId : this.objectDataForDialog.repositoryId,
				docTitle: _docTitle,
				CaseRefNo: _CaseRefNo,
				repositoryId : _this.objectDataForDialog.repositoryId,
				userId : ecm.model.desktop.userId
			};
			var temp = json.stringify(updatedPayload);
				
				
				console.log('_this.noCountDocuments first time vieweropen=== :',_this.noCountDocuments[0].docIDs);
				
				console.log('_this.noCountDocuments first time vieweropen length=== :',_this.noCountDocuments[0].docIDs.length);
				
				if(_this.noCountDocuments[0].docIDs.length > 0)
				{
					var data = _this.buildDocDataNoCount();
					console.log('data',data);
					
					this._vIframe.docIdData = data;
					//this._vIframe.src = documentURL;
					_this.noCountViewerOpen = true;
					this.resize();
					//this.selectedDocuments=data;
					this.selectedDocuments=temp;
				    var ViewoneHTMLViewerObj= new ViewoneHTMLViewer();
			        ViewoneHTMLViewerObj._loadViewerConfig(this); 	
					
				}
			}else if(_this.noCountViewerOpen == true && _this.noCountDocuments[0].docIDs.length > 0){
                //alert("call openviewer is true"); 
				var data = _this.buildDocDataNoCount();
				console.log('data in openDocNoPageCount openviewer true### :',_this.noCountDocuments);
				//_this.noCountDocuments=data;
				//this._vIframe.docIdData = data;
				//this._vIframe.src = documentURL;
				this.resize();
				//this.selectedDocuments=data;
				this.selectedDocuments=_this.noCountDocuments;
				var ViewoneHTMLViewerObj= new ViewoneHTMLViewer();
			    ViewoneHTMLViewerObj._loadViewerConfig(this); 	
				
				
			}else{
				this.noCountViewerOpen = false;
				if(_this.noPageCountDocumentListForComment.length > 0){
					dojo.forEach(_this.noPageCountDocumentListForComment, function(item){
						_this.documentListForComment.push(item);
					});	
				}	
				var docList = json.stringify(this.documentListForComment);
				var currentTime = dojoLocale.format(new Date(), {datePattern: 'EEE, dd MMM yyyy'});
				var commentText = "Action: Print - Document: " + docList + " Action Time: " + currentTime + " - UserID: " + ecm.model.desktop.userId;
				
				
				//Modified by Purna for defect id 6068 - Introducing new service for adding comments and calling the new service instead of the existing OOTB service
				//this.objectDataForDialog.caseObject.addCaseComment(icm.base.Constants.prototype.CommentContext.CASE, commentText,function() {});
				
				//var reqUrl = "/v11/ewf/rest/commentservice/case?caseId=" + this.objectDataForDialog.caseObject.id + "&commentText=" + commentText;
				var postData = {"caseId": this.objectDataForDialog.caseObject.id, "commentText": commentText};
				var reqUrl = "/v11/ewf/rest/commentservice/case";
				request.post(reqUrl, {
					handleAs: 'json',
					data: postData
				}).then(lang.hitch(this, function(response){
					//do nothing
				}), lang.hitch(this, function(err){
					console.log(err);
				}));
				//End change by Purna


				if (this.viewer.children.length > 0) {
					this.viewer.removeChild(this.viewer.children[0]);
					this._vIframe = null;
				}
				_this.noCountDocuments = [];
				_this.documentListForComment = [];
				_this.noPageCountDocumentListForComment = [];
			}
			
		},
		
		buildDocListNoPageCount: function(documentList){
		
			var _this = this;
			var docListArray = [];
			var docIdArray = [];
			dojo.forEach(documentList, function(item){
				var selectedGridItem = _this.grid.row(item, true).item();
				var docId = _this.grid.store.getValue(selectedGridItem, "docId");
				var vsId = _this.grid.store.getValue(selectedGridItem, "vsId");
				var name = _this.grid.store.getValue(selectedGridItem, "Document");
				//var noOfPages = (_this.grid.store.getValue(selectedGridItem, "PageCount")=='NA') ? 1 : _this.grid.store.getValue(selectedGridItem, "PageCount");
				if(_this.grid.store.getValue(selectedGridItem, "PageCount")=='NA')
				{
					var docObject = {
						docID : docId,
						vsID : vsId,
						docTitle : name
					};
					docIdArray.push(docObject);
				}
				
			});	
			
			
			var object = {
				CaseRefNo : this.objectDataForDialog.caseReferenceNumber,
				docIDs : docIdArray
			};
			docListArray.push(object);
			
			console.log('docListArray  for no page count : ', docListArray);
			return docListArray;
		},
		
		buildDocumentList: function(documentList){

			var _this = this;
			_this.documentListForComment = [];
			var docListArray = [];
			var docIdArray = [];
			var countCheck = false;
			dojo.forEach(documentList, function(item){
				var selectedGridItem = _this.grid.row(item, true).item();
				var docId = _this.grid.store.getValue(selectedGridItem, "docId");
				var vsId = _this.grid.store.getValue(selectedGridItem, "vsId");
				var name = _this.grid.store.getValue(selectedGridItem, "Document");
				
				if(_this.grid.store.getValue(selectedGridItem, "PageCount")!='NA')
				{
					var noOfPages = _this.grid.store.getValue(selectedGridItem, "PageCount");
					var docObject = {
						docID : docId,
						vsID : vsId,
						totalPages : noOfPages,
						docTitle : name
					};
					countCheck = true;
					_this.documentListForComment.push(name);
					docIdArray.push(docObject);
				}

			});	
			
			var object = {
				CaseRefNo : this.objectDataForDialog.caseReferenceNumber,
				docIDs : docIdArray
			};
			docListArray.push(object);
			
			console.log('docListArray  -> ', docListArray);
			if(countCheck){
				return docListArray;
			}else{
				return null;
			}
		},
		
		//Added by Purna for PBDocArchival changes - Always Print the Primary document 1st and then remaining documents
		swapDocListForPrimaryDoc: function(selectedDocuments) {
			if(selectedDocuments && selectedDocuments.length && selectedDocuments.length > 1) {
				for(var index=0; index<selectedDocuments.length; index++){
					var item = selectedDocuments[index];
					var selectedGridItem = this.grid.row(item, true).item();
					var docId = this.grid.store.getValue(selectedGridItem, "docId");
					if(docId && docId.indexOf(this.primaryDocClass) >= 0) {
						if(index == 0) {
							break;
						} else {
							selectedDocuments[index] = selectedDocuments[0];
							selectedDocuments[0] = item;
						}
					}
				}
			}
			return selectedDocuments;
		},
		
		captureCommentAbtPrint: function() {
			var currentTime = dojoLocale.format(new Date(), {datePattern: 'EEE, dd MMM yyyy'});
			var commentText = "Action: Print - Action Time: " + currentTime + " - UserID: " + ecm.model.desktop.userId;
			var documentList = this.swapDocListForPrimaryDoc(this.grid.select.row.getSelected());
			var documentTitles = '';
			
			dojo.forEach(documentList, lang.hitch(this, function(item, index){
				var selectedGridItem = this.grid.row(item, true).item();
				var name = this.grid.store.getValue(selectedGridItem, "Document");
				documentTitles = documentTitles + " " + (index + 1) + ". " + name;
			}));
			commentText = commentText + " - Document Titles: " + documentTitles;

			var postData = {"caseId": this.objectDataForDialog.caseObject.id, "commentText": commentText};
			var reqUrl = "/v11/ewf/rest/commentservice/case";
			request.post(reqUrl, {
				handleAs: 'json',
				data: postData
			}).then(lang.hitch(this, function(response){
				//do nothing
			}), lang.hitch(this, function(err){
				console.log(err);
			}));
		},
		
		_onDocViewerEvent: function(n) {
			
			var methodName = "_sendFnViewerSignal";
			this.lastEvent = n;

			switch (n) {
			
				case 27:
					//alert('Print Completed');
					//this.viewer.removeChild(this.viewer.children[0]);
					//this.objectDataForDialog.tempStore.items=[]; -- do remember to work on this
					if((this.noCountViewerOpen == false)&&(this.noCountDocuments.length == 0)){
						//open no count viewer as first time 
						//this.viewer.removeChild(this.viewer.children[0]);
						
						//Added by Purna for PBDocArchival changes - Capture the comment about the Printed documents
						this.captureCommentAbtPrint();
						//End change
						
						this.openDocNoPageCount();
					}else if((this.noCountViewerOpen == true)&&(this.noCountDocuments.length > 0)){
						//reopen existing no count viewer
						var _docTitle = this.noCountDocuments[0].docTitle;
						this.noPageCountDocumentListForComment.push(_docTitle);
						this.noCountDocuments.splice(0, 1);
						console.log('New array after Print', this.noCountDocuments);
						this.openDocNoPageCount();
					}
				/*	if((this.noCountViewerOpen == false) && (this.noCountDocuments.length == 0))
					{
						var docList = json.stringify(this.documentListForComment); // do remember to work on this
						var currentTime = dojoLocale.format(new Date(), {datePattern: 'EEE, dd MMM yyyy'});
						var commentText = "Action: Print - Document: " + docList + " Action Time: " + currentTime + " - UserID: " + ecm.model.desktop.userId;
						this.objectDataForDialog.caseObject.addCaseComment(icm.base.Constants.prototype.CommentContext.CASE, commentText,function() {});
					
					}*/
					// need to fire the event 
					break;
				case 26:
					console.log('print Cancel	-> ');
						if((this.noCountViewerOpen == false)&&(this.noCountDocuments.length == 0)){
						//open no count viewer as first time 
						//this.viewer.removeChild(this.viewer.children[0]);
						this.openDocNoPageCount();
						
					}else if((this.noCountViewerOpen == true)&&(this.noCountDocuments.length > 0)){
						//reopen existing no count viewer
						this.noCountDocuments.splice(0, 1);
						console.log('New array after Print', this.noCountDocuments);
						this.openDocNoPageCount();
						
					}
					// need to fire the event 
					break;
				case 61: // document failed to load.
					this.logDebug(methodName, "FileNet Viewer failed to load the document");
					break;
				case 21: // focus out of the Applet
					this.logDebug(methodName, "Focus out of the applet");
					break;
				case 24:
					this.logDebug(methodName, "Saving FileNet Viewer annotations completed.");
					
					// Don't break - fall through to case 33...
				case 33:
					this.logDebug(methodName, "Calling onDirty(false)");
					
					break;
				case 32:
					this.logDebug(methodName, "Calling onDirty(true)");
					
					break;
				case 22:
					console.log('Document is Ready');
					//alert(1);
					var applet = this._vIframe.contentWindow.document.viewONE;
					applet.printDocument();
					break;
				default: // assume it is a save completed.
					break;
			}

		},
		show: function() {
			this.inherited(arguments);
			if (this.cancelButtonDefault) {
				setTimeout(lang.hitch(this, function() {
					this.cancelButton.focus();
				}, 300));
			}
		}
	});
});
