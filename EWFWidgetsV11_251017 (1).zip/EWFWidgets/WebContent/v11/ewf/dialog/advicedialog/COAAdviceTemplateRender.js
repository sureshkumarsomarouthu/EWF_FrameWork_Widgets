define(["dojo/_base/declare",
        "dojo/_base/lang",
		"icm/base/_BaseWidget",
		"dojo/dom-construct",
         "dojo/data/ItemFileReadStore",
		"dojo/_base/array",
         "dojo/text!./templates/COAAdviceTemplateRender.html",
		"dijit/form/SimpleTextarea",
		"idx/form/CheckBox",
		"dojo/request",
         "idx/form/TextBox",
         "dijit/form/RadioButton",
         "dojo/dom-class",
 		"idx/form/FilteringSelect"
         ], function(declare, lang, _BaseWidget, domConstruct, ItemFileReadStore, array, template, Textarea, CheckBox, request){
	
	return declare("v11.ewf.dialog.advicedialog.COAAdviceTemplateRender", [_BaseWidget], {
		templateString: template,
        widgetsInTemplate: true,
		reasonSelected: "",
		
		postCreate: function(){

		},

		setModel: function(parentWidget, templateDetailContentPane, templateData){		
			domConstruct.empty(templateDetailContentPane.containerNode);
			this.parentWidget = parentWidget;
			this.templateDetailContentPane = templateDetailContentPane;
			this.templateData = templateData;
		},
		
		buildContent: function(dialogObject){
			dialogObject.setSize(850,700);		
			var _this = this;	
			var arrReasonList = "";
			request("/ewf/rest/suggest/?ref=adv_reasons&start=0", 
				{handleAs: "json", sync: true}).then(function(data){
					arrReasonList = data.items;
				},
				function(err){console.log(err)}, 
				function(evt){console.log(evt)}); 

			
			var response = this.templateData;
			var attributes = response.attributes;
			//var text = document.createTextNode("Please select one address: ");
			//this.templateDetailContentPane.domNode.appendChild(text);
			
				

						
			var attributesMap = {};
			dojo.forEach(attributes, lang.hitch(this, function(attribute){
				attributesMap[attribute.symbolicName] = attribute;
			}));

			var brStr2 = document.createElement('br');
			this.templateDetailContentPane.domNode.appendChild(brStr2);
			var field1 = new idx.form.TextBox({
					label: attributesMap["CaseFolder.CustomerName1"].displayName,
					value: attributesMap["CaseFolder.CustomerName1"].value,
					symbolicName: attributesMap["CaseFolder.CustomerName1"].value,
					style: "display: block;",
					readOnly: false,
					labelWidth: "120px",
					fieldWidth: "450px"
			});
			this.customerName1 = attributesMap["CaseFolder.CustomerName1"].value;
			this.templateDetailContentPane.addChild(field1);
			this.connect(field1, "onChange", "setTextField_1");

			var field2 = new idx.form.TextBox({
				label: attributesMap["CaseFolder.CustomerName2"].displayName,
				value: attributesMap["CaseFolder.CustomerName2"].value,
				symbolicName: attributesMap["CaseFolder.CustomerName2"].value,
				style: "display: block;",
				readOnly: false,
				labelWidth: "120px",
				fieldWidth: "450px"
			});
			field1.textbox.onblur = function(){
				this.value = this.value.toUpperCase();
			};
			field2.textbox.onblur = function(){
				this.value = this.value.toUpperCase();
			};
			this.customerName2 = attributesMap["CaseFolder.CustomerName2"].value;
			this.templateDetailContentPane.addChild(field2);
			this.connect(field2, "onChange", "setTextField_2");

 			var brStr1 = document.createElement('br');


			//Reason List
  			var reasonListTable = domConstruct.create("table"), tr, th, td;
  			
  			//Reason Sort
  			arrReasonList = arrReasonList.sort(function(a,b){
  				return (a.name - b.name);
  			});
  			//Reason Sort

				for (var i = 0; i < arrReasonList.length; i++){
					tr = domConstruct.create("tr");
					td = domConstruct.create("td");
					
					var checkBox = new CheckBox({
						label: arrReasonList[i]['key'],
						value: "  -  " + arrReasonList[i]['key'],
						readonly : false,
						fieldWidth: '98%',
						labelWidth: '85%'
						//checked: false,
					});
					this.connect(checkBox, "onClick", this.selectReason);

					//checkBox.labelWrap.style.width = '93%';
					td.appendChild(checkBox.domNode);
					tr.appendChild(td);
					reasonListTable.appendChild(tr);
				
				} 

			this.reasonList.set("title", "Reason List");
			this.reasonList.set("style", "height : 150px; overflow : auto;");
			this.reasonList.set("content", reasonListTable);




			// address table
			var table = dojo.create('table', {
				style: 'margin-top: 10px; border-collapse: collapse; border:1px solid #CCCCCC; height: 250px; width: 80%; display:inline-block; overflow-y : scroll; vertical-align: top; align: left;'
			});
			var tr1 = dojo.create('tr', {
				style: 'height: 25px; width: 80%; border:1px solid black;position: static',
				className: "gridxRowHeaderHeader"
			});
			var th1 = dojo.create('th', {
				innerHTML: '', 
				style: 'border:1px solid #CCCCCC; font-weight: bold;padding-left:10px',
				className:"gridxRowHeaderHeaderCell"
			});
			var th2 = dojo.create('th', {
				innerHTML: "Address", 
				style: 'border:1px solid #CCCCCC; font-weight: bold;padding-left:10px; text-align:left; width: 500px;',
				className:"gridxRowHeaderHeaderCell"
			});
			tr1.appendChild(th1);
			tr1.appendChild(th2);
			table.appendChild(tr1);
			
			this.radioButtonSet1 = [];
			this.radioButtonSet2 = [];
			dojo.forEach(attributesMap["Address"].choiceList.choices, lang.hitch(this, function(address, index){
				var tr2 = dojo.create('tr', {
					style: 'height: 5%; width: 80%; border:1px solid #CCCCCC;'
				});
				var td1 = dojo.create('td', {
					style: 'width: 20%; vertical-align: center; text-align: center; border:1px solid #CCCCCC;'
				});

				var addr = address.value;
				//$$-->CASE-ADDR-RES<--$$
				//$$-->CASE-ADDR-MAILING<--$$
				if(addr && (addr.indexOf('$$-->CASE-ADDR-RES<--$$') > -1)){
					addr = address.displayName + "<div style=\"color:grey;display:block;\"></div><div style=\"color:grey;display:block;\">(Residential Address on Form)</div>";
				}else if(addr && (addr.indexOf('$$-->CASE-ADDR-MAILING<--$$') > -1)){
					addr = address.displayName + "<div style=\"color:grey;display:block;\"></div><div style=\"color:grey;display:block;\">(Mailing Address on Form)</div>";
				}
				/*if(index == 0){
					addr = addr + "<div style=\"color:grey;display:block;\"></div><div style=\"color:grey;display:block;\">(Mailing Address on Form)</div>";
				} else if(index == 1){
					addr = addr + "<div style=\"color:grey;display:block;\"></div><div style=\"color:grey;display:block;\">(Residential Address on Form)</div>";
				}*/

				var td2 = dojo.create('td', {
					innerHTML: addr, 
					style: 'width: 80%; vertical-align: top; text-align: left; border:1px solid #CCCCCC; color:#333333;padding-left:10px'
				});
				var button1 = new dijit.form.RadioButton({
					name: address.displayName, 
					value: address.displayName
				});
				//console.dir(["button1", button1]);
				this.radioButtonSet1.push(button1);

				td1.appendChild(button1.domNode);
				tr2.appendChild(td1);
				tr2.appendChild(td2);
				table.appendChild(tr2);
			}));
			
			dojo.forEach(this.radioButtonSet1, lang.hitch(this, function(button){
				this.connect(button, "onClick", this.onRadioClick);
			}));
			
			
		var textArea = new Textarea({
			placeholder: "Key-in the content here.",
			style: "width: 97%; height: 145px; display: block; border: 1px solid #aaaaaa; margin-top: 10px; margin-bottom: 5px;"
		});
		this.connect(this.textArea, "onkeyup", "setTextArea");

			
			this.templateDetailContentPane.domNode.appendChild(table);

			if (this.templateData.displayName.indexOf("Blank Template") > -1){
				this.templateDetailContentPane.addChild(textArea);
				this.textArea = true;
			}
			array.forEach(this.templateData.attributes, lang.hitch(this, function(item,index){
					if (item['displayName'] === "ReasonList" ){
							this.templateDetailContentPane.addChild(this.reasonList);
							this.reasonListExist = true;
							}
				}));


			this.parentWidget.setSaveButtonDisabled(true);
		},

		getSelection: function(){
			var atts = dojo.clone(this.templateData.attributes);
			//var atts = this.templateData.attributes;
			dojo.forEach(atts, function(att){
				if(att.symbolicName == "DATE"){
					var m_names = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
					var d = new Date();
					var curr_date = d.getDate();
					var curr_month = d.getMonth();
					var curr_Year = d.getFullYear();
					att.value = curr_date + " " + m_names[curr_month] + " " + curr_Year;
				} 
				else if(att.symbolicName == "Address"){
					att.value = this.selectedAddress;
					delete att.choiceList;
				} else if(att.symbolicName == "ReasonList"){
					att.value = this.reasonSelected;
					try{
						//Fix to re-adjust the alignment starts here
						var temp1 = att.value;
						var selReasonsSplitArray = temp1.replace(/\n/g, '**newlinechar**').split('**newlinechar**');
						var finalStringToReturn = "";
						for(var i=0; i < selReasonsSplitArray.length; i++){
							var eachSelectedReason = selReasonsSplitArray[i];
							if(eachSelectedReason && (eachSelectedReason.length > 0)){
								var formattedReason = "";
								var eachSelectedReasonWordsSplitArray = eachSelectedReason.split(" ");
								var breakPointReached = false;
								for(var j=0; j<eachSelectedReasonWordsSplitArray.length; j++){
									var eachWord = eachSelectedReasonWordsSplitArray[j];
									if((formattedReason + " " + eachWord).length <= 105){
										formattedReason += " " + eachWord;
									}else{
										if(formattedReason.indexOf('      ') > -1){
											formattedReason += " " + eachWord;
										}else{
											formattedReason += "\n      " + eachWord;
										}
									}
								}
								finalStringToReturn += "\n" + formattedReason;
							}
						}
						finalStringToReturn += '\n';
						//Fix to re-adjust the alignment ends here
						att.value = finalStringToReturn;
					}catch(e){}
					
					//delete att.choiceList;
				} else if(att.symbolicName == "CaseFolder.CustomerName1"){
					var custName = "";
						if(typeof this.customerName1 != "undefined"){
							//att.value = this.customerName1+" ";
							custName = this.customerName1.toUpperCase();
						}
						if(typeof this.customerName2 != "undefined"){
							if(custName!==""){
							//att.value = this.customerName1+" ";
								custName = custName +"\n" +this.customerName2.toUpperCase();
							}else{
								custName = this.customerName2.toUpperCase();
							}
						}	
						if(custName !==""){
							att.value = custName;
						}
/*				} else if(att.symbolicName == "CaseFolder.CustomerName2"){
						if(typeof this.customerName2 != "undefined"){
							att.value = this.customerName2;
						}*/
				}else if(att.symbolicName == "ContentBlankTemplate"){
					var text = " " +this.textAreaContent.srcElement.value
					var spaceChar = "\r\n" + " ";
					att.value = text.replace(/\r?\n/g, spaceChar);
				}
				
			}, this);

			//console.dir(["atts", atts]);
			return atts;
		},
		
		onRadioClick: function(event){
			//console.dir(["event", event]);
			var value = -1;
			dojo.forEach(this.radioButtonSet1, lang.hitch(this, function(button){
				if(button.checked){
					value = button.value;
					this.selectedAddress = value;
					if(this.reasonListExist){
						if(this.reasonSelected){
							this.parentWidget.setSaveButtonDisabled(false);
						}else{
							this.parentWidget.setSaveButtonDisabled(true);
						}
					}	
 					else if (this.textArea){
						if(this.textAreaContent && this.textAreaContent.srcElement && this.textAreaContent.srcElement.value && this.textAreaContent.srcElement.value !=""){
							this.parentWidget.setSaveButtonDisabled(false);
						}else{
							this.parentWidget.setSaveButtonDisabled(true);
						}
					} 
					else{
						this.parentWidget.setSaveButtonDisabled(false);
					}
				}
					
				if(event.target.name != button.name){
					button.set("checked", false);
				} else {
					if(this.reasonListExist){
						if(this.reasonList.get("value")){
							this.parentWidget.setSaveButtonDisabled(false);
						}
					}
	
				}
			}));
			
			//console.log("select = "+ value);
		},
		
		selectReason: function(event){
			if(event.toElement.checked){
				this.reasonSelected = this.reasonSelected + event.toElement.value + "\n";	
			}else {
				var currentValue = event.toElement.value + "\n";
				this.reasonSelected = this.reasonSelected.replace(currentValue, "");
				}	

			if(this.reasonSelected && this.selectedAddress){
				this.parentWidget.setSaveButtonDisabled(false);
			}else{
				this.parentWidget.setSaveButtonDisabled(true);
			}
		},
		
		setTextField_1: function(event){
			this.customerName1 = event;
		},
		setTextField_2: function(event){
			this.customerName2 = event;
		},
		setTextArea: function(event){
			this.textAreaContent = event;
			if(this.selectedAddress){
				if(this.textAreaContent.srcElement.value != ""){
					this.parentWidget.setSaveButtonDisabled(false);
				}else{
					this.parentWidget.setSaveButtonDisabled(true);
				}
			}
			else{
				this.parentWidget.setSaveButtonDisabled(true);
			}
		}

	});
});