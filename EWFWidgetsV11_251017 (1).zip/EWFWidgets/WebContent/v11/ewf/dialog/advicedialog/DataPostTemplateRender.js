define(["dojo/_base/declare",
        "dojo/_base/lang",
         "ecm/widget/dialog/BaseDialog",
         "dijit/form/SimpleTextarea",
         "dijit/Editor",
         "idx/form/TextBox"
         ], function(declare, lang, BaseDialog,Textarea,Editor,TextBox){
	
	return declare("v11.ewf.dialog.advicedialog.DataPostTemplateRender", [BaseDialog], {
		
		postCreate: function(){

		},

		setModel: function(parentWidget, templateDetailContentPane, templateData){
			this.parentWidget = parentWidget;
			this.templateDetailContentPane = templateDetailContentPane;
			this.templateData = templateData;
		},
		
		buildContent: function(dialogObject)
		{
			dialogObject.setSize(800,550);
			var textArea = new Textarea({
				placeholder: "Key-in the content here ######.",
				style: "width: 97%; height: 200px; display: block; border: 1px solid #aaaaaa; margin-top: 10px; margin-bottom: 5px;"
			});
			
			var editorArea = new Editor({
				placeholder: "*******",
				disabled: true,
				style: "width: 97%; display: block; border: 1px solid #aaaaaa; margin-top: 10px; margin-bottom: 5px;"
			});
			
			
			var response = this.templateData;
			console.log("response is @@@@......... :",response);
			console.log("response.datapostContent is.....$$$$$.... :",response.datapostContent);
			if(response && response.datapostContent) {
				//textArea.set("value", response.content);
				editorArea.set("value", response.datapostContent);
			}			
						
			else{
			var attributes = response.attributes;
			console.log("attributes!!!!!!!!!!!!......... :",attributes);	
				
			dojo.forEach(attributes, lang.hitch(this, function(attribute){								
				var field = new idx.form.TextBox({
					label: attribute.displayName,
					value: attribute.value,
					symbolicName: attribute.symbolicName,
					style: "display: block;",
					readOnly: true,
					labelWidth: "180px"
				});				
				this.templateDetailContentPane.addChild(field);
				
			}));
			
			}
			editorArea.startup();
			this.templateDetailContentPane.addChild(editorArea);
		},

		getSelection: function(){
			var fieldValues = [];
			dojo.forEach(this.templateDetailContentPane.getChildren(), function(childField){												
				var fieldId = childField.get("symbolicName");
				var fieldValue = childField.get("value");
				var displayName = childField.get("label");
				fieldValues.push({
					symbolicName: fieldId,
					displayName: displayName,
					value: fieldValue
				});
			});

			return fieldValues;
		}
		
	});
});