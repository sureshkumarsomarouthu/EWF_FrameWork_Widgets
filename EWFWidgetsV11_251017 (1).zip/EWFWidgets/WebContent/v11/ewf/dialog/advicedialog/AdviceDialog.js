define(["dojo/_base/declare",
        "dojo/_base/lang",
         "ecm/widget/dialog/BaseDialog",
         "dojo/text!./templates/AdviceDialogContent.html",
         "v11/ewf/model/Advice",
         "dojo/dom-style",
         "dojo/data/ItemFileReadStore",
         "idx/form/FilteringSelect",
         "v11/ewf/dialog/advicedialog/DefaultTemplateRender",
         "v11/ewf/dialog/advicedialog/DuplicateAdviceTemplateRender",
         "idx/form/TextBox"
         ], function(declare, lang, BaseDialog, template, AdviceModel, domStyle, ItemFileReadStore){
	
	return declare("v11.ewf.dialog.advicedialog.AdviceDialog", [BaseDialog], {
		
		contentString: template,
		
		title: "Generate Advice Letter",
		
		postCreate: function(){
			
			this.inherited(arguments);
			
			this.renderTemplateList();
			
			this.setTitle(this.title);
			
			var roleName = ecm.model.desktop.currentRole.name;
			
			console.log("roleName  is  :: ",roleName);
			
			var saveButtonObj = {
				buttonLabel: "Save",
				onExecute: this.onSave,
				disabled: !this.templateId.get("value"),
				isDfault: false
			};
			
			this.saveButton = this.addButton(saveButtonObj.buttonLabel, saveButtonObj.onExecute, saveButtonObj.disabled, saveButtonObj.isDefault);
			
			this.connect(this.templateId, "onChange", "renderFields");
		},
		
		renderTemplateList: function(){
			
			var _showTemplateList = lang.hitch(this, function(response){
				var choices = {
						identifier: "value",
						label: "displayName",
						items: response.choices
				};
				
				var templateStore = new ItemFileReadStore({data: choices});				
				this.templateId.set("store", templateStore);	
	        	this.templateId.set("searchAttr", "displayName");			
			});
			
			this.adviceModel = new AdviceModel({
				repository: this.repository,
				parentCase: this.parentCase
			});
			
			this.adviceModel.retrieveAdviceTemplates(_showTemplateList);
		},
		
		renderFields: function(){			
		    this.setSize(700,500);		
			this.saveButton.set("disabled", !this.templateId.get("value"));
			
			var _showFields = lang.hitch(this, function(response){
				
				dojo.forEach(this.templateDetail.getChildren(), function(childField){
					childField.destroy();
				});
				var renderClassName;
				if(response.renderDijitClass == null){
					renderClassName = "v11.ewf.dialog.advicedialog.DefaultTemplateRender";
					//renderClassName = "ewf.dialog.advicedialog.DuplicateAdviceTemplateRender";
				} else {
					renderClassName = response.renderDijitClass;
				}
				dojo.require(renderClassName);
				var renderClass =  dojo.getObject(renderClassName);
				this.renderDijit = new renderClass();
				this.renderDijit.setModel(this, this.templateDetail, response);
				var dialogScope=this;
				this.renderDijit.buildContent(dialogScope);

				if(this.templateDetail.getChildren().length > 0 
					|| this.templateDetail.domNode.innerHTML.length > 0){
					dojo.style(this.templateDetail.domNode, "display", "");
				}else{
					dojo.style(this.templateDetail.domNode, "display", "none");
				}
				
				dojo.style(this.contentArea, "height", "auto");
			});
			
			var templateName = this.templateId.get("value");
			
			if(templateName){
				this.adviceModel.retrieveAdviceTemplateDetail(_showFields, templateName, true);
			}
		},

		setSaveButtonDisabled: function(disabled){
			this.saveButton.set("disabled", disabled);
			try{this.actionBar.style.cssText = 'padding-top: 0px !important;';}catch(e){}
		},
		
		onSave: function(){
			
			var fieldValues = this.renderDijit.getSelection();
			
			var template = this.templateId.get("value");
			var templateName = this.templateId.get("displayName");
			
			var _sendOpenDocumentEvent = lang.hitch(this, function(response){
				this.hide();
				this.okCallBack(response);
			});
			
			this.adviceModel.generateAdvice(_sendOpenDocumentEvent, null, fieldValues, template, templateName);					
		}
		
	});
});