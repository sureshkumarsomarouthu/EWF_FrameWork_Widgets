define(["dojo/_base/declare",
        "dojo/_base/lang",
		"icm/base/_BaseWidget",
         "dojo/data/ItemFileReadStore",
         "dojo/text!./templates/DuplicateAdviceTemplateRender.html",
         "idx/form/TextBox",
         "dijit/form/RadioButton",
         "dojo/dom-class",
 		"idx/form/FilteringSelect"
         ], function(declare, lang, _BaseWidget, ItemFileReadStore, template){
	
	return declare("v11.ewf.dialog.advicedialog.DuplicateAdviceTemplateRender", [_BaseWidget], {
		templateString: template,
        widgetsInTemplate: true,

		postCreate: function(){

		},

		setModel: function(parentWidget, templateDetailContentPane, templateData){
			this.parentWidget = parentWidget;
			this.templateDetailContentPane = templateDetailContentPane;
			this.templateData = templateData;
		},
		
		buildContent: function(){			
			var response = this.templateData;
			var attributes = response.attributes;
			//var text = document.createTextNode("Please select one address: ");
			//this.templateDetailContentPane.domNode.appendChild(text);


			var attributesMap = {};
			dojo.forEach(attributes, lang.hitch(this, function(attribute){
				attributesMap[attribute.symbolicName] = attribute;
			}));

			var brStr2 = document.createElement('br');
			this.templateDetailContentPane.domNode.appendChild(brStr2);
			var field = new idx.form.TextBox({
					label: attributesMap["CaseFolder.COPC_Salutation"].displayName,
					value: attributesMap["CaseFolder.COPC_Salutation"].value,
					symbolicName: attributesMap["CaseFolder.COPC_Salutation"].value,
					style: "display: block;",
					readOnly: true,
					labelWidth: "100px"
			});
			this.templateDetailContentPane.addChild(field);
			var cName =  attributesMap["CaseFolder.COPC_NameasinNRICPassportPR"].value ;
			if(cName){
				cName = cName.replace("|||", " ");
			}
			var field2 = new idx.form.TextBox({
					label: "Name",
					value: cName,
					symbolicName: attributesMap["CaseFolder.COPC_Salutation"].value+1,
					style: "display: block;",
					readOnly: true,
					labelWidth: "100px"
			});
			this.templateDetailContentPane.addChild(field2);
			//var SalutationText = document.createTextNode(attributesMap["CaseFolder.COPC_Salutation"].displayName
			//+ ": " +attributesMap["CaseFolder.COPC_Salutation"].value);
			//this.templateDetailContentPane.domNode.appendChild(SalutationText);

			//var nameText = document.createTextNode(attributesMap["CaseFolder.CustomerName1"].value 
			//+ " "+ attributesMap["CaseFolder.CustomerName2"].value);
			//this.templateDetailContentPane.domNode.appendChild(nameText);

 			var brStr1 = document.createElement('br');

			//this.templateDetailContentPane.domNode.appendChild(brStr1);
			var choices = {
						identifier: "value",
						label: "displayName",
						items:  dojo.clone(attributesMap["TargetCard"].choiceList.choices)
				};
			var templateStore = new ItemFileReadStore({
				data: choices
			});	
			this.cardList.set("store", templateStore);	
        	this.cardList.set("searchAttr", "displayName");	

        	this.connect(this.cardList, "onChange", "selectCard");

			// address table
			var table = dojo.create('table', {
				style: 'margin-top: 10px; border-collapse: collapse; border:1px solid #CCCCCC; width: 100%; height: 80%; vertical-align: top; align: left;'
			});
			var tr1 = dojo.create('tr', {
				style: 'height: 25px; width: 100%; border:1px solid black;position: static',
				className: "gridxRowHeaderHeader"
			});
			var th1 = dojo.create('th', {
				innerHTML: '', 
				style: 'border:1px solid #CCCCCC; font-weight: bold;padding-left:10px',
				className:"gridxRowHeaderHeaderCell"
			});
			var th2 = dojo.create('th', {
				innerHTML: "Address", 
				style: 'border:1px solid #CCCCCC; font-weight: bold;padding-left:10px; text-align:left',
				className:"gridxRowHeaderHeaderCell"
			});
			tr1.appendChild(th1);
			tr1.appendChild(th2);
			table.appendChild(tr1);
			
			this.radioButtonSet1 = [];
			this.radioButtonSet2 = [];
			dojo.forEach(attributesMap["Address"].choiceList.choices, lang.hitch(this, function(address, index){
				var tr2 = dojo.create('tr', {
					style: 'height: 5%; width: 100%; border:1px solid #CCCCCC;'
				});
				var td1 = dojo.create('td', {
					style: 'width: 20%; vertical-align: center; text-align: center; border:1px solid #CCCCCC;'
				});

				var addr = address.displayName;
				if(index == 0){
					addr = addr + "<div style=\"color:grey;display:block;\"></div><div style=\"color:grey;display:block;\">(Home address on Form)</div>";
				} else if(index == 1){
					addr = addr + "<div style=\"color:grey;display:block;\"></div><div style=\"color:grey;display:block;\">(Office address on Form)</div>";
				}

				var td2 = dojo.create('td', {
					innerHTML: addr, 
					style: 'width: 80%; vertical-align: top; text-align: left; border:1px solid #CCCCCC; color:#333333;padding-left:10px'
				});
				var button1 = new dijit.form.RadioButton({
					name:address.value, 
					value: address.value
				});
				//console.dir(["button1", button1]);
				this.radioButtonSet1.push(button1);

				td1.appendChild(button1.domNode);
				tr2.appendChild(td1);
				tr2.appendChild(td2);
				table.appendChild(tr2);
			}));
			
			dojo.forEach(this.radioButtonSet1, lang.hitch(this, function(button){
				this.connect(button, "onClick", this.onRadioClick);
			}));

			
			this.templateDetailContentPane.domNode.appendChild(table);
			this.templateDetailContentPane.addChild(this.cardList);
			this.parentWidget.setSaveButtonDisabled(true);
		},

		getSelection: function(){
			var atts = dojo.clone(this.templateData.attributes);
			//var atts = this.templateData.attributes;
			dojo.forEach(atts, function(att){
				if(att.symbolicName == "Address"){
					att.value = this.selectedAddress;
					delete att.choiceList;
				} else if(att.symbolicName == "TargetCard"){
					att.value = this.cardList.get("value");
					delete att.choiceList;
				}
				
			}, this);

			//console.dir(["atts", atts]);
			return atts;
		},
		
		onRadioClick: function(event){
			//console.dir(["event", event]);
			var value = -1;
			
			dojo.forEach(this.radioButtonSet1, lang.hitch(this, function(button){
				console.log(" button.checked = " + button.checked);
				if(button.checked){
					value = button.value;
					this.selectedAddress = value;
				}

				if(event.target.name != button.name){
					button.set("checked", false);
				} else {
					if(this.cardList.get("value")){
						this.parentWidget.setSaveButtonDisabled(false);
					}
	
				}
			}));
			
			//console.log("select = "+ value);
		},

		selectCard: function(event){
			if(this.cardList.get("value") && this.selectedAddress){
				this.parentWidget.setSaveButtonDisabled(false);
			}
		}
	});
});