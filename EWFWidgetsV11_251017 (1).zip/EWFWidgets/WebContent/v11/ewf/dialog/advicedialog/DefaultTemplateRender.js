define(["dojo/_base/declare",
        "dojo/_base/lang",
         "ecm/widget/dialog/BaseDialog",
         "idx/form/TextBox"
         ], function(declare, lang, BaseDialog){
	
	return declare("v11.ewf.dialog.advicedialog.DefaultTemplateRender", [BaseDialog], {
		
		postCreate: function(){

		},

		setModel: function(parentWidget, templateDetailContentPane, templateData){
			this.parentWidget = parentWidget;
			this.templateDetailContentPane = templateDetailContentPane;
			this.templateData = templateData;
		},
		
		buildContent: function(){
			var response = this.templateData;
			var attributes = response.attributes;
			//var text = document.createTextNode("The following fields");
			//this.templateDetailContentPane.domNode.appendChild(text);
			dojo.forEach(attributes, lang.hitch(this, function(attribute){
				var field = new idx.form.TextBox({
					label: attribute.displayName,
					value: attribute.value,
					symbolicName: attribute.symbolicName,
					style: "display: block;",
					readOnly: true,
					labelWidth: "180px"
				});
				this.templateDetailContentPane.addChild(field);
			}));
			
			
			//dojo.style(this.contentArea, "height", "auto");

		},

		getSelection: function(){
			var fieldValues = [];
			dojo.forEach(this.templateDetailContentPane.getChildren(), function(childField){
				var fieldId = childField.get("symbolicName");
				var fieldValue = childField.get("value");
				var displayName = childField.get("label");
				fieldValues.push({
					symbolicName: fieldId,
					displayName: displayName,
					value: fieldValue
				});
			});


			return fieldValues;
		}
		
	});
});