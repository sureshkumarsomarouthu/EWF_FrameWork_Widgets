define(["dojo/_base/declare",
        "dojo/_base/lang",
         "dojo/text!./templates/AdviceDialogContent.html",
         "v11/ewf/dialog/advicedialog/AdviceDialog",
         "icm/model/properties/controller/ControllerManager",
         "v11/ewf/util/Util"
         ], function(declare, lang, template, AdviceDialog, ControllerManager, Util){
	
	return declare("v11.ewf.dialog.advicedialog.DataPostAdviceDialog", [AdviceDialog], {
		
		contentString: template,
		
		title: "Generate Advice Letter",
		
		
		renderFields: function(){
			
			var roleName = ecm.model.desktop.currentRole.name;
			
			if(roleName == Util.getConstant("ROLE_NAMES").MANUAL_PROCESSING) {			
				this.saveButton.set("disabled", !this.templateId.get("value"));
			} else {
				this.saveButton.set("disabled", true);
			}
			
			var _showFields = lang.hitch(this, function(response){
				
				dojo.forEach(this.templateDetail.getChildren(), function(childField){
					childField.destroy();
				});
				var renderClassName;
				if(response.renderDijitClass == null){
					renderClassName = "v11.ewf.dialog.advicedialog.DefaultTemplateRender";
					//renderClassName = "ewf.dialog.advicedialog.DuplicateAdviceTemplateRender";
				} else {
					renderClassName = response.renderDijitClass;
				}
				dojo.require(renderClassName);
				var renderClass =  dojo.getObject(renderClassName);
				this.renderDijit = new renderClass();
				this.renderDijit.setModel(this, this.templateDetail, response);
				var dialogScope=this;
				console.log("dialogScope ^^^^^^^^^^ ",dialogScope);
				this.renderDijit.buildContent(dialogScope);

				if(this.templateDetail.getChildren().length > 0 
					|| this.templateDetail.domNode.innerHTML.length > 0){
					dojo.style(this.templateDetail.domNode, "display", "");
				}else{
					dojo.style(this.templateDetail.domNode, "display", "none");
				}
				
				dojo.style(this.contentArea, "height", "auto");
			});
			
			var templateName = this.templateId.get("value");
			
			if(templateName){
				this.adviceModel.retrieveAdviceTemplateDetail(_showFields, templateName, true);
			}
		},
		
		onSave: function(){
			
			console.log("this.workItemEditable: ", this.workItemEditable);
			var _controller = ControllerManager.bind(this.workItemEditable);
			
			try {
				var adviceGeneratedPropController = _controller.getPropertyController("WF_AdviceGenerated");
				if(adviceGeneratedPropController && adviceGeneratedPropController != null) {
					adviceGeneratedPropController.set("value", true);
					adviceGeneratedPropController.set("dirty", true);
				} else {
					console.log('WF_AdviceGenerated field is not exposed at this step.');
				}
			} catch(e){console.log('Exception occurred in DataPostAdviceDialog:', e);}
			
			this.hide();
			ControllerManager.unbind(this.workItemEditable);
		}
		
	});
});