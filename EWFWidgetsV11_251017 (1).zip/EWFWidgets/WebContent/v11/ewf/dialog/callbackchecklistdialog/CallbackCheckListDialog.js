define([ "dojo/_base/declare",
		 "dojo/_base/connect",
         "dojo/_base/lang",
         "dojo/_base/array",
		 "dojo/dom-class",
         "ecm/widget/dialog/BaseDialog",
		 "v11/ewf/util/Util",
         "dojo/text!./templates/CallbackCheckListDialog.html",
         "dojo/dom-construct",
         "idx/form/CheckBox",
		 "dojo/ready", 
		 "dijit/layout/BorderContainer",
		 "dijit/layout/ContentPane",
		 "dijit/layout/TabContainer",
		 "idx/html",
		 "idx/layout/TitlePane",
		 "dojo/dom"
       ], function(declare, connect, lang, baseArray, domClass, BaseDialog, Util, template, domConstruct, CheckBox, ready, BorderContainer, ContentPane, TabContainer,
		  idxHtml, TitlePane, dom){


	return declare("v11.ewf.dialog.callbackchecklistdialog.CallbackCheckListDialog", [BaseDialog], {
		
		contentString: template,
		
		title: "Callback Check List",
		
		parentCellForReasons: null,
		
		selectedOptions: "",
		
		createdWidgets: [],
		
		
		postCreate: function(){
			this.inherited(arguments);
			domClass.add(this.domNode, "ewfCallBackCheckListDialog");
			this.setResizable(true);
			this.createTemplate();
			this.setTitle(this.title);
			var submitButtonObj = {
				buttonLabel: "Submit",
				onExecute: this.onSubmitClick,
				disabled: this.readOnly,
				isDefault: false
			};
			this.setSize(850,550);
			this.submitButton = this.addButton(submitButtonObj.buttonLabel, submitButtonObj.onExecute, submitButtonObj.disabled, submitButtonObj.isDefault);

		},


	
		onSubmitClick: function(){
		var checkListController = this.editable[0]['propertiesCollection']['EWS_CallBackCheckList'];
		var arrSelectedOptions = []; 
		this.selectedOptions = this.selectedOptions.replace(/,\s*$/, "");  // To Remove the trailing comma(,) from the string.
		this.selectedOptions = this.selectedOptions.replace(/^,/, "");     // To Remove the leading comma(,) from the string.
		arrSelectedOptions = this.selectedOptions.split(',');
					
		checkListController['value'] = arrSelectedOptions;
		checkListController['dirty'] = true;

		this.destroy();
		},
		

		
		createTemplate: function(){
			var _this=this;
			var caseTypeConstant = null;
			if('icm.model.CaseEditable' === this.editable[0]['declaredClass']){
				this.readOnly = true;
				 caseTypeConstant = Util.getConstant("CallBackCheckList",this.editable[0]['propertiesCollection']['SolutionPrefix']['value'],this.editable[0]['caseType']['id']);
			//domConstruct.empty(this.contentArea);
			}else{
			 caseTypeConstant = Util.getConstant("CallBackCheckList",this.editable[0]['icmWorkItem']['_solutionPrefix'],this.editable[0]['icmWorkItem']['_caseTypeName']);
			}
			var value = this.editable[0]['propertiesCollection']['EWS_CallBackCheckList']['value'];
			_this.selectedOptions = value.toString();
			
			if(!Array.prototype.indexOf){
				Array.prototype.indexOf = function (elem, startFrom){
					var startFrom = startFrom || 0;
					if (startFrom > this.length) return -1;
					
					for(var i = 0; i < this.length; i++){
						if(this[i] == elem && startFrom <= i){
							return i;
						}else if(this[i] == elem && startFrom > i){
							return -1;
						}
					}
					return -1;
				}
			}
			
			if(_this.selectedOptions.match(',$')){
				
			 }else{
				_this.selectedOptions = _this.selectedOptions + ",";
			 }
			 
			var table = domConstruct.create("table"), tr, th, td;
			var sourceArray = caseTypeConstant.ipi;
			for(var j=0; j<sourceArray.length; j++){

				for(var k=0; k<sourceArray[j]['fields'].length; k++){
				
					tr = domConstruct.create("tr");
					if(k===0){
						var rowSpan	= sourceArray[j]['fields'].length;
						th = domConstruct.create('th', {'rowspan': rowSpan, 'style': "border: 1px solid #ccc;"});
						th.appendChild(domConstruct.toDom("<span><b>" + sourceArray[j].source + "</b></span>"));
						tr.appendChild(th);
					}
					
					
					td = domConstruct.create("td");
					var checkList, check = "";
					check = sourceArray[j]['fields'][k]['id'];
					if(value.indexOf(check) > -1)
						checkList = true;
					else 
						checkList = false;

					
					var checkBox = new CheckBox({
						label: sourceArray[j]['fields'][k]['label'],
						value: "k",
						readOnly: this.readOnly,
						checked: checkList,
						value_id: sourceArray[j]['fields'][k]['id'],
							onChange: function(isChecked){
								var currentValue = this.value_id;
								
								if(_this.selectedOptions.indexOf(",") > -1){
									if(_this.selectedOptions.indexOf(currentValue) < 0){
										if(isChecked){
											_this.selectedOptions = _this.selectedOptions + currentValue + ",";
										}
									} else{
										if(!isChecked){
											var replace_currentValue = currentValue + ",";
											_this.selectedOptions = _this.selectedOptions.replace(replace_currentValue, "");
										}
									}
								} else{
									if(isChecked){
										_this.selectedOptions = _this.selectedOptions +  currentValue + ",";
									} else{
										_this.selectedOptions = _this.selectedOptions + "";
										_this.selectedOptions = _this.selectedOptions.replace(currentValue, "");
									}
								}
							}
							
							
					});
					td.appendChild(checkBox.domNode);
					tr.appendChild(td);
					table.appendChild(tr);
				}
			}
			 
			var	pane1 = new idx.layout.TitlePane({
					title : "In-Pocket Information", 
					content : table
					});
					
				pane1.startup();




		var table_opi = domConstruct.create("table"), tr_opi, th_opi, td_opi;
			var sourceArray_opi = caseTypeConstant.opi;
			
			for(var j=0; j<sourceArray_opi.length; j++){
				for(var k=0; k<sourceArray_opi[j]['fields'].length; k++){
					tr_opi = domConstruct.create("tr");
					if(k===0){
						var rowSpan	= sourceArray_opi[j]['fields'].length;
						th_opi = domConstruct.create('th', {'rowspan': rowSpan, 'style': "border: 1px solid #ccc;"});
						th_opi.appendChild(domConstruct.toDom("<span><b>" + sourceArray_opi[j].source + "</b></span>"));
						tr_opi.appendChild(th_opi);
					}
					
					
					td_opi = domConstruct.create("td");
					
					var checkList, check = "";
					check = sourceArray_opi[j]['fields'][k]['id'];
					if(value.indexOf(check) > -1)
						checkList = true;
					else
						checkList = false;

					
					var checkBox = new CheckBox({
						label: sourceArray_opi[j]['fields'][k]['label'],
						value: "k",
						readOnly: this.readOnly,
						checked: checkList,
						value_id: sourceArray_opi[j]['fields'][k]['id'],
							onChange: function(isChecked){
								var currentValue = this.value_id;

								
								if(_this.selectedOptions.indexOf(",") > -1){
									if(_this.selectedOptions.indexOf(currentValue) < 0){
										if(isChecked){
											_this.selectedOptions = _this.selectedOptions + currentValue + ",";
										}
									} else{
										if(!isChecked){
											var replace_currentValue = currentValue + ",";
											_this.selectedOptions = _this.selectedOptions.replace(replace_currentValue, "");
										}
									}
								} else{
									if(isChecked){
										_this.selectedOptions = _this.selectedOptions + currentValue + ",";
									} else{
										_this.selectedOptions = _this.selectedOptions + "";
										_this.selectedOptions = _this.selectedOptions.replace(currentValue, "");
									}
								}
							}
							
							
					});
					td_opi.appendChild(checkBox.domNode);
					tr_opi.appendChild(td_opi);
					table_opi.appendChild(tr_opi);
				}

			}
				
			var	pane2 = new idx.layout.TitlePane({
					title : "Out-Pocket Information", 
					content : table_opi
					});		
				pane2.startup();

				this.contentText.appendChild(pane1.domNode);
				this.contentText.appendChild(pane2.domNode);
		}
	});
});